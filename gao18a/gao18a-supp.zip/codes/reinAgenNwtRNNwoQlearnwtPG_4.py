from __future__ import division
import tensorflow as tf
import numpy as np
import cifar10_simu as simu
import os

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

workers = ["10.138.0.8:2222",
           "10.138.0.9:2222",
           "10.138.0.10:2222",
           "10.138.0.12:2222",
           "10.138.0.12:2222"]

copy_num = 3

cluster = tf.train.ClusterSpec({"worker":workers})

server3 = tf.train.Server(cluster,
                          job_name='worker',
                          task_index=copy_num)

def imit(opsNum, plaOps):
    num_copies = 5

    phaseSignal1 = tf.Variable(tf.constant(0, shape = [], dtype = tf.int64), trainable = False)
    phaseSignal2 = tf.Variable(tf.constant(0, shape=[], dtype=tf.int64), trainable=False)
    phaseSignal3 = tf.Variable(tf.constant(0, shape=[], dtype=tf.int64), trainable=False)
    phaseSignal4 = tf.Variable(tf.constant(0, shape=[], dtype=tf.int64), trainable=False)
    phaseSignal5 = tf.Variable(tf.constant(0, shape=[], dtype=tf.int64), trainable=False)

    placementVec = tf.Variable(tf.constant(0, shape=[num_copies, opsNum], dtype=tf.int64), trainable=False)

    runtime0 = tf.Variable(tf.constant(0.0, shape=[], dtype=tf.float64), trainable=False)
    runtime1 = tf.Variable(tf.constant(0.0, shape=[], dtype=tf.float64), trainable=False)
    runtime2 = tf.Variable(tf.constant(0.0, shape=[], dtype=tf.float64), trainable=False)
    runtime3 = tf.Variable(tf.constant(0.0, shape=[], dtype=tf.float64), trainable=False)
    runtime4 = tf.Variable(tf.constant(0.0, shape=[], dtype=tf.float64), trainable=False)
    runtime5 = tf.Variable(tf.constant(0.0, shape=[], dtype=tf.float64), trainable=False)

    runtime = tf.placeholder(tf.float64, shape=[])

    feed_runtime3 = tf.assign(runtime3, runtime)

    disnable_signal3= tf.assign(phaseSignal3, 0)

    init = tf.global_variables_initializer()
    sess = tf.Session(target=server3.target)
    sess.run(init)

    while(True):
        while(sess.run(phaseSignal3) == 0):
            pass

        placement_np = sess.run(placementVec)

        runTime = simu.train(placement_np[copy_num].tolist(), plaOps)

        print("runTime: ", runTime)

        print("simu policy: ", placement_np[copy_num].tolist())

        sess.run(feed_runtime3, feed_dict = {runtime: runTime})

        sess.run(disnable_signal3)