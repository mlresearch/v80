# Copyright 2015 The TensorFlow Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

"""A binary to train CIFAR-10 using a single GPU.

Accuracy:
cifar10_train.py achieves ~86% accuracy after 100K steps (256 epochs of
data) as judged by cifar10_eval.py.

Speed: With batch_size 128.

System        | Step Time (sec/batch)  |     Accuracy
------------------------------------------------------------------
1 Tesla K20m  | 0.35-0.60              | ~86% at 60K steps  (5 hours)
1 Tesla K40m  | 0.25-0.35              | ~86% at 100K steps (4 hours)

Usage:
Please see the tutorial and website for how to download the CIFAR-10
data set, compile the program and train the model.

http://tensorflow.org/tutorials/deep_cnn/
"""
from __future__ import absolute_import
from __future__ import division

from datetime import datetime
import time

import reinAgenNwtRNNwoQlearnwtPPO as ra

from tensorflow.python.client import timeline

#import graAbstra as ga

import tensorflow as tf

#import heurisGen_Clus as hs_C
#import heurisGen as hs
#import heurisGen_HEFT as hs_H

import cifar10

import cifar10_simu as simu

parser = cifar10.parser

parser.add_argument('--train_dir', type=str, default='/tmp/cifar10_train',
                    help='Directory where to write event logs and checkpoint.')

parser.add_argument('--max_steps', type=int, default=100000,
                    help='Number of batches to run.')

parser.add_argument('--log_device_placement', type=bool, default=True,
                    help='Whether to log device placement.')

parser.add_argument('--log_frequency', type=int, default=100,
                    help='How often to log results to the console.')


def train():
  """Train CIFAR-10 for a number of steps."""
  totalTime = 0
  graph = tf.Graph()
  with graph.as_default():
    with tf.name_scope('globalStep/globalStep'):
      global_step = tf.contrib.framework.get_or_create_global_step()

    # Get images and labels for CIFAR-10.
    # Force input pipeline to CPU:0 to avoid operations sometimes ending up on
    # GPU and resulting in a slow down.
    beginTime_input = time.time()

    with tf.name_scope('input_ops/input_ops'):
      with tf.device('/cpu:0'):
        images, labels = cifar10.distorted_inputs()

    endTime_input = time.time()
    interval = endTime_input - beginTime_input
    totalTime = totalTime + interval

    # Build a Graph that computes the logits predictions from the
    # inference model.
    logits = cifar10.inference(images)

    # Calculate loss.
    loss = cifar10.loss(logits, labels)

    # Build a Graph that trains the model with one batch of examples and
    # updates the model parameters.
    train_op = cifar10.train(loss, global_step)

    class _LoggerHook(tf.train.SessionRunHook):
      """Logs loss and runtime."""

      def begin(self):
        self._step = -1
        self._start_time = time.time()

      def before_run(self, run_context):
        self._step += 1
        return tf.train.SessionRunArgs(loss)  # Asks for loss value.

      def after_run(self, run_context, run_values):
        if self._step % FLAGS.log_frequency == 0:
          current_time = time.time()
          duration = current_time - self._start_time
          self._start_time = current_time

          loss_value = run_values.results
          examples_per_sec = FLAGS.log_frequency * FLAGS.batch_size / duration
          sec_per_batch = float(duration / FLAGS.log_frequency)

          '''format_str = ('%s: step %d, loss = %.2f (%.1f examples/sec; %.3f '
                        'sec/batch)')
          print (format_str % (datetime.now(), self._step, loss_value,
                               examples_per_sec, sec_per_batch))'''

    abst_plaOps = []
    ops = graph.get_operations()
    actNum = 3

    #print("ops: ", ops)

    abst_plaOps = []
    for i in range(len(ops)):
      #print("name: ",ops[i].name)
      name = ops[i].name.split("/")
      abst_name = ""
      for j in range(len(name)):
        if j == 2:
          break
        abst_name = abst_name + name[j] + '/'
      if abst_name not in abst_plaOps:
        abst_plaOps.append(abst_name)

    print("abst: ", abst_plaOps)

    print(len(abst_plaOps))

    placement = ra.imit(len(abst_plaOps), abst_plaOps) # when RNN is used

    # performing placement for each operation:
    for i in range(len(ops)):
        name = ops[i].name.split("/")
        abst_name = ""
        for j in range(len(name)):
            if j == 2:
                break
            abst_name = abst_name + name[j] + '/'
        indx = abst_plaOps.index(abst_name)
        if placement[indx] != actNum - 1:
            ops[i]._set_device('/gpu:' + str(placement[indx]))
        else:
            ops[i]._set_device('/cpu:0')

    '''[nodeList, computeCost, matrixT] = ga.graAbstra('costModel.txt')

    nodeList = nodeList[0:299]

    for i in range(len(nodeList)):
        nodeList[i] = nodeList[i].split('"')[1]

    heuSet = []

    heuSet.append(
        hs_C.heurisGen(nodeList, computeCost, matrixT))
    print("placement1: ", heuSet[len(heuSet) - 1])

    print("node list: ", nodeList)

    counter = 0
    count = 0
    for ops in graph.get_operations():
        if counter < 200:
            print ("operation's name: ", ops.name)
            counter = counter + 1
        if ops.name in nodeList:
            count = count + 1
            pos = nodeList.index(ops.name)
            ops._set_device('/gpu:' + str(heuSet[0][pos]))
    print("how many ops been placed: ", count)

    placementCounter = 0
    for ops in graph.get_operations():
        if placementCounter % 4 == 0:
            ops._set_device('/GPU:0')
            placementCounter = placementCounter + 1
        elif placementCounter % 4 == 1:
            ops._set_device('/GPU:0')
            placementCounter = placementCounter + 1
        elif placementCounter % 4 == 2:
            ops._set_device('/GPU:0')
            placementCounter = placementCounter + 1
        else:
            ops._set_device('/GPU:0')
            placementCounter = placementCounter + 1'''

    '''run_options = tf.RunOptions(trace_level=tf.RunOptions.FULL_TRACE)
    run_metadata = tf.RunMetadata()
    ops = tf.GraphOptions(build_cost_model=1)'''

    beginTime = time.time()

    f = open('logs_cifar.txt', 'w+')

    #options = tf.RunOptions(trace_level=tf.RunOptions.FULL_TRACE)
    #run_metadata = tf.RunMetadata()

    step = 1

    with tf.train.MonitoredTrainingSession(
        checkpoint_dir=FLAGS.train_dir,
        hooks=[tf.train.StopAtStepHook(last_step=FLAGS.max_steps),
               tf.train.NanTensorHook(loss),
               _LoggerHook()],
        config=tf.ConfigProto(allow_soft_placement=True, log_device_placement=FLAGS.log_device_placement)) as mon_sess:
      while not mon_sess.should_stop():
        _, loss_train = mon_sess.run([train_op, loss])
        #_, loss_train = mon_sess.run([train_op, loss], options=options, run_metadata = run_metadata)
        print("train loss: ", loss_train)
        print >> f, "train loss: ", loss_train
        print ("time elapsed: ", float(time.time() - beginTime))
        print >> f, "time elapsed: ", float(time.time() - beginTime)
        print("steps left: ", FLAGS.max_steps - step)
        if (step == 2):
          beginTime4 = time.time()
        step = step + 1
    runtime = time.time() - beginTime4

    '''fetched_timeline = timeline.Timeline(run_metadata.step_stats)
    chrome_trace = fetched_timeline.generate_chrome_trace_format()
    with open('timeline.json', 'w') as f:
      f.write(chrome_trace)'''

    '''myfile = file("costModel.txt", 'w')
    print >> myfile, str(run_metadata.cost_graph)
    myfile.close()'''
    print ("totalTime ", totalTime)
    print("runtime: ", runtime)


def main(argv=None):  # pylint: disable=unused-argument
  cifar10.maybe_download_and_extract()
  if tf.gfile.Exists(FLAGS.train_dir):
    tf.gfile.DeleteRecursively(FLAGS.train_dir)
  tf.gfile.MakeDirs(FLAGS.train_dir)
  train()

if __name__ == '__main__':
  FLAGS = parser.parse_args()
  tf.app.run()
