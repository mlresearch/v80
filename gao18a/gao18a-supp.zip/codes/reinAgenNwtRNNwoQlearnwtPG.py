from __future__ import division
import tensorflow as tf
import math
import random
import numpy as np
import cifar10_simu as simu

import os
import time

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

# the recurrent neural network:
class neuSys():
    #constructor specifies the structure of the neural network:
    def __init__(self, inp_dim, oup_dim, steLen):
        self.inp_dim = inp_dim
        self.oup_dim = oup_dim
        self.steLen= steLen
        self.num_copies = 5
        self.batSize = 2 * self.num_copies
        self.hidUni = 256
        self.encoder_layers = 2
        self.decoder_layers = 2
        self.gamma = 1
        self.beta = 0.01
        self.graph = tf.Graph()
        with self.graph.as_default():
            with tf.device('/gpu:0'):
                # examples including input, output and reward:
                self.x = tf.placeholder(tf.float32, shape=[self.batSize, steLen, inp_dim])
                self.y = tf.placeholder(tf.float32, shape=[self.batSize, steLen, oup_dim])
                self.z = tf.placeholder(tf.float32, shape=[self.batSize, steLen, oup_dim])

                fake_output = tf.constant(0, shape=[self.batSize, steLen, oup_dim], dtype = tf.float32)

                self.enc_cells = []
                for _ in range(self.encoder_layers):
                    self.enc_cell = tf.contrib.rnn.LSTMCell(num_units=self.hidUni)
                    self.enc_cells.append(self.enc_cell)
                self.enc_cell = tf.contrib.rnn.MultiRNNCell(self.enc_cells)
                #self.cell = tf.contrib.rnn.LSTMCell(num_units=self.hidUni)
                self.encoder_outputs, self.encoder_final_state = tf.nn.dynamic_rnn(self.enc_cell, self.x, dtype=tf.float32)

                self.dec_cells = []
                for _ in range(self.decoder_layers):
                    self.dec_cell = tf.contrib.rnn.LSTMCell(num_units=self.hidUni)
                    self.dec_cells.append(self.dec_cell)

                attn_cell = self.dec_cells.pop(0)

                attention_mechanism = tf.contrib.seq2seq.BahdanauAttention(num_units=self.hidUni, memory=self.encoder_outputs, memory_sequence_length= [self.steLen] * self.batSize)
                attn_cell = tf.contrib.seq2seq.AttentionWrapper(attn_cell, attention_mechanism, attention_layer_size=self.hidUni)
                out_cell = tf.contrib.rnn.OutputProjectionWrapper(attn_cell, self.oup_dim, reuse=None)

                self.decoder_outputs, decoder_final_state = tf.nn.dynamic_rnn(out_cell, fake_output, initial_state=out_cell.zero_state(dtype=tf.float32, batch_size=self.batSize), dtype=tf.float32, time_major=False, scope="plain_decoder")

                self.prob = tf.nn.softmax(self.decoder_outputs)

                self.prob_log = tf.log(tf.abs(self.prob))

                self.Entropy = - self.prob * tf.log(self.prob)

                self.loss = - tf.reduce_mean((self.prob_log * self.y) * self.z + self.beta * self.Entropy)

                self.tri = tf.train.AdamOptimizer(1e-4).minimize(self.loss)

            init = tf.initialize_all_variables()

            self.sess = tf.Session(config = tf.ConfigProto(allow_soft_placement=True, log_device_placement=True), graph=self.graph)

            self.sess.run(init)

    def showSta(self, x, y, z):
        return self.sess.run([self.prob, self.prob_old], feed_dict={self.x: x, self.y: y, self.z: z})

    def pred(self, x):
        return self.sess.run(self.prob, feed_dict={self.x: x})

    def updtHype(self, playCount):
        #dropPeriod = 200
        #dropRate = 0.8
        #epsl_init = 0.1
        self.beta = self.beta - self.batSize * 0.1 / 30000

    def update(self, x, y, z):
        for i in range(1):
            self.sess.run(self.tri, feed_dict={self.x: x, self.y: y, self.z: z})

workers = ["10.138.0.8:2222",
           "10.138.0.9:2222",
           "10.138.0.10:2222",
           "10.138.0.12:2222",
           "10.138.0.12:2222"]

copy_num = 0

cluster = tf.train.ClusterSpec({"worker":workers})

server0 = tf.train.Server(cluster,
                          job_name='worker',
                          task_index=copy_num)

def imit(opsNum, plaOps):
    f = open('logs_RNN.txt', 'w+')
    chamPol = []
    totalPlay = 0
    totalRuntime = 0
    totalReward = 0
    actNum = 3
    minRunTime = 10000
    playNum = 20000
    playCount = 1
    movAvg_init = 0
    movAReward = 0
    alpha = 0.98
    encInp_bat = []
    action_bat = []
    r_bat = []
    beginTime = time.time()
    num_copies = 5
    batSize = 2 * num_copies

    for i in range(5):
        print("single GPU's performance: ")
        state = [0] * 4
        state.extend([4])
        state.extend([0] * (len(plaOps) - 5))
        runTime = simu.train(state, plaOps)
        print("simu policy: ", state)
        print >> f, "simu policy: ", state
        print("run time: ", runTime)
        print >> f, "run time: ", runTime

    encInp = []
    for i in range(len(plaOps)):
        # type vector
        typ = [0] * len(plaOps)
        typ[i] = 1

        encInp.append(typ)

    neu =  neuSys(len(encInp), actNum, len(encInp))

    state_vector = tf.placeholder(tf.int64, shape=[num_copies, opsNum])
    runtime = tf.placeholder(tf.float64, shape=[])

    phaseSignal1 = tf.Variable(tf.constant(0, shape = [], dtype = tf.int64), trainable = False)
    phaseSignal2 = tf.Variable(tf.constant(0, shape=[], dtype=tf.int64), trainable=False)
    phaseSignal3 = tf.Variable(tf.constant(0, shape=[], dtype=tf.int64), trainable=False)
    phaseSignal4 = tf.Variable(tf.constant(0, shape=[], dtype=tf.int64), trainable=False)
    phaseSignal5 = tf.Variable(tf.constant(0, shape=[], dtype=tf.int64), trainable=False)

    placementVec = tf.Variable(tf.constant(0, shape=[num_copies, opsNum], dtype=tf.int64), trainable=False)

    runtime0 = tf.Variable(tf.constant(0.0, shape=[], dtype=tf.float64), trainable=False)
    runtime1 = tf.Variable(tf.constant(0.0, shape=[], dtype=tf.float64), trainable=False)
    runtime2 = tf.Variable(tf.constant(0.0, shape=[], dtype=tf.float64), trainable=False)
    runtime3 = tf.Variable(tf.constant(0.0, shape=[], dtype=tf.float64), trainable=False)
    runtime4 = tf.Variable(tf.constant(0.0, shape=[], dtype=tf.float64), trainable=False)
    runtime5 = tf.Variable(tf.constant(0.0, shape=[], dtype=tf.float64), trainable=False)

    placementVec = tf.assign(placementVec, state_vector)

    feed_runtime0 = tf.assign(runtime0, runtime)

    # notifying all copies to fetch the placement:
    enable_signal1 = tf.assign(phaseSignal1, 1)
    enable_signal2 = tf.assign(phaseSignal2, 1)
    enable_signal3 = tf.assign(phaseSignal3, 1)
    enable_signal4= tf.assign(phaseSignal4, 1)
    #enable_signal5 = tf.assign(phaseSignal5, 1)

    init = tf.global_variables_initializer()
    sess = tf.Session(target=server0.target)
    sess.run(init)

    while (playCount < playNum):
        state_vec = []
        action_vec = []
        for k in range(num_copies):
            state = []
            action = []
            if (k == 0):
                placement = neu.pred(np.array([encInp]*batSize))
                placement = placement[0]
            for i in range(len(placement)):
                prePol = placement[i].tolist()
                # using sampling based action
                cdf = [prePol[0]]
                act_oneHot = [0] * actNum
                # sampling the policy network to generate an action:
                for j in range(1, len(prePol)):
                    cdf.append(cdf[j - 1] + prePol[j])
                cdf[actNum - 1] = 1
                b = random.random()
                for j in range(0, len(cdf)):
                    if b < cdf[j]:
                        place = j
                        break
                act_oneHot[place] = 1
                state.append(place)
                action.append(act_oneHot)
            state_vec.append(state)
            action_vec.append(action)

        placement_np = sess.run(placementVec, feed_dict = {state_vector: np.array(state_vec)})

        sess.run(enable_signal1)
        sess.run(enable_signal2)
        sess.run(enable_signal3)
        sess.run(enable_signal4)
        #sess.run(enable_signal5)

        runTime = simu.train(placement_np[copy_num].tolist(), plaOps)

        sess.run(feed_runtime0, feed_dict = {runtime: runTime})

        #print("simu policy: ", placement_np[copy_num].tolist())
        print >> f, "simu policy: ", placement_np[copy_num].tolist()

        while(sess.run(phaseSignal1) == 1 and sess.run(phaseSignal2) == 1 and sess.run(phaseSignal3) == 1 and sess.run(phaseSignal4) == 1):
            pass
            #print("waiting runtime responses...")

        runtimeRecord = []
        runtimeRecord.append(sess.run(runtime0))
        runtimeRecord.append(sess.run(runtime1))
        runtimeRecord.append(sess.run(runtime2))
        runtimeRecord.append(sess.run(runtime3))
        runtimeRecord.append(sess.run(runtime4))

        for i in range(len(runtimeRecord)):
            if (runtimeRecord[i] < minRunTime):
                chamPol = [col for col in state]
                print("current best policy: ", chamPol)
                print >> f, "current best policy: ", chamPol
                minRunTime = runtimeRecord[i]
            totalPlay = totalPlay + 1
            totalRuntime = totalRuntime + runtimeRecord[i]
            avgRuntime = totalRuntime / totalPlay
            movAvg_init = alpha * movAvg_init + (1 - alpha) * runtimeRecord[i]
            movAvg = movAvg_init/(1 - alpha ** playCount)
            r = avgRuntime - runtimeRecord[i]
            totalReward = totalReward + r
            movAReward = alpha * movAReward + (1 - alpha) * r

            print("########## A new sample ##########")
            print("run time: ", runtimeRecord[i])
            print >> f, "run time: ",runtimeRecord[i]
            print("current min runtime: ", minRunTime)
            print >> f, "current min runtime: ", minRunTime
            print("current avg runtime: ", avgRuntime)
            print >> f, "current avg runtime: ", avgRuntime
            print("current moving avg: ", movAvg)
            print >> f, "current moving avg: ", movAvg
            print("time elapsed: ", float(time.time() - beginTime))
            print >> f, "time elapsed: ", float(time.time() - beginTime)
            print("current total reward: ", totalReward)
            print >> f, "current total reward: ", totalReward

            encInp_bat.append(encInp)
            action_bat.append(action)
            r_bat.append([[10 * r]*actNum]*opsNum)

        if (len(encInp_bat) == 2 * num_copies):
            neu.update(np.array(encInp_bat), np.array(action_bat), np.array(r_bat))
            #neu.updtHype(playCount)
            #prob, prob_old = neu.showSta(np.array(encInp_bat), np.array(action_bat), np.array(r_bat))
            encInp_bat = []
            action_bat = []
            r_bat = []
            #print("prob: ", prob)

        playCount = playCount + num_copies
        print("play count: ", playCount)
        print >> f, "play count: ", playCount

    print("using chamPol: ", chamPol)
    print >> f, "using chamPol: ", chamPol

    return chamPol