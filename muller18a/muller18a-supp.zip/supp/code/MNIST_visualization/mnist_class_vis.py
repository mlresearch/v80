""" 
written by Lorenz K Muller, 2017
"""

from __future__ import print_function

# Import MNIST data
from tensorflow.examples.tutorials.mnist import input_data
mnist = input_data.read_data_sets("/tmp/data/", one_hot=True)

import sys
import tensorflow as tf
import numpy as np
from time import time


seed = int(time())
np.random.seed(seed)

###################
# Hyper-Parameters#
###################

num_steps = 2000 #20000 #8000 was used for the autoencoder setting in the paper
batch_size = 1024
display_step = 200
global_step = tf.Variable(0, trainable=False)
#vary the number units for quicker (but worse) embeddings
n_hidden = 2000 
n_embed = 40 #sqrt of number of neurons in embedding layer
n_inp = 50 #sqrt of number of neuons projecting into the embedding layer
num_input = 784 
num_classes = 10 
n_dims = 2
#commandline options
classification = int(sys.argv[1]) if len(sys.argv) > 1 else 0
 #classifcation or autoencoder setting
kernel = sys.argv[2] if len(sys.argv) > 2 else 'RBF'
 #what kind of kernel to use (e.g. RBF or tdist)


learning_rate_init = 0.0001 if classification else 0.0003 #0.0001
learning_rate = tf.train.exponential_decay(learning_rate_init, global_step,
                                           1000, 0.9, staircase=True)

###############
#Create inputs#
###############
X = tf.placeholder("float", [None, num_input])
Y = tf.placeholder("float", [None, num_classes])
keep = tf.placeholder("float")
Stim = tf.placeholder("float", [None, n_embed**2])



################
#Define helpers#
################
def make_stimulus(loc,scale=1.0):
    '''
    create artificial input to the decoder to
    visualize low-dim latent space after training.
    '''
    c = getGrid(n_embed,2)
    diff = c[:,None,:] - loc[:,:,None] #dims, locs, inps
    n = np.linalg.norm(diff,ord=2,axis=0)
    r = np.exp(-(n*scale)**2) #loc, inp
    r = level_shift_np(r)
    r /= r.mean(1,keepdims=True) + 1e-5
    print(r.shape)
    return r #locs,inps

def get_weight(u,v,alpha,kernel='dot'):
    '''
    computes the kernel response 
    '''
    if kernel == 'RBF':
        d = u  - v
        d *= tf.Variable(.001)
        dist = tf.reduce_sum(d**2,0) 
        return tf.exp(- dist)* tf.expand_dims(alpha,1)
    elif kernel == 'tdist':
        d = u  - v
        d *= tf.Variable(.01)
        dist = tf.reduce_sum(d**2,0) 
        return 1.0/(1.0+dist)* tf.expand_dims(alpha,1)
    elif kernel == 'dot':
        return tf.reduce_sum(u*v,0)* tf.expand_dims(alpha,1)
    elif kernel == 'poly':
        return tf.reduce_sum((1.+u*v)**2,0)* tf.expand_dims(alpha,1)


def getGrid(n=28,ndim=2):
    '''
    constructs an ndim dimensional grid with n points on each axis
    '''
    v = np.zeros((ndim,n**ndim))
    grid = np.meshgrid(*[np.linspace(-1.0,1.0,n) for i in range(ndim)])
    for j,g in enumerate(grid):
            v[j] = g.flatten()
    return v.astype('float32')

def level_shift(x):
    '''
    activation function for embedding layer
    '''
    alpha = 0.95
    shift = (1-alpha)*tf.reduce_mean(x,1) + alpha*tf.reduce_max(x,1)
    shifted = tf.maximum(x - tf.expand_dims(shift,1), 0.0)
    return shifted

def level_shift_np(x):
    '''
    activation funciton in numpy for creation of 
    artificial inputs to decoder
    '''
    alpha = 0.95
    shift = (1-alpha)*x.mean(1,keepdims=True) + alpha*x.max(1,keepdims=True)
    return np.maximum(x - shift, 0.0)

def selu(x, l=1.050701, a=1.673263):
    '''
    selu activation function (self-normalizing)
    '''
    return tf.nn.selu(x)#l* tf.where(x<0, a*(tf.exp(a*x)-1.0),x)

def encoder(x, kernel='RBF'):
    '''
    constructs the encoder part of the network
    returns the latent space activity as well as the kernel centers of inputs and outputs
    '''
    W1 = tf.get_variable("W1",shape=[num_input,n_hidden], 
                         initializer=tf.contrib.layers.xavier_initializer())
    b1 = tf.get_variable("b1",shape=[n_hidden],initializer=tf.zeros_initializer())
    layer_1 = selu(tf.matmul(tf.layers.batch_normalization(x), W1) + b1)

    W1b =  tf.get_variable("W1b",shape=[n_hidden, n_hidden],
                           initializer=tf.contrib.layers.xavier_initializer())
    b1b = tf.get_variable("b1b",shape=[n_hidden],initializer=tf.zeros_initializer())
    layer_1b = selu(tf.matmul(layer_1, W1b) + b1b)

    W2 =  tf.get_variable("W2",shape=[n_hidden, n_inp**2],
                          initializer=tf.contrib.layers.xavier_initializer())
    b2 = tf.get_variable("b2",shape=[n_inp**2],initializer=tf.zeros_initializer())
    layer_2 = tf.nn.dropout(tf.nn.relu(tf.matmul(layer_1b, W2) + b2),keep)

    v = tf.expand_dims(getGrid(n_embed,2),1)#tf.Variable(tf.random_uniform([2,1,n_embed**2],-1,1))
    u = tf.Variable(tf.random_uniform([2,n_inp**2,1],-1,1))

    alpha = tf.abs(tf.Variable(1.*tf.random_normal([n_inp**2])))
    W3 = get_weight(u, v,alpha,kernel=kernel)
    layer_3 = level_shift(tf.matmul(layer_2,W3))

    #normalize activity in embedding layer
    #prevents that the sum of activity becomes a 3rd 'latent dimension'
    layer_3 /= tf.expand_dims(tf.reduce_mean(layer_3,1),1) + 1e-5
    return layer_3,v,u

def decoder(x,kernel='RBF', classification=True):
    '''
    constructs the decoder part of the network
    '''
    W4 = tf.get_variable("W4",shape=[n_embed**2, n_hidden], 
                         initializer=tf.contrib.layers.xavier_initializer())
    b4 = tf.get_variable("b4",shape=[n_hidden],initializer=tf.zeros_initializer())
    layer_4 = selu(tf.matmul(x*tf.Variable(0.03), W4) )#+ b4)

    W5 =  tf.get_variable("W5",shape=[n_hidden,n_hidden],
                          initializer=tf.contrib.layers.xavier_initializer())
    b5 = tf.get_variable("b5",shape=[n_hidden],initializer=tf.zeros_initializer())
    layer_5 = selu(tf.matmul(layer_4, W5) )#+ b5)

    num_out = num_classes if classification else num_input
    W6 = tf.get_variable("W6",shape=[n_hidden, num_out], 
                         initializer=tf.contrib.layers.xavier_initializer())
    b6 = tf.get_variable("b6",shape=[num_out],initializer=tf.zeros_initializer())
    out_layer = tf.matmul(layer_5, W6) #+ b6
    return out_layer

def neural_net(x, kernel='RBF', classification=True):
    '''
    creates the network 
    returns the prediction, latent space activity, and kernel centers
    '''
    embedding,v,u = encoder(x,kernel=kernel)
    out_layer = decoder(embedding,kernel=kernel,classification=classification)
    return out_layer, embedding, v, u


##################
# Construct model#
##################

with tf.variable_scope("all") as scope:
    logits, embedding, v, u = neural_net(X,kernel=kernel,classification=classification)
    prediction = tf.nn.softmax(logits) if classification else tf.nn.sigmoid(logits)

    # Define loss and optimizer
    costfn = tf.nn.softmax_cross_entropy_with_logits if classification else tf.nn.sigmoid_cross_entropy_with_logits
    targets = Y if classification else X
    loss_op = tf.reduce_mean(costfn(logits=logits, labels=targets))

    correct_pred = tf.equal(tf.argmax(prediction, 1), tf.argmax(targets, 1))
    accuracy = tf.reduce_mean(tf.cast(correct_pred, tf.float32))

    optimizer = tf.train.RMSPropOptimizer(learning_rate=learning_rate)#, beta1=0.2,beta2=0.5)
    train_op = optimizer.minimize(loss_op,global_step=global_step)

    scope.reuse_variables()
    decode_op = tf.nn.sigmoid(decoder(Stim,kernel=kernel,classification=classification))

    # Initialize the variables (i.e. assign their default value)
    init = tf.global_variables_initializer()

    
#################    
# Start training#
#################

with tf.Session() as sess:
    sess.run(init)

    print("training a " + str(n_dims) + "-KNN with " + kernel + " Kernel.") 
    for step in range(1, num_steps+1):
        batch_x, batch_y = mnist.train.next_batch(batch_size)
        sess.run(train_op, feed_dict={X: batch_x, Y: batch_y,keep:0.5})
        if step % display_step == 0 or step == 1:
            feed = {X:batch_x,Y:batch_y,keep:0.5} if classification else {X:batch_x,keep:0.5}
            loss, acc = sess.run([loss_op, accuracy], feed_dict=feed)
            print("Step " + str(step) + ", Minibatch Loss= " + \
                  "{:.4f}".format(loss)) #+ ", Training Accuracy= " + \
                  #"{:.3f}".format(acc))

    test_acc = sess.run(accuracy, feed_dict={X: mnist.test.images,
                                             Y: mnist.test.labels,
                                             keep: 1.0})
    if classification:
        print("Testing Accuracy:", test_acc)

    feed = {X:mnist.test.images,Y:mnist.test.labels,keep:1.0} if classification else {X:mnist.test.images,keep:1.0}
    test_err,test_embed,reconstruct = sess.run([loss_op, embedding, prediction], feed_dict=feed)

    encoded = sess.run(embedding, feed_dict={X: mnist.test.images,keep:1.})

    stimulus = make_stimulus(getGrid(100,2))
    decoded = sess.run(decode_op, feed_dict={Stim: stimulus,keep:1.})

    #retrieve v and u to compute center of mass
    cv = v.eval()
    cu = u.eval()

##############   
#create plots#
##############

from plotting import imscatter, getCM, tilePlot
import matplotlib.pyplot as plt

if not classification:
    plt.imshow(tilePlot(decoded),cmap='Greys',interpolation='None')
    #plt.savefig('embedding_space_2.pdf', dpi=400)

plt.figure(figsize=(12,6))

#uncomment to plot u and v
#plt.figure()
#ax1 = plt.subplot(111)
#ax1.scatter(cv[0],cv[1],marker='+',c='red')
#ax1.scatter(cu[0],cu[1],marker='x',c='blue')
cmapl = [(0,0,1),(1,0,0),(0,1,0),(0,0.5,0.5),(0,0,0),(0.5,0,0.5),(1,0.5,0.5),(0,1,1),(1,0,1),(0.4,0.2,0.8)]

ax2 = plt.subplot(121)
x,y = getCM(test_embed, cv)
for i in xrange(x.shape[0]):
    ax2.scatter(y[i], -x[i], c=cmapl[int(np.argmax(mnist.test.labels[i]))],alpha=1.0,s=8,edgecolors='none')

n=4000
ax = plt.subplot(122)
imscatter(y[:n], -x[:n], mnist.test.images[:n].reshape(-1,28,28), cat = np.argmax(mnist.test.labels[:n],1), zoom=1.0, ax=ax)
#plt.savefig('embedding.pdf', dpi=400)
plt.show()


