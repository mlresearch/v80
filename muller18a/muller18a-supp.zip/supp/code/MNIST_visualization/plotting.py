import numpy as np
import matplotlib.pyplot as plt
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
from matplotlib.cbook import get_sample_data
from matplotlib.colors import LinearSegmentedColormap


def imscatter(x, y, image, cat=None, ax=None, zoom=1):
    '''
    creates a scatter plot in which points are images
    '''
    cmapl = [(0,0,1),(1,0,0),(0,1,0),(0,0.5,0.5),(0,0,0),(0.5,0,0.5),(1,0.5,0.5),(0,1,1),(1,0,1),(0.4,0.2,0.8)]
    if ax is None:
        ax = plt.gca()
    x, y = np.atleast_1d(x, y)
    artists = []
    ind = 0
    for x0, y0, i0 in zip(x, y, image):
        cmap = LinearSegmentedColormap.from_list('mycmap', [(1,1,1), cmapl[cat[ind]]])
        cmap.set_under('k',alpha=0)
        im = OffsetImage(i0, zoom=zoom, cmap=cmap, clim=[0.5,1], alpha=0.5)
        #im = OffsetImage(i0, zoom=zoom, clim=[0.5,1], alpha=0.5)
        ab = AnnotationBbox(im, (x0, y0), xycoords='data', frameon=False)
        artists.append(ax.add_artist(ab))
        ind += 1
    ax.update_datalim(np.column_stack([x, y]))
    ax.autoscale()
    return artists


def getCM_grid(embed, nunits=20):
    '''
    computes the 'center of mass' of the embedding
    assuming ouput units lying on a grid
    '''
    e = embed.reshape(-1,nunits,nunits)
    #e = np.clip(e,0,1e12)
    cm = np.zeros((e.shape[0],2))
    mtot = e.sum((1,2))
    ind = np.arange(nunits)
    cm[:,0] = (ind[None,:,None]*e).sum((1,2))
    cm[:,1] = (ind[None,None,:]*e).sum((1,2))
    return cm / (mtot[:,None] + 1e-12)

def getCM(embed, ch):
    '''
    computes the 'center of mass' of the embedding
    '''
    x = (ch[0,:]*embed).sum(1)/embed.sum(1)
    y = (ch[1,:]*embed).sum(1)/embed.sum(1)
    return x,y


def tilePlot(w, l=28,dim=2,normalize=False,color=False):
    side = int(np.sqrt( w.shape[0] ))

    if color:
        w1 = tilePlot(w[:,0],l=l, dim=dim,normalize=normalize)
        w2 = tilePlot(w[:,1],l=l, dim=dim,normalize=normalize)
        w3 = tilePlot(w[:,2],l=l, dim=dim,normalize=normalize)
        allw = np.zeros((w1.shape[0],w1.shape[1],3))
        allw[:,:,0] = w1
        allw[:,:,1] = w2
        allw[:,:,2] = w3
        return allw

    allw = np.ones( (side*(l+1)+1, side*(l+1)+1))*w.max()
    for i in range(w.shape[0]):
        if dim==1:
            tw = np.zeros((l,l))
            for j in range(l):
                tw[j] = w[i]
        elif dim==2:
            tw = w[i].reshape((l,l))
        if normalize:
            tw = tw/tw.max()
            tw = (tw - tw.min()) / (tw.max() - tw.min())
        xi = i%side
        yi = i/side
        xb = xi*(l+1)
        yb = yi*(l+1)
        if tw.shape == allw[xb:xb+l, yb:yb+l].shape:
            allw[xb+1:xb+l+1, yb+1:yb+l+1] = tw
    return allw#plt.imshow(allw, cmap='Greys')
