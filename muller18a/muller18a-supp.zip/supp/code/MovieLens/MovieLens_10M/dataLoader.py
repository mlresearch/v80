'''
written by Lorenz K. Muller (lorenz@ini.ethz.ch), 11.12.2017
'''

import numpy as np
import tensorflow as tf
from time import time

def loadData(path='./', valfrac=0.1, delimiter='::',seed=1234,
             transpose=False, storeDenseMatrix=False, indicator_rating=False):
    '''
    takes path to dataset, fraction of data to be used for validation 
    and a delimiter for splitting the data into columns
    returns a num_users x num_items training matrix 
    and a binary matrix indicating non-zero entries of that training matrix
    as well as a corresponding validation matrices
    '''
    np.random.seed(seed)
    tic = time()
    print 'reading data...'
    data = np.loadtxt(path, skiprows=0, delimiter=delimiter).astype('int32')
    #data = np.loadtxt(path, skiprows=0, delimiter=delimiter,dtype='int32').astype('int32')
    print 'data read in', time() - tic, 'seconds'
    n_u = np.unique(data[:,0]).shape[0]#
    n_m = np.unique(data[:,1]).shape[0]#
    n_r = data.shape[0] #number of ratings
    n_rt = np.unique(data[:,2]).shape[0]
        
    udict = {}
    for i,u in enumerate(np.unique(data[:,0]).tolist()):
        udict[u] = i
    mdict = {}
    for i,m in enumerate(np.unique(data[:,1]).tolist()):
        mdict[m] = i
    rtdict = {}
    for i,rt in enumerate(np.unique(data[:,2]).tolist()):
        rtdict[rt] = i

    print n_u, n_m, n_rt
    print rtdict
    #exit()

    idx = np.arange(n_r)
    np.random.shuffle(idx)

    if indicator_rating:
        trainRatings = np.zeros((n_u, n_m, n_rt))
        validRatings = np.zeros((n_u, n_m, n_rt))
        
        for i in xrange(n_r):
            u_id = data[idx[i],0]
            m_id = data[idx[i],1]
            rt_id = data[idx[i],2]
            if i <= valfrac*n_r:
                validRatings[udict[u_id], mdict[m_id], rtdict[rt_id]] = 1.0
            else:
                trainRatings[udict[u_id], mdict[m_id], rtdict[rt_id]] = 1.0
    else:
        trainRatings = np.zeros((n_u, n_m),dtype='float32')
        validRatings = np.zeros((n_u, n_m))

        for i in xrange(n_r):
            u_id = data[idx[i],0]# -1
            m_id = data[idx[i],1]# -1
            r = data[idx[i],2]
            if i <= valfrac*n_r:
                validRatings[udict[u_id], mdict[m_id]] = int(r)
            else:
                trainRatings[udict[u_id], mdict[m_id]] = int(r)

    if transpose:
        order = (1,0,2) if indicator_rating else (1,0)
        trainRatings = np.transpose(trainRatings, order)#trainRatings.T
        validRatings = np.transpose(validRatings, order)#validRatings.T

    trainMask = np.greater(trainRatings, 1e-12)
    validMask = np.greater(validRatings, 1e-12)

    print 'loaded dense data matrix'

    if storeDenseMatrix:
        np.save('trainRatings', trainRatings if (not transpose) else trainRatings.T)
        np.save('validRatings', validRatings if (not transpose) else validRatings.T)

    return trainRatings, trainMask, validRatings, validMask


def loadDense(path, transpose=False):
    trainRatings = np.load(path+'trainRatings.npy')
    validRatings = np.load(path+'validRatings.npy')
    if transpose:
        trainRatings = trainRatings.T
        validRatings = validRatings.T
    trainMask = np.greater(trainRatings, 1e-12)
    validMaks = np.greater(validRatings, 1e-12)
    return trainRatings, trainMask, validRatings, validMask


def loadSparseData(path='./', valfrac=0.1, delimiter='::',seed=1234,
             transpose=False, storeDenseMatrix=False):
    '''
    takes path to dataset, fraction of data to be used for validation 
    and a delimiter for splitting the data into columns
    returns a num_users x num_items training matrix 
    and a binary matrix indicating non-zero entries of that training matrix
    as well as a corresponding validation matrices
    '''
    np.random.seed(seed)
    tic = time()
    print 'reading data...'
    #data = np.loadtxt(path+'ratings.dat', skiprows=0, delimiter=delimiter).astype('int32')
    data = np.loadtxt(path, skiprows=0, delimiter=delimiter,dtype='float32').astype('float32')
    print 'data read in', time() - tic, 'seconds'
    tic = time()

    unique_users = np.unique(data[:,0])
    unique_movies = np.unique(data[:,1])
    print unique_users
    print unique_movies

    n_u = unique_users.shape[0]
    n_m = unique_movies.shape[0]
    print 'num users:', n_u
    print 'num movies:', n_m

    n_r = data.shape[0] #number of ratings
    
    udict = {}
    for i,u in enumerate(unique_users.tolist()):
        udict[u] = i
    mdict = {}
    for i,m in enumerate(unique_movies.tolist()):
        mdict[m] = i

    print n_u, n_m

    idx = np.arange(n_r)
    np.random.shuffle(idx)

    train_user_list = []
    train_movie_list = []
    train_rating_list = []
    valid_user_list = []
    valid_movie_list = []
    valid_rating_list = []

    for i in xrange(n_r):
        u_id = udict[data[idx[i],0]]
        m_id = mdict[data[idx[i],1]]        
        r = data[idx[i],2]
        if i <= valfrac*n_r:
            valid_user_list.append(int(u_id))
            valid_movie_list.append(int(m_id))
            valid_rating_list.append(r)
        else:
            train_user_list.append(int(u_id))
            train_movie_list.append(int(m_id))
            train_rating_list.append(r)

    print 'data rearranged in', time() - tic, 'seconds'
    return np.asarray(train_user_list), np.asarray(train_movie_list), np.asarray(train_rating_list), np.asarray(valid_user_list), np.asarray(valid_movie_list), np.asarray(valid_rating_list), n_u, n_m
    
