'''
written by Lorenz K. Muller (lorenz@ini.ethz.ch), Apr. 2018
'''

import numpy as np
import tensorflow as tf
from time import time
import sys
import os
from subprocess import call
seed = int(time())
np.random.seed(seed)
tf.set_random_seed(seed)

from dataLoader import loadData, loadSparseData

#################
#Hyperparameters#
#################
wreg = float(sys.argv[1]) if len(sys.argv) > 1 else 50.
breg = float(sys.argv[2]) if len(sys.argv) > 2 else 0.
sreg = float(sys.argv[3]) if len(sys.argv) > 3 else .005
maxiter = int(sys.argv[4]) if len(sys.argv) > 4 else 2000
n_hid = 500
n_dim = 5


###########
#Load data#
###########
tul, tml, trl, vul, vml, vrl, n_u, n_m = loadSparseData('./data/ml-10m/ratings.dat',seed=seed, valfrac=0.1)

#choose between item- and user-based
transpose = False #(item based if false)
if not transpose:
    tind = np.vstack([tml.T,tul.T]).T
    vind = np.vstack([vml.T,vul.T]).T
else:
    #note: naming is potentially confusing in this case
    #as n_u is the number of movies...
    tind = np.vstack([tul.T,tml.T]).T
    vind = np.vstack([vul.T,vml.T]).T
    [n_u, n_m] = [n_m, n_u]

#define function to split data into batches
batch_size = n_m/32
#we always use the gradients of accumulated over all samples to make a parameter update
#the batch_size merely determines the gradients for how many samples are computed
#in parallel

def makeBatches(inds, rats, batch_size=100):
    nbatch = n_m/batch_size +1
    batches_i = []
    batches_r = []
    for i in xrange(nbatch):
        mask = (inds[:,0] >= i*batch_size) * (inds[:,0] < (i+1)*batch_size)
        these_inds = inds[mask]
        offset = np.zeros_like(these_inds)
        offset[:,0] = i*batch_size
        batches_i.append(these_inds - offset)
        batches_r.append(rats[mask])
    return batches_i, batches_r

##############
#Define model#
##############
#placeholders
xvals = tf.placeholder(tf.float32)
xind = tf.placeholder(tf.int64)
xshape = tf.placeholder(tf.int64)

yvals = tf.placeholder(tf.float32)
yind = tf.placeholder(tf.int64)
yshape = xshape

#inputs are defined as sparse tensors
x = tf.SparseTensor(xind,xvals,xshape) #given ratings
y = tf.SparseTensor(yind,yvals,yshape) #ratings to predict

#define the sparsifying kernel function
def hatRBF(u,v):
    diff = u - v
    dist = tf.reduce_sum(diff**2, 0)

    dist1m = 1 - tf.sqrt(dist)
    #dist1m = 1 - tf.reduce_sum(tf.abs(diff), 0)
    return tf.maximum(dist1m, 0)

#define a layer (with option for sparse input)
def layer(x, n_in, act=None,n_out=500,n_dim=n_dim,is_sparse=False,name=''):
    with tf.variable_scope('standard',reuse=False):
        W = tf.get_variable('weight'+name,#initializer=tf.random_normal([n_in,n_out])*0.05)
                            shape=[n_in, n_out],initializer=tf.contrib.layers.xavier_initializer())
        b = tf.get_variable('bias'+name,#initializer=tf.random_normal([n_out])*0.001)
                            shape=[n_out], initializer=tf.zeros_initializer())
    with tf.variable_scope('sparse',reuse=False):
        u = tf.get_variable('u'+name, initializer=tf.truncated_normal([n_dim,n_in,1])*.001)
        v = tf.get_variable('v'+name, initializer=tf.truncated_normal([n_dim,1,n_out])*.001)
    sparse = hatRBF(u,v)
    Weff = W * sparse
    a = tf.sparse_tensor_dense_matmul(x,Weff) if is_sparse else tf.matmul(x,Weff)
    if act is None:
        return a + b, sparse
    else:
        return act(a+b), sparse

#optional binarized activation function also given in original AutoRec (not used here)
from tensorflow.python.framework import ops
def binaryRound(x):
    g = tf.get_default_graph()
    with ops.name_scope("BinaryRound") as name:
        with g.gradient_override_map({"Round": "Identity"}):
            return tf.round(x, name=name)
def binarySigmoid(x):
    return binaryRound(tf.nn.sigmoid(x))

#build model
hid,s1 = layer(x,n_u,act=tf.nn.sigmoid,n_out=n_hid,is_sparse=True,name='in')
hid2,sh = layer(hid, n_hid, n_out=n_hid, act=tf.nn.sigmoid,name='h')
rec,s2 = layer(hid2,n_hid, n_out=n_u,name='out')

#compute loss
rec_m = -rec
rec_m_sparse = tf.SparseTensor(indices=yind, values=tf.gather_nd(rec_m,yind), dense_shape=yshape)
loss = 0.5*tf.sparse_reduce_sum(tf.square(tf.sparse_add(y, rec_m_sparse)))
valid_loss = tf.sparse_reduce_sum(tf.square(tf.sparse_add(y, rec_m_sparse)))

#regularize
reg_loss = 0
for W in [v for v in tf.global_variables() if 'weight' in v.name]:
    reg_loss += wreg*tf.reduce_sum(W**2)
for b in [v for v in tf.global_variables() if 'bias' in v.name]:
    reg_loss += breg*tf.reduce_sum(b**2)
for s in [s1,s2,sh]:
    reg_loss += sreg*tf.reduce_sum(tf.square(s))

#compute sparsity (overall)
ztot = 0.
tot = 0.
for s in [s1,s2,sh]:
    ztot += tf.reduce_sum(tf.where(s < 1e-20, tf.ones_like(s),tf.zeros_like(s)))
    tot += tf.to_float(tf.size(s)) 
sparsity = ztot / tot

#instantiate optimizer
import rprop
optimizer1 = rprop.RPropOptimizer()
standard_vars = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES)
#standard_vars = [v for v in standard_vars if not ('sparse' in v.name)]

#compute gradients (symbolic)
grad_placeholders = []
grad_ops = []
reg_grad_ops = []
for i,v in enumerate(standard_vars):
    grad_op = tf.gradients(loss, v)[0] 
    grad_ops.append(grad_op) 
    reg_grad_op = tf.gradients(reg_loss,v)[0] 
    reg_grad_ops.append(reg_grad_op) 
    grad_placeholder = tf.placeholder(grad_op.dtype, shape=grad_op.get_shape(), name='g_'+str(i))
    grad_placeholders.append(grad_placeholder)
    #Note: the loss gradients (lg) and regularizer gradients (rg) need to be calculated seperately
    #because the lg are summed across all inputs, while the rg are added only once

grads_and_vars = []
for g,v in zip(grad_placeholders, standard_vars):
    grads_and_vars.append((g,v))

#define train function
train_op = optimizer1.apply_gradients(grads_and_vars)


###########
#Run Model#
###########
init = tf.global_variables_initializer()
[train_batches_i, train_batches_r] = makeBatches(tind, trl, batch_size)
[valid_batches_i, valid_batches_r] = makeBatches(vind, vrl, batch_size)
current_file = open('./output_'+str(seed)+'.txt','a')
with tf.Session() as sess:
    sess.run(init)
    writer = tf.summary.FileWriter("./tmp/log/graph", sess.graph)
    for i in xrange(maxiter):
        #use same RPROP params as AutoRec: first very high step growth, then decrease once
        if i == 0:
            step_grow = sess.graph.get_tensor_by_name("step_grow:0")
            sess.run(tf.assign(step_grow,5.0))
        if i >= 6:
            step_grow = sess.graph.get_tensor_by_name("step_grow:0")
            sess.run(tf.assign(step_grow,1.2)) 
        tic = time()

        #reset gradients
        grads_tot = None

        #sum gradients over all mini-batches
        for tindx, trlx in zip(train_batches_i, train_batches_r):
            if tindx.shape[0] == 0:
                continue
            max = np.max(tindx[:,0]) +1
            feed = {xvals:trlx.astype('float32'), xind:tindx, xshape:(max,n_u),
                    yvals:trlx.astype('float32'), yind:tindx}
            grads = sess.run(grad_ops, feed_dict=feed)
            if grads_tot is None:
                grads_tot = grads
            else:
                for gt, g in zip(grads_tot, grads):
                    gt += g

        #add regularizer gradients
        reg_grads = sess.run(reg_grad_ops)
        for gt, rg in zip(grads_tot, reg_grads):
            gt += rg
        feed = {}
        for gt, gp in zip(grads_tot, grad_placeholders):
            feed[gp] = gt

        #run training step with computed gradients
        sess.run(train_op, feed_dict=feed)

        #compute generalization error
        tot_v_loss = 0.
        rec_sum = np.zeros((n_m, n_u))
        for b_idx in xrange(len(train_batches_i)): 
            tindx = train_batches_i[b_idx]
            vindx = valid_batches_i[b_idx]
            trlx = train_batches_r[b_idx]
            vrlx = valid_batches_r[b_idx]

            if tindx.shape[0] == 0:
                continue

            feed = {xvals:trlx.astype('float32'), xind:tindx, xshape:(tindx[:,0].max()+1,n_u),
                    yvals:vrlx.astype('float32'), yind:vindx}
            l = sess.run(valid_loss, feed_dict=feed)
            tot_v_loss += l
        sin = sess.run(sparsity)

        #outputs: Epoch No., validation RMSE, No. of validation ratings, sparsity, time for this epoch
        printstring = str(i)+' '+str(np.sqrt(tot_v_loss/vind.shape[0]))+' '+str(vind.shape[0])+' '+str(tind.shape[0])+' '+str(sin)+' '+str(time() - tic)+'\n'
        print printstring
        #current_file.write(printstring)
        #current_file.flush()
    sin = sess.run(sparsity)
    #u = sess.run([v for v in tf.global_variables() if v.name=='sparse/uin:0'])[0]
    #v = sess.run([v for v in tf.global_variables() if v.name=='sparse/vin:0'])[0]
    #s = sess.run(s1)

# import matplotlib.pyplot as plt
# plt.figure(figsize=(12,6))
# plt.subplot(121)
# plt.hist(s.flatten(),50)
# plt.subplot(122)
# plt.scatter(u[0,:,0],u[1,:,0],alpha=0.6)
# plt.scatter(v[0,0,:],v[1,0,:],color='red',alpha=0.6)
# plt.show()    

with open('summary_test.txt', 'a') as file:
    for a in sys.argv[1:]:
        file.write(a+' ')
    file.write(str(np.sqrt(tot_v_loss/vind.shape[0]))+' '+str(sin)+' '+str(seed)+'\n')
    file.close()
