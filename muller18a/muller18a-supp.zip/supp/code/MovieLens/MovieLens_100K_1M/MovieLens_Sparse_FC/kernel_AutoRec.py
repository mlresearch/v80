'''
written by Lorenz Muller 2017
'''

import numpy as np
import tensorflow as tf
 

def get_poly_kernel_weight(nin,nout,n_dim,ncopy=1):
    #new parameters
    u = tf.Variable(tf.random_normal([n_dim,nin,1])*.01,dtype=tf.float32)
    v = tf.Variable(tf.random_normal([n_dim,1,nout])*.01,dtype=tf.float32)

    w = tf.Variable(tf.random_normal([nin, nout])*0.03, dtype=tf.float32)

    #compute matrix from parameters (gaussian rbf kernel)
    d = u - v
    dist = tf.reduce_sum(tf.square(d),0) #2-norm over dims (squared)
    rbf =  tf.maximum( 1-dist, 0)
    #rbf = tf.exp(-dist) 
    return w,rbf


def kernel_AutoRec(x, n_u, n_hid, n_m, n_dim, n_layers=3, 
                   V_kernel=True, W_kernel=True):
    if W_kernel:
        #Wfin = get_kernel_weight(n_hid, n_m, n_dim)
        W,ws = get_poly_kernel_weight(n_hid, n_m, n_dim)
        Wfin = W*ws
    else:
        W = tf.get_variable(name="W", 
                            initializer=tf.truncated_normal(
                                shape=[n_hid, n_m],
                                mean=0, stddev=0.03),dtype=tf.float32)
    b = tf.get_variable(name="b", initializer=tf.zeros(shape=n_m), dtype=tf.float32)

    q = x
    rs = []
    Vs = []
    for i in range(n_layers):
        n_in = n_m if i==0 else n_hid
        if V_kernel:
            #Vfin = get_kernel_weight(n_in, n_hid, n_dim)
            V,r = get_poly_kernel_weight(n_in, n_hid, n_dim)
            Vfin = V*r
        else:
            V = tf.get_variable(name="V"+str(i), 
                                initializer=tf.truncated_normal(
                                    shape=[n_in, n_hid],
                                    mean=0, stddev=0.03),dtype=tf.float32)
        mu = tf.get_variable(name="mu"+str(i), 
                             initializer=tf.zeros(shape=n_hid),
                             dtype=tf.float32)
        q = tf.matmul(q, Vfin) + mu
        q = tf.nn.sigmoid(q)
        rs.append(r)
        Vs.append(Vfin)
        

    l_out = tf.matmul(q, Wfin) + b
    return l_out, [ws]+rs, [W]+Vs#+Vs


