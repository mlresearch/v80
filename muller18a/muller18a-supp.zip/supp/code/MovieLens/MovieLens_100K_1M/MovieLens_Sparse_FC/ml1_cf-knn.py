'''
written by Lorenz Muller 2017
'''

import numpy as np
import tensorflow as tf
from time import time
import sys
import os
from subprocess import call
seed = int(time())
np.random.seed(seed)

from dataLoader import loadData
from kernel_AutoRec import * 

#Load data: Expected directory './data/ml-1m/'
tr, tm, vr, vm = loadData('./data/ml-1m/',
                          seed=seed,transpose=True)
unseen_u = np.greater(vm.sum(axis=1) - tm.sum(axis=1),0.5)
unseen_m = np.greater(vm.sum(axis=0) - tm.sum(axis=0),0.5)
unseen_matrix = np.outer(unseen_u, unseen_m)
n_unseen = unseen_matrix.sum()

#Set hyperparameters
n_m = tr.shape[0]
n_u = tr.shape[1]
print 'n_m:', n_m
n_hid = 500
n_dim = int(sys.argv[1]) if len(sys.argv) > 1 else 12
n_h_layers = int(sys.argv[2]) if len(sys.argv) > 2 else 1
lambda_reg_out = float(sys.argv[3]) if len(sys.argv) > 3 else .1#sparsity
lambda_reg_in = float(sys.argv[4]) if len(sys.argv) > 4 else 1.#.3#100.
output_every = 50 #breaks L-BFGS loop
n_epoch = n_h_layers*10*output_every
display_bfgs = True
kernelize_output = True
kernelize_input = True
recording = (len(sys.argv) > 1)

if recording:
    directory = './recording/'+str(time())+'/'
    if not os.path.exists(directory):
        os.makedirs(directory)
    outfile = open(directory+'performance.txt','wa')
    call(['cp','ml1_cf-knn.py',directory])
    with open(directory+'params.txt','wa') as paramfile:
        for a in sys.argv:
            paramfile.write(a+' ')
        paramfile.close()

#Input placeholders
R = tf.placeholder("float", [None, n_u])
M = tf.placeholder("float", [None, n_u])

#Instantiate network
prediction, reg_params_out, reg_params_in = kernel_AutoRec(R, n_m, n_hid, 
                                                   n_u, n_dim,
                                                   W_kernel=kernelize_output,
                                                   V_kernel=kernelize_input,
                                                   n_layers = n_h_layers)

#Compute loss (symbolic)
diff = tf.multiply(R - prediction, M)
sqE = tf.reduce_sum(diff**2)
loss = sqE
for p in reg_params_in:
    loss += tf.reduce_sum(p**2) * lambda_reg_in #*.5
for p in reg_params_out:
    loss += tf.reduce_sum(p**2) * lambda_reg_out
V = reg_params_out[0]

#Instantiate L-BFGS Optimizer
ScipyOptimizerInterface = tf.contrib.opt.ScipyOptimizerInterface
optimizer = ScipyOptimizerInterface(loss, 
                                    options={'maxiter':output_every, 
                                             'disp':display_bfgs,
                                             'maxcor':10}, 
                                    method='L-BFGS-B')

saver = tf.train.Saver()

#Training and validation loop
init = tf.global_variables_initializer()
with tf.Session() as sess:
    sess.run(init)
    print 'optimizing'
    for i in range( int(n_epoch/output_every) ):
        optimizer.minimize(sess, feed_dict={R:tr, M:tm})
        pre = sess.run(prediction, feed_dict={R:tr, M:tm})
        if n_unseen > 0:
            pre[unseen_matrix] = 3.
        error = (vm*(np.clip(pre,1.,5.) - vr)**2).sum() / vm.sum()
        vnp = V.eval()
        sparsity = 1. - (np.greater(np.abs(vnp),0)).sum() / float(vnp.shape[0]*vnp.shape[1])
        print '.-^-._'*10
        print 'epoch:', i, 'validation rmse:', np.sqrt(error), 'sparsity:', sparsity
        if recording:
            outfile.write(str(i)+' '+str(np.sqrt(error))+' '+str(sparsity)+'\n')
            save_path = saver.save(sess, directory+"model.ckpt")
        print '.-^-._'*10

if recording:
    with open('summary.txt','a') as file:
        for a in sys.argv[1:]:
            file.write(a+' ')
        file.write(str(np.sqrt(error))+' ')
        file.write(str(sparsity)+'\n')
        file.close()
print 'done'


