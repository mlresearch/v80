'''
written by Lorenz Muller 2017
'''

import numpy as np
import tensorflow as tf
from time import time

def loadData(path='./', valfrac=0.1, delimiter='::',seed=1234,
             transpose=False):
    '''
    takes path to dataset, fraction of data to be used for validation 
    and a delimiter for splitting the data into columns
    returns a num_users x num_items training matrix 
    and a binary matrix indicating non-zero entries of that training matrix
    as well as a corresponding validation matrices
    '''
    np.random.seed(seed)
    tic = time()
    print 'reading data...'
    data = np.loadtxt(path+'ratings.dat', skiprows=0, delimiter=delimiter).astype('int32')
    print 'data read in', time() - tic, 'seconds'
    n_u = data[:,0].max() #number of users
    n_m = data[:,1].max() #number of movies
    n_r = data.shape[0] #number of ratings
    
    #print n_u, n_m
    #exit()

    idx = np.arange(n_r)
    np.random.shuffle(idx)
    
    trainRatings = np.zeros((n_u, n_m),dtype='float32')
    validRatings = np.zeros((n_u, n_m))
    trainMask = np.zeros((n_u, n_m),dtype='float32')
    validMask = np.zeros((n_u, n_m))

    for i in xrange(n_r):
        u_id = data[idx[i],0] - 1
        m_id = data[idx[i],1] - 1
        r = data[idx[i],2]
        if i <= valfrac*n_r:
            validRatings[u_id, m_id] = int(r)
            validMask[u_id, m_id] = 1
        else:
            trainRatings[u_id, m_id] = int(r)
            trainMask[u_id, m_id] = 1
            
    if transpose:
        return trainRatings.T, trainMask.T, validRatings.T, validMask.T
    else:
        return trainRatings, trainMask, validRatings, validMask
