'''
written by Lorenz Muller 2017
'''

import numpy as np
import tensorflow as tf
from time import time
import sys
import os
from subprocess import call
seed = int(time())
np.random.seed(seed)

from dataLoader import loadData
from kernel_AutoRec import * 

#Load data
#tr, tm, vr, vm = loadData('./data/ml-100k/',delimiter='\t',
#                          seed=seed,transpose=True, valfrac=0.2)
tr, tm, vr, vm = loadData('./data/ml-1m/',delimiter='::',
                          seed=seed,transpose=True, valfrac=0.1,storeDenseMatrix=False)

unseen_u = np.greater(vm.sum(axis=1) - tm.sum(axis=1),0.5)
unseen_m = np.greater(vm.sum(axis=0) - tm.sum(axis=0),0.5)
unseen_matrix = np.outer(unseen_u, unseen_m)
n_unseen = unseen_matrix.sum()

import os
#os.environ['CUDA_VISIBLE_DEVICES'] = '-1'

#Set hyperparameters
n_m = tr.shape[0]
n_u = tr.shape[1]
print 'n_m:', n_m, 'n_u:', n_u
n_hid = 500
n_dim = int(sys.argv[1]) if len(sys.argv) > 1 else 5
n_h_layers = int(sys.argv[2]) if len(sys.argv) > 2 else 1
lambda_reg_out = float(sys.argv[3]) if len(sys.argv) > 3 else 100.#sparsity #alphas
lambda_reg_in = float(sys.argv[4]) if len(sys.argv) > 4 else 100.#.3#100.
output_every = 20 #breaks L-BFGS loop
n_epoch = n_h_layers*25*output_every
display_bfgs = True
kernelize_output = False
kernelize_input = False
recording = True#(len(sys.argv) > 1)
use_BFGS=False

if recording:
    directory = './recording/'+str(time())+'/'
    if not os.path.exists(directory):
        os.makedirs(directory)
    outfile = open(directory+'performance.txt','wa')
    call(['cp','ml1_cf-knn.py',directory])
    with open(directory+'params.txt','wa') as paramfile:
        for a in sys.argv:
            paramfile.write(a+' ')
        paramfile.close()

#Input placeholders
R = tf.placeholder("float", [None, n_u])
#M = tf.placeholder("float", [None, n_u])

#Instantiate network
prediction, reg_params_out, reg_params_in,mats = kernel_AutoRec(R, n_m, n_hid, 
                                                   n_u, n_dim,
                                                   W_kernel=kernelize_output,
                                                   V_kernel=kernelize_input,
                                                   n_layers = n_h_layers)

#Compute loss (symbolic)
M = tf.to_float(tf.greater(R, 1e-12))
diff = tf.multiply(R - prediction, M)
sqE = tf.reduce_sum(diff**2)
loss = sqE
for p in reg_params_in:
    loss += tf.reduce_sum(p**2) * lambda_reg_in #*.5
for p in reg_params_out:
    loss += tf.reduce_sum(p**2) * lambda_reg_out
#V = reg_params_out[0]
#alpha = reg_params_in[0]


if use_BFGS:
    #Instantiate L-BFGS Optimizer
    ScipyOptimizerInterface = tf.contrib.opt.ScipyOptimizerInterface
    optimizer = ScipyOptimizerInterface(loss, 
                                        options={'maxiter':output_every,
                                                 'disp':display_bfgs,
                                                 'maxcor':10}, 
                                        method='L-BFGS-B')

    saver = tf.train.Saver()

    #Training and validation loop
    init = tf.global_variables_initializer()
    with tf.Session(config=tf.ConfigProto(device_count = {'GPU': 0})) as sess:
        sess.run(init)
        print 'optimizing'
        for i in range( int(n_epoch/output_every) ):
            optimizer.minimize(sess, feed_dict={R:tr})

            #for param in mats:
            #    p = param.eval()
            #    pflat = (p*(p>0)).mean(1) + (p*(p<0)).mean(1)
            #    sess.run(tf.assign(param,np.tile(pflat,(p.shape[1],1)).T ))

            pre = sess.run(prediction, feed_dict={R:tr})
            if n_unseen > 0:
                pre[unseen_matrix] = 3.
            error = (vm*(np.clip(pre,1.,5.) - vr)**2).sum() / vm.sum()
            #vnp = V.eval()
            sparsity=0
            #sparsity = 1. - (np.greater(np.abs(vnp),0)).sum() / float(vnp.shape[0]*vnp.shape[1])
            print '.-^-._'*10
            print 'epoch:', i, 'validation rmse:', np.sqrt(error), 'sparsity:', sparsity
            if recording:
                outfile.write(str(i)+' '+str(np.sqrt(error))+' '+str(sparsity)+'\n')
                save_path = saver.save(sess, directory+"model.ckpt")
            print '.-^-._'*10

        if recording:
            with open('summary.txt','a') as file:
                for a in sys.argv[1:]:
                    file.write(a+' ')
                file.write(str(np.sqrt(error))+' ')
                file.write(str(sparsity)+'\n')
                file.close()

else:
#Optimize with RPROP
    batch_size=n_m#128
    display_step = output_every
    num_batch = int(n_m / batch_size)
    import rprop
    #optimizer = tf.train.RMSPropOptimizer(0.001)#
    optimizer = rprop.RPropOptimizer(step_grow=1.2,max_step=0.01)
    gvs = optimizer.compute_gradients(loss)
    capped_gvs = [(tf.clip_by_value(grad, -1e12, 1e12), var) for grad, var in gvs]
    train_op = optimizer.apply_gradients(capped_gvs)

    #initialize variables
    init = tf.global_variables_initializer()

    #train & test network
    error = 0
    with tf.Session() as sess:
        sess.run(init)
        #v = V.eval()
        #print 'mean v:', np.abs(v).mean()
        tic = time()
        for epoch in xrange(1,n_epoch):
            u_idx = np.random.permutation(n_m)
            cost_sum = 0 
            for i in xrange(num_batch):
                #training loop
                if i == num_batch -1:
                    batch_idx = u_idx[i*batch_size:]
                else:
                    batch_idx = u_idx[i*batch_size:(i+1)*batch_size]
                _, cost = sess.run([train_op,loss], feed_dict={R:tr[batch_idx], 
                                                               M:tm[batch_idx]})
                cost_sum += cost
            print 'epoch', epoch, 'cost', cost_sum
    
            if epoch % display_step == display_step-1 or epoch == 1:
                #prediction and testing loop
                esum = 0
                u_idx = np.arange(n_m)
                for i in xrange(num_batch):
                    if i == num_batch -1:
                        batch_idx = u_idx[i*batch_size:]
                    else:
                        batch_idx = u_idx[i*batch_size:(i+1)*batch_size]
                    pre = sess.run(prediction, feed_dict={R:tr[batch_idx],
                                                          M:tm[batch_idx]})
                    error = (vm[batch_idx]*(np.clip(pre,1.,5.) - vr[batch_idx])**2).sum()
                    esum += error
                #pre = sess.run(prediction, feed_dict={R:tr, M:tm})
                #if n_unseen > 0:
                #    pre[unseen_matrix] = 3.
                error = float(esum)/vm.sum()#(vm*(np.clip(pre,1.,5.) - vr)**2).sum() / vm.sum()
                print '%'*50
                print 'epoch',epoch, 'validation rmse:', np.sqrt(error)
                #print 'alpha', alpha.eval().mean(), alpha.eval().std()
                #print 'W', V.eval().mean(), V.eval().std()
                print '%'*50

        if recording:
            with open('summary.txt','a') as file:
                for a in sys.argv[1:]:
                    file.write(a+' ')
                file.write(str(np.sqrt(error))+'\n')
                file.close()


