"written by Lorenz K. Muller 2017"

import tensorflow as tf
from tensorflow.python.training import optimizer

class RPropOptimizer(optimizer.Optimizer):
    """RPROP Optimizer implementation"""

    def __init__(self, stepsize=0., step_grow=1.2, step_shrink=0.5, max_step=1e-2, min_step=1e-6,
                 use_locking=False, name="RProp"):
        super(RPropOptimizer, self).__init__(use_locking, name)
        self._stepsize = stepsize
        self._step_grow = tf.Variable(step_grow, trainable=False, name='step_grow')
        self._step_shrink = step_shrink
        self._max_step = max_step
        self._min_step = min_step

    def _create_slots(self, variables):
        for v in variables:
            self._get_or_make_slot(v, tf.fill(v.get_shape(), self._stepsize), "step", self._name)
            self._get_or_make_slot(v, tf.zeros([v.get_shape().num_elements()], dtype=tf.float32), "last_grad", self._name)

    def _apply_dense(self, grad, var):
        last_grad = self.get_slot(var, "last_grad")
        step = self.get_slot(var, "step")

        grad = tf.reshape(grad, [-1])
        grad_prod = last_grad*grad
        with tf.control_dependencies([grad_prod]):
            last_grad = last_grad.assign(grad)

        #Depending on the sign of the product of the this gradient and the previous one,
        #we multiply the step by step_shrink, 1, or step_grow
        multiplier = tf.where(grad_prod > 0, 
                              tf.ones_like(grad_prod)*self._step_grow, 
                              tf.ones_like(grad_prod)*self._step_shrink)
        multiplier = tf.where(grad_prod == 0, 
                              tf.ones_like(grad_prod),
                              multiplier)

        new_step = step * tf.reshape(multiplier, tf.shape(step))
        new_step = tf.clip_by_value(new_step,self._min_step, self._max_step) 

        #we step in the direction of the gradient sign, with a step size given by new_step
        up = new_step * tf.reshape(tf.sign(last_grad), tf.shape(step))
        var_update = var.assign_sub(up, use_locking=self._use_locking) 
        step_update = step.assign(new_step)

        return tf.group(*[var_update, step_update])

    def _apply_sparse(self, grad, var):
        raise NotImplementedError("use dense update")

