'''
written by Lorenz Muller 2017
'''
import numpy as np
import tensorflow as tf
 

def get_kernel_weight(nin,nout,n_dim):
    #new parameters
    n_rbf = 1#2
    u = tf.Variable(tf.random_normal([n_dim,nin,1,n_rbf])*.01,dtype=tf.float32)
    v = tf.Variable(tf.random_normal([n_dim,1,nout,n_rbf])*.01,dtype=tf.float32)
    alpha = tf.Variable(tf.random_normal([nin,1,n_rbf])*0.03,dtype=tf.float32)
    #g = tf.Variable(1.0,dtype=tf.float32)
    rbf = tf.reduce_sum(  (tf.tanh( tf.reduce_sum(u*v,0)  )) *alpha,2)
    return rbf,alpha

def kernel_AutoRec(x, n_u, n_hid, n_m, n_dim, n_layers=3, 
                   V_kernel=True, W_kernel=True):
    mats = []
    alphas = []
    Ws = []
    if W_kernel:
        #Wfin = get_kernel_weight(n_hid, n_m, n_dim)
        W,alpha = get_poly_kernel_weight(n_hid, n_m, n_dim)
        mats.append(W)
        alphas.append(alpha)
    else:
        W = tf.get_variable(name="W", 
                            initializer=tf.truncated_normal(
                                shape=[n_hid, n_m],
                                mean=0, stddev=0.03),dtype=tf.float32)
    b = tf.get_variable(name="b", initializer=tf.zeros(shape=n_m), dtype=tf.float32)
    Ws.append(W)
    Wfin = W

    q = x 
    for i in range(n_layers):
        n_in = n_m if i==0 else n_hid
        if V_kernel:
            #Vfin = get_kernel_weight(n_in, n_hid, n_dim)
            V,alpha = get_poly_kernel_weight(n_in, n_hid, n_dim)
            alphas.append(alpha)
        else:
            V = tf.get_variable(name="V"+str(i), 
                                initializer=tf.truncated_normal(
                                    shape=[n_in, n_hid],
                                    mean=0, stddev=0.03),dtype=tf.float32)
        mu = tf.get_variable(name="mu"+str(i), 
                             initializer=tf.zeros(shape=n_hid),
                             dtype=tf.float32)
        Vfin = V
        q = tf.matmul(q, Vfin) + mu
        q = tf.nn.sigmoid(q)
        Ws.append(V)
        mats.append(V)
        

    l_out = tf.matmul(q, Wfin) + b
    return l_out, alphas, Ws, mats#+Vs



