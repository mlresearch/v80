This is the code we used to generate the results on the MovieLens dataset.

We re-implemented the network for the larger dataset (ML-10M), and this code is more legible and better commented; if you are looking for the details of implementation we recommend reading the ML-10M code first.
