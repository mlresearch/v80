
""" 
Adapted by Lorenz K. Muller from
https://github.com/aymericdamien/TensorFlow-Examples/
"""

from __future__ import print_function

# Import MNIST data
from tensorflow.examples.tutorials.mnist import input_data
mnist = input_data.read_data_sets("./tmp/data/", one_hot=True)

import sys
import tensorflow as tf
import numpy as np
from time import time

seed = int(time())
np.random.seed(seed)

# Hyper-Parameters
learning_rate_init = float(sys.argv[3]) if len(sys.argv) > 3 else 0.01
lambda2 = float(sys.argv[4]) if len(sys.argv) > 4 else 1.
num_steps = 50000
batch_size = 512
display_step = 200
global_step = tf.Variable(0, trainable=False)
learning_rate = tf.train.exponential_decay(learning_rate_init, global_step,
                                           10000, 0.5, staircase=True)
n_hidden_1 = 500 # 1st layer number of neurons
n_hidden_2 = 500 # 2nd layer number of neurons
num_input = 784 
num_classes = 10 
n_dims = int(sys.argv[1]) if len(sys.argv) > 1 else 2
scale = 1./float(n_dims)
kernel = sys.argv[2] if len(sys.argv) > 2 else 'RBF'


# tf Graph input
X = tf.placeholder("float", [None, num_input])
Y = tf.placeholder("float", [None, num_classes])



h1init = tf.random_normal([n_dims,num_input,1])*scale

cv = {
    #'h1' : tf.Variable(tf.random_normal([n_dims, num_input,1])*scale),
    'h1' : tf.Variable(h1init),
    'h2' : tf.Variable(tf.random_normal([n_dims,n_hidden_1,1])*scale),
    'out' : tf.Variable(tf.random_normal([n_dims, n_hidden_2,1])*scale)
}
ch = {
    'h1' : tf.Variable(tf.random_normal([n_dims,1,n_hidden_1])*scale),
    'h2' : tf.Variable(tf.random_normal([n_dims,1,n_hidden_2])*scale),
    'out' : tf.Variable(tf.random_normal([n_dims,1,num_classes])*scale)
}
alpha = {
    'h1' : tf.Variable(tf.random_normal([num_input])*0.01),
    'h2' : tf.Variable(tf.random_normal([n_hidden_1])*0.01),
    'out' : tf.Variable(tf.random_normal([n_hidden_2])*0.01)
}
biases = {
    'b1': tf.Variable(tf.zeros([n_hidden_1])),
    'b2': tf.Variable(tf.zeros([n_hidden_2])),
    'out': tf.Variable(tf.zeros([num_classes]))
}


def get_weight(cv,ch,alpha,kernel='RBF'):
    if kernel == 'RBF':
        d = cv  - ch
        dist = tf.reduce_sum(d**2,0) 
        return tf.exp(- dist), tf.expand_dims(alpha,1)
    elif kernel == 'dot':
        return tf.reduce_sum(cv*ch,0), tf.expand_dims(alpha,1)
    elif kernel == 'poly':
        return tf.reduce_sum((1.+cv*ch)**2,0), tf.expand_dims(alpha,1)


# Create 
def neural_net(x, kernel='RBF'):
    W1,a1 = get_weight(cv['h1'],ch['h1'],alpha['h1'],kernel=kernel)
    layer_1 = tf.nn.relu(tf.matmul(tf.nn.dropout(x,1.0), W1*a1)+biases['b1'])

    W2,a2 = get_weight(cv['h2'],ch['h2'],alpha['h2'],kernel=kernel) 
    layer_2 = tf.nn.relu(tf.matmul(tf.nn.dropout(layer_1,1.0), W2*a2) + biases['b2'])

    W3,a3 = get_weight(cv['out'],ch['out'],alpha['out'],kernel=kernel) 
    out_layer = tf.matmul(tf.nn.dropout(layer_2,1.0), W3*a3) + biases['out']
    return out_layer, [W1,W2,W3], [a1,a2,a3]

# Construct model
logits,Ws,As = neural_net(X,kernel=kernel)
prediction = tf.nn.softmax(logits)

# Define loss and optimizer
l2 = 0
for a,W in zip(As,Ws):
    l2 += tf.reduce_mean((a*W)**2) * lambda2

loss_op = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(
    logits=logits, labels=Y)) + l2

# Evaluate model
correct_pred = tf.equal(tf.argmax(prediction, 1), tf.argmax(Y, 1))
accuracy = tf.reduce_mean(tf.cast(correct_pred, tf.float32))


optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate)#, beta1=0.2,beta2=0.5)
train_op = optimizer.minimize(loss_op,global_step=global_step)


# Initialize the variables (i.e. assign their default value)
init = tf.global_variables_initializer()

# Start training
with tf.Session() as sess:
    sess.run(init)

    print("training a " + str(n_dims) + "-KNN with " + kernel + " Kernel.") 
    for step in range(1, num_steps+1):
        batch_x, batch_y = mnist.train.next_batch(batch_size)
        sess.run(train_op, feed_dict={X: batch_x, Y: batch_y})
        if step % display_step == 0 or step == 1:
            loss, acc = sess.run([loss_op, accuracy], feed_dict={X: batch_x,
                                                                 Y: batch_y})
            print("Step " + str(step) + ", Minibatch Loss= " + \
                  "{:.4f}".format(loss) + ", Training Accuracy= " + \
                  "{:.3f}".format(acc))

    test_acc = sess.run(accuracy, feed_dict={X: mnist.test.images,
                                             Y: mnist.test.labels})

    print("Testing Accuracy:", test_acc)

with open('summary.txt','a') as file:
    for a in sys.argv[1:]:
        file.write(a+' ')
    file.write(str(test_acc)+'\n')
    file.close()


