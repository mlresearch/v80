%the dataset is available at: https://archive.ics.uci.edu/ml/datasets/MiniBooNE+particle+identification

X = load("MiniBooNE_PID.txt"); 
mp= 36499;
mn= 93565;
Y = zeros(mp+mn,1);
Y(1:mp) = 1;
Y(mp+1:mp+mn) = -1;

mm = 50000;
s = 1000;
%Y = D(:, 9); 
%Y = sign(Y-1/2);
%X = D(:, 1:8); 
M = size(X,1); 
d = size(X,2); 

T=10; %repeat the experiment T times
mu = mean(X); 
sg = std(X); 
for i=1:size(X,1) 
    X(i,:) = (X(i,:)-mu)./sg;
end
%we will test three scenarios: first draw a sample of 10K from D and train.
%Second, draw 10 samples (each is 1K) and take the average. 
%Third, train on a sample of size 1K
%we tream the empirical distribution as the true distribution in order to
%measure test accuracy reliably. 

E1 = []; 
E2 = []; 
E3 = [];
Etrn1 = [];
Etrn2 = [];
Etrn3 = [];

T1 = [];
T2 = []; 

for t=1:T 
    Xtrn = zeros(mm,d); 
    Ytrn = zeros(mm,1);
    for i=1:mm 
        idx = ceil(rand()*M); 
        Xtrn(i,:) =  X(idx,:); 
        Ytrn(i) =  Y(idx); 
    end
    t1 = cputime;
    model = train(Ytrn, sparse(Xtrn), '-s 0 -c 1');
    T1 = [T1 cputime-t1];
    %model.w is the solution 
    Yp = sign(X*model.w'); 
    err = mean(Yp ~= Y); 
    E1 = [E1 err]; 
    Yp = sign(Xtrn*model.w');
    err_trn = mean(Yp ~= Ytrn); 
    Etrn1 = [Etrn1 err_trn];
    
    %option 2, split and average
    w_f = zeros(1,d); 
    for k=0:49 
        idx = k*s+1:(k+1)*s;
        t1 = cputime;
        model = train(Ytrn(idx), sparse(Xtrn(idx,:)), '-s 0 -c 50');    %here C=10 the regularization term is fixed.
        T2 = [T2 cputime-t1]; 
        w_f = w_f + model.w;
    end
    w_f = w_f/50; 
    Yp = sign(X*w_f'); 
    err = mean(Yp ~= Y); 
    E2 = [E2 err]; 
    Yp = sign(Xtrn*w_f');
    err_trn = mean(Yp ~= Ytrn); 
    Etrn2 = [Etrn2 err_trn];
    
    %option 3 is to train on the first 1000 examples only
    model = train(Ytrn(1:s), sparse(Xtrn(1:s,:)), '-s 0 -c 50');
    Yp = sign(X*model.w'); 
    err = mean(Yp ~= Y); 
    E3 = [E3 err]; 
    Yp = sign(Xtrn*model.w');
    err_trn = mean(Yp ~= Ytrn); 
    Etrn3 = [Etrn3 err_trn];
    
end

[mean(E1), std(E1); mean(E2), std(E2); mean(E3), std(E3) ]
[mean(T1), mean(T2)]