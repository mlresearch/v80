%=== clear the figure =======
hold off

%==== generate reproducible random numbers 
rng('default');
rng(1111);

fig_id = 0; %used to create subplots
for dstar=5:5:15,   %polynomial degree is 5, 10, 15 (hence, the optimal number of parameters is 6,11,16 
fig_id = fig_id + 1;
subplot(1,3,fig_id); 

P_degree = dstar; 
m = 100*P_degree;   %use 100d training examples

AIC_T = []; 
BIC_T = []; 
UIC_T = []; 

for T=1:5,          %run the same experiment 5 times and report averages
X = [];
Y = [];
r = rand(P_degree,1); %these are the roots of the polynomial in [-1, 1]
for i=1:2:P_degree, 
    r(i) = -r(i);
end

for t=1:m, 
    x = rand()*2-1;
    X = [X x];
    y = 1; 
    for i=1:P_degree
        y =y*(x-r(i));
    end
    y = y + 0.001*randn();  %add a small noise (noise is small because the interval is limited to [-1, +1])
    
    Y = [Y y];
end

%now carry out least squares regression
AIC = []; 
UIC = []; 
BIC = []; 

%the goal is for the learning algorithm to infer dstar from the training
%sample only. Hence, it loops over possible values of d, calculates the
%information criterion, and selects the value of d that minimizes the
%information criterion. 
%in our code, we only plot the information criterion vs. d
for d=1:2*P_degree, 
    Xtrn = [];
    for k=1:d, 
        Xtrn = [Xtrn (X').^(k-1)];
    end
    z = Xtrn\Y'; 
    
    %AIC 
    AIC = [AIC norm(Xtrn*z-Y')^2/m+d/m]; 
    
    %BIC 
    BIC = [BIC norm(Xtrn*z-Y')^2/m+0.5*d/m*log(m)];
    
    %UIC
    sig = max(abs(Xtrn*z-Y'));
    UIC = [UIC norm(Xtrn*z-Y')^2/m + sig*sqrt(d/(2*m))];
end

AIC_T = [AIC_T; AIC]; 
UIC_T = [UIC_T; UIC];
BIC_T = [BIC_T; BIC];
end


plot(mean(AIC_T), 'red'); hold on;
plot(mean(BIC_T), 'black'); hold on;

plot(mean(UIC_T), 'blue'); hold on;
set(gca, 'YScale', 'log')
end