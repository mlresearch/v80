import gc
import numpy as np
import scipy.linalg.interpolative as sli
import math
import glob
import csv
import scipy.linalg as sl
import scipy.sparse as sp
import scipy.sparse.linalg as ssl
import timeit
import const_data as cd
from numpy import linalg as la
import os
import itertools

dataset = ['Netflix', 'Movielens', 'Synthetic', 'Yahoo', 'Jester']
run_on_dataset = dataset[2]
ojas = False

run_platforms = ["Local", "AWS", "Azure"]
run_on = run_platforms[2]
run_on_complete_data = False
line_search = False
compute_non_private = False
T_arr = [50, 25, 20, 15, 10, 5] #200, 150, 100, 50, 25, 20, 15, 10, 5] # 5, 10, 15, 20, 25, 50] # 200, 150, 100, 50, 25, 20, 15, 10, 5]
k_sum_of_eigs = 1
force_k_take_non_zero = True
run_on_unsampled_data = False
normalize_ratings = True
normalize_like = "Only_U_avg"  # should be from 'WL08', 'MM09', 'JS10', 'JS10v2', and 'Only_U_avg'
checkpoint_save_every = 0
load_from_prev_ckpt = False
delete_prev_ckpt = True
lr_const_arr = [1.0, 0.5]

calc_on_all_indices = False
testing_sample = False
subtract_avg_extra_movies = False
calculate_nmae = False
do_projection = True

# eps_arr = []
eps_arr = [20, 10, 5, 2, 1, 0.5, 0.1] # 20, 10, 5, 2, 1, 0.5, 0.1]
delta = pow(10, -6)
beta = 0.001
compute_globally_private = False
private_line_search = False
calibrate_noise = True

ratings_threshold_for_movie = 0
pairwiseFW = 0  # Parameter which keeps track of pairwiseFW previous iterates

if not run_on_unsampled_data:
    if not run_on_complete_data:
        max_samp_arr = [120]

ml_data_str = "ml-10m-rb//"  # should be from 'ml-100k', 'ml-1m', 'ml-10m', and 'ml-10m-rb'

if len(eps_arr) == 0:
    calibrate_noise = False
    compute_non_private = True

if calibrate_noise:
    if ojas:
        step_multiplier_arr = [11]
    else:
        step_multiplier_arr = [10, 9, 8, 7, 6, 5, 4, 3, 2]

# Additionally, set run on complete data to false if not running on AWS
if run_on == run_platforms[0]:
    # run_on_complete_data = False
    # ratings_threshold_for_movie = 0
    if run_on_dataset == dataset[0]:
        run_on_unsampled_data = False
    else:
        run_on_unsampled_data = True

if normalize_ratings:
    assert normalize_like in ['WL08', 'MM09', 'JS10', 'JS10v2', 'Only_U_avg']
else:
    normalize_like = ""

if not run_on_complete_data:
    if max_samp_arr[0] == 120:
        ml_data_str += "top900//"
    elif max_samp_arr[0] == 80:
        ml_data_str += "top400//"

if run_on_dataset == dataset[4]:
    run_on_complete_data = True
    run_on_unsampled_data = True

if run_on_dataset == dataset[2]:
    force_k_take_non_zero = False

if force_k_take_non_zero:
    if run_on_dataset == dataset[0]:
        if run_on_complete_data:
            force_k_arr = [99592.0 / 2]
        else:
            force_k_arr = [160000.0, 150000.0]  # 120000.0, 130000.0]
    elif run_on_dataset == dataset[1]:
        if ml_data_str == "ml-100k//":
            force_k_arr = [9975.0 / 2]
        elif ml_data_str == "ml-1m//":
            force_k_arr = [36060.0 / 2]
        elif ml_data_str == "ml-10m-rb//" or ml_data_str == "ml-10m//":
            force_k_arr = [130000.0, 135000.0, 140000.0]
        else:
            force_k_arr = [60000.0, 50000.0]  # 40000.0, 30000.0]
    elif run_on_dataset == dataset[2]:
        force_k_arr = [1.0]
        if testing_sample:
            users = 10
            movies = 5
        else:
            users = 500000
            if max_samp_arr[0] == 120:
                movies = 900
            elif max_samp_arr[0] == 80:
                movies = 400 #400
    elif run_on_dataset == dataset[4]:
        force_k_arr = [20000.0, 25000.0]
    else:
        if max_samp_arr == [160]:
            force_k_arr = [395000.0, 400000.0, 405000.0]
        elif max_samp_arr == [120]:
            force_k_arr = [270000.0, 260000.0]
        else:
            force_k_arr = [130000.0, 150000.0]
else:
    force_k = 0
    k_sum_of_eigs = 1500
    if run_on_dataset == dataset[2]:
        if testing_sample:
            users = 10
            movies = 5
        else:
            users = 500000
            if max_samp_arr[0] == 120:
                movies = 900
            elif max_samp_arr[0] == 80:
                movies = 400 #400


if not run_on_dataset == dataset[1]:
    calculate_nmae = False

print("run_on_dataset: " + run_on_dataset)
if run_on_dataset == dataset[1]:
    assert ml_data_str in ["ml-100k//", "ml-1m//", "ml-10m//", "ml-10m-rb//", "ml-10m-rb//top400//", "ml-10m-rb//top900//"]
    print("ml_data_str: " + ml_data_str)
elif run_on_dataset == dataset[2]:
    print("users: " + str(users) + ", movies: " + str(movies))
print("Starting experiment with the following flag values: ")
print("General flags: ")
print("run_on: " + str(run_on))
print("run_on_complete_data: " + str(run_on_complete_data))
print("line_search: " + str(line_search))
if not line_search:
    print("lr_const_arr: " + str(lr_const_arr))
print("compute_non_private: " + str(compute_non_private))
print("T_arr: " + str(T_arr))
print("k_sum_of_eigs: " + str(k_sum_of_eigs))
print("force_k_take_non_zero: " + str(force_k_take_non_zero))
print("run_on_unsampled_data: " + str(run_on_unsampled_data))
print("normalize_ratings: " + str(normalize_ratings))
if normalize_ratings:
    print("normalize_like: " + str(normalize_like))
print("checkpoint_save_every: " + str(checkpoint_save_every))
print("load_from_prev_ckpt: " + str(load_from_prev_ckpt))
print("delete_prev_ckpt: " + str(delete_prev_ckpt))
print("subtract_avg_extra_movies " + str(subtract_avg_extra_movies))
print("calculate_nmae: " + str(calculate_nmae))
print("do_projection: " + str(do_projection))
if not run_on_unsampled_data:
    print("max_samp: " + str(max_samp_arr))

print("Privacy flags: ")
print("eps_arr: " + str(eps_arr))
print("compute_globally_private: " + str(compute_globally_private))
print("private_line_search: " + str(private_line_search))
print("calibrate_noise: " + str(calibrate_noise))
if calibrate_noise:
    print("step_multiplier_arr: " + str(step_multiplier_arr))

print("Optimization flags: ")
print("ratings_threshold_for_movie: " + str(ratings_threshold_for_movie))
print("pairwiseFW: " + str(pairwiseFW))

print("Data flags:")
print("run_on_unsampled_data: " + str(run_on_unsampled_data))
print("ojas: " + str(ojas))

if not (run_on == run_platforms[0]):
    import resource

    rsrc = resource.RLIMIT_DATA
    resource.setrlimit(rsrc, (20971520, 41943040))


def top_svd(X, eigh=0):
    if eigh == 1:
        m = min(np.shape(X))
        S, V = sl.eigh(np.dot(X.T, X), eigvals=(m - 1, m - 1))
        S = math.sqrt(S)
        V = -1 * V
        # print("S: "+str(S))
        return S, V
    elif not run_on_dataset == dataset[2]:
        U, S, V = sli.svd(X, 5)
    else:
        U, S, V = sli.svd(X, 1)
    # print("S: " + str(S))
    return S[0], V[:, 0]


def private_FW(Y_star, k, L, T, eps, delta, beta, proj_omega, val_nonzero, tot_nonzero, calc_val_path="", centraldp=0, write=1,
               ratings_per_movie=[], ratings_threshold_for_movie=0, r_bar_params=[], max_samp=0,
               lr_const=0, force_k=0, step_multiplier=0, ojas = False, range_ratings = 5):
    if run_on_dataset == dataset[0]:
        data_str = "Netf_"
    elif run_on_dataset == dataset[1]:
        data_str = ml_data_str.replace("//", "")
    elif run_on_dataset == dataset[3]:
        data_str = "Yahoo_"
    elif run_on_dataset == dataset[4]:
        data_str = "Jester_"
    else:
        data_str = "Synth_"
    nr_str = "_nr" + normalize_like if normalize_ratings else ""
    rtfm_str = "_rtfm" + str(ratings_threshold_for_movie) if ratings_threshold_for_movie > 0 else ""
    pwfw_str = "_pwfw" + str(pairwiseFW) if pairwiseFW > 0 else ""
    uns_str = "_uns" if run_on_unsampled_data else ""
    force_k_str = "_fk" if force_k > 0.0 else ""
    lr_name_str = "_lr" if line_search else "_lr_const_" + str(lr_const)
    max_samp_str = "_max_samp_" + str(max_samp) if not run_on_unsampled_data else ""
    calib_str = "_calib_noise_" + str(step_multiplier) if calibrate_noise else ""
    if eps == 0.0:
        calib_str = ""
    pr_str = "_pr" if do_projection else ""

    print("Len of proj_omega: " + str(proj_omega[0].__len__()))
    m, n = Y_star.shape
    print("m: " + str(m) + ", n: " + str(n))
    store_path = "Exp_running//"
    final_store_path = "Results//"
    if not run_on_dataset == dataset[2]:
        tmpfile = data_str + "results_top_" + str(n) + "_k_" + str(k) + "_L_" + str(L) + "_eps_" + str(eps)
    else:
        tmpfile = data_str + "results_rank_1_" + str(m) + "_" + str(n) + "_k_" + str(k) + "_L_" + str(
            L) + "_eps_" + str(eps)
    if not centraldp == 0:
        tmpfile += "_centraldp"
    tmpfile += (rtfm_str + pwfw_str + force_k_str + lr_name_str + max_samp_str + nr_str + calib_str + pr_str)
    if eps > 0:
        tmpfile += "_T_" + str(T)
    tmpfile += ".csv"
    resfile = store_path + tmpfile
    final_res_file = final_store_path + tmpfile
    print("results file name: " + resfile)

    if calculate_nmae:
        label_set = [None] * 5
    else:
        label_set = [None] * 4
    if eps == 0:
        label_set[0] = " non_private"
    elif centraldp == 0:
        label_set[0] = " private, eps: " + str(eps)
    else:
        label_set[0] = " central dp, eps: " + str(eps)

    if line_search:
        lrfile = resfile.replace("results", "lr")
        final_lrfile = final_res_file.replace("results", "lr")
        print("lr file name: " + lrfile)

    if run_on_dataset == dataset[1] and calculate_nmae:
        nmae_file = resfile.replace("results", "nmae")
        print("nmae file name: " + nmae_file)

    ckpt_path = "Checkpoints//"

    # if not run_on_aws:
    directory = os.path.dirname(ckpt_path)
    if checkpoint_save_every > 0:
        try:
            os.stat(directory)
        except:
            os.mkdir(directory)

    if checkpoint_save_every > 0 or load_from_prev_ckpt:
        ckpt_folder = ckpt_path + tmpfile.replace("results", "ckpt").replace(".csv", "//")
        directory = os.path.dirname(ckpt_folder)
        if checkpoint_save_every > 0:
            try:
                os.stat(directory)
            except:
                os.mkdir(directory)
        Y_check_file = ckpt_folder + tmpfile.replace("results", "Y_ckpt").replace(".csv", "")
        Y_check_file_end = ".npz"
        print("Y ckpt file name: " + Y_check_file)
        V_check_file = ckpt_folder + tmpfile.replace("results", "V_ckpt").replace(".csv", "")
        V_check_file_end = ".npy"
        print("V ckpt file name: " + V_check_file)
        lambda_check_file = ckpt_folder + tmpfile.replace("results", "lambda_ckpt").replace(".csv", "")
        lambda_check_file_end = ".npy"
        print("lambda ckpt file name: " + lambda_check_file)

    label_set[1] = "lr"
    label_set[2] = "lr_num"
    label_set[3] = "lr_denom"
    if calculate_nmae:
        label_set[4] = "NMAE" + label_set[0]

    for ind_lab in range(len(label_set)):
        label_set[ind_lab] += (rtfm_str + pwfw_str + force_k_str + nr_str + uns_str)

    reslabel = label_set[0]
    lr_label = label_set[1]
    lr_num_label = label_set[2]
    lr_denom_label = label_set[3]
    if calculate_nmae:
        nmaelabel = label_set[4]

    if not calibrate_noise:
        term_num = T * np.log(1.0 / delta)
        term_num2 = term_num + (eps * T)
        sigma = 0
        if eps > 0:
            if centraldp == 0:
                sigma = pow(L, 2) * (np.sqrt(term_num) + np.sqrt(term_num2)) / eps
            else:
                sigma = L * (np.sqrt(term_num) + np.sqrt(term_num2)) / eps
    else:
        step_const = 1
        last_step = 0
    # print "sigma: ", sigma

    X = sp.csr_matrix(sp.coo_matrix(([0.0] * proj_omega[0].__len__(), proj_omega)))
    print("Number of entries in X: " + str(X.nnz))
    count_rmse = proj_omega[0].__len__()

    if normalize_like == "JS10":
        ones_p_omega = sp.csr_matrix(sp.coo_matrix(([1] * count_rmse, proj_omega)))
        r_bar_u_diag = sp.csr_matrix(
            sp.coo_matrix((r_bar_params[0], (range(len(r_bar_params[0])), range(len(r_bar_params[0]))))))
        r_bar_m_diag = sp.csr_matrix(
            sp.coo_matrix((r_bar_params[1], (range(len(r_bar_params[1])), range(len(r_bar_params[1]))))))
        avg_proj_mat = (r_bar_u_diag.dot(ones_p_omega) + ones_p_omega.dot(r_bar_m_diag)) / 2
        del ones_p_omega, r_bar_u_diag, r_bar_m_diag
        gc.collect()
        scaled_err_mat = sp.csr_matrix(sp.coo_matrix(([0.0] * proj_omega[0].__len__(), proj_omega)))

    if (not calc_val_path == ""):
        if not testing_sample:
            val_file_name = calc_val_path.replace("probe_values_by_users_r.csv", "probe_set.npz")
        else:
            val_file_name = calc_val_path.replace("probe_values_by_users_r.csv", "probe_set_test_samp.npz")
        if not os.path.isfile(val_file_name):
            val_data_temp = []
            if not calc_val_path == "":
                val_file = open(calc_val_path, "r")
                val_nonzero = ([], [])
                lines = val_file.readlines()
                for line in lines:
                    if line.__contains__('|'):
                        head = line.split(',')
                        cur_user = int(head[0])
                    # val_dict[cur_user] = {}
                    else:
                        head = line.replace('\r\n', '').split(',')
                        val_nonzero[0].append(cur_user)
                        movie = int(head[0])
                        val_nonzero[1].append(movie)
                        rating = float(head[1])
                        if normalize_like == "WL08":
                            rating -= (r_bar_params[0][cur_user] + r_bar_params[1][movie] - r_bar_params[2])
                        elif normalize_like == "MM09":
                            rating -= (r_bar_params[0][cur_user] + r_bar_params[1][movie])
                        val_data_temp.append(rating)
                val_file.close()
                del lines
            val_nonzero = tuple(np.asarray(val_nonzero))
            coo = sp.coo_matrix((val_data_temp, val_nonzero)).astype(np.float)
            del val_data_temp
            gc.collect()
            val_data = sp.csr_matrix(coo)
            print("Nonzero entries in val_data: " + str(val_data.get_nonzero()))
            del coo
            gc.collect()
            sp.save_npz(val_file_name, val_data)
            count_val = val_nonzero[0].__len__()
        else:
            val_start_time = timeit.default_timer()
            val_data = sp.load_npz(val_file_name)
            # val_nonzero = val_data.nonzero()
            count_val = val_nonzero[0].__len__()
            print("Total ratings in val_data: " + str(val_data.nnz))
            print("count_val: " + str(count_val))
            row_nonz = val_data.getnnz(axis=1)
            zero_ratings = 0
            for ele in row_nonz:
                if ele == 0:
                    zero_ratings += 1
            print("Users with 0 ratings in val data: " + str(zero_ratings))
            ones_val = sp.csr_matrix(sp.coo_matrix(([1] * count_val, val_nonzero)))
            m_val, n_val = val_data.shape
            if m < m_val:
                print("Validation set contains row(s) not present in training set.")
            if n < n_val:
                print("Validation set contains column(s) not present in training set.")

            if (m_val < m) or (n_val < n):
                val_data._shape = (m, n)
                for _ in range(m - m_val):
                    val_data.indptr = np.append(val_data.indptr, val_data.indptr[-1])
            print("Shape of val data: " + str(val_data.shape))
            m_val, n_val = ones_val.shape
            if m < m_val:
                print("Validation set contains row(s) not present in training set.")
            if n < n_val:
                print("Validation set contains column(s) not present in training set.")

            if (m_val < m) or (n_val < n):
                ones_val._shape = (m, n)
                for _ in range(m - m_val):
                    ones_val.indptr = np.append(ones_val.indptr, ones_val.indptr[-1])
            print("Shape of ones_val: " + str(ones_val.shape))
            if normalize_like == "WL08":
                r_bar_val = sp.csr_matrix(sp.coo_matrix(([r_bar_params[2]] * count_val, val_nonzero)))

                if (m_val < m) or (n_val < n):
                    r_bar_val._shape = (m, n)
                    for _ in range(m - m_val):
                        r_bar_val.indptr = np.append(r_bar_val.indptr, r_bar_val.indptr[-1])

                r_bar_u_diag = sp.csr_matrix(
                    sp.coo_matrix((r_bar_params[0], (range(len(r_bar_params[0])), range(len(r_bar_params[0]))))))
                r_bar_m_diag = sp.csr_matrix(
                    sp.coo_matrix((r_bar_params[1], (range(len(r_bar_params[1])), range(len(r_bar_params[1]))))))
                val_data -= (r_bar_u_diag.dot(ones_val) + ones_val.dot(r_bar_m_diag) - r_bar_val)
                del r_bar_val, r_bar_u_diag, r_bar_m_diag
                gc.collect()
            elif normalize_like == "JS10" or normalize_like == "JS10v2":
                r_bar_u_diag = sp.csr_matrix(
                    sp.coo_matrix((r_bar_params[0], (range(len(r_bar_params[0])), range(len(r_bar_params[0]))))))
                r_bar_m_diag = sp.csr_matrix(
                    sp.coo_matrix((r_bar_params[1], (range(len(r_bar_params[1])), range(len(r_bar_params[1]))))))
                avg_val_mat = (r_bar_u_diag.dot(ones_val) + ones_val.dot(r_bar_m_diag)) / 2
                if normalize_like == "JS10v2":
                    val_data -= avg_val_mat
                del r_bar_u_diag, r_bar_m_diag
                gc.collect()
            elif normalize_like == "Only_U_avg":
                r_bar_u_diag = sp.csr_matrix(
                    sp.coo_matrix((r_bar_params[0], (range(len(r_bar_params[0])), range(len(r_bar_params[0]))))))
                # val_data -= r_bar_u_diag.dot(ones_val)
                # del r_bar_u_diag
                gc.collect()
            elif normalize_like == "MM09":
                r_bar_u_diag = sp.csr_matrix(
                    sp.coo_matrix((r_bar_params[0], (range(len(r_bar_params[0])), range(len(r_bar_params[0]))))))
                r_bar_m_diag = sp.csr_matrix(
                    sp.coo_matrix((r_bar_params[1], (range(len(r_bar_params[1])), range(len(r_bar_params[1]))))))
                val_data -= (r_bar_u_diag.dot(ones_val) + ones_val.dot(r_bar_m_diag))
                del r_bar_u_diag, r_bar_m_diag
                gc.collect()
            val_elapsed = timeit.default_timer() - val_start_time
            print("Val data loaded in " + str(int(val_elapsed)) + " seconds.")

        err_val_mat = sp.csr_matrix(sp.coo_matrix(([0.0] * count_val, val_nonzero)))

    if calc_val_path == "":
        tot_nonzero = proj_omega
    # else:
        # tot_nonzero = (Y_star + val_data).nonzero()

        # tot_nonzero = np.concatenate((proj_omega, val_nonzero), axis=1)
        # tot_nonzero = list(set(zip(*tot_nonzero)))
        # tot_nonzero.sort()
        # tot_nonzero = tuple(np.array(zip(*tot_nonzero)))
    if subtract_avg_extra_movies:
        extra_movies = list(set(val_nonzero[1]) - set(proj_omega[1]))
        Y_star_avg = Y_star.sum() / len(proj_omega[0])
        count_extra_val = 0
        print("Length of extra movies: " + str(len(extra_movies)))
        if len(extra_movies) > 0:
            for i, j in enumerate(val_nonzero[1]):
                if j in extra_movies:
                    val_data[val_nonzero[0][i], j] -= Y_star_avg
                    count_extra_val += 1
            print("Avg " + str(Y_star_avg) + " subtracted from " + str(
                count_extra_val) + " ratings in the validation set with extra movies.")

    print("Length of tot_nonzero: " + str(tot_nonzero[0].__len__()))

    if ratings_threshold_for_movie > 0:
        thresh_vec = (ratings_per_movie >= ratings_threshold_for_movie).astype(int)
        thresh_vec = thresh_vec.reshape((1, len(thresh_vec)))
        thresh_cov = thresh_vec.T * thresh_vec

    UVT1 = sp.csr_matrix(sp.coo_matrix(([1] * len(tot_nonzero[0]), tot_nonzero)))

    if pairwiseFW > 0:
        S_U = [None] * pairwiseFW
        S_V = [None] * pairwiseFW
        S_lr = [1.0] * pairwiseFW

    start_iter = 0
    if load_from_prev_ckpt:
        check_load_file_arr = glob.glob(Y_check_file + "*" + Y_check_file_end)
        if len(check_load_file_arr) > 0:
            print("Previous checkpoint found. Loading from latest one.")
            ind_to_load = -1
            max_iter_till_now = 0
            for ind_ckpt in range(len(check_load_file_arr)):
                file_ckpt = check_load_file_arr[ind_ckpt]
                iter_cur = int(file_ckpt.split("_")[-1].replace(Y_check_file_end, ""))
                if iter_cur > max_iter_till_now:
                    max_iter_till_now = iter_cur
                    ind_to_load = ind_ckpt
            Y_check_load_file = check_load_file_arr[ind_to_load]
            start_iter = int(Y_check_load_file.split("_")[-1].replace(Y_check_file_end, "")) + 1
            Y_pred = sp.load_npz(Y_check_load_file)
            V_check_load_file = Y_check_load_file.replace("Y", "V").replace(Y_check_file_end, V_check_file_end)
            V = np.load(V_check_load_file)
            lambda_check_load_file = Y_check_load_file.replace("Y", "lambda").replace(Y_check_file_end,
                                                                                      lambda_check_file_end)
            lambda_1 = np.load(lambda_check_load_file)
            X[proj_omega] = Y_pred[proj_omega] - Y_star[proj_omega]
            print("Previous checkpoint loaded.")
        else:
            Y_pred = sp.csr_matrix(sp.coo_matrix(([0.0] * tot_nonzero[0].__len__(), tot_nonzero)))
    else:
        if not calc_on_all_indices:
            Y_pred = sp.csr_matrix(sp.coo_matrix(([0.0] * tot_nonzero[0].__len__(), tot_nonzero)))
        else:
            Y_pred = np.zeros((m, n))

    print("Starting FW from iteration " + str(start_iter))
    if eps == 0:
        sigma = 0
    for t in range(start_iter, T + 1):
        print("iteration " + str(t))
        start_time = timeit.default_timer()
        if t > 0:
            U_start_time = timeit.default_timer()
            # V = np.reshape(V, (np.shape(V)[0],1))
            # print("Number of zero entries in V: " + str(n - np.count_nonzero(V)))
            # zero_V = np.where(V == 0)[0]
            # print("Zero entry movies: " + str(zero_V))
            if ojas:
                U = (X.dot(V.T)) / (lambda_1)
            else:
                U = (X * V) / (lambda_1)

            if pairwiseFW > 0:
                S_U[t % pairwiseFW] = U
                S_V[t % pairwiseFW] = V

            U_elapsed = timeit.default_timer() - U_start_time
            print("U constructed in " + str(int(U_elapsed)) + " seconds.")
            UVT_start_time = timeit.default_timer()

            if calc_on_all_indices:
                kUVT = k * U.reshape((943, 1)) * V.T.reshape((1, 1682))
            else:
                if ojas:
                    v_len = V.shape[1]
                    u_len = U.shape[0]
                else:
                    v_len = len(V)
                    u_len = len(U)
                U_UVT = sp.csr_matrix(sp.coo_matrix((np.array(U).flatten(), (range(u_len), range(u_len))))).dot(UVT1)
                kUVT = U_UVT.dot(sp.csr_matrix(sp.coo_matrix((np.array(V).flatten(), (range(v_len), range(v_len)))))) * float(k)
                del U, U_UVT
                gc.collect()

            # UVT = sp.coo_matrix((np.concatenate([U[tot_nonzero[0][ind]]*V[tot_nonzero[1][ind]] for ind in range(tot_nonzero[0].__len__())], axis=0), (tot_nonzero[0], tot_nonzero[1])))
            # kUVT = sp.csr_matrix(UVT) * float(k)
            # del UVT
            # gc.collect()

            UVT_elapsed = timeit.default_timer() - UVT_start_time
            print("UVT constructed in " + str(int(UVT_elapsed)) + " seconds.")

            if line_search:
                lr_start_time = timeit.default_timer()
                lr_max = 1.0
                if pairwiseFW > 0:
                    pw_start_time = timeit.default_timer()
                    max_val = -1e10
                    max_ind = -1
                    for ind in range(pairwiseFW):
                        if (S_U[ind] is not None) and (S_V[ind] is not None) and (not (ind == (t % pairwiseFW))):
                            pfw_U_UVT = sp.csr_matrix(
                                sp.coo_matrix((S_U[ind].flatten(), (range(len(S_U[ind])), range(len(S_U[ind])))))).dot(
                                UVT1)
                            pfw_kUVT = pfw_U_UVT.dot(
                                sp.csr_matrix(sp.coo_matrix(
                                    (S_V[ind].flatten(), (range(len(S_V[ind])), range(len(S_V[ind]))))))) * float(k)
                            del pfw_U_UVT
                            gc.collect()
                            cur_val = (X.multiply(pfw_kUVT)).sum()
                            del pfw_kUVT
                            gc.collect()
                            max_val = max(max_val, cur_val)
                            if max_val == cur_val:
                                max_ind = ind
                    if max_ind >= 0:
                        lr_max = S_lr[max_ind]
                    pw_elapsed = timeit.default_timer() - pw_start_time
                    print("Max ind for pairwiseFW constructed in " + str(int(pw_elapsed)) + " seconds.")

                UVT_diff = sp.csr_matrix(sp.coo_matrix(([0.0] * proj_omega[0].__len__(), proj_omega)))
                UVT_diff[proj_omega] = kUVT[proj_omega] + Y_pred[proj_omega]
                lr_num = (X.multiply(UVT_diff)).sum()
                lr_denom = math.pow(ssl.norm(UVT_diff), 2)
                print("lr_num: " + str(lr_num))
                print("lr_denom: " + str(lr_denom))
                del UVT_diff
                gc.collect()
                if eps > 0 and private_line_search:
                    lr_num += np.random.laplace(scale=(2 * L * (L + k)) / eps)
                    lr_denom += np.random.laplace(scale=math.pow(L + k, 2) / eps)
                lr = max(0, min(lr_max, lr_num / lr_denom))
                if write == 1:
                    if not os.path.isfile(lrfile):
                        with open(lrfile, 'w') as lr_myfile:
                            writer = csv.writer(lr_myfile)
                            writer.writerow([m, n])
                            writer.writerow([lr_num_label])
                            writer.writerow([lr_num])
                            writer.writerow([lr_denom_label])
                            writer.writerow([lr_denom])
                            writer.writerow([lr_label])
                            writer.writerow([lr])
                    else:
                        with open(lrfile, "r") as myfile:
                            reader = csv.reader(myfile)
                            title_row = next(reader)
                            num_str = next(reader)
                            lr_num_arr = next(reader)[0:t - 1]
                            lr_num_arr.append(lr_num)
                            denom_str = next(reader)
                            lr_denom_arr = next(reader)[0:t - 1]
                            lr_denom_arr.append(lr_denom)
                            lr_str = next(reader)
                            lr_arr = next(reader)[0:t - 1]
                            lr_arr.append(lr)
                        with open(lrfile, "w") as lr_myfile:
                            writer = csv.writer(lr_myfile)
                            writer.writerow(title_row)
                            writer.writerow(num_str)
                            writer.writerow(lr_num_arr)
                            writer.writerow(denom_str)
                            writer.writerow(lr_denom_arr)
                            writer.writerow(lr_str)
                            writer.writerow(lr_arr)
                            print("Updating lr file done.")
                if pairwiseFW > 0:
                    S_lr[t % pairwiseFW] = lr
                lr_elapsed = timeit.default_timer() - lr_start_time
                print("Learning rate: " + str(lr) + " constructed in " + str(int(lr_elapsed)) + " seconds.")
            else:
                lr = lr_const / t
            upd_start_time = timeit.default_timer()
            # Y_pred[tot_nonzero] = (1.0 - lr) * Y_pred[tot_nonzero] - (lr * kUVT[tot_nonzero])
            if pairwiseFW > 0 and max_ind >= 0:
                U_UVT = sp.csr_matrix(
                    sp.coo_matrix(
                        (S_U[max_ind].flatten(), (range(len(S_U[max_ind])), range(len(S_U[max_ind])))))).dot(
                    UVT1)
                B_t = U_UVT.dot(
                    sp.csr_matrix(
                        sp.coo_matrix(
                            (S_V[max_ind].flatten(),
                             (range(len(S_V[max_ind])), range(len(S_V[max_ind]))))))) * float(
                    k)
                del U_UVT
                gc.collect()
                D_t = kUVT + B_t
                del B_t
                gc.collect()
            else:
                D_t = kUVT + Y_pred
            Y_pred -= lr * D_t
            # print("Number of zero entries in Y_pred: " + str(len(tot_nonzero[0]) - Y_pred.count_nonzero()))
            # nonz_pred = sp.find(Y_pred)
            # zip_pred = zip(nonz_pred[0], nonz_pred[1])
            # zeroed_out = list(set(zip_tot_nonz) - set(zip_pred))
            # not_in_zero_V = []
            # for ele in zeroed_out:
            #     if not ele[1] in zero_V:
            #         not_in_zero_V.append(ele)
            # print("Zero entries not in zero_V: " + str(not_in_zero_V))
            # zero_V_in_train = []
            # for ele in zero_V:
            #     if ele in proj_omega[1]:
            #         zero_V_in_train.append(ele)
            # print("Movies zeroed in V but in training set: " + str(zero_V_in_train))
            # print("Number of zero entries in Y_pred from val set: " + str(len(val_nonzero[0]) - np.count_nonzero(Y_pred[val_nonzero])))

            del kUVT, D_t
            gc.collect()
            upd_elapsed = timeit.default_timer() - upd_start_time
            print("Update done in " + str(int(upd_elapsed)) + " seconds.")

            if eps > 0 and do_projection:
                proj_start_time = timeit.default_timer()
                norm_Y_pred = ssl.norm(Y_pred, axis=1)
                with np.errstate(divide='ignore', invalid='ignore'):
                    proj_pi = np.true_divide([2 * L] * len(norm_Y_pred), norm_Y_pred)
                    proj_pi[~ np.isfinite(proj_pi)] = 0
                # proj_pi = (2 * L) / norm_Y_pred
                proj_pi[proj_pi > 1] = 1.0
                Y_pred = sp.csr_matrix(sp.coo_matrix((proj_pi, (range(len(proj_pi)), range(len(proj_pi))))).dot(Y_pred))
                del norm_Y_pred
                del proj_pi
                gc.collect()
                proj_elapsed = timeit.default_timer() - proj_start_time
                print("Projection done in " + str(int(proj_elapsed)) + " seconds.")
        cov_start_time = timeit.default_timer()
        X[proj_omega] = Y_pred[proj_omega] - Y_star[proj_omega]
        if centraldp == 1:
            X += sp.csr_matrix(sp.coo_matrix((np.random.normal(0, sigma, proj_omega[0].__len__()), proj_omega)))

        W_t = X.T * X
        # print "W_t:", W_t[0]
        if calibrate_noise:
            if step_const==1 and T < t + step_multiplier * step_const:
                eps_cal = eps / np.sqrt(T)
            elif T > t + step_multiplier * (step_const + 1):
                eps_cal = eps/(pow(2, step_const) * np.sqrt(step_multiplier * step_const))
            else:
                eps_cal = eps / (pow(2, step_const) * np.sqrt(T - (last_step + step_multiplier * step_const)))
            if eps > 0 and centraldp == 0:
                sigma = pow(L, 2) * np.sqrt(np.log(1.0 / delta))/eps_cal
            if t == last_step + step_multiplier * step_const:
                if T > t + step_multiplier * (step_const + 1):
                    step_const += 1
                    last_step = t
        if not ojas:
            W_t = W_t.todense()
            if centraldp == 0 and eps > 0:
                print("sigma: " + str(sigma))
                W_t += np.random.normal(0, sigma, (n, n))
            if ratings_threshold_for_movie > 0:
                W_t = np.multiply(W_t, thresh_cov)
            cov_elapsed = timeit.default_timer() - cov_start_time
            print("Cov done in " + str(int(cov_elapsed)) + " seconds.")
            svd_start_time = timeit.default_timer()
            sing_1, V = top_svd(W_t)
        else:
            if t == 0:
                V = np.random.normal(0, sigma, (1,n))
            cov_elapsed = timeit.default_timer() - cov_start_time
            print("Cov done in " + str(int(cov_elapsed)) + " seconds.")
            svd_start_time = timeit.default_timer()
            sing_1, V = ojas_alg(W_t, sigma, V)
        del W_t
        gc.collect()
        lambda_1 = np.sqrt(sing_1)
        svd_elapsed = timeit.default_timer() - svd_start_time
        print("SVD done in " + str(int(svd_elapsed)) + " seconds.")

        if t > 0:
            if checkpoint_save_every > 0 and t % checkpoint_save_every == 0:
                ckpt_start_time = timeit.default_timer()
                if delete_prev_ckpt:
                    check_load_file_arr = glob.glob(Y_check_file + "*" + Y_check_file_end)
                    if len(check_load_file_arr) > 0:
                        print("Deleting previous checkpoint.")
                        ind_to_load = -1
                        max_iter_till_now = 0
                        for ind_ckpt in range(len(check_load_file_arr)):
                            file_ckpt = check_load_file_arr[ind_ckpt]
                            iter_cur = int(file_ckpt.split("_")[-1].replace(Y_check_file_end, ""))
                            if iter_cur > max_iter_till_now:
                                max_iter_till_now = iter_cur
                                ind_to_load = ind_ckpt
                        Y_check_load_file = check_load_file_arr[ind_to_load]
                        os.remove(Y_check_load_file)
                        V_check_load_file = Y_check_load_file.replace("Y", "V").replace(Y_check_file_end,
                                                                                        V_check_file_end)
                        os.remove(V_check_load_file)
                        lambda_check_load_file = Y_check_load_file.replace("Y", "lambda").replace(Y_check_file_end,
                                                                                                  lambda_check_file_end)
                        os.remove(lambda_check_load_file)
                Y_check_save_file = Y_check_file + "_" + str(t) + Y_check_file_end
                sp.save_npz(Y_check_save_file, Y_pred)
                V_check_save_file = Y_check_save_file.replace("Y", "V").replace(Y_check_file_end, V_check_file_end)
                np.save(V_check_save_file, V)
                lambda_check_save_file = Y_check_save_file.replace("Y", "lambda").replace(Y_check_file_end,
                                                                                          lambda_check_file_end)
                np.save(lambda_check_save_file, lambda_1)
                ckpt_elapsed = timeit.default_timer() - ckpt_start_time
                print("Checkpoint done in " + str(int(ckpt_elapsed)) + " seconds.")

            val_start_time = timeit.default_timer()
            print("Err done.")

            if normalize_like == "JS10":
                scaled_err_mat[proj_omega] = np.multiply(X[proj_omega], avg_proj_mat[proj_omega])
                rmse_err_sq = scaled_err_mat.power(2).sum()
            else:
                rmse_err_sq = X.power(2).sum()
            rmse_err = math.sqrt(rmse_err_sq / count_rmse)
            print("train error: " + str(rmse_err))

            if run_on_dataset == dataset[1] and calculate_nmae:
                nmae_err = abs(X).sum() / (4 * count_rmse)
                print("nmae train error: " + str(nmae_err))

            if not calc_val_path == "":
                if normalize_like == "Only_U_avg":
                    if calc_on_all_indices:
                        err_val_mat[val_nonzero] = Y_pred[val_nonzero] + r_bar_u_diag.dot(ones_val)[val_nonzero]
                        nz_row = np.array(val_nonzero[0])
                        nz_col = np.array(val_nonzero[1])
                        large_inds = np.array(err_val_mat[val_nonzero] > range_ratings)[0]
                        err_val_mat[(nz_row[large_inds], nz_col[large_inds])] = range_ratings
                        small_inds = np.array(err_val_mat[val_nonzero] < 0)[0]
                        err_val_mat[(nz_row[small_inds], nz_col[small_inds])] = 0.0
                        err_val_mat[val_nonzero] -= val_data[val_nonzero]
                    else:
                        err_val_mat = Y_pred.multiply(ones_val) + r_bar_u_diag.dot(ones_val)
                        nz_row = np.array(val_nonzero[0])
                        nz_col = np.array(val_nonzero[1])
                        large_inds = np.array(err_val_mat[val_nonzero] > range_ratings)[0]
                        err_val_mat[(nz_row[large_inds], nz_col[large_inds])] = range_ratings
                        small_inds = np.array(err_val_mat[val_nonzero] < 0)[0]
                        err_val_mat[(nz_row[small_inds], nz_col[small_inds])] = 0.0
                        err_val_mat -= val_data

                elif normalize_like == "JS10":
                    err_val_mat[val_nonzero] = np.multiply(Y_pred[val_nonzero], avg_val_mat[val_nonzero]) - val_data[
                        val_nonzero]
                else:
                    if calc_on_all_indices:
                        err_val_mat[val_nonzero] = Y_pred[val_nonzero] - val_data[val_nonzero]
                    else:
                        err_val_mat = Y_pred.multiply(ones_val) - val_data
                val_err_sq = err_val_mat.power(2).sum()
                val_err = math.sqrt(val_err_sq / count_val)
                print("val error: " + str(val_err))
                if run_on_dataset == dataset[1] and calculate_nmae:
                    nmae_val_err = abs(err_val_mat).sum() / (4 * count_val)
                    print("nmae val error: " + str(nmae_val_err))
            if write == 1:
                if not os.path.isfile(resfile):
                    with open(resfile, 'w') as myfile:
                        writer = csv.writer(myfile)
                        writer.writerow([m, n])
                        writer.writerow([reslabel])
                        writer.writerow([rmse_err])
                        if not calc_val_path == "":
                            writer.writerow(["val " + reslabel])
                            writer.writerow([val_err])
                        myfile.close()
                else:
                    with open(resfile, "r") as myfile:
                        reader = csv.reader(myfile)
                        title_row = next(reader)
                        tr_err_str = next(reader)
                        tr_err_arr = next(reader)[0:t - 1]
                        tr_err_arr.append(rmse_err)
                        if not calc_val_path == "":
                            val_err_str = next(reader)
                            val_err_arr = next(reader)[0:t - 1]
                            val_err_arr.append(val_err)
                        myfile.close()

                    with open(resfile, "w") as res_myfile:
                        writer = csv.writer(res_myfile)
                        writer.writerow(title_row)
                        writer.writerow(tr_err_str)
                        writer.writerow(tr_err_arr)
                        if not calc_val_path == "":
                            writer.writerow(val_err_str)
                            writer.writerow(val_err_arr)
                        res_myfile.close()
                        print("Updating validation file done.")

                if run_on_dataset == dataset[1] and calculate_nmae:
                    if not os.path.isfile(nmae_file):
                        with open(nmae_file, 'w') as myfile:
                            writer = csv.writer(myfile)
                            writer.writerow([m, n])
                            writer.writerow([nmaelabel])
                            writer.writerow([nmae_err])
                            if not calc_val_path == "":
                                writer.writerow(["val " + nmaelabel])
                                writer.writerow([nmae_val_err])
                            myfile.close()
                    else:
                        with open(nmae_file, "r") as myfile:
                            reader = csv.reader(myfile)
                            title_row = next(reader)
                            tr_err_str = next(reader)
                            tr_err_arr = next(reader)[0:t - 1]
                            tr_err_arr.append(nmae_err)
                            if not calc_val_path == "":
                                val_err_str = next(reader)
                                val_err_arr = next(reader)[0:t - 1]
                                val_err_arr.append(nmae_val_err)
                            myfile.close()
                        with open(nmae_file, "w") as nmae_myfile:
                            writer = csv.writer(nmae_myfile)
                            writer.writerow(title_row)
                            writer.writerow(tr_err_str)
                            writer.writerow(tr_err_arr)
                            if not calc_val_path == "":
                                writer.writerow(val_err_str)
                                writer.writerow(val_err_arr)
                            nmae_myfile.close()
                            print("Updating nmae validation file done.")
            val_elapsed = timeit.default_timer() - val_start_time
            print("Val error done in " + str(int(val_elapsed)) + " seconds.")
        # if val_err <= 0.93 and run_on_complete_data:
        #     break
        elapsed = timeit.default_timer() - start_time
        print("Iteration done in " + str(int(elapsed)) + " seconds.")

    del Y_pred
    gc.collect()
    os.rename(resfile, final_res_file)
    if line_search:
        os.rename(lrfile, final_lrfile)


def ojas_alg(W, sigma, v):
    n = W.shape[0]
    _, S, _ = ssl.svds(W, min(n - 1, 5))
    eta = S[0]
    v_t = (np.eye(n) + eta * W).dot(v.T).T + eta * np.random.normal(0, sigma, v.shape)
    if sl.norm(v_t) > 0:
        v_t = v_t/sl.norm(v_t)
    sing_t = np.linalg.norm(W.dot(v_t.T)) + np.random.normal(0, sigma)
    return sing_t, v_t


def gen_results_with_data(Y_star, T, k, L, eps_arr, delta, beta, proj_omega, val_nonzero, tot_nonzero, calc_val_path="",
                          ratings_per_movie=[], ratings_threshold_for_movie=0, r_bar_params=[], write=1,
                          max_samp=0, lr_const=0, force_k=0, step_multiplier=0, range_ratings=5):
    if compute_non_private:
        eps_arr = [0] + eps_arr

    if compute_globally_private:
        eps_arr.append(eps_arr[-1])

    eps_len = eps_arr.__len__()
    centraldp = 0

    for ind in range(eps_len):
        eps = eps_arr[ind]
        print("eps: " + str(eps))
        if compute_globally_private and ind == eps_len - 1:
            centraldp = 1
            print("central dp")

        private_FW(Y_star, k, L, T, eps, delta, beta,
                   calc_val_path=calc_val_path, centraldp=centraldp,
                   ratings_per_movie=ratings_per_movie,
                   ratings_threshold_for_movie=ratings_threshold_for_movie,
                   r_bar_params=r_bar_params,
                   write=write, max_samp=max_samp, lr_const=lr_const,
                   force_k = force_k, step_multiplier=step_multiplier,
                   proj_omega=proj_omega, val_nonzero=val_nonzero, tot_nonzero=tot_nonzero,
                   ojas=ojas, range_ratings=range_ratings)


def count_ratings_per_movie(path=""):
    num_ratings = np.zeros(17770)
    tot = np.size(glob.glob(path + '*.csv'))
    for ind in range(1, tot + 1):
        user_file = path + "user_values_combined_" + str(ind) + "_sampled_r.csv"
        with open(user_file, "r") as myfile:
            for line in myfile:
                if not line.__contains__('|'):
                    line.replace('\r\n', '')
                    head = line.split(',')
                    num_ratings[int(float(head[0]))] += 1
            myfile.close()
            print("Counts from " + user_file + " loaded.")
    print("Counts loaded in function")
    return num_ratings


def get_data(path="", get_both=True, ratings_per_movie=[]):
    data_start_time = timeit.default_timer()
    Y = []
    Y_star = []
    if run_on_complete_data or (run_on == run_platforms[0] and run_on_unsampled_data and run_on_dataset == dataset[0]):
        sources = ["training_set_r//", "sampled_set_r//"]
    else:
        sources = ["user_data_combined_r//", "initial//"]
    if run_on_unsampled_data:
        sources[1] = sources[0]
    for inde in range(sources.__len__()):
        if (inde == 0 and not get_both and not run_on_unsampled_data) or (inde == 1 and run_on_unsampled_data):
            continue
        data = []
        row = []
        col = []
        initial_data_path = path + sources[inde]
        print("Getting data from: " + initial_data_path)
        tot = np.size(glob.glob(initial_data_path + '*.csv'))
        for ind in range(1, tot + 1):
            if inde == 0:
                user_file = initial_data_path + "user_values_combined_" + str(ind) + "_r.csv"
            else:
                user_file = initial_data_path + "user_values_combined_" + str(ind) + "_sampled_r.csv"
            with open(user_file, "r") as myfile:
                lines = myfile.readlines()
                for line in lines:
                    if not line.__contains__('|'):
                        line.replace('\r\n', '')
                        head = line.split(',')
                        if run_on_complete_data or (run_on_unsampled_data and run_on_dataset == dataset[0]):
                            rating = float(head[1])
                            row.append(curr_user)
                            movie = int(float(head[0]))
                            col.append(movie)
                            if (ratings_threshold_for_movie == 0) or (
                                        ratings_per_movie[movie] >= ratings_threshold_for_movie):
                                data.append(rating)
                            else:
                                data.append(2.5)
                        else:
                            for movie, rating in enumerate(head):
                                rating = float(rating)
                                if rating > 0.0:
                                    row.append(curr_user)
                                    col.append(movie)
                                    data.append(rating)
                    else:
                        line.replace('\r\n', '')
                        head = line.split(',')
                        curr_user = int(head[0])
                myfile.close()
                del lines
                print("Data from " + user_file + " loaded.")
        if inde == 0:
            Y = sp.csr_matrix(sp.coo_matrix((data, (row, col))))
        elif inde == 1:
            Y_star = sp.csr_matrix(sp.coo_matrix((data, (row, col))))
        del data
        del row
        del col
        gc.collect()
    data_elapsed = timeit.default_timer() - data_start_time
    print("Data loaded in function in " + str(int(data_elapsed)) + " seconds.")
    return Y, Y_star


def replace_ratings_threshold(Y, ratings_per_movie, replace_rating=2.5):
    m, n = Y.shape
    for movie in range(n):
        if ratings_per_movie[movie] < ratings_threshold_for_movie:
            Y[:, movie] = replace_rating
    return Y


def replace_ratings_threshold_in_memory(Y, Y_star, replace_rating=2.5):
    nnz = Y.nonzero()
    ratings_per_movie = Y_star.getnnz(axis=0)
    for ind in range(nnz[0].__len__()):
        movie = nnz[1][ind]
        if ratings_per_movie[movie] < ratings_threshold_for_movie:
            Y[nnz[0][ind], movie] = replace_rating
    return Y, ratings_per_movie


def normalize_data_WL08(Y_star, Y=[], get_both=True):
    tr_start_time = timeit.default_timer()
    row_sums = np.array(Y_star.sum(axis=1).flatten())
    row_nonz = Y_star.getnnz(axis=1)
    tot_ratings = row_nonz.sum()
    col_sums = np.array(Y_star.sum(axis=0))
    col_nonz = Y_star.getnnz(axis=0)
    with np.errstate(divide='ignore', invalid='ignore'):
        r_tilde_m_temp = np.true_divide(col_sums, col_nonz)
        r_tilde_m = r_tilde_m_temp[0]
        r_tilde_m[~ np.isfinite(r_tilde_m)] = 0
        r_tilde_u_temp = np.true_divide(row_sums, row_nonz)
        r_tilde_u = r_tilde_u_temp[0]
        r_tilde_u[~ np.isfinite(r_tilde_u)] = 0
    r_bar = row_sums.sum() / tot_ratings
    del row_sums, col_sums, r_tilde_m_temp, r_tilde_u_temp
    gc.collect()

    if run_on_dataset == dataset[0]:
        kappa_1 = 50.0 * (float(tot_ratings) / (100480507 - 1408395))
        kappa_2 = 2 * kappa_1
    else:
        if ml_data_str == "ml-100k//":
            kappa_1 = 25.0
            kappa_2 = 5.0
        elif ml_data_str == "ml-1m//":
            kappa_1 = 25.0
            kappa_2 = 15.0
        else:
            kappa_1 = 25.0
            kappa_2 = 50.0
    print("tot_ratings: " + str(tot_ratings))
    print("kappa_1: " + str(kappa_1))
    print("kappa_2: " + str(kappa_2))

    r_bar_u = r_bar + (row_nonz / (row_nonz + kappa_1)) * (r_tilde_u - r_bar)
    r_bar_m = r_bar + (col_nonz / (col_nonz + kappa_2)) * (r_tilde_m - r_bar)

    del r_tilde_m, r_tilde_u
    gc.collect()

    proj_omega = Y_star.nonzero()
    ones_p_omega = sp.csr_matrix(sp.coo_matrix(([1] * tot_ratings, proj_omega)))
    r_bar_omega = sp.csr_matrix(sp.coo_matrix(([r_bar] * tot_ratings, proj_omega)))
    r_bar_u_diag = sp.csr_matrix(sp.coo_matrix((r_bar_u, (range(len(r_bar_u)), range(len(r_bar_u))))))
    r_bar_m_diag = sp.csr_matrix(sp.coo_matrix((r_bar_m, (range(len(r_bar_m)), range(len(r_bar_m))))))
    Y_star -= (r_bar_u_diag.dot(ones_p_omega) + ones_p_omega.dot(r_bar_m_diag) - r_bar_omega)
    del proj_omega, ones_p_omega
    gc.collect()

    if get_both:
        proj_tot = Y.nonzero()
        proj_tot_ratings = len(proj_tot[0])
        r_bar_proj_tot = sp.csr_matrix(sp.coo_matrix(([r_bar] * proj_tot_ratings, proj_tot)))
        ones_p_tot = sp.csr_matrix(sp.coo_matrix(([1] * proj_tot_ratings, proj_tot)))
        Y -= (r_bar_u_diag.dot(ones_p_tot) + ones_p_tot.dot(r_bar_m_diag) - r_bar_proj_tot)
        del proj_tot, ones_p_tot
        gc.collect()
    r_bar_params = [r_bar_u, r_bar_m, r_bar]
    tr_elapsed = timeit.default_timer() - tr_start_time
    print("Data normalized in function in " + str(int(tr_elapsed)) + " seconds.")
    print("Average rating of Y_star: " + str(r_bar))
    return Y, Y_star, r_bar_params


def normalize_data_MM09(Y_star, Y=[], get_both=True):
    tr_start_time = timeit.default_timer()
    col_sums = np.array(Y_star.sum(axis=0))
    col_nonz = Y_star.getnnz(axis=0)
    tot_ratings = col_nonz.sum()
    r_bar = col_sums.sum() / tot_ratings
    beta_m = 15.0
    beta_p = 20.0
    print("tot_ratings: " + str(tot_ratings))
    print("beta_m: " + str(beta_m))
    print("beta_p: " + str(beta_p))
    proj_omega = Y_star.nonzero()
    ones_p_omega = sp.csr_matrix(sp.coo_matrix(([1] * tot_ratings, proj_omega)))

    r_bar_m_temp = (col_sums + beta_m * r_bar) / (col_nonz + beta_m)
    r_bar_m = r_bar_m_temp[0]
    r_bar_m_diag = sp.csr_matrix(sp.coo_matrix((r_bar_m, (range(len(r_bar_m)), range(len(r_bar_m))))))
    Y_star -= ones_p_omega.dot(r_bar_m_diag)

    row_sums = np.array(Y_star.sum(axis=1).flatten())
    row_nonz = Y_star.getnnz(axis=1)
    r_bar_u_temp = (row_sums + beta_p * r_bar) / (row_nonz + beta_p)
    r_bar_u = r_bar_u_temp[0]
    r_bar_u_diag = sp.csr_matrix(sp.coo_matrix((r_bar_u, (range(len(r_bar_u)), range(len(r_bar_u))))))
    Y_star -= r_bar_u_diag.dot(ones_p_omega)

    del proj_omega, ones_p_omega
    gc.collect()

    if get_both:
        proj_tot = Y.nonzero()
        proj_tot_ratings = len(proj_tot[0])
        ones_p_tot = sp.csr_matrix(sp.coo_matrix(([1] * proj_tot_ratings, proj_tot)))
        Y -= (r_bar_u_diag.dot(ones_p_tot) + ones_p_tot.dot(r_bar_m_diag))
        del proj_tot, ones_p_tot
        gc.collect()
    r_bar_params = [r_bar_u, r_bar_m]
    tr_elapsed = timeit.default_timer() - tr_start_time
    print("Data normalized in function in " + str(int(tr_elapsed)) + " seconds.")
    return Y, Y_star, r_bar_params


def normalize_data_JS10(Y_star, Y=[], get_both=True):
    tr_start_time = timeit.default_timer()
    row_sums = np.array(Y_star.sum(axis=1).flatten())
    row_nonz = Y_star.getnnz(axis=1)
    tot_ratings = row_nonz.sum()
    col_sums = np.array(Y_star.sum(axis=0))
    col_nonz = Y_star.getnnz(axis=0)
    with np.errstate(divide='ignore', invalid='ignore'):
        r_tilde_m_temp = np.true_divide(col_sums, col_nonz)
        r_bar_m = r_tilde_m_temp[0]
        r_bar_m[~ np.isfinite(r_bar_m)] = 0
        r_tilde_u_temp = np.true_divide(row_sums, row_nonz)
        r_bar_u = r_tilde_u_temp[0]
        r_bar_u[~ np.isfinite(r_bar_u)] = 0
    del row_sums, col_sums, r_tilde_m_temp, r_tilde_u_temp
    gc.collect()

    print("tot_ratings: " + str(tot_ratings))

    proj_omega = Y_star.nonzero()
    ones_p_omega = sp.csr_matrix(sp.coo_matrix(([1] * tot_ratings, proj_omega)))
    r_bar_u_diag = sp.csr_matrix(sp.coo_matrix((r_bar_u, (range(len(r_bar_u)), range(len(r_bar_u))))))
    r_bar_m_diag = sp.csr_matrix(sp.coo_matrix((r_bar_m, (range(len(r_bar_m)), range(len(r_bar_m))))))
    avg_mat = (r_bar_u_diag.dot(ones_p_omega) + ones_p_omega.dot(r_bar_m_diag)) / 2
    if normalize_like == 'JS10':
        Y_star[proj_omega] /= avg_mat[proj_omega]
    else:
        Y_star[proj_omega] -= avg_mat[proj_omega]
    del proj_omega, ones_p_omega, avg_mat
    gc.collect()

    if get_both:
        proj_tot = Y.nonzero()
        proj_tot_ratings = len(proj_tot[0])
        ones_p_tot = sp.csr_matrix(sp.coo_matrix(([1] * proj_tot_ratings, proj_tot)))
        avg_mat_tot = (r_bar_u_diag.dot(ones_p_tot) + ones_p_tot.dot(r_bar_m_diag)) / 2
        if normalize_like == 'JS10':
            Y[proj_tot] /= avg_mat_tot[proj_tot]
        else:
            Y[proj_tot] -= avg_mat_tot[proj_tot]
        del proj_tot, avg_mat_tot
        gc.collect()
    tr_elapsed = timeit.default_timer() - tr_start_time
    r_bar_params = [r_bar_u, r_bar_m]
    print("Data normalized in function in " + str(int(tr_elapsed)) + " seconds.")
    return Y, Y_star, r_bar_params


def normalize_data_only_u_avg(Y_star, Y=[], get_both=True):
    tr_start_time = timeit.default_timer()
    row_sums = np.array(Y_star.sum(axis=1).flatten()).astype(float)
    row_nonz = Y_star.getnnz(axis=1)
    tot_ratings = row_nonz.sum()
    print("Min. value in Y_star: " + str(Y_star.data.min()))
    zero_ratings = 0
    for i, ele in enumerate(row_nonz):
        if ele == 0.0:
            zero_ratings += 1
    print("Users with 0 ratings: " + str(zero_ratings))
    with np.errstate(divide='ignore', invalid='ignore'):
        r_tilde_u_temp = np.true_divide(row_sums, row_nonz)
        r_bar_u = r_tilde_u_temp[0]
        r_bar_u[~ np.isfinite(r_bar_u)] = 0
    del row_sums, r_tilde_u_temp
    gc.collect()
    print("Min. value in r_bar_u: " + str(np.min(r_bar_u[r_bar_u > 0])))

    print("tot_ratings: " + str(tot_ratings))

    proj_omega = Y_star.nonzero()
    ones_p_omega = sp.csr_matrix(sp.coo_matrix(([1] * tot_ratings, proj_omega)))
    r_bar_u_diag = sp.csr_matrix(sp.coo_matrix((r_bar_u, (range(len(r_bar_u)), range(len(r_bar_u))))))
    Y_star[proj_omega] -= r_bar_u_diag.dot(ones_p_omega)[proj_omega]
    del proj_omega, ones_p_omega
    gc.collect()

    if get_both:
        proj_tot = Y.nonzero()
        proj_tot_ratings = len(proj_tot[0])
        ones_p_tot = sp.csr_matrix(sp.coo_matrix(([1] * proj_tot_ratings, proj_tot)))
        Y[proj_tot] -= r_bar_u_diag.dot(ones_p_tot)[proj_tot]
        del proj_tot
        gc.collect()
    tr_elapsed = timeit.default_timer() - tr_start_time
    r_bar_params = [r_bar_u]
    print("Max. value in Y_star: " + str(max(Y_star.max(), (-1 * Y_star).max())))
    print("Data normalized in function in " + str(int(tr_elapsed)) + " seconds.")
    return Y, Y_star, r_bar_params


# Baseline RMSE with avg rating:  1.12746269824

def calc_baseline_with_avg_rating(calc_val_path="", r_bar=3.66535490655):
    print("Calculating baseline with each rating: " + str(r_bar))
    if not calc_val_path == "":
        err_sq = 0.0
        count_val = 0
        val_file = open(calc_val_path, "r")
        if not run_on == run_platforms[0]:
            lines = val_file.readlines()
        else:
            lines = val_file
        for line in lines:
            if not line.__contains__('|'):
                head = line.replace('\r\n', '').split(',')
                rating = float(head[1])
                err_sq += math.pow(rating - r_bar, 2)
                count_val += 1
        val_file.close()
        if not run_on == run_platforms[0]:
            del lines
        rmse = np.sqrt(err_sq / count_val)
        print("Number of ratings in validation set: " + str(count_val))
        print("Baseline RMSE: " + str(rmse))


def sample_val(Y, frac, sampled_per_row=80, path = ""):
    count = Y.getnnz()
    ind_nnz = Y.nonzero()
    samples = np.random.choice(count, size=int(count * frac), replace=False)
    m, n = Y.shape

    row_arr = []
    col_arr = []
    data = []
    for ele in samples:
        row = ind_nnz[0][ele]
        col = ind_nnz[1][ele]
        row_arr.append(row)
        col_arr.append(col)
        data.append(Y[row, col])
        Y[row, col] = 0.0
    Y.eliminate_zeros()
    val_data = sp.csr_matrix(sp.coo_matrix((data, (row_arr, col_arr))).astype(np.float))
    print("Number of entries in val_data: " + str(val_data.nnz))
    probe_file_name = "probe_set_" + str(m) + "_" + str(n) + "_sampled_" + str(sampled_per_row) + ".npz"
    sp.save_npz(path + probe_file_name, val_data)
    return Y


def createData(a, b, rank=1, sampled_per_row=80, path = ""):
    # rtfm_str = "_rtfm" + str(ratings_threshold_for_movie) if ratings_threshold_for_movie > 0 else ""
    # pwfw_str = "_pwfw" + str(pairwiseFW) if pairwiseFW > 0 else ""
    # uns_str = "_uns" if run_on_unsampled_data else ""
    # force_k_str = "_fk" if force_k > 0.0 else ""
    # max_samp_str = "_max_samp_" + str(sampled_per_row) if not run_on_unsampled_data else ""
    print("Creating synthetic data")
    if not testing_sample:
        assert (rank <= min(a, b)), 'Rank too high w.r.t. the dimensions'
        sampled_per_row = min(b, sampled_per_row)
        print("Sampling " + str(sampled_per_row) + " movies per user.")
        U = np.random.random((a, rank))
        # U_norm = la.norm(U, axis=1)
        # U = np.array([u / U_norm[i] for i, u in enumerate(U)]).transpose()
        VTrans = np.random.random((rank, b))
        # V_norm = la.norm(VTrans, axis=1)
        # VTrans = np.array([v / V_norm[i] for i, v in enumerate(VTrans)])
        # sigma = nucNorm / rank

        sampled_coords = ([], [])
        for ind in range(a):
            samples = np.random.choice(b, size=sampled_per_row, replace=False)
            sampled_coords[0].extend([ind] * sampled_per_row)
            sampled_coords[1].extend(samples)
        ones_nnz = sp.csr_matrix(([1] * a * sampled_per_row, sampled_coords))

        Y = sp.csr_matrix(U.dot(VTrans))
        # params_file = "Params//Synth_users_" + str(a) + "_movies_" + str(b) + \
        #               "_samples_" + str(sampled_per_row) + \
        #               (rtfm_str + pwfw_str + force_k_str + max_samp_str + uns_str) + ".csv"
        # myfile = open(params_file, 'w')
        # writer = csv.writer(myfile)
        # L = np.max(ssl.norm(Y, axis=1))
        # print("L: " + str(L))
        # writer.writerow(["L:" + str(L)])
        # _, sv_Y, _ = ssl.svds(Y, k=rank)
        # k = np.sum(sv_Y)
        # print("k:" + str(k))
        # writer.writerow(["k: " + str(k)])
        # myfile.close()
        dataMatrix = Y.multiply(ones_nnz)
        # norm_Y_pred = ssl.norm(dataMatrix, axis=1)
        # proj_pi = (1.0) / norm_Y_pred
        # # proj_pi[proj_pi > 1] = 1.0
        # dataMatrix = sp.csr_matrix(sp.coo_matrix((proj_pi, (range(len(proj_pi)), range(len(proj_pi))))).dot(dataMatrix))
        # del norm_Y_pred
        # del proj_pi
        # gc.collect()
        dataMatrix = sample_val(dataMatrix, frac=0.01, path=path, sampled_per_row=sampled_per_row)
        file_name = path + "Synth_train_" + str(a) + "_" + str(b) + "_sampled_" + str(sampled_per_row) + ".npz"
        sp.save_npz(file_name, dataMatrix)
    else:
        U = [5, 6, 7, 8, 9]
        U /= la.norm(U)
        U = np.array(U).reshape((5, 1))
        V = [1, 2, 3, 4]
        V /= la.norm(V)
        V = np.array(V).reshape(1, 4)
        non = ([0, 1, 2, 2, 3, 3, 4], [3, 0, 1, 3, 2, 3, 2])
        dataMatrix = sp.csr_matrix((U.dot(V)[non], non))  # .multiply(ones_nnz)
        Y = U.dot(V)
    return Y, dataMatrix


def run_on_data(params_list):
    for params in params_list:
        max_samp = params[0]
        T = params[1]
        lr_const = params[2]
        step_multiplier = params[3]
        force_k = params[4]
        if run_on_dataset == dataset[0]:
            data_str = "Netf_"
            range_ratings = 4
        elif run_on_dataset == dataset[1]:
            data_str = ml_data_str.replace("//", "")
            range_ratings = 4.5
        elif run_on_dataset == dataset[3]:
            data_str = "Yahoo_"
            range_ratings = 5
        elif run_on_dataset == dataset[2]:
            data_str = "Synth_"
            range_ratings = 1
        else:
            data_str = "Jester_"
            range_ratings = 5
        nr_str = "_nr" + normalize_like if normalize_ratings else ""
        rtfm_str = "_rtfm" + str(ratings_threshold_for_movie) if ratings_threshold_for_movie > 0 else ""
        pwfw_str = "_pwfw" + str(pairwiseFW) if pairwiseFW > 0 else ""
        uns_str = "_uns" if run_on_unsampled_data else ""
        force_k_str = "_fk" if force_k > 0.0 else ""
        max_samp_str = "_max_samp_" + str(max_samp) if not run_on_unsampled_data else ""

        if ratings_threshold_for_movie == 0:
            ratings_per_movie = []
        if not run_on == run_platforms[0]:
            if run_on == run_platforms[1]:
                disk_path = ""
            else:
                disk_path = "//mnt//datasets//Data_DP_Frank_Wolfe//"
            if run_on_dataset == dataset[0]:
                if run_on_complete_data:
                    pick_top = 17770
                else:
                    if max_samp == 120:
                        pick_top = 900
                    else:
                        pick_top = 400
            elif run_on_dataset == dataset[2]:
                pick_top = movies
            elif run_on_dataset == dataset[1] and not run_on_complete_data:
                if max_samp == 120:
                    pick_top = 900
                else:
                    pick_top = 400
            elif run_on_dataset == dataset[3] and not run_on_complete_data:
                if max_samp == 160:
                    pick_top = 1600
                elif max_samp == 120:
                    pick_top = 900
                else:
                    pick_top = 400
            elif run_on_dataset == dataset[4]:
                pick_top = 100
            else:
                pick_top = 1682
        else:
            disk_path = "C://Users//Om//Downloads//"
            if run_on_dataset == dataset[0]:
                if run_on_unsampled_data:
                        pick_top = 5
                else:
                    pick_top = 9
            elif run_on_dataset == dataset[1]:
                if ml_data_str == "ml-100k//":
                    pick_top = 943
                elif ml_data_str == "ml-1m//":
                    pick_top = 6040
                else:
                    pick_top = 400
            elif run_on_dataset == dataset[2]:
                pick_top = movies
            elif run_on_dataset == dataset[4]:
                pick_top = 100

        sv_cal = min(k_sum_of_eigs, pick_top - 1)
        if not run_on_dataset == dataset[2]:
            params_file = "Params//" + data_str + "top_" + str(pick_top) + "_k_" + str(sv_cal) + (
                rtfm_str + pwfw_str + nr_str + force_k_str + max_samp_str + uns_str) + ".csv"
        else:
            params_file = "Params//" + data_str + "users_" + str(users) + "_movies_" + str(movies) +\
                          "_samples_" + str(max_samp) + \
                          (rtfm_str + pwfw_str + nr_str + force_k_str + max_samp_str + uns_str) + ".csv"
        if run_on_complete_data:
            if run_on_dataset == dataset[0]:
                path = disk_path + "Netflix_dataset//"
            elif run_on_dataset == dataset[1]:
                path = disk_path + ml_data_str
            elif run_on_dataset == dataset[3]:
                path = disk_path + "Yahoo_dataset//"
            elif run_on_dataset == dataset[4]:
                path = disk_path + "Jester//"
            else:
                path = disk_path + "Synthetic//"
        else:
            if run_on_dataset == dataset[0]:
                if run_on_unsampled_data:
                    path = disk_path + "Netflix_dataset//Demo_dataset//"
                else:
                    path = disk_path + "Netflix_dataset//top" + str(pick_top) + "//"
            elif run_on_dataset == dataset[1]:
                    path = disk_path + ml_data_str
            elif run_on_dataset == dataset[2]:
                path = disk_path + "Synthetic//"
            else:
                path = disk_path + "Yahoo_dataset//top" + str(pick_top) + "//"

        if os.path.isfile(params_file):
                myfile = open(params_file, 'r')
                lines = myfile.readlines()
                L = float(lines[0].split(':')[1])
                k = float(lines[1].split(':')[1])
                print("L and k preloaded from " + params_file)
        else:
            L = 0.0
            k = 0.0

        if force_k > 0.0:
            k = force_k
            print("k changed to: " + str(k))

        print("Initial L: " + str(L) + ", k: " + str(k))
        get_both = (k == 0)
        if run_on_dataset == dataset[2]:
            get_both = False
        max_samp_str = "_max_samp_" + str(max_samp) if not run_on_unsampled_data else ""
        if not run_on_dataset == dataset[2]:
            if not run_on_unsampled_data:
                Y_star_file_name = path + "training_set_sampled" + max_samp_str + ".npz"
            else:
                Y_star_file_name = path + "training_set_complete.npz"
            Y_file_name = path + "training_set_complete.npz"
            print("Searching for file " + Y_star_file_name)
            if not os.path.isfile(Y_star_file_name):
                # if run_on_dataset == dataset[1]:
                cd.const_sampled_training(path=path, max_per_user=max_samp)
                # else:
                #     if run_on_complete_data and ratings_threshold_for_movie > 0:
                #         ratings_per_movie = count_ratings_per_movie(path=path + "initial//")
                #     Y, Y_star = get_data(path=path, get_both=get_both, ratings_per_movie=ratings_per_movie)
                #     save_start_time = timeit.default_timer()
                #     sp.save_npz(Y_star_file_name, Y_star)
                #     sp.save_npz(Y_file_name, Y)
                #     save_elapsed = timeit.default_timer() - save_start_time
                #     print("Saved data in " + str(int(save_elapsed)) + " seconds.")
            data_start_time = timeit.default_timer()
            if run_on_unsampled_data:
                Y_star = sp.load_npz(Y_file_name)
            else:
                Y_star = sp.load_npz(Y_star_file_name)
            print("Total ratings in Y_star: " + str(Y_star.count_nonzero()))
            if get_both:
                Y = sp.load_npz(Y_file_name)
                if ratings_threshold_for_movie > 0:
                    Y, _ = replace_ratings_threshold_in_memory(Y, Y_star)
            else:
                Y = []
            if ratings_threshold_for_movie > 0:
                Y_star, ratings_per_movie = replace_ratings_threshold_in_memory(Y_star, Y_star)
            data_elapsed = timeit.default_timer() - data_start_time
            print("Data loaded in " + str(int(data_elapsed)) + " seconds.")
        else:
            Y_star_file_name = path + "Synth_train_" + str(users) + "_" + str(movies) + "_sampled_" + str(
                max_samp) + ".npz"
            print("Y_star file name: " + Y_star_file_name)
            if not os.path.isfile(Y_star_file_name):
                Y, Y_star = createData(users, movies, path=path, sampled_per_row = max_samp)
            else:
                Y_star = sp.load_npz(Y_star_file_name)
                Y = []
        m,n = Y_star.shape
        proj_omega = Y_star.nonzero()
        if not run_on_dataset == dataset[2]:
            val_file = path + "probe_set.npz"
        else:
            val_file = path + "probe_set_" + str(users) + "_" + str(movies) + "_sampled_" + str(
                max_samp) + ".npz"
        val_data = sp.load_npz(val_file)
        val_nonzero = val_data.nonzero()
        ones_val = sp.csr_matrix(sp.coo_matrix(([1] * len(val_nonzero[0]), val_nonzero)))
        m_val, n_val = val_data.shape
        if m < m_val:
            print("Validation set contains row(s) not present in training set.")
        if n < n_val:
            print("Validation set contains column(s) not present in training set.")

        if (m_val < m) or (n_val < n):
            val_data._shape = (m, n)
            for _ in range(m - m_val):
                val_data.indptr = np.append(val_data.indptr, val_data.indptr[-1])
        tot_nonzero = (Y_star + val_data).nonzero()

        m_ones_val, n_ones_val = ones_val.shape
        if m < m_ones_val:
            print("Validation set contains row(s) not present in training set.")
        if n < n_ones_val:
            print("Validation set contains column(s) not present in training set.")

        if (m_ones_val < m) or (n_ones_val < n):
            ones_val._shape = (m, n)
            for _ in range(m - m_ones_val):
                ones_val.indptr = np.append(ones_val.indptr, ones_val.indptr[-1])
        global_avg = Y_star.sum()/len(proj_omega[0])
        print("Global average: " + str(global_avg))

        X = val_data - ones_val * global_avg
        rmse_err_sq = X.power(2).sum()
        rmse_err = math.sqrt(rmse_err_sq / len(val_nonzero[0]))
        print("RMSE by predicting global average:" + str(rmse_err))
        print("max_samp:" + str(max_samp))
        for eps in eps_arr:
            sigma = (np.sqrt(2 * np.log(2 / delta))) / eps
            noisy_avg = (Y_star.sum() + np.random.normal(0, sigma * np.max(ssl.norm(Y_star, axis=1))))/\
                        (len(proj_omega[0]) + np.random.normal(0, sigma * np.sqrt(max_samp)))
            print("Noisy  average for eps=" + str(eps) + ": " + str(noisy_avg))
            X = val_data - ones_val * noisy_avg
            rmse_err_sq = X.power(2).sum()
            rmse_err = math.sqrt(rmse_err_sq / len(val_nonzero[0]))
            print("RMSE by predicting noisy global average for eps=" + str(eps) + ":" + str(rmse_err))

        del val_data
        print("Probe set number of entries: " + str(len(val_nonzero[0])))
        print("Total set number of entries: " + str(len(tot_nonzero[0])))
        # if get_both:
        #     print("Y Entries: " + str(Y.nnz))
        print("Y_star Entries: " + str(Y_star.nnz))
        # print("Y_star before transformation: " + str(Y_star))
        if normalize_like == "WL08":
            Y, Y_star, r_bar_params = normalize_data_WL08(Y_star=Y_star, Y=Y, get_both=get_both)
        elif normalize_like == "MM09":
            Y, Y_star, r_bar_params = normalize_data_MM09(Y_star=Y_star, Y=Y, get_both=get_both)
        elif normalize_like == "JS10" or normalize_like == "JS10v2":
            Y, Y_star, r_bar_params = normalize_data_JS10(Y_star=Y_star, Y=Y, get_both=get_both)
        elif normalize_like == "Only_U_avg":
            Y, Y_star, r_bar_params = normalize_data_only_u_avg(Y_star=Y_star, Y=Y, get_both=get_both)
        else:
            r_bar_params = []
        # print("r_bar_params: " + str(r_bar_params))
        if not (L > 0 and k > 0):
            myfile = open(params_file, 'w')
            writer = csv.writer(myfile)
            if L == 0.0:
                L = np.max(ssl.norm(Y_star, axis=1))
                print("L: " + str(L))
            writer.writerow(["L:" + str(L)])
            if k == 0.0:
                _, sv_Y, _ = ssl.svds(Y_star, k=sv_cal)
                print("sv_y:" + str(sv_Y[0:5]) + str(sv_Y[-5:]))
                k = np.sum(sv_Y)
                print("k:" + str(k))
            writer.writerow(["k: " + str(k)])
            myfile.close()
            del Y

        print("Calling gen_results_with_data")
        gen_results_with_data(Y_star, T, k, L, eps_arr, delta, beta, calc_val_path=val_file,
                              ratings_per_movie=ratings_per_movie,
                              ratings_threshold_for_movie=ratings_threshold_for_movie,
                              r_bar_params=r_bar_params, write=1, max_samp=max_samp, lr_const=lr_const,
                              force_k=force_k, step_multiplier=step_multiplier,
                              proj_omega = proj_omega, val_nonzero=val_nonzero, tot_nonzero=tot_nonzero,
                              range_ratings=range_ratings)

if force_k_take_non_zero:
    fk_list = force_k_arr
else:
    fk_list = [0]

if not line_search:
    lr_list = lr_const_arr
else:
    lr_list = [0]

if not run_on_unsampled_data:
    samp_list = max_samp_arr
else:
    samp_list = [0]

if calibrate_noise:
    mult_list = step_multiplier_arr
else:
    mult_list = [0]

params_list = list(itertools.product(samp_list, T_arr, lr_list, mult_list, fk_list))

print("params_list: " + str(params_list))
run_on_data(params_list)



