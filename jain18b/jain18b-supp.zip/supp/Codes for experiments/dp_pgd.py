from __future__ import division
from __future__ import print_function
import gc
import timeit
import numpy as np
import scipy.sparse.linalg as ssl
import scipy.sparse as sp
import math
import os
import csv

dataset = ['Netflix', 'Movielens', 'Synthetic', 'Yahoo', 'Jester']
run_on_dataset = dataset[2]
# eps_arr = [0.2]
eta_sched_arr = [-2] #-2, -1, 0.05, 0.1, 0.2, 0.5]  # should be {-1 for "sqrt", -2 for "inv"}
# eps = 1
eps_arr = [0]  # 5, 2, 1, 0.5, 0.1]
delta = pow(10, -6)
ml_data_str = "ml-10m-rb//top400//"
calibrate_noise = False
step_multiplier_arr = [10, 5]
T_arr = [400]
normalize_like = "JS10v2"    # or "Only_U_avg"
print("run_on_dataset: " + run_on_dataset)
print("eta_sched_arr: " + str(eta_sched_arr))
print("normalize_like: " + str(normalize_like))
print("eps_arr: " + str(eps_arr))


def algo_PGD(Y_star, val_data, val_nonzero, tot_nonzero,
             eps, delta, L, T, eta_sched, k, step_multiplier, r_bar_params, range_ratings):
    if run_on_dataset == dataset[0]:
        data_str = "Netf_"
    elif run_on_dataset == dataset[1]:
        data_str = ml_data_str.replace("//", "")
    elif run_on_dataset == dataset[3]:
        data_str = "Yahoo_"
    elif run_on_dataset == dataset[4]:
        data_str = "Jester_"
    else:
        data_str = "Synth_"

    data_str = "SGD_" + data_str + "eta_" + str(eta_sched) + "_"
    max_samp_str = "_max_samp_" + str(max_samp)
    nr_str = "_nr" + normalize_like

    m, n = Y_star.shape
    print("m: " + str(m) + ", n: " + str(n))
    store_path = "Exp_running//"
    final_store_path = "Results//"
    if not run_on_dataset == dataset[2]:
        tmpfile = data_str + "results_top_" + str(n) + "_L_" + str(L) + "_eps_" + str(eps)
    else:
        tmpfile = data_str + "results_rank_1_" + str(m) + "_" + str(n) + "_L_" + str(L) + "_eps_" + str(eps)
    tmpfile += (max_samp_str + nr_str)
    if eps > 0:
        tmpfile += "_T_" + str(T)
    tmpfile += ".csv"
    resfile = store_path + tmpfile
    final_res_file = final_store_path + tmpfile

    count_val = val_nonzero[0].__len__()
    print("Total ratings in val_data: " + str(val_data.nnz))
    print("count_val: " + str(count_val))
    row_nonz = val_data.getnnz(axis=1)
    zero_ratings = 0
    for ele in row_nonz:
        if ele == 0:
            zero_ratings += 1
    print("Users with 0 ratings in val data: " + str(zero_ratings))
    ones_val = sp.csr_matrix(sp.coo_matrix(([1] * count_val, val_nonzero)))
    m_val, n_val = val_data.shape
    if m < m_val:
        print("Validation set contains row(s) not present in training set.")
    if n < n_val:
        print("Validation set contains column(s) not present in training set.")

    if (m_val < m) or (n_val < n):
        val_data._shape = (m, n)
        for _ in range(m - m_val):
            val_data.indptr = np.append(val_data.indptr, val_data.indptr[-1])
    print("Shape of val data: " + str(val_data.shape))
    m_val, n_val = ones_val.shape
    if m < m_val:
        print("Validation set contains row(s) not present in training set.")
    if n < n_val:
        print("Validation set contains column(s) not present in training set.")

    if (m_val < m) or (n_val < n):
        ones_val._shape = (m, n)
        for _ in range(m - m_val):
            ones_val.indptr = np.append(ones_val.indptr, ones_val.indptr[-1])
    print("Shape of ones_val: " + str(ones_val.shape))
    proj_omega = Y_star.nonzero()
    if r_bar_params:
        r_bar_u_diag = sp.csr_matrix(
            sp.coo_matrix((r_bar_params[0], (range(len(r_bar_params[0])), range(len(r_bar_params[0]))))))
        if len(r_bar_params) > 1:
            r_bar_m_diag = sp.csr_matrix(
                sp.coo_matrix((r_bar_params[1], (range(len(r_bar_params[1])), range(len(r_bar_params[1]))))))
            avg_mat = (r_bar_u_diag.dot(ones_val) + ones_val.dot(r_bar_m_diag)) / 2
        # val_data -= avg_val_mat
        # del r_bar_u_diag, r_bar_m_diag
        # gc.collect()
    ones_val = ones_val.todense()
    tr_start_time = timeit.default_timer()

    count_proj = len(proj_omega[0])
    ones_tr = sp.csr_matrix(sp.coo_matrix(([1] * count_proj, proj_omega))).todense()
    print("sum of Y_star: " + str(Y_star.sum()))
    Y_pred = sp.csr_matrix(sp.coo_matrix(([0.0] * len(tot_nonzero[0]), tot_nonzero)))
    err_for_grad = sp.csr_matrix(sp.coo_matrix(([0.0] * count_proj, proj_omega)))
    ones_tot_nonzero = sp.csr_matrix(sp.coo_matrix(([1.0] * len(tot_nonzero[0]), tot_nonzero)))
    if eps == 0:
        lab = " non_private"
    else:
        lab = " private, eps: " + str(eps)

    if eta_sched >= 0:
        eta = eta_sched

    if not calibrate_noise:
        term_num = T * np.log(1.0 / delta)
        term_num2 = term_num + (eps * T)
        sigma = 0
        if eps > 0:
            sigma = L * (np.sqrt(term_num) + np.sqrt(term_num2)) / eps
    else:
        step_const = 1
        last_step = 0
    for t in range(T):
        if calibrate_noise and eps>0:
            if step_const == 1 and T < t + step_multiplier * step_const:
                eps_cal = eps / np.sqrt(T)
            elif T > t + step_multiplier * (step_const + 1):
                eps_cal = eps / (pow(2, step_const) * np.sqrt(step_multiplier * step_const))
            else:
                eps_cal = eps / (pow(2, step_const) * np.sqrt(T - (last_step + step_multiplier * step_const)))
            sigma = pow(L, 2) * np.sqrt(np.log(1.0 / delta)) / eps_cal
            if t == last_step + step_multiplier * step_const:
                if T > t + step_multiplier * (step_const + 1):
                    step_const += 1
                    last_step = t
        err_for_grad[proj_omega] = Y_pred[proj_omega] - Y_star[proj_omega]
        if eta_sched == -1:
            eta = 1.0/(np.sqrt(2 + t))
        elif eta_sched == -2:
            eta = 1.0/(2 + t)

        ## New code for Projected GD
        Y_pred -= eta * err_for_grad
        # if eps>0:
        Cov = Y_pred.T.dot(Y_pred)
        if eps > 0:
            Cov += np.random.normal(0, sigma, (n, n))
        _, S, V_T = ssl.svds(Cov, k=min(Cov.shape)-1)
        S = np.sqrt(S)
        S_inv = [1.0 / x if x > 0 else 0 for x in S]
        U = (Y_pred.dot(V_T.T)).dot(np.diag(S_inv))
        if np.sum(S) > k:
            S = project_eigs(S, k)
        # else:
        #     U, S, V_T = ssl.svds(Y_pred, k=min(Y_pred.shape) - 1)
        #     if np.sum(S) > k:
        #         S = project_eigs(S, k)
        Y_pred = (U.dot(np.diag(S))).dot(V_T)


        # ## Old code
        # if q < 1.0:
        #     batch_inds = (np.random.uniform(0.0, 1.0, m) <= q) * 1
        #     batch_diag = sp.csr_matrix(sp.coo_matrix((batch_inds, (range(len(batch_inds)), range(len(batch_inds))))))
        #     err_for_grad = batch_diag * err_for_grad
        # grad = np.array(err_for_grad.sum(axis=0))[0]
        # grad = np.add(grad, np.random.normal(0, sigma, grad.shape))
        # grad /= B
        # grad_diag = sp.csr_matrix(sp.coo_matrix((grad, (range(len(grad)), range(len(grad))))))
        #
        # Y_pred -= eta * (ones_tot_nonzero * grad_diag)
        err_tr_mat = np.multiply(Y_pred, ones_tr) - Y_star
        tr_err_sq = np.power(err_tr_mat,2).sum()
        tr_err = math.sqrt(tr_err_sq / count_proj)
        print("Training error in iteration " + str(t) + ": " + str(tr_err))
        Y_pred_out = np.multiply(Y_pred, ones_val)
        if len(r_bar_params) == 1:
            Y_pred_out[val_nonzero] += r_bar_u_diag.dot(ones_val)[val_nonzero]
        elif len(r_bar_params) == 2:
            Y_pred_out[val_nonzero] += avg_mat[val_nonzero]

        nz_row = np.array(val_nonzero[0])
        nz_col = np.array(val_nonzero[1])
        large_inds = np.array(Y_pred_out[val_nonzero] > range_ratings)[0]
        Y_pred_out[(nz_row[large_inds], nz_col[large_inds])] = range_ratings
        small_inds = np.array(Y_pred_out[val_nonzero] < 0)[0]
        Y_pred_out[(nz_row[small_inds], nz_col[small_inds])] = 0.0

        err_val_mat = Y_pred_out - val_data
        val_err_sq = np.power(err_val_mat,2).sum()
        val_err = math.sqrt(val_err_sq / count_val)
        print("Validation error in iteration " + str(t) + ": " + str(val_err))
        if not os.path.isfile(resfile):
            with open(resfile, 'w') as myfile:
                writer = csv.writer(myfile)
                writer.writerow([m, n])
                writer.writerow(["tr " + lab])
                writer.writerow([tr_err])
                writer.writerow(["val " + lab])
                writer.writerow([val_err])
                myfile.close()
        else:
            with open(resfile, "r") as myfile:
                reader = csv.reader(myfile)
                title_row = next(reader)
                tr_err_str = next(reader)
                tr_err_arr = next(reader)[0:t - 1]
                tr_err_arr.append(tr_err)
                val_err_str = next(reader)
                val_err_arr = next(reader)[0:t - 1]
                val_err_arr.append(val_err)
                myfile.close()

            with open(resfile, "w") as res_myfile:
                writer = csv.writer(res_myfile)
                writer.writerow(title_row)
                writer.writerow(tr_err_str)
                writer.writerow(tr_err_arr)
                writer.writerow(val_err_str)
                writer.writerow(val_err_arr)
                res_myfile.close()

    tr_elapsed = timeit.default_timer() - tr_start_time
    os.rename(resfile, final_res_file)
    print("Algo done in function in " + str(int(tr_elapsed)) + " seconds.")

def project_eigs(S, k):
    sum_s = np.sum(S)
    tau = 0
    while sum_s > k:
        if tau == 0:
            tau = 1
        else:
            tau *= 2
        sum_s = 0.0
        for x in S:
            sum_s += max(0.0, x - tau)

    high_tau = tau
    low_tau = tau / 2
    while high_tau > (low_tau + 1):
        tau = low_tau + int((high_tau - low_tau) / 2)
        sum_s = 0.0
        for x in S:
            sum_s += max(0.0, x - tau)
        if sum_s > k:
            low_tau = tau
        else:
            high_tau = tau

    return np.array([max(0.0, x - high_tau) for x in S])


def normalize_data_JS10(Y_star):
    tr_start_time = timeit.default_timer()
    row_sums = np.array(Y_star.sum(axis=1).flatten())
    row_nonz = Y_star.getnnz(axis=1)
    tot_ratings = row_nonz.sum()
    col_sums = np.array(Y_star.sum(axis=0))
    col_nonz = Y_star.getnnz(axis=0)
    with np.errstate(divide='ignore', invalid='ignore'):
        r_tilde_m_temp = np.true_divide(col_sums, col_nonz)
        r_bar_m = r_tilde_m_temp[0]
        r_bar_m[~ np.isfinite(r_bar_m)] = 0
        r_tilde_u_temp = np.true_divide(row_sums, row_nonz)
        r_bar_u = r_tilde_u_temp[0]
        r_bar_u[~ np.isfinite(r_bar_u)] = 0
    del row_sums, col_sums, r_tilde_m_temp, r_tilde_u_temp
    gc.collect()

    print("tot_ratings: " + str(tot_ratings))

    proj_omega = Y_star.nonzero()
    ones_p_omega = sp.csr_matrix(sp.coo_matrix(([1] * tot_ratings, proj_omega)))
    r_bar_u_diag = sp.csr_matrix(sp.coo_matrix((r_bar_u, (range(len(r_bar_u)), range(len(r_bar_u))))))
    r_bar_m_diag = sp.csr_matrix(sp.coo_matrix((r_bar_m, (range(len(r_bar_m)), range(len(r_bar_m))))))
    avg_mat = (r_bar_u_diag.dot(ones_p_omega) + ones_p_omega.dot(r_bar_m_diag)) / 2
    Y_star[proj_omega] -= avg_mat[proj_omega]
    del proj_omega, ones_p_omega, avg_mat
    gc.collect()
    tr_elapsed = timeit.default_timer() - tr_start_time
    r_bar_params = [r_bar_u, r_bar_m]
    print("Data normalized in function in " + str(int(tr_elapsed)) + " seconds.")
    return Y_star, r_bar_params


def normalize_data_only_u_avg(Y_star):
    tr_start_time = timeit.default_timer()
    row_sums = np.array(Y_star.sum(axis=1).flatten()).astype(float)
    row_nonz = Y_star.getnnz(axis=1)
    tot_ratings = row_nonz.sum()
    print("Min. value in Y_star: " + str(Y_star.data.min()))
    zero_ratings = 0
    for i, ele in enumerate(row_nonz):
        if ele == 0.0:
            zero_ratings += 1
    print("Users with 0 ratings: " + str(zero_ratings))
    with np.errstate(divide='ignore', invalid='ignore'):
        r_tilde_u_temp = np.true_divide(row_sums, row_nonz)
        r_bar_u = r_tilde_u_temp[0]
        r_bar_u[~ np.isfinite(r_bar_u)] = 0
    del row_sums, r_tilde_u_temp
    gc.collect()
    print("Min. value in r_bar_u: " + str(np.min(r_bar_u[r_bar_u > 0])))

    print("tot_ratings: " + str(tot_ratings))

    proj_omega = Y_star.nonzero()
    ones_p_omega = sp.csr_matrix(sp.coo_matrix(([1] * tot_ratings, proj_omega)))
    r_bar_u_diag = sp.csr_matrix(sp.coo_matrix((r_bar_u, (range(len(r_bar_u)), range(len(r_bar_u))))))
    Y_star[proj_omega] -= r_bar_u_diag.dot(ones_p_omega)[proj_omega]
    del proj_omega, ones_p_omega
    gc.collect()

    # val_nonzero = val_data.nonzero()
    # count_val = val_nonzero[0].__len__()
    # ones_val = sp.csr_matrix(sp.coo_matrix(([1] * count_val, val_nonzero)))
    # m_val, n_val = val_data.shape
    # if m < m_val:
    #     print("Validation set contains row(s) not present in training set.")
    # if n < n_val:
    #     print("Validation set contains column(s) not present in training set.")
    #
    # if (m_val < m) or (n_val < n):
    #     val_data._shape = (m, n)
    #     for _ in range(m - m_val):
    #         val_data.indptr = np.append(val_data.indptr, val_data.indptr[-1])
    # print("Shape of val data: " + str(val_data.shape))
    # m_val, n_val = ones_val.shape
    # if m < m_val:
    #     print("Validation set contains row(s) not present in training set.")
    # if n < n_val:
    #     print("Validation set contains column(s) not present in training set.")
    #
    # if (m_val < m) or (n_val < n):
    #     ones_val._shape = (m, n)
    #     for _ in range(m - m_val):
    #         ones_val.indptr = np.append(ones_val.indptr, ones_val.indptr[-1])
    # print("Shape of ones_val: " + str(ones_val.shape))
    # r_bar_u_diag = sp.csr_matrix(
    #     sp.coo_matrix((r_bar_u, (range(len(r_bar_u)), range(len(r_bar_u))))))
    # val_data -= r_bar_u_diag.dot(ones_val)
    tr_elapsed = timeit.default_timer() - tr_start_time
    print("Max. value in Y_star: " + str(max(Y_star.max(), (-1 * Y_star).max())))
    print("Data normalized in function in " + str(int(tr_elapsed)) + " seconds.")
    return Y_star, [r_bar_u]

disk_path = "//mnt//datasets//Data_DP_Frank_Wolfe//"
if run_on_dataset == dataset[4]:
    pick_top = 100
    max_samp = 100
else:
    pick_top = 400
    max_samp = 80
max_samp_str = "_max_samp_" + str(max_samp)

if run_on_dataset == dataset[4]:
    path = disk_path + "Jester//"
elif run_on_dataset == dataset[0]:
    path = disk_path + "Netflix_dataset//top" + str(pick_top) + "//"
elif run_on_dataset == dataset[1]:
    path = disk_path + ml_data_str
elif run_on_dataset == dataset[2]:
    path = disk_path + "Synthetic//"
    users = 500000
    movies = 400
else:
    path = disk_path + "Yahoo_dataset//top" + str(pick_top) + "//"

if run_on_dataset == dataset[2]:
    Y_star_file_name = path + "Synth_train_" + str(users) + "_" + str(movies) + "_sampled_" + str(
        max_samp) + ".npz"
elif not run_on_dataset == dataset[4]:
    Y_star_file_name = path + "training_set_sampled" + max_samp_str + ".npz"
else:
    Y_star_file_name = path + "training_set_complete.npz"

print("Y_star file name: " + Y_star_file_name)
Y_star = sp.load_npz(Y_star_file_name)
m,n = Y_star.shape
print("Total ratings in Y_star: " + str(Y_star.count_nonzero()))

proj_omega = Y_star.nonzero()
if not run_on_dataset == dataset[2]:
    val_file = path + "probe_set.npz"
else:
    val_file = path + "probe_set_" + str(users) + "_" + str(movies) + "_sampled_" + str(
        max_samp) + ".npz"
val_data = sp.load_npz(val_file)
val_nonzero = val_data.nonzero()
m_val, n_val = val_data.shape
if m < m_val:
    print("Validation set contains row(s) not present in training set.")
if n < n_val:
    print("Validation set contains column(s) not present in training set.")

if (m_val < m) or (n_val < n):
    val_data._shape = (m, n)
    for _ in range(m - m_val):
        val_data.indptr = np.append(val_data.indptr, val_data.indptr[-1])
tot_nonzero = (Y_star + val_data).nonzero()
print("Probe set number of entries: " + str(len(val_nonzero[0])))
print("Total set number of entries: " + str(len(tot_nonzero[0])))
r_bar_params = []

if normalize_like == "Only_U_avg":
    Y_star, r_bar_params = normalize_data_only_u_avg(Y_star=Y_star)
else:
    Y_star, r_bar_params = normalize_data_JS10(Y_star=Y_star)


if run_on_dataset == dataset[0]:
    data_str = "Netf_"
    range_ratings = 4
elif run_on_dataset == dataset[1]:
    range_ratings = 4.5
    data_str = ml_data_str.replace("//", "")
elif run_on_dataset == dataset[3]:
    data_str = "Yahoo_"
    range_ratings = 5
elif run_on_dataset == dataset[2]:
    data_str = "Synth_"
    range_ratings = 1
else:
    range_ratings = 5
    data_str = "Jester_"

k_sum_of_eigs = 1500
nr_str = "_nr" + normalize_like
if data_str == "Jester_":
    nr_str += "_uns"
    max_samp_str = ""
sv_cal = min(k_sum_of_eigs, pick_top - 1)
if not run_on_dataset == dataset[2]:
    params_file = "Params//" + data_str + "top_" + str(pick_top) + "_k_" + str(sv_cal) + (
             nr_str + max_samp_str) + ".csv"
else:
    params_file = "Params//" + data_str + "users_" + str(users) + "_movies_" + str(movies) + \
                  "_samples_" + str(max_samp) + \
                  (nr_str + max_samp_str) + ".csv"
print("Params file: " + params_file)
if os.path.isfile(params_file):
    myfile = open(params_file, 'r')
    lines = myfile.readlines()
    L = float(lines[0].split(':')[1])
    k = float(lines[1].split(':')[1])
    print("L and k preloaded from " + params_file)
else:
    print("No value of k found.")
    exit()
    L = np.max(ssl.norm(Y_star, axis=1))
print("L: " + str(L))

# if sampling == True:
#     if eps > 0:
#         B = int(m * np.sqrt(eps/(8 * T)) + 1)
#     else:
#         B = int(m/10)
# else:
#     B = m
#
# print("B: " + str(B))
# q = float(B)/m

# if eps > (8 * pow(q, 2) * T):
#     print("Upper bound on epsilon not satisfied.")
#     exit()
for eta_sched in eta_sched_arr:
    for step_multiplier in step_multiplier_arr:
        for T in T_arr:
            for eps in eps_arr:
                print("step_multiplier: " + str(step_multiplier))
                print("T: " + str(T))
                print("eps: " + str(eps))
                print("eta_sched: " + str(eta_sched))
                algo_PGD(Y_star, val_data, val_nonzero, tot_nonzero, eps, delta, L, T, eta_sched,k=k,
                         step_multiplier = step_multiplier, r_bar_params = r_bar_params, range_ratings=range_ratings)


