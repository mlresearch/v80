import csv
import glob
import random as rand
import numpy as np

# import resource
# rsrc = resource.RLIMIT_DATA
# resource.setrlimit(rsrc, (20971520, 41943040))

# from pathlib import Path

import os
import shutil
import scipy.sparse as sp
import xlrd

def netflix_data_const_users(built_dic_for_max, tot_num = 17770, par = '', net_path = "Netflix_dataset//"):

    if par == 'sorted':
        data_path = net_path + "training_set//"
        store_init_path = net_path + "top" + str(tot_num) + "//"
        directory = os.path.dirname(store_init_path)
        try:
            os.stat(directory)
        except:
            os.mkdir(directory)
        sorted_movies_path = net_path + "unique_users_stats//"
        sorted_movies_file = sorted_movies_path + "sorted_movie_list.csv"
        tot_movies = []
        count = 0
        with open(sorted_movies_file, "r") as myfile:
            for line in myfile:
                head = line.split(',')
                count += 1
                if count <= tot_num:
                    tot_movies.append(int(head[0]))
                else:
                    break
        myfile.close
        tot_movies.sort()
        print(str(tot_movies))
    else:
        data_path = net_path + "training_set//"
        store_init_path = net_path
        next_movie = 1
        tot_movies = range(next_movie, 17770 + 1)
    mov_interval = min(built_dic_for_max, tot_num)
    if mov_interval > built_dic_for_max:
        flag = 1
        store_path = store_init_path + "user_data//"
    else:
        flag = 2
        store_path = store_init_path + "user_data_combined//"
    directory = os.path.dirname(store_path)
    try:
        os.stat(directory)
    except:
        os.mkdir(directory)
    user_dict = {}
    for ind in range(tot_movies.__len__()):
        mov = tot_movies[ind]
        mov_file_num = str(mov).zfill(7)
        net_file = data_path + "mv_" + mov_file_num + ".txt"
        with open(net_file, "r") as myfile:
            reader = csv.reader(myfile)
            read_arr = list(reader)
            read_arr = read_arr[1:]
        for elem in read_arr:
            if flag > 0:
                if not user_dict.has_key(int(elem[0])):
                    user_dict[int(elem[0])] = []
                user_dict[int(elem[0])].append([mov, int(elem[1])])
            # print elem[0], "stored"
            # elif mov == next_movie and int(elem[0]) == 79712:
            #     flag = 1
        print("Computing for movie "+str(mov)+ " completed.")
        myfile.close
        if flag == 1:
            if (ind + 1) % mov_interval == 0:
                for user_key in user_dict.iterkeys():
                    user_file = store_path + "user_" + str(user_key).zfill(7) + ".csv"
                    with open(user_file, "a") as myfilestr:
                        writer = csv.writer(myfilestr)
                        for rating in user_dict[user_key]:
                            writer.writerow(rating)
                    myfilestr.close

                user_dict.clear()
                print("Storing for "+str(ind)+ " movies completed.")
    if user_dict.__len__() > 0:
        if flag == 1:

                for user_key in sorted(user_dict.iterkeys()):
                    user_file = store_path + "user_" + str(user_key).zfill(7) + ".csv"
                    with open(user_file, "a") as myfilestr:
                        writer = csv.writer(myfilestr)
                        for rating in user_dict[user_key]:
                            writer.writerow(rating)
                    myfilestr.close

        elif flag == 2:
            counter = 0
            glob_counter = 1
            users_per_file = 100000
            user_file = store_path + "user_values_combined_" + str(glob_counter) + ".csv"
            myfilestr = open(user_file, "w")
            writer = csv.writer(myfilestr)
            for user_key in sorted(user_dict.iterkeys()):
                counter += 1
                writer.writerow([user_key, '|', len(user_dict[user_key])])
                for rating in user_dict[user_key]:
                    writer.writerow(rating)
                if counter % users_per_file == 0:
                    myfilestr.close
                    glob_counter += 1
                    user_file = store_path + "user_values_combined_" + str(glob_counter) + ".csv"
                    myfilestr = open(user_file, "a")
                    writer = csv.writer(myfilestr)
        user_dict.clear()
    print("Storing for all movies completed.")


def netflix_probe_const_users(built_dic_for_max, tot_num = 17770, par = '', net_path = "Netflix_dataset//"):
    if par == 'sorted':
        data_path = net_path + "top" + str(tot_num) + "//"
        store_path = data_path
        store_interval = min(built_dic_for_max,tot_num)
    else:
        data_path = net_path
        store_path = data_path
        store_interval = built_dic_for_max
    directory = os.path.dirname(store_path)
    try:
        os.stat(directory)
    except:
        os.mkdir(directory)
    if tot_num > built_dic_for_max:
        flag = 1
        store_path = store_path + "probe_data//"
        directory = os.path.dirname(store_path)
        try:
            os.stat(directory)
        except:
            os.mkdir(directory)
    else:
        flag = 2

    data_file = data_path + "probe_values.csv"
    user_dict = {}
    mov = 0
    count_mov = 0
    with open(data_file, "r") as myfile:
        for line in myfile:
            if line.__contains__(':'):
                count_mov += 1
                if count_mov % store_interval == 0 and flag == 1:
                    if user_dict.__len__() > 0:
                        for user_key in sorted(user_dict.iterkeys()):
                            user_file = store_path + "user_" + str(user_key).zfill(7) + ".csv"
                            with open(user_file, "a") as myfilestr:
                                writer = csv.writer(myfilestr)
                                for rating in user_dict[user_key]:
                                    writer.writerow(rating)
                            myfilestr.close

                        user_dict.clear()
                        print "Storing for ", count_mov, " movies completed."

                head = line.split(',')
                mov = int(head[0])
            else:
                rating = line.split(',')
                if not user_dict.has_key(int(rating[0])):
                    user_dict[int(rating[0])] = []
                user_dict[int(rating[0])].append([mov, int(rating[1].replace('\r\n',''))])
    myfile.close

    if user_dict.__len__() > 0:
        if flag == 1:
            for user_key in user_dict.iterkeys():
                user_file = store_path + "user_" + str(user_key).zfill(7) + ".csv"
                with open(user_file, "a") as myfilestr:
                    writer = csv.writer(myfilestr)
                    for rating in user_dict[user_key]:
                        writer.writerow(rating)
                myfilestr.close()
        elif flag == 2:
            counter = 0
            store_file = store_path + "probe_values_by_users.csv"
            myfilestr = open(store_file, "a")
            writer = csv.writer(myfilestr)
            for user_key in sorted(user_dict.iterkeys()):
                counter += 1
                writer.writerow([user_key, '|', len(user_dict[user_key])])
                for rating in user_dict[user_key]:
                    writer.writerow(rating)
            myfilestr.close()
            os.remove(data_file)
        user_dict.clear()
    print("Storing for all movies completed.")


def netflix_combine_data(tot_num = 17770, par = '', net_path = "Netflix_dataset//"):
    if par == 'probe':
        data_path = net_path + "probe_data//"
        store_path = net_path
    elif par == 'sorted':
        data_path = net_path + "top" + str(tot_num) + "//user_data//"
        store_path = net_path + "top" + str(tot_num) + "//user_data_combined//"
    elif par == 'probe_sorted':
        data_path = net_path + "top" + str(tot_num) + "//probe_data//"
        store_path = net_path + "top" + str(tot_num) + "//"
    else:
        data_path = net_path + "user_data//"
        store_path = net_path + "user_data_combined//"

    directory = os.path.dirname(store_path)
    try:
        os.stat(directory)
    except:
        os.mkdir(directory)

    counter = 0
    if 'probe' not in par:
        counter_glob = 1
    to_store = []
    users_per_file = 100000
    for user_file in glob.glob(data_path + '*.csv'):
        counter += 1
        user = user_file.replace(data_path, '').replace('user_','').replace('.csv', '')
        with open(user_file, "r") as myfile:
            reader = csv.reader(myfile)
            read_arr = list(reader)
        myfile.close
        tot = read_arr.__len__()
        to_store.append([user,'|',tot])
        for rating in read_arr:
            to_store.append(rating)
        if counter%users_per_file == 0:
            if 'probe' in par:
                if tot_num < 17770:
                    store_file = store_path + "probe_values_by_users.csv"
                else:
                    store_file = store_path + "probe_values_by_users_r.csv"
            else:
                store_file = store_path + "user_values_combined_" + str(counter/users_per_file) + ".csv"
            with open(store_file, "a") as myfilestr:
                writer = csv.writer(myfilestr)
                for elem in to_store:
                    writer.writerow(elem)
                # writer.writerow([user,'|',tot])
                # for rating in read_arr:
                #     writer.writerow(rating)
            myfilestr.close
            to_store = []
            print(str(counter)+ " users combined")
            if 'probe' not in par:
                counter_glob+=1
    shutil.rmtree(data_path)




def sample_ratings(max_per_user, tot_num = 17770, par = '', net_path = "Netflix_dataset//"):
    if par == 'sorted':
        data_path = net_path + "top" + str(tot_num) + "//user_data_combined//"
        store_path = net_path + "top" + str(tot_num) + "//user_data_sampled//"
    else:
        data_path = net_path + "user_data_combined//"
        store_path = net_path + "user_data_sampled//"
    count = 1
    directory = os.path.dirname(store_path)
    try:
        os.stat(directory)
    except:
        os.mkdir(directory)
    tot_files = glob.glob(data_path + '*.csv').__len__()
    for ind in range(1, tot_files + 1):
        user_file = data_path + "user_values_combined_" + str(ind) + ".csv"
        user = user_file.replace(data_path, '').replace('user_', '').replace('.csv', '')
        store_file = user_file.replace(data_path, store_path).replace('.csv', '_sampled.csv')
        mystr = open(store_file, "w")
        writer = csv.writer(mystr)

        with open(user_file, "r") as myfile:
            local_count = -1
            local_tot = -1
            sampled = []
            for line in myfile:
                if line.__contains__('|'):
                    head = line.split(',')
                    local_tot = int(head[2].replace('\n',''))
                    local_count = 0
                    if local_tot<max_per_user:
                        writer.writerow([head[0],'|',local_tot])
                        sampled = range(local_tot)
                    else:
                        writer.writerow([head[0], '|', max_per_user])
                        sampled = rand.sample(range(local_tot),max_per_user)
                else:
                    if sampled.__contains__(local_count):
                        rating = line.split(',')
                        writer.writerow([rating[0],rating[1].replace('\r\n','')])
                    local_count+=1

        myfile.close
        mystr.close
        if count % 100 == 0:
            print("Ratings of files till count "+ str(count)+ " sampled.")
        count += 1

def netflix_const_probe(net_path = "Netflix_dataset//"):
    data_path = net_path + "training_set//"
    probe_file = net_path + "probe.txt"
    save_file = net_path + "probe_values.csv"
    mov = 0
    with open(probe_file, "r") as myfile:
        for line in myfile:
            with open(save_file, "a") as myfilesave:
                writer = csv.writer(myfilesave)
                if line.__contains__(':'):
                    mov = int(line.replace(':',''))
                    print(str(mov))
                    writer.writerow([mov, ':'])
                    mov_file_num = str(mov).zfill(7)
                    # rate_file = data_path + "mv_" + mov_file_num + ".txt"
                    rate_file = data_path + "mv_" + mov_file_num + ".txt"
                    with open(rate_file, "r") as myfilelook:
                        reader = csv.reader(myfilelook)
                        read_arr = list(reader)
                        users = []
                        ratings = []
                        for ind in range(1,len(read_arr)):
                            users.append(int(read_arr[ind][0]))
                            ratings.append(int(read_arr[ind][1]))
                    myfilelook.close
                else:
                    user = int(line)
                    mov_file_num = str(mov).zfill(7)
                    # rate_file = data_path + "mv_" + mov_file_num + ".txt"
                    if users.__contains__(user):
                        writer.writerow([user,ratings[users.index(user)]])
                    # with open(rate_file, "r") as myfilelook:
                    #     for rating in myfilelook:
                    #         if not rating.__contains__(':'):
                    #             head = rating.split(',')
                    #             if int(head[0]) == user:
                    #                 writer.writerow([user, head[1]])
                    #                 break
                    # myfilelook.close
            myfilesave.close
    myfile.close


def netflix_sort_movies(net_path = "Netflix_dataset"):

    data_path = net_path + "training_set//"
    store_path = net_path + "unique_users_stats//"
    directory = os.path.dirname(store_path)
    try:
        os.stat(directory)
    except:
        os.mkdir(directory)
    tot_movies = 17770
    next_movie = 1
    num_ratings = np.zeros(17770)

    for mov in range(next_movie,tot_movies+1):
        mov_file_num = str(mov).zfill(7)
        net_file = data_path + "mv_" + mov_file_num + ".txt"
        with open(net_file, "r") as myfile:
            reader = csv.reader(myfile)
            read_arr = list(reader)
            read_arr = read_arr[1:]
        num_ratings[mov -1] = read_arr.__len__()
        if mov %1000 == 0:
            print("Computing for movies till "+str(mov)+ " completed.")
        myfile.close

    sorted_args = num_ratings.argsort()[::-1]

    store_file = store_path + "sorted_movie_list.csv"
    with open(store_file, "w") as myfilestr:
        writer = csv.writer(myfilestr)
        for ind in range(tot_movies):
            writer.writerow([sorted_args[ind] + 1, num_ratings[sorted_args[ind]]])
    myfilestr.close


def netflix_count_unique_users(tot, start, net_path = "Netflix_dataset//"):
    movie_path = net_path + "training_set//"
    data_path = net_path + "unique_users_stats//"
    data_file = data_path + "sorted_movie_list.csv"
    users_file = data_path + "unique_users.csv"
    users_file_temp = data_path + "unique_users_temp.csv"
    num_unique_file = data_path + "number_unique_users.csv"
    count = 0
    with open(data_file, "r") as myfile:
        for line in myfile:
            count += 1
            if count > tot:
                break
            if count == start:
                head = line.split(',')
                mov = int(head[0])
                mov_file_num = str(mov).zfill(7)
                net_file = movie_path + "mv_" + mov_file_num + ".txt"
                with open(net_file, "r") as myfilemov:
                    reader = csv.reader(myfilemov)
                    read_arr = list(reader)
                    read_arr = read_arr[1:]
                myfilemov.close
                read_arr_users = []
                for elem in read_arr:
                    read_arr_users.append(int(elem[0]))
                read_arr_users.sort()
                myfileusers = None
                if os.path.isfile(users_file):
                    myfileusers = open(users_file, "r")
                with open(users_file_temp, "w") as myfileusers_temp:
                    writer = csv.writer(myfileusers_temp)
                    stored_user = ""
                    if not myfileusers == None:
                        stored_user = myfileusers.readline()
                    ind_new = 0
                    count_new = 0
                    new_len = read_arr_users.__len__()
                    while (not stored_user == "") and ind_new < new_len:
                        head = stored_user.split(',')
                        stored_user_int = int(head[0])
                        stored_user_count = int(head[1].replace('\r\n', ''))
                        if stored_user_int < read_arr_users[ind_new]:
                            writer.writerow([stored_user_int,stored_user_count])
                            stored_user = myfileusers.readline()
                        elif stored_user_int > read_arr_users[ind_new]:
                            writer.writerow([read_arr_users[ind_new], 1])
                            ind_new += 1
                            count_new +=1
                        else:
                            writer.writerow([read_arr_users[ind_new], stored_user_count + 1])
                            ind_new += 1
                            stored_user = myfileusers.readline()
                    if not stored_user == "":
                        while not stored_user == "":
                            head = stored_user.split(',')
                            stored_user_int = int(head[0])
                            stored_user_count = int(head[1].replace('\r\n', ''))
                            writer.writerow([stored_user_int,stored_user_count])
                            stored_user = myfileusers.readline()
                    if ind_new < new_len:
                        while ind_new < new_len:
                            count_new += 1
                            writer.writerow([read_arr_users[ind_new], 1])
                            ind_new += 1

                myfileusers_temp.close
                if not myfileusers == None:
                    myfileusers.close

                myfileusers_temp = open(users_file_temp, "r")
                with open(users_file, "w") as myfileusers:
                    writer = csv.writer(myfileusers)
                    stored_user = myfileusers_temp.readline()
                    while not stored_user == "":
                        head = stored_user.split(',')
                        stored_user_int = int(head[0])
                        stored_user_count = int(head[1].replace('\r\n', ''))
                        writer.writerow([stored_user_int, stored_user_count])
                        stored_user = myfileusers_temp.readline()
                myfileusers_temp.close
                myfileusers.close

                if not os.path.is_file():
                    with open(num_unique_file, "w") as myfilenum:
                        writer = csv.writer(myfilenum)
                        writer.writerow(["Movie", "# Ratings", "# unique ratings"])
                    myfileusers.close
                with open(num_unique_file, "a") as myfilenum:
                    writer = csv.writer(myfilenum)
                    writer.writerow([mov, new_len, count_new])
                myfilenum.close

                print("Counting for top movie "+str(count)+ "done. It has "+str(count_new)+ " unique users out of "+str(new_len)+ "users.")
                start+=1
    myfile.close
    os.remove(users_file_temp)


def netflix_count_users(net_path = "Netflix_dataset//"):
    data_path = net_path + "unique_users_stats//"
    data_file = data_path + "unique_users.csv"
    count = 0
    with open(data_file, "r") as myfile:
        for line in myfile:
            count += 1
    print(str(count)+ "users in file.")

def netflix_count_users_ratings(net_path = "Netflix_dataset//"):
    data_path = net_path + "unique_users_stats//"
    data_file = data_path + "unique_users.csv"
    store_file = data_path + "unique_users_stats.csv"
    count = {}
    with open(data_file, "r") as myfile:
        for line in myfile:
            head = line.split(',')
            stored_user_count = int(head[1].replace('\r\n', ''))
            if not count.has_key(stored_user_count):
                count[stored_user_count] = 0
            count[stored_user_count] += 1
    myfile.close
    with open(store_file, "w") as myfilestr:
        writer = csv.writer(myfilestr)
        writer.writerow(["# of ratings", "# of users"])
        for key in count.iterkeys():
            writer.writerow([key, count[key]])
    myfilestr.close


def netflix_const_new_probe(tot_num, frac, net_path = "Netflix_dataset//"):
    data_path = net_path + "unique_users_stats//"
    store_path = net_path + "top" + str(tot_num) + "//"
    directory = os.path.dirname(store_path)
    try:
        os.stat(directory)
    except:
        os.mkdir(directory)
    movie_path = net_path + "training_set//"
    data_file = data_path + "sorted_movie_list.csv"
    store_file = store_path + "probe_values.csv"
    count = 0
    mov_count = 0
    movies = []
    with open(data_file, "r") as myfile:
        for line in myfile:
            mov_count += 1
            if mov_count<= tot_num:
                head = line.split(',')
                movies.append(int(head[0]))
                ratings_count = int(float(head[1].replace('\r\n', '')))
                count+=ratings_count
            else:
                break
    myfile.close
    movies.sort()
    print("Total number of ratings for "+str(tot_num)+" top movies: "+str(count))
    samples = np.random.choice(count, size = int(count*frac), replace = False)
    samples.sort()

    myfilestr = open(store_file, "w")
    writer = csv.writer(myfilestr)
    user_dict = {}
    users_done = 0
    done_till = 0
    for ind in range(movies.__len__()):
        mov = movies[ind]
        mov_file_num = str(mov).zfill(7)
        net_file = movie_path + "mv_" + mov_file_num + ".txt"
        with open(net_file, "r") as myfile:
            reader = csv.reader(myfile)
            read_arr = list(reader)
            read_arr = read_arr[1:]
        myfile.close
        user_count_max = users_done + read_arr.__len__()
        if samples[done_till] < user_count_max:
            writer.writerow([mov, ':'])
            while samples[done_till] < user_count_max:
                writer.writerow(read_arr[samples[done_till] - users_done][0:2])
                done_till += 1
                if done_till >= np.size(samples):
                    break
        users_done += read_arr.__len__()
        print("Computing for movie "+str(mov)+ " completed.")
    myfilestr.close()


def print_sorted_movies(tot_num, data_path = "Netflix_dataset//unique_users_stats//"):
    data_file = data_path + "sorted_movie_list.csv"
    count = 0
    mov_count = 0
    movies = []
    with open(data_file, "r") as myfile:
        for line in myfile:
            mov_count += 1
            if mov_count <= tot_num:
                head = line.split(',')
                movies.append(int(head[0]))
                ratings_count = int(float(head[1].replace('\r\n', '')))
                count += ratings_count
            else:
                break
    myfile.close
    movies.sort()
    print(str(movies))


def netflix_renumber(tot_num = 17770, net_path = "Netflix_dataset//"):

    user_arr = []
    if tot_num < 17770:
        user_data_path = net_path + "top" + str(tot_num) + "//"
    else:
        user_data_path = net_path
    user_data_folder = user_data_path + "user_data_combined//"
    tot_files = np.size(glob.glob(user_data_folder + '*.csv'))
    for ind in range(1,tot_files+1):
        user_data_file = user_data_folder + "user_values_combined_" + str(ind) + ".csv"
        myfile = open(user_data_file, "r")
        for line in myfile:
            if line.__contains__('|'):
                head = line.split(',')
                user_arr.append(int(head[0]))
        myfile.close()
    # print user_arr

    if tot_num < 17770:
        data_path = net_path + "top" + str(tot_num) + "//"
        sorted_movie_path = net_path + "unique_users_stats//"
        data_file = sorted_movie_path + "sorted_movie_list.csv"
        count = 0
        mov_count = 0
        movies = []
        with open(data_file, "r") as myfile:
            for line in myfile:
                mov_count += 1
                if mov_count<= tot_num:
                    head = line.split(',')
                    movies.append(int(head[0]))
                    ratings_count = int(float(head[1].replace('\r\n', '')))
                    count+=ratings_count
                else:
                    break
        myfile.close
        movies.sort()

    else:
        data_path = net_path
    user_counter = 0
    probe_name = "probe_values_by_users.csv"
    probe_file = data_path + probe_name
    probe_store_file = data_path + probe_name.replace('.csv', '_r.csv')
    if not os.path.isfile(probe_store_file):
        myfilestr = open(probe_store_file, "w")
        writer = csv.writer(myfilestr)
        with open(probe_file, "r") as myfile:
            for line in myfile:
                if not line.__contains__('|'):
                    head = line.split(',')
                    rating = int(float(head[1].replace('\r\n', '')))
                    if tot_num<17770:
                        new_ind_mov = movies.index(int(head[0]))
                    else:
                        new_ind_mov = int(head[0]) - 1
                    writer.writerow([new_ind_mov, rating])
                else:
                    head = line.split(',')
                    head[2] = int(float(head[2].replace('\r\n', '')))
                    ind_search = int(head[0])
                    while user_arr[user_counter] < ind_search:
                        user_counter += 1
                    head[0] = user_counter
                    writer.writerow(head)

        myfilestr.close()
        myfile.close
        print "probe values renumbered."
        os.remove(probe_file)

    user_path_arr = ["user_data_sampled//", "user_data_combined//"]
    dest_path_arr = ["initial//", "user_data_combined_r//"]
    for inde in range(user_path_arr.__len__()):
        user_counter = 0
        user_path = user_path_arr[inde]
        dest_path = dest_path_arr[inde]
        user_folder = data_path + user_path
        user_store_folder = data_path + dest_path
        directory = os.path.dirname(user_store_folder)
        try:
            os.stat(directory)
        except:
            os.mkdir(directory)
        tot_files = glob.glob(user_folder + '*.csv').__len__()
        for ind in range(1, tot_files + 1):
            if inde == 0:
                user_file = user_folder + "user_values_combined_" + str(ind) + "_sampled.csv"
            else:
                user_file = user_folder + "user_values_combined_" + str(ind) + ".csv"
            store_file = user_file.replace(user_folder, user_store_folder).replace('.csv','_r.csv')

            mystr = open(store_file, "w")
            writer = csv.writer(mystr)

            with open(user_file, "r") as myfile:
                ratings = np.zeros(tot_num)
                for line in myfile:
                    if line.__contains__('|'):
                        if not np.sum(ratings) == 0:
                            writer.writerow(ratings)
                        ratings = np.zeros(tot_num)
                        head = line.split(',')
                        head[2] = int(float(head[2].replace('\r\n', '')))
                        ind_search = int(head[0])
                        while user_arr[user_counter] < ind_search:
                            user_counter += 1
                        head[0] = user_counter
                        writer.writerow(head[0:2])

                    else:
                        head = line.split(',')
                        rating = int(head[1].replace('"','').replace('\r\n',''))
                        if tot_num < 17770:
                            new_ind_mov = movies.index(int(head[0]))
                        else:
                            new_ind_mov = int(head[0])-1
                        # writer.writerow([new_ind_mov, rating])
                        ratings[new_ind_mov] = rating

            if not np.sum(ratings) == 0:
                writer.writerow(ratings)
            myfile.close
            print "file", user_file.replace(user_folder, ''), "renumbered"
            mystr.close
        if inde == 0:
            shutil.rmtree(user_folder)
            print "all sampled users renumbered."
        else:
            print "all users renumbered."


def netflix_renumber_full(net_path = "Netflix_dataset//"):

    user_arr = []
    user_data_path = net_path
    user_data_folder = user_data_path + "user_data_combined//"
    tot_files = np.size(glob.glob(user_data_folder + '*.csv'))
    for ind in range(1,tot_files+1):
        user_data_file = user_data_folder + "user_values_combined_" + str(ind) + ".csv"
        myfile = open(user_data_file, "r")
        for line in myfile:
            if line.__contains__('|'):
                head = line.split(',')
                user_arr.append(int(head[0]))
        myfile.close()
    # print user_arr

    data_path = net_path

    user_counter = 0
    probe_name = "probe_values_by_users.csv"
    probe_file = data_path + probe_name
    probe_store_file = data_path + probe_name.replace('.csv', '_r.csv')
    if not os.path.isfile(probe_store_file):
        myfilestr = open(probe_store_file, "w")
        writer = csv.writer(myfilestr)
        with open(probe_file, "r") as myfile:
            for line in myfile:
                if not line.__contains__('|'):
                    head = line.split(',')
                    rating = int(float(head[1].replace('\r\n', '')))
                    new_ind_mov = int(head[0]) - 1
                    writer.writerow([new_ind_mov, rating])
                else:
                    head = line.split(',')
                    head[2] = int(float(head[2].replace('\r\n', '')))
                    ind_search = int(head[0])
                    while user_arr[user_counter] < ind_search:
                        user_counter += 1
                    head[0] = user_counter
                    writer.writerow(head)

        myfilestr.close()
        myfile.close
        print "probe values renumbered."
        os.remove(probe_file)

    user_path_arr = ["user_data_sampled//", "user_data_combined//"]
    dest_path_arr = ["initial//", "user_data_combined_r//"]
    for inde in range(user_path_arr.__len__()):
        user_counter = 0
        user_path = user_path_arr[inde]
        dest_path = dest_path_arr[inde]
        user_folder = data_path + user_path
        user_store_folder = data_path + dest_path
        directory = os.path.dirname(user_store_folder)
        try:
            os.stat(directory)
        except:
            os.mkdir(directory)
        tot_files = glob.glob(user_folder + '*.csv').__len__()
        for ind in range(1, tot_files + 1):
            if inde == 0:
                user_file = user_folder + "user_values_combined_" + str(ind) + "_sampled.csv"
            else:
                user_file = user_folder + "user_values_combined_" + str(ind) + ".csv"
            store_file = user_file.replace(user_folder, user_store_folder).replace('.csv','_r.csv')

            mystr = open(store_file, "w")
            writer = csv.writer(mystr)

            with open(user_file, "r") as myfile:
                for line in myfile:
                    if line.__contains__('|'):

                        head = line.split(',')
                        head[2] = int(float(head[2].replace('\r\n', '')))
                        ind_search = int(head[0])
                        while user_arr[user_counter] < ind_search:
                            user_counter += 1
                        head[0] = user_counter
                        writer.writerow(head[0:2])

                    else:
                        head = line.split(',')
                        rating = int(head[1].replace('"','').replace('\r\n',''))
                        new_ind_mov = int(head[0])-1
                        # writer.writerow([new_ind_mov, rating])
                        writer.writerow([new_ind_mov, rating])

            myfile.close
            print "file", user_file.replace(user_folder, ''), "renumbered"
            mystr.close
        if inde == 0:
            shutil.rmtree(user_folder)
            print "all sampled users renumbered."
        else:
            print "all users renumbered."

def const_probe_not_from_train_set(Y, Y_star, data_path="", test_frac = 0.01):
    tot_train_ratings = Y_star.nnz
    sample_ratings = int(tot_train_ratings * test_frac)
    probe = Y - Y_star
    proj_omega = probe.nonzero()
    pos_set = zip(proj_omega[0], proj_omega[1])
    samples = np.random.choice(len(pos_set), size=sample_ratings, replace=False)
    samples = sorted(samples)
    probe_inds = [pos_set[i] for i in samples]

    probe_name = "probe_values_by_users_r.csv"
    probe_store_file = data_path + probe_name
    myfilestr = open(probe_store_file, "w")
    writer = csv.writer(myfilestr)
    cur_user = -1
    for ind in probe_inds:
        if not (cur_user == ind[0]):
            cur_user = ind[0]
            writer.writerow([cur_user, "|"])
        movie = ind[1]
        rating = float(probe[ind])
        writer.writerow([movie, rating])
    myfilestr.close()
    print("New probe constructed.")

def renumber_original_data(path=""):
    training_data_folder = path + "training_set//"
    file_name_start = "combined_data_"
    tot_files = np.size(glob.glob(training_data_folder + file_name_start + '*.txt'))

    user_numbers = set()
    for ind in range(1, tot_files + 1):
        temp_list = []
        training_data_file = training_data_folder + file_name_start + str(ind) + ".txt"
        myfile = open(training_data_file, "r")
        lines = myfile.readlines()
        for line in lines:
            if line.__contains__(':'):
                user_numbers.update(temp_list)
                temp_list = []
            else:
                head = line.split(',')
                temp_list.append(int(head[0]))
        myfile.close()
        del lines
        user_numbers.update(temp_list)
        print(training_data_file + " done")
    user_numbers = list(sorted(user_numbers))
    user_dict = {}
    for ind in range(len(user_numbers)):
        user_dict[user_numbers[ind]] = ind
    del user_numbers
    print("User numbers done.")

    Y = [{} for _ in range(len(user_dict))]
    print("Y initialized.")
    for ind in range(1, tot_files + 1):
        training_data_file = training_data_folder + file_name_start + str(ind) + ".txt"
        myfile = open(training_data_file, "r")
        lines = myfile.readlines()
        for line in lines:
            if line.__contains__(':'):
                head = line.split(':')
                movie = int(head[0]) - 1
                if movie%1000 == 0:
                    print("Starting for movie: " + str(movie))
            else:
                head = line.split(',')
                user = user_dict[int(head[0])]
                rating = int(head[1])
                Y[user][movie] = rating
        myfile.close()
        del lines
        print(training_data_file + " done")
    print("Y constructed.")
    # print(Y)
    tot_users = len(user_dict)

    probes = [{} for _ in range(tot_users)]
    probe_file = path + "probe.txt"
    myfile = open(probe_file, "r")
    lines = myfile.readlines()
    for line in lines:
        if line.__contains__(':'):
            head = line.split(':')
            movie = int(head[0]) - 1
        else:
            user = user_dict[int(line)]
            probes[user][movie] = Y[user][movie]
            del Y[user][movie]
    myfile.close()
    del lines
    print("probes constructed.")
    probe_file = path + "probe_values_by_users_r.csv"
    myfilestr = open(probe_file, "w")
    writer = csv.writer(myfilestr)
    for i in range(tot_users):
        writer.writerow([i, "|"])
        for j in sorted(probes[i].iterkeys()):
            writer.writerow([j, probes[i][j]])
    myfilestr.close()
    del probes
    print("probe file done.")

    store_path = path + "training_set_r//"
    directory = os.path.dirname(store_path)
    try:
        os.stat(directory)
    except:
        os.mkdir(directory)
    users_per_file = 100000
    for file_ind in range(1, int(tot_users/users_per_file) + 2):
        file_name = store_path + "user_values_combined_" + str(file_ind) + "_r.csv"
        myfilestr = open(file_name, "w")
        writer = csv.writer(myfilestr)
        for i in range((file_ind - 1) * users_per_file, min(file_ind * users_per_file, tot_users)):
            writer.writerow([i, "|"])
            for j in sorted(Y[i].iterkeys()):
                writer.writerow([j, Y[i][j]])
        myfilestr.close()
        print(file_name + " done.")

def const_new_complete_sampled_database(path="", max_per_user = 100):
    row = []
    col = []
    data = []
    row_wise_cols = []
    row_wise_data = []
    initial_data_path = path + "training_set_r//"
    tot = np.size(glob.glob(initial_data_path + '*.csv'))
    for ind in range(1, tot + 1):
        user_file = initial_data_path + "user_values_combined_" + str(ind) + "_r.csv"
        with open(user_file, "r") as myfile:
            lines = myfile.readlines()
            for line in lines:
                if not line.__contains__('|'):
                    line.replace('\r\n', '')
                    head = line.split(',')
                    row.append(curr_user)
                    movie = int(float(head[0]))
                    rating = float(head[1])
                    col.append(movie)
                    data.append(rating)
                    row_wise_cols[curr_user].append(movie)
                    row_wise_data[curr_user].append(rating)
                else:
                    line.replace('\r\n', '')
                    head = line.split(',')
                    curr_user = int(head[0])
                    row_wise_cols.append([])
                    row_wise_data.append([])
            myfile.close()
            del lines
            print("Data from " + user_file + " loaded.")
    Y = sp.csr_matrix(sp.coo_matrix((data, (row, col))))
    print("Data loaded in function")
    del row, data, col

    row_nonz = Y.getnnz(axis=1)
    store_path = path + "sampled_set_r//"
    directory = os.path.dirname(store_path)
    try:
        os.stat(directory)
    except:
        os.mkdir(directory)

    tot_users = len(row_wise_cols)
    users_per_file = 100000
    for file_ind in range(1, int(tot_users / users_per_file) + 2):
        file_name = store_path + "user_values_combined_" + str(file_ind) + "_sampled_r.csv"
        myfilestr = open(file_name, "w")
        writer = csv.writer(myfilestr)
        for i in range((file_ind - 1) * users_per_file, min(file_ind * users_per_file, tot_users)):
            writer.writerow([i, "|"])
            if i % 10000 == 0:
                print("Starting for user: " + str(i))
            if row_nonz[i] <= max_per_user:
                for j in row_wise_cols[i]:
                    writer.writerow([j, Y[i,j]])
            else:
                sampled_list = sorted(np.random.choice(row_wise_cols[i], size=max_per_user, replace=False))
                for j in sorted(sampled_list):
                    writer.writerow([j, Y[i,j]])
        myfilestr.close()
        print(file_name + " done.")
    print("Dataset constructed.")

# renumber_original_data(path="Netflix_dataset//")
# const_new_complete_sampled_database(path="Netflix_dataset//", max_per_user = 100)

# renumber_original_data(path="C:/Users/Om/Downloads/Netflix_dataset/Demo_dataset//")
# const_new_complete_sampled_database(path="C:/Users/Om/Downloads/Netflix_dataset/Demo_dataset//", max_per_user = 1)





def const_top_movie_database(pick_top, max_per_user, test_frac, net_path = "Netflix_dataset//", built_dic_for_max = 150):
    netflix_data_const_users(tot_num=pick_top, par = 'sorted', net_path=net_path, built_dic_for_max=built_dic_for_max)
    if pick_top > built_dic_for_max:
        netflix_combine_data(tot_num=pick_top, par = 'sorted', net_path=net_path)
    sample_ratings(max_per_user = max_per_user, tot_num=pick_top, par = 'sorted', net_path=net_path)
    netflix_const_new_probe(tot_num = pick_top, frac = test_frac, net_path=net_path)
    netflix_probe_const_users(tot_num=pick_top, par = 'sorted', net_path=net_path, built_dic_for_max=built_dic_for_max)
    if pick_top > built_dic_for_max:
        netflix_combine_data(tot_num=pick_top, par = 'probe_sorted', net_path=net_path)
    netflix_renumber(tot_num = pick_top, net_path=net_path)
    print "Database for", pick_top, "movies constructed."


def netflix_prepare_dataset_all(max_samples_per_user, net_path, built_dic_for_max = 17770):
    netflix_data_const_users(built_dic_for_max = built_dic_for_max, net_path=net_path)
    if built_dic_for_max < 17770:
        netflix_combine_data(net_path=net_path)
    sample_ratings(max_samples_per_user, net_path=net_path)
    netflix_const_probe(net_path=net_path)
    netflix_probe_const_users(built_dic_for_max = built_dic_for_max, net_path=net_path)
    if built_dic_for_max < 17770:
        netflix_combine_data('probe', net_path=net_path)
    netflix_renumber_full(net_path=net_path)
    print "Database for all movies constructed."


# Just call netflix_prepare_dataset_all(max_samples_per_user, net_path = path) to construct database for all movies grouped by users,
# where path is the path to the netflix dataset
# netflix_prepare_dataset_all(max_samples_per_user = 18000, net_path = "Netflix_dataset//")



# # Pick top pick_top movies by number of ratings, sample max(max_per_user, user_ratings) per user, and generate
# # test_frac fraction of ratings for testing
# path = "Netflix_dataset//"
# netflix_sort_movies(net_path = path)
# pick_top = 400
# max_per_user = 4 * int(np.sqrt(pick_top))
# test_frac = 0.01
# const_top_movie_database(pick_top, max_per_user, test_frac, net_path = path, built_dic_for_max = 400)





# netflix_count_unique_users(pick_top,1)
# netflix_count_users()
# netflix_count_users_ratings()




















# Movielens code
def count_ratings_movielens_dataset(path = ""):
    if "ml-100k" in path:
        data_file = path + "u.data"
    else:
        data_file = path + "ratings.dat"

    tot_files = 1
    if "rb" in path:
        tot_files = 2
    for ind in range(tot_files):
        tot_ratings = 0
        user_ratings = np.zeros(71567)
        if tot_files == 2 and ind == 0:
            data_file = path + "rb.train"
        if tot_files == 2 and ind == 1:
            data_file = path + "rb.test"
        with open(data_file, "r") as myfile:
            lines = myfile.readlines()
            for line in lines:
                head = line.split('::')
                user_ratings[int(head[0]) - 1] += 1
                tot_ratings += 1
        myfile.close()
        print("Reading from " + data_file + " done. Total ratings: " + str(tot_ratings))
        if ind == 0:
            print("Users less than 1 rating: " + str((user_ratings < 1).sum()))
            train_zeros = user_ratings < 1
        else:
            print("Users less than 1 rating: " + str((user_ratings < 1).sum()))
            print("Same with train data: " + str(np.allclose(train_zeros,user_ratings < 1)))

# count_ratings_movielens_dataset(path = "C://Users//Om//Downloads//ml-10m-rb//")

def count_ratings_sparse_movielens_dataset(path = ""):
    tot_files = [path + "training_set_complete.npz", path + "probe_set.npz"]
    zero_list = [[],[]]
    for ind in range(2):
        data = sp.load_npz(tot_files[ind])
        print("Reading from " + tot_files[ind] + " done. Total ratings: " + str(data.count_nonzero()))
        row_nonz = data.getnnz(axis=1)
        tot_ratings = row_nonz.sum()

        zero_ratings = 0
        for i, ele in enumerate(row_nonz):
            if ele == 0:
                zero_ratings += 1
                zero_list[ind].append(i)
        print("Users with 0 ratings: " + str(zero_ratings))
    set_tr = set(zero_list[0])
    set_val = set(zero_list[1])
    print("Differing with train?: " + str([list(set_tr - set_val), list(set_val - set_tr)]))

# count_ratings_sparse_movielens_dataset(path="C://Users//Om//Downloads//ml-10m-rb//")

def make_smaller_dataset(path = "", pick_top = 400):
    Y = sp.load_npz(path + "training_set_complete.npz")
    val_data = sp.load_npz(path + "probe_set.npz")
    m_val, n_val = val_data.shape
    m,n = Y.shape
    if m < m_val:
        print("Validation set contains row(s) not present in training set.")
    if n < n_val:
        print("Validation set contains column(s) not present in training set.")

    if (m_val < m) or (n_val < n):
        val_data._shape = (m, n)
        for _ in range(m - m_val):
            val_data.indptr = np.append(val_data.indptr, val_data.indptr[-1])
    sp.save_npz(path + "probe_set.npz", val_data)
    Y += val_data
    del val_data
    print("Reading done. Total ratings: " + str(Y.count_nonzero()))
    col_counts = Y.getnnz(axis=0)
    top_movies = np.argsort(col_counts)[-pick_top:]
    Y_small = Y[:, top_movies]
    Y_small = Y_small[Y_small.getnnz(1) > 0]
    store_dir = path + "top" + str(pick_top) + "//"
    directory = os.path.dirname(store_dir)
    try:
        os.stat(directory)
    except:
        os.mkdir(directory)
    store_file = store_dir + "training_set_complete.npz"
    sp.save_npz(store_file, Y_small)
    print("Storing from " + store_file + " done. Shape: " + str(Y_small.shape) + ". Number of ratings: " + str(Y_small.count_nonzero()))

def const_probe(path = "", probe_frac = 0.01):
    Y = sp.load_npz(path + "training_set_complete.npz")
    tot_ind = Y.nonzero()
    tot_ind = np.array((zip(tot_ind[0], tot_ind[1])))
    tot_count = Y.count_nonzero()
    samples = np.random.choice(len(tot_ind), int(tot_count * probe_frac), replace=False)
    chosen = tot_ind[samples]
    chosen_ind = (chosen[:, 0], chosen[:, 1])
    probes = sp.csr_matrix(sp.coo_matrix((np.array(Y[chosen_ind]).flatten(), chosen_ind), shape=Y.shape))
    Y -= probes
    Y.eliminate_zeros()
    print("Probe constructed with " + str(probes.count_nonzero()) + " ratings. Left in Y: " + str(Y.count_nonzero()))
    sp.save_npz(path + "training_set_complete.npz", Y)
    sp.save_npz(path + "probe_set.npz", probes)


def transform_movielens_dataset(path = ""):
    if "ml-100k" in path:
        data_file = path + "u.data"
    else:
        data_file = path + "ratings.dat"

    movies = set()
    with open(data_file, "r") as myfile:
        lines = myfile.readlines()
        for line in lines:
            if "ml-100k" in path:
                head = line.split('\t')
            else:
                head = line.split('::')
            movies.add(int(head[1]))
    myfile.close()
    movies = list(sorted(movies))
    movies_dict = {}
    for ind in range(len(movies)):
        movies_dict[movies[ind]] = ind
    print("Movies dict constructed. Total number of movies: " + str(len(movies_dict.keys())))

    tot_files = 1
    if "rb" in path:
        tot_files = 2
    for ind in range(tot_files):
        if tot_files == 2 and ind == 0:
            data_file = path + "rb.train"
        if tot_files == 2 and ind == 1:
            data_file = path + "rb.test"
        row = []
        col = []
        data = []
        with open(data_file, "r") as myfile:
            lines = myfile.readlines()
            for line in lines:
                if "ml-100k" in path:
                    head = line.split('\t')
                else:
                    head = line.split('::')
                user = int(head[0]) - 1
                movie = movies_dict[int(head[1])]
                rating = float(head[2])
                row.append(user)
                col.append(movie)
                data.append(rating)
        myfile.close()
        print("Reading from " + data_file + " done.")
        Y = sp.csr_matrix(sp.coo_matrix((data, (row, col))))
        store_file = data_file.replace('.', '_') + ".npz"
        sp.save_npz(store_file, Y)
        print("Storing from " + store_file + " done.")

def const_probe_and_training_movielens(path = "", train_frac = 0.5):
    if "ml-100k" in path:
        data_file = path + "u_data.npz"
    else:
        data_file = path + "ratings_dat.npz"
    if "rb" in path:
        train_data = sp.load_npz(path + "rb_train.npz")
        tr_m,tr_n = train_data.shape
        test_data = sp.load_npz(path + "rb_test.npz")
        te_m, te_n = test_data.shape
        if (te_m < tr_m) or (te_n < tr_n):
            test_data._shape = (tr_m, tr_n)
            for _ in range(tr_m - te_m):
                test_data.indptr = np.append(test_data.indptr, test_data.indptr[-1])
        data = train_data + test_data
    else:
        data = sp.load_npz(data_file)
    print("Data loaded.")

    Y_store_file = path + "training_set_complete.npz"

    probe_store_file = path + "probe_set.npz"
    probe = data.copy()

    for ind in range(data.shape[0]):
        row_nnz = data[ind].nonzero()[1]
        row_nnz_len = len(row_nnz)
        if row_nnz_len > 1:
            half_samp = sorted(np.random.choice(row_nnz, int(train_frac * row_nnz_len), replace=False))
        else:
            half_samp = []
        row_left = list(set(row_nnz) - set(half_samp))
        # row_left = [x for x in row_nnz if x not in half_samp]
        probe[ind,row_left] = 0
        data[ind, half_samp] = 0
    data.eliminate_zeros()
    sp.save_npz(Y_store_file, data)
    probe.eliminate_zeros()
    sp.save_npz(probe_store_file, probe)
    print("Data split into training and sampled.")


def const_sampled_training(path = "", max_per_user = 100):
    print("Sampling training data with max " + str(max_per_user) + " ratings per user.")
    data_file = path + "training_set_complete.npz"
    data = sp.load_npz(data_file)
    probe_check_file = path + "probe_set.npz"
    probes = sp.load_npz(probe_check_file)
    probe_nonz = probes.nonzero()
    data[probe_nonz] = 0.0
    data.eliminate_zeros()
    del probes, probe_nonz
    print("Data loaded.")
    max_samp_str = "_max_samp_" + str(max_per_user)
    Y_star_store_file = path + "training_set_sampled" + max_samp_str + ".npz"
    for ind in range(data.shape[0]):
        row_nnz = data[ind].nonzero()[1]
        row_nnz_len = len(row_nnz)
        if row_nnz_len > max_per_user:
            samp_inds = sorted(np.random.choice(row_nnz, max_per_user, replace=False))
            row_left = list(set(row_nnz) - set(samp_inds))
            # row_left = [x for x in row_nnz if x not in samp_inds]
            data[ind, row_left] = 0
    data.eliminate_zeros()
    sp.save_npz(Y_star_store_file, data)
    print("Sampled training data constructed.")

# make_smaller_dataset(path="//mnt//datasets//Data_DP_Frank_Wolfe//Yahoo_dataset//", pick_top=400)
# const_probe(path="//mnt//datasets//Data_DP_Frank_Wolfe//Yahoo_dataset//top400//")
# const_sampled_training(path = "//mnt//datasets//Data_DP_Frank_Wolfe//Yahoo_dataset//top400//", max_per_user = 80)

# make_smaller_dataset(path="//mnt//datasets//Data_DP_Frank_Wolfe//Netflix_dataset//", pick_top=900)
# const_probe(path="//mnt//datasets//Data_DP_Frank_Wolfe//Netflix_dataset//top900//")
# const_sampled_training(path = "//mnt//datasets//Data_DP_Frank_Wolfe//Netflix_dataset//top900//", max_per_user = 120)

path_for_movielens = "C://Users//Om//Downloads//FW Datasets//ml-10m-rb//Not Used//"
transform_movielens_dataset(path = path_for_movielens)
const_probe_and_training_movielens(path = path_for_movielens)
make_smaller_dataset(path= path_for_movielens, pick_top=400)
const_probe(path= path_for_movielens + "top400//")
const_sampled_training(path = path_for_movielens + "top400//", max_per_user = 80)

def transform_yahoo_dataset(path = ""):
    data_files = ["trainIdx1.txt", "validationIdx1.txt", "testIdx1.txt"]

    for ind in range(len(data_files)):
        ratings_count = 0
        if not ind==1:
            row = []
            col = []
            data = []
        with open(path + data_files[ind], "r") as myfile:
            lines = myfile.readlines()
            for line in lines:
                if line.__contains__('|'):
                    head = line.split('|')
                    user = int(head[0])
                else:
                    head = line.split('\t')
                    movie = int(head[0])
                    rating = float(head[1])/20
                    if rating == 0.0:
                        rating = 1e-8  # So that it remains non-zero in the sparse matrix
                    row.append(user)
                    col.append(movie)
                    data.append(rating)
                    ratings_count += 1
        myfile.close()
        print("Reading from " + data_files[ind] + " done. Number of ratings: " + str(ratings_count))
        if not ind == 0:
            Y = sp.csr_matrix(sp.coo_matrix((data, (row, col))))
            print("Y shape: " + str(Y.shape))
            if ind == 1:
                store_file = path + "training_set_complete.npz"
            else:
                store_file = path + "probe_set.npz"
            sp.save_npz(store_file, Y)
            print("Storing from " + store_file + " done.")

# transform_yahoo_dataset(path="//mnt//datasets//Data_DP_Frank_Wolfe//Yahoo_dataset//")

def transform_jester_dataset(path = ""):
    file_str = "jester-data-"
    data_files = []
    for i in range(1,4):
        data_files.append(file_str+str(i)+".xls")

    data = []
    for ind in range(len(data_files)):
        ratings_count = 0
        with xlrd.open_workbook(path + data_files[ind]) as myfile:
            sheet = myfile.sheet_by_index(0)
            for row in range(sheet.nrows):
                line = sheet.row_values(row)
                line = np.array(line[1:])
                line += 10
                line /= 4
                line = [x if not x == 27.25 else 0.0 for x in line]
                data.append(line)

        print("Reading from " + data_files[ind] + " done.")
    Y = sp.csr_matrix(data)
    print("Number of ratings: " + str(Y.count_nonzero()))
    store_file = path + "training_set_complete.npz"
    sp.save_npz(store_file, Y)
    print("Storing from " + store_file + " done.")

# transform_jester_dataset(path="//mnt//datasets//Data_DP_Frank_Wolfe//Yahoo_dataset//")
# transform_jester_dataset(path="C://Users//Om//Downloads//Jester//")
# const_probe(path="C://Users//Om//Downloads//Jester//")

def count_jester_dataset(path = "", rating = -10.0):
    file_str = "jester-data-"
    data_files = []
    for i in range(1,4):
        data_files.append(file_str+str(i)+".xls")

    data = []
    ratings_count = 0
    for ind in range(len(data_files)):
        with xlrd.open_workbook(path + data_files[ind]) as myfile:
            sheet = myfile.sheet_by_index(0)
            for row in range(sheet.nrows):
                line = sheet.row_values(row)
                line = np.array(line[1:])
                for x in line:
                    if x == rating:
                        ratings_count += 1
        print("Reading from " + data_files[ind] + " done.")
    print("Number of ratings equal to " + str(rating) + ": " + str(ratings_count))
# count_jester_dataset(path="C://Users//Om//Downloads//Jester//Not used//")










# Old code
def yahoo_rescale_ratings(data_path = "Yahoo_dataset//ydata-ymusic-kddcup-2011-track1//", store_path = "Yahoo_dataset//large_scaled//"):
    directory = os.path.dirname(store_path)
    try:
        os.stat(directory)
    except:
        os.mkdir(directory)
    train_name = "trainIdx1.txt"
    test_name = "testIdx1.txt"
    validate_name = "validationIdx1.txt"

    scaled_train_name = "trainIdx1_scaled.csv"
    scaled_test_name = "testIdx1_scaled.csv"
    scaled_validate_name = "validationIdx1_scaled.csv"

    validate_file = data_path + train_name
    store_file = store_path + scaled_train_name
    mystr = open(store_file,"w")
    writer = csv.writer(mystr)
    with open(validate_file,"r") as myfile:
        for line in myfile:
            if line.__contains__('|'):
                head = line.split('|')
                writer.writerow([int(head[0]), '|', int(head[1].replace('\n',''))])
            else:
                rating = line.split('\t')
                rating[1] = (int(rating[1]) * 5.0) / 100
                writer.writerow(rating[0:2])
    myfile.close
    mystr.close()

def yahoo_sample(n, data_path = "Yahoo_dataset//large_scaled//", store_path = "Yahoo_dataset//sampled//"):

    train_name_sampled = "trainIdx1_scaled_sampled.csv"
    test_name_sampled = "testIdx1_scaled_sampled.csv"
    validate_name_sampled = "validationIdx1_scaled_sampled.csv"

    scaled_train_name = "trainIdx1_scaled.csv"
    scaled_test_name = "testIdx1_scaled.csv"
    scaled_validate_name = "validationIdx1_scaled.csv"

    user_file = data_path + scaled_train_name
    store_file = store_path + train_name_sampled
    mystr = open(store_file, "w")
    writer = csv.writer(mystr)
    count = 0

    with open(user_file,"r") as myfile:
        local_count = -1
        local_tot = -1
        sampled = []
        for line in myfile:
            if line.__contains__('|'):
                if count%10000 == 0:
                    print count, "users sampled"

                count += 1

                head = line.split(',')
                local_tot = int(head[2].replace('\n', ''))
                local_count = 0
                if local_tot < n:
                    writer.writerow([head[0], '|', local_tot])
                    sampled = range(local_tot)
                else:
                    writer.writerow([head[0], '|', n])
                    sampled = rand.sample(range(local_tot), n)
            else:
                if sampled.__contains__(local_count):
                    rating = line.split(',')
                    writer.writerow([rating[0], rating[1].replace('\n', '')])
                local_count += 1
    myfile.close
    mystr.close()

# yahoo_rescale_ratings()
# sample_yahoo(200)