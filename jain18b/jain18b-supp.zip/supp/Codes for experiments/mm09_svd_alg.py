from __future__ import division
from __future__ import print_function
import gc
import timeit
import numpy as np
import scipy.linalg.interpolative as sli
import scipy.sparse as sp
import math
import csv

dataset = ['Netflix', 'Movielens', 'Synthetic', 'Yahoo', 'Jester']
run_on_dataset = dataset[4]
max_samp = 120
beta_p_arr = np.arange(5, 16, 5)
beta_m_arr = np.arange(5, 16, 5)
beta_arr = np.arange(5, 26, 5)


if run_on_dataset == dataset[4]:
    max_samp = 100
# eps_arr = [0.2]
reg_arr = [0.1, 0.3]
eps_arr = [20, 10, 5, 2, 1, 0.5, 0.1]
delta = pow(10, -6)
if max_samp == 80:
    ml_data_str = "ml-10m-rb//top400//"
else:
    ml_data_str = "ml-10m-rb//top900//"
print("run_on_dataset: " + run_on_dataset)
print("max samp: " + str(max_samp))
print("eps_arr: " + str(eps_arr))

def algo_MM09(Y_star, val_data, val_nonzero, tot_nonzero,
              eps, delta, range_ratings, k=20.0, regularization = 0.0, max_samp = 80,
              beta_p = 20.0, beta_m = 15.0, beta = 30.0):
    m,n = Y_star.shape
    count_val = val_nonzero[0].__len__()
    print("Total ratings in val_data: " + str(val_data.nnz))
    print("count_val: " + str(count_val))
    row_nonz = val_data.getnnz(axis=1)
    zero_ratings = 0
    for ele in row_nonz:
        if ele == 0:
            zero_ratings += 1
    print("Users with 0 ratings in val data: " + str(zero_ratings))
    ones_val = sp.csr_matrix(sp.coo_matrix(([1] * count_val, val_nonzero)))
    m_val, n_val = val_data.shape
    if m < m_val:
        print("Validation set contains row(s) not present in training set.")
    if n < n_val:
        print("Validation set contains column(s) not present in training set.")

    if (m_val < m) or (n_val < n):
        val_data._shape = (m, n)
        for _ in range(m - m_val):
            val_data.indptr = np.append(val_data.indptr, val_data.indptr[-1])
    print("Shape of val data: " + str(val_data.shape))
    m_val, n_val = ones_val.shape
    if m < m_val:
        print("Validation set contains row(s) not present in training set.")
    if n < n_val:
        print("Validation set contains column(s) not present in training set.")

    if (m_val < m) or (n_val < n):
        ones_val._shape = (m, n)
        for _ in range(m - m_val):
            ones_val.indptr = np.append(ones_val.indptr, ones_val.indptr[-1])
    print("Shape of ones_val: " + str(ones_val.shape))

    delta_i = delta/3
    eps_arr = eps * np.array([0.02, 0.19, 0.79])
    eps_arr[0] = eps_arr[0] * np.sqrt(max_samp)  # Since used for computing averages
    eps_arr[1] = eps_arr[1] * np.sqrt(max_samp)  # Since used for computing averages
    sigma_arr = (np.sqrt(2 * np.log(2 / delta_i))) / eps_arr
    tr_start_time = timeit.default_timer()
    col_sums = np.array(Y_star.sum(axis=0))[0]
    col_sums_noisy = col_sums + np.random.normal(0, sigma_arr[1] * range_ratings, col_sums.shape)
    col_nonz = Y_star.getnnz(axis=0)
    col_nonz_noisy = col_nonz + np.random.normal(0, sigma_arr[1], col_nonz.shape)
    tot_ratings = col_nonz.sum()
    r_bar = (col_sums.sum() + np.random.normal(0, sigma_arr[0] * range_ratings))/\
            (tot_ratings + np.random.normal(0, sigma_arr[0]))
    print("tot_ratings: " + str(tot_ratings))
    proj_omega = Y_star.nonzero()
    ones_p_omega = sp.csr_matrix(sp.coo_matrix(([1] * tot_ratings, proj_omega)))
    # print(len(tot_nonzero[0]))
    # print(np.shape(tot_nonzero))
    ones_tot_nonzero = sp.csr_matrix(sp.coo_matrix(([1] * len(tot_nonzero[0]), tot_nonzero)))

    r_bar_m = (col_sums_noisy + beta_m * r_bar) / (col_nonz_noisy + beta_m)
    r_bar_m_diag = sp.csr_matrix(sp.coo_matrix((r_bar_m, (range(len(r_bar_m)), range(len(r_bar_m))))))
    print("Shape(r_bar_m_diag): " + str(r_bar_m_diag.shape))

    Y_star -= ones_p_omega.dot(r_bar_m_diag)

    # val_data -= ones_val.dot(r_bar_m_diag)

    row_sums = np.array(Y_star.sum(axis=1).flatten())
    row_nonz = Y_star.getnnz(axis=1)
    r_bar_u_temp = (row_sums + beta_p * r_bar) / (row_nonz + beta_p)
    r_bar_u = r_bar_u_temp[0]
    r_bar_u_diag = sp.csr_matrix(sp.coo_matrix((r_bar_u, (range(len(r_bar_u)), range(len(r_bar_u))))))
    Y_star -= r_bar_u_diag.dot(ones_p_omega)
    # val_data -= r_bar_u_diag.dot(ones_val)

    nz_row = np.array(proj_omega[0])
    nz_col = np.array(proj_omega[1])
    large_inds = np.array(Y_star[proj_omega] > 1)[0]
    Y_star[(nz_row[large_inds], nz_col[large_inds])] = 1.0
    small_inds = np.array(Y_star[proj_omega] < -1)[0]
    Y_star[(nz_row[small_inds], nz_col[small_inds])] = -1.0

    gc.collect()
    w_u = 1.0/np.array(row_nonz)
    w_u_mat = sp.csr_matrix(sp.coo_matrix((w_u.flatten(), (range(len(w_u)), range(len(w_u))))))
    cov = (Y_star.T * w_u_mat.dot(Y_star)).todense() +\
          np.random.normal(0, sigma_arr[2] * (1 + 2 * np.sqrt(2)),(Y_star.shape[1],Y_star.shape[1]))
    cov_avg = np.average(cov)
    wgt = (ones_p_omega.T * w_u_mat.dot(ones_p_omega)).todense() + \
          np.random.normal(0, sigma_arr[2] * (np.sqrt(2)), (Y_star.shape[1], Y_star.shape[1]))
    wgt_avg = np.average(wgt)
    print("beta: " + str(beta))
    cov = (cov + beta * cov_avg) / (wgt + beta * wgt_avg)

    U, S, V = sli.svd(cov, min(k, m, n))
    if regularization == 0.0:
        U = (Y_star * V)/S
        S = sp.csr_matrix(sp.coo_matrix((S.flatten(), (range(len(S)), range(len(S))))))
        US = U * S
    else:
        US = np.zeros((m,int(k)))
        reg_eye = regularization * np.eye(int(k))
        for user in range(m):
            t = Y_star.getrow(user)
            t_nz = t.nonzero()
            if len(t_nz[1])>0:
                t = np.array(t[t_nz])[0]
                X = V[t_nz[1],]
                US[user] = np.dot(np.dot(np.linalg.inv(np.dot(X.T, X) + reg_eye),X.T),t.T).T
            # if user % 100000 == 0:
            #     print("U computation till user " + str(user) + " completed.")
    UVT1 = sp.csr_matrix(sp.coo_matrix(([1] * len(tot_nonzero[0]), tot_nonzero)))
    Y_pred = sp.csr_matrix(sp.coo_matrix(([0] * len(tot_nonzero[0]), tot_nonzero)))


    # UVT1 = sp.csr_matrix(sp.coo_matrix(([1] * len(proj_omega[0]), proj_omega)))
    # pred = sp.csr_matrix(sp.coo_matrix(([0] * len(proj_omega[0]), proj_omega)))

    for i in range(US.shape[1]):
        U_UVT = sp.csr_matrix(sp.coo_matrix((US[:,i].flatten(), (range(len(US[:,i])), range(len(US[:,i])))))).dot(UVT1)
        Y_pred += U_UVT.dot(sp.csr_matrix(sp.coo_matrix((V[:,i].flatten(), (range(len(V[:,i])), range(len(V[:,i])))))))

    # pred = (U * S).dot(V.T)

    tr_elapsed = timeit.default_timer() - tr_start_time
    Y_pred += r_bar_u_diag.dot(ones_tot_nonzero)
    Y_pred += ones_tot_nonzero.dot(r_bar_m_diag)
    nz_row = np.array(tot_nonzero[0])
    nz_col = np.array(tot_nonzero[1])
    large_inds = np.array(Y_pred[tot_nonzero] > range_ratings)[0]
    Y_pred[(nz_row[large_inds], nz_col[large_inds])] = range_ratings
    small_inds = np.array(Y_pred[tot_nonzero] < 0)[0]
    Y_pred[(nz_row[small_inds], nz_col[small_inds])] = 0.0
    print("Algo done in function in " + str(int(tr_elapsed)) + " seconds.")
    # err_val_mat = sp.csr_matrix(sp.coo_matrix(([0.0] * count_val, val_nonzero)))
    err_val_mat = Y_pred.multiply(ones_val) - val_data
    val_err_sq = err_val_mat.power(2).sum()
    val_err = math.sqrt(val_err_sq / count_val)
    return val_err

disk_path = "//mnt//datasets//Data_DP_Frank_Wolfe//"
if run_on_dataset == dataset[4]:
    pick_top = 100
    eps_rating = []
    for i in range(len(eps_arr)):
        eps_rating.append(float(eps_arr[i]) / max_samp)
else:
    if max_samp == 80:
        pick_top = 400
    else:
        pick_top = 900
    max_samp_str = "_max_samp_" + str(max_samp)
    eps_rating = []
    for i in range(len(eps_arr)):
        eps_rating.append(float(eps_arr[i]) / max_samp)

if run_on_dataset == dataset[4]:
    path = disk_path + "Jester//"
    range_ratings = 5
elif run_on_dataset == dataset[0]:
    path = disk_path + "Netflix_dataset//top" + str(pick_top) + "//"
    range_ratings = 4
elif run_on_dataset == dataset[1]:
    path = disk_path + ml_data_str
    range_ratings = 4.5
elif run_on_dataset == dataset[2]:
    path = disk_path + "Synthetic//"
    users = 500000
    if max_samp == 80:
        movies = 400
    else:
        movies = 900
    range_ratings = 1
else:
    path = disk_path + "Yahoo_dataset//top" + str(pick_top) + "//"
    range_ratings = 5

if run_on_dataset == dataset[2]:
    Y_star_file_name = path + "Synth_train_" + str(users) + "_" + str(movies) + "_sampled_" + str(
        max_samp) + ".npz"
elif not run_on_dataset == dataset[4]:
    Y_star_file_name = path + "training_set_sampled" + max_samp_str + ".npz"
else:
    Y_star_file_name = path + "training_set_complete.npz"

print("Y_star file name: " + Y_star_file_name)
Y_star = sp.load_npz(Y_star_file_name)
m,n = Y_star.shape
print("Total ratings in Y_star: " + str(Y_star.count_nonzero()))

proj_omega = Y_star.nonzero()
if not run_on_dataset == dataset[2]:
    val_file = path + "probe_set.npz"
else:
    val_file = path + "probe_set_" + str(users) + "_" + str(movies) + "_sampled_" + str(
        max_samp) + ".npz"
val_data = sp.load_npz(val_file)
val_nonzero = val_data.nonzero()
m_val, n_val = val_data.shape
if m < m_val:
    print("Validation set contains row(s) not present in training set.")
if n < n_val:
    print("Validation set contains column(s) not present in training set.")

if (m_val < m) or (n_val < n):
    val_data._shape = (m, n)
    for _ in range(m - m_val):
        val_data.indptr = np.append(val_data.indptr, val_data.indptr[-1])
tot_nonzero = (Y_star + val_data).nonzero()
print("Probe set number of entries: " + str(len(val_nonzero[0])))
print("Total set number of entries: " + str(len(tot_nonzero[0])))

final_store_path = "Results//"
if run_on_dataset == dataset[0]:
    data_str = "Netf_" + str(pick_top)
elif run_on_dataset == dataset[1]:
    data_str = ml_data_str.replace("//", "")
elif run_on_dataset == dataset[3]:
    data_str = "Yahoo_" + str(pick_top)
elif run_on_dataset == dataset[4]:
    data_str = "Jester_"
else:
    data_str = "Synth_" + str(movies)
str_file = final_store_path + "MM09_" + data_str + ".csv"
for beta_p in beta_p_arr:
    for beta_m in beta_m_arr:
        for beta in beta_arr:
            for reg in reg_arr:
                print("beta_p: " + str(beta_p) + ", beta_m: " + str(beta_m) + ", beta: " + str(beta))
                print("reg: " + str(reg))
                errs = []
                for i, eps in enumerate(eps_rating):
                    print("Calling MM09 for eps: " + str(eps_arr[i]))
                    err = algo_MM09(Y_star, val_data, val_nonzero, tot_nonzero,
                              eps, delta, range_ratings,regularization=reg, max_samp = max_samp,
                                    )
                    print("eps: " + str(eps_arr[i]) + ", val error: " + str(err))
                    errs.append(err)
                with open(str_file, "a") as myfile:
                    writer = csv.writer(myfile)
                    writer.writerow([beta_p, beta_m, beta, reg])
                    writer.writerow(errs)
                    print("Updating str file done.")
                print("eps arr: " + str(eps_arr))
                print("val err: " + str(errs))


