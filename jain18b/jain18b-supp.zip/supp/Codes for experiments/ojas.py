import scipy.linalg as sl
import numpy as np
from scipy.sparse import csr_matrix
import scipy.sparse as sp
import scipy.sparse.linalg as ssl
import scipy.linalg.interpolative as sli
import timeit

def top_svd(X):
    U, S, V = sli.svd(X, 1)
    return S[0], V[:, 0]

def ojas_alg(W, sigma, v):
    n = W.shape[0]
    _, S, _ = ssl.svds(W, min(n - 1, 5))
    eta = S[0]
    v_t = (np.eye(n) + eta * W).dot(v.T).T + eta * np.random.normal(0, sigma, v.shape)
    v_t = v_t/sl.norm(v_t)
    sing_t = np.linalg.norm(W.dot(v_t.T)) + np.random.normal(0, sigma)
    return sing_t, v_t

sigma = 1.5
n = 20000
W_t = sp.random(n, n, density=np.sqrt(n)/n)
dense_start_time = timeit.default_timer()
print("to_dense started")
X_t = W_t.todense()
dense_elapsed = timeit.default_timer() - dense_start_time
print("to_dense done in " + str(int(dense_elapsed)) + " seconds.")
noja_start_time = timeit.default_timer()
print("noja started")
X_t += np.random.normal(0, sigma, (n, n))
sing_1, V = top_svd(X_t)
noja_elapsed = timeit.default_timer() - noja_start_time
print("noja done in " + str(int(noja_elapsed)) + " seconds.")

V = np.random.normal(0, sigma, (1, n))
oja_start_time = timeit.default_timer()
print("oja started")
sing_1, V = ojas_alg(W_t, sigma, V)
oja_elapsed = timeit.default_timer() - oja_start_time
print("oja done in " + str(int(oja_elapsed)) + " seconds.")



