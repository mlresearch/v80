Sound files reconstructed from spectrogram using the Griffin-Lim algorithm with 1000 iterations.

The algorithm only models the magnitude (or amplitude) of the spectrum. This means the phase needs to be estimated for signal reconstruction, which might affect the quality of the synthesised speech. 

We believe that a better phase estimation algorithm will improve the sound quality.
