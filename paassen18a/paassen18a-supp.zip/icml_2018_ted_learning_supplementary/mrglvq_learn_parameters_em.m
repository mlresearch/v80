function [ params, W, err] = mrglvq_learn_parameters_em( X, Y, comp, params, algo, W, train_idxs, regul_fun, param_fun, optimizer )
% Learns the optimal metric parameters by median relational generalized
% learning vector quantization in an alternating optimization scheme.
% In particular, in each training epoch, we first adapt the metric and
% then adapt the prototypes.
%
% Parameters:
% X           - a m-element list of trees.
% Y           - the data point labels.
% comp        - a java object which provides the function 'setParameters'
%               to set the current parameters. Using this function should
%               also influence all the calculations made by the following
%               java objects.
% params      - the initial parameter settings.
% algo        - an algorithm which computes a CooptimalMatrix for the
%               input trees.
% W           - a K x 1 vector containing the prototype indices for median
%               relational GLVQ in terms of the train_idxs.
% train_idxs  - a n x 1 vector containing data point indices for training.
% regul_fun   - (optional) a function which returns a regularization error
%               and a regularization gradient for a given parameter vector
% param_fun   - (optional) a function handle to post-process parameters
%               after a gradient step
% optimizer   - (optional) a string flag determining which optimizer to
%               use. Either 'lbfgs' or 'desc'. 'lbfgs' per default.
%
% Outputs:
% params      - the optimal metric parameters found via MRGLVQ metric learning
% W           - the prototype indices after learning
% err         - the initial GLVQ error and the error after each epoch

m = X.size();

if(nargin < 2 || ~isvector(Y) || numel(Y) ~= m)
    error('expected an %d x 1 label vector as second argument!', m);
end

if(nargin < 7 || isempty(train_idxs))
    train_idxs = 1:m;
elseif(~isvector(train_idxs) || any(train_idxs < 1) || any(train_idxs ~= round(train_idxs)) || any(train_idxs > m))
    error('expected a data point index vector specifying the training data points as seventh argument!');
end

if(nargin < 6 || ~isvector(W) || any(W < 1) || any(W ~= round(W)) || any(W > numel(train_idxs)))
    error('expected a data point index vector specifying the median prototypes in terms of the training indices as sixth argument!');
end

if(nargin < 8)
    regul_fun = [];
end

if(nargin < 9)
    param_fun = [];
end

if(nargin < 10 || isempty(optimizer))
    optimizer = 'lbfgs';
elseif(~ischar(optimizer) || (~strcmp(optimizer, 'lbfgs') && ~strcmp(optimizer, 'desc')))
    error('Expected either lbfgs or desc as tenth argument');
end

initial_params = params;

% compute the cooptimal matrices between data and prototypes
X_W = de.citec.tcs.utils.MatlabListInterface.selectFromList(X, train_idxs(W));
algo.setComparator(comp);
comp.setParameters(initial_params);
try
    algo.setCrispness(inf);
catch
end
try
    engine = de.citec.tcs.alignment.trees.TreeParallelProcessingEngine(algo, X, X_W);
catch
    engine = de.citec.tcs.alignment.ParallelProcessingEngine(algo, X, X_W);
end
engine.setReporter([]);
engine.setFull();
engine.calculate();
C_W = engine.getResultMatrix();

% compute the cooptimal matrices between training data points
X_train = de.citec.tcs.utils.MatlabListInterface.selectFromList(X, train_idxs);
try
    engine = de.citec.tcs.alignment.trees.TreeSquareParallelProcessingEngine(algo, X_train);
catch
    engine = de.citec.tcs.alignment.SquareParallelProcessingEngine(algo, X_train);
end
engine.setReporter([]);
engine.setFull();
engine.calculate();
C_train = engine.getResultMatrix();

% set up the distance engine for training
dist_engine_train = de.citec.ml.icml2018.lmnn.CooptimalDistanceEngine(C_train, comp);
dist_engine_train.setFull();
dist_engine_train.setReporter([]);

% set up the engines for distance computation and gradient calculation
dist_engine = de.citec.ml.icml2018.lmnn.CooptimalDistanceEngine(C_W, comp);
dist_engine.setFull();
dist_engine.setReporter([]);

% set up the gradient calculator
grad_calc = de.citec.ml.icml2018.medianglvq.MedianGLVQCooptimalGradientCalculator(C_W, Y, train_idxs(W) - 1);
grad_calc.setReporter([]);

% compute the initial error
err = mrglvq_error_and_gradient(initial_params, dist_engine, grad_calc, comp, regul_fun, param_fun);

% start with the actual optimization process
while(true)

    % optimize metric parameters using gradient descent
    if(strcmp(optimizer, 'desc'))
        err_last2   = inf;
        err_last    = inf;
        eta         = 1. / (m * 2 * numel(W));
        params_last = params;
        params_new  = params;
        while(true)
            % compute the gradient
            [new_err, grad] = mrglvq_error_and_gradient(params_new, dist_engine, grad_calc, comp, regul_fun, param_fun);
            if(abs(err_last - new_err) < 1E-3)
                % if the error does not change much anymore, stop the search.
                break;
            elseif(err_last < new_err)
                % if the error has grown, take the last gradient step back
                % reduce the learning rate and try again
                eta = eta * 0.5;
                params_new = params_last;
                err_last = err_last2;
                continue;
            end
            % otherwise continue the search
            params_last = params_new;
            err_last2 = err_last;
            err_last    = new_err;
            % and increase the learning rate
            eta = eta * 1.5;
            % do a gradient step
            params_new  = params_new - eta * grad;
        end
        current_err = new_err;
    else
        options = optimoptions('fminunc','Algorithm', 'quasi-newton', ... %'trust-region', ...
            'SpecifyObjectiveGradient',true, 'Display', 'final',...
            'MaxFunEvals', 200);
        [params_new, current_err] = fminunc(@(params_new) (mrglvq_error_and_gradient(params_new, dist_engine, grad_calc, comp, regul_fun, param_fun)), params, options);
    end
    if(abs(current_err - err(end)) < 1E-3)
        % stop if we can not really decrease the error anymore.
        break;
    end

    if(~isempty(param_fun))
        params   = param_fun(params_new);
    else
        params   = params_new;
    end
    err = [err, current_err];
    
    % optimize the prototypes using median relational GLVQ
    comp.setParameters(params);

    dist_engine_train.calculate();
    D    = dist_engine_train.getDoubleResultMatrix();
    mrglvq_model = de.citec.ml.mrglvq.MedianRelationalGLVQ.train(D, Y(train_idxs), W - 1);
    W_new = mrglvq_model.getPrototypeIndices() + 1;
    % check if the prototypes have actually changed
    if(all(sort(W) == sort(W_new)))
        % if not, we end the training
        break;
    end
    % check if the error 
    
    W = W_new;
    % otherwise we re-compute the cooptimal matrix
    X_W = de.citec.tcs.utils.MatlabListInterface.selectFromList(X, train_idxs(W_new));
    algo.setComparator(comp);
    comp.setParameters(initial_params);
    try
        engine = de.citec.tcs.alignment.trees.TreeParallelProcessingEngine(algo, X, X_W);
    catch
        engine = de.citec.tcs.alignment.ParallelProcessingEngine(algo, X, X_W);
    end
    engine.setReporter([]);
    engine.setFull();
    engine.calculate();
    C_W = engine.getResultMatrix();
    dist_engine = de.citec.ml.icml2018.lmnn.CooptimalDistanceEngine(C_W, comp);
    dist_engine.setFull();
    dist_engine.setReporter([]);

    % set up the gradient calculator
    grad_calc = de.citec.ml.icml2018.medianglvq.MedianGLVQCooptimalGradientCalculator(C_W, Y, train_idxs(W_new) - 1);
    grad_calc.setReporter([]);

    % check if the error for the metric learning data has improved by re-learning the prototypes
    new_err = mrglvq_error_and_gradient(params_new, dist_engine, grad_calc, comp, regul_fun, param_fun);
    % If the error got worse, use the prototypes from before and end the
    % search
    if(new_err > err(end))
        break;
    end
    W = W_new;
end

end


% dist_engine - a java object which provides the functions 'calculate()' to
%               calculate all pairwise distances and
%               'getDoubleResultMatrix()' to retrieve the results.
% grad_calc   - a java object which provides the functions
%               'computeErrorAndGradient' which takes a comparator and a 
%               matrix of pairwise distances as inputs and outputs a vector
%               containing the current LMNN error as first output and the
%               current gradient as remaining output.
% regul_fun   - (optional) a function which returns a regularization error
%               and a regularization gradient for a given parameter vector
% param_fun   - (optional) a function handle to post-process parameters
%               after a gradient step
function [err, grad] = mrglvq_error_and_gradient(params, dist_engine, grad_calc, comp, regul_fun, param_fun)

if(~isempty(param_fun))
    params = param_fun(params);
end

comp.setParameters(params);

dist_engine.calculate();
D    = dist_engine.getDoubleResultMatrix();

err_and_grad = grad_calc.computeErrorAndGradient(comp, D);

if(any(~isfinite(err_and_grad) | isnan(err_and_grad)))
    error('invalid error and gradient result!');
end

err  = err_and_grad(1);
grad = err_and_grad(2:end);

if(~isempty(regul_fun))
    [regul_err, regul_grad] = regul_fun(params);
    err  = err  + regul_err;
    grad = grad + regul_grad;
end

end
