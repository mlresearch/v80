function show_cost_matrix( C, symbols )

[m, n] = size(C);
if(m ~= n)
    error('expected square matrix as input!');
end

if(numel(symbols) ~= m-1 || ~iscell(symbols))
    error('expected a symbol label for each embedded symbol');
end

symbols = [symbols, {'-'}];

figure;
imagesc(C); colorbar;
xticks(1:numel(symbols));
xticklabels(symbols);
yticks(1:numel(symbols));
yticklabels(symbols);
end

