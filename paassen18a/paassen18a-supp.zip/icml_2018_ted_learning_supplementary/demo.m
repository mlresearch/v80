%% Tree Edit Distance Learning via Adaptive Symbol Embeddings
% 
% Copyright (C) 2018
% Benjamin Paaßen
% AG Machine Learning
% Centre of Excellence Cognitive Interaction Technology (CITEC)
% University of Bielefeld
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% This script executes the experimental evaluation described in the ICML
% 2018 paper 'Tree Edit Distance Learning via Adaptive Symbol Embeddings'
% on the strings experiment.

%% clear workspace

clear;
close all;
clc;

% load dependencies

javaaddpath ICML2018-0.0.2.jar;
addpath gesl;
addpath libsvm/matlab/;
addpath nystroem;
addpath plotting;

%% load data

m = 200;
l = 5;

dataset = de.citec.ml.icml2018.input.ArtificialData.createStringDataset(m, l);
X = dataset.data;
Y = de.citec.ml.icml2018.input.Dataset.collectionToPrimitiveArr(dataset.labels);

%% set up distance measure

alphabet         = {'A', 'B', 'C', 'D'};

idxfun           = de.citec.ml.icml2018.comparators.SetIndexingFunction(alphabet);
X_idxs           = de.citec.ml.icml2018.comparators.VectorEmbeddingComparator.indexForest(X, idxfun);

comp             = de.citec.ml.icml2018.comparators.VectorEmbeddingComparator(uint32(numel(alphabet)));
initial_params   = comp.getParameters();
show_parameter_embedding(comp.getTheta(), alphabet);
title('embedding parameters pre learning');

comp_wrap = de.citec.tcs.alignment.trees.DerivableLabelComparator(comp);

score_algo       = de.citec.tcs.alignment.trees.TreeEditScoreAlgorithm(comp_wrap);
soft_algo        = de.citec.tcs.alignment.trees.TreeEditSoftAlgorithm(comp_wrap);

comp_matrix      = de.citec.ml.icml2018.comparators.SymmetricMatrixComparator(uint32(numel(alphabet)));
initial_params_matrix = comp_matrix.getParameters();
show_cost_matrix(comp_matrix.getCostMatrix(), alphabet);
title('matrix parameters pre learning');

comp_wrap_matrix = de.citec.tcs.alignment.trees.DerivableLabelComparator(comp_matrix);
strict_algo      = de.citec.tcs.alignment.trees.TreeEditFullAlgorithm(comp_wrap_matrix);

%% compute initial distances

score_engine = de.citec.tcs.alignment.trees.TreeSquareParallelProcessingEngine(score_algo, X_idxs);
score_engine.setFull();
score_engine.calculate();

D = score_engine.getDoubleResultMatrix();

figure; imagesc(D); title('distances pre learning'); colorbar;
clear score_engine;

%% distribute data into crossvalidation folds

F = 20;

fold_idxs = de.citec.tcs.utils.Crossvalidation.createCrossvalidationFolds(Y, F) + 1;

%% optimize the symbol embedding in crossvalidation

% we evaluate the following methods
method_labels    = {'Initial', 'GESL', 'GESL multi', 'GESL proto multi', 'LVQ proto multi', 'LVQ proto multi embedding'};
% ... both for the pseudo-edit distance and for the actual edit distance
condition_labels = {'pseudo-edit', 'edit'};

% a function to normalize parameters such that they become metric
param_fun          = @(params) (de.citec.ml.icml2018.comparators.SymmetricMatrixComparator.normalizeParameters(params));

% the hyper-parameter ranges for median LVQ (number of prototypes), for knn
% (number of neighbors), for SVM (sigma), and for the goodness classifier
% (sparsity regularization)
Ks               = [1];
K_errs           = zeros(F, numel(Ks));
K_knn_errs       = zeros(F, numel(Ks));
sigmas           = [0.1, 0.5, 1, 2, 10] * (sum(sum(D)) / m.^2);
sigma_errs       = zeros(F, numel(sigmas));
lambdas          = [1E-5, 1E-2, 1, 10];
lambda_errs      = zeros(F, numel(lambdas));
betas            = [1E-6, 1E-4, 1E-2];
beta_errs_gesl   = zeros(F, numel(betas));
beta_errs_lvq    = zeros(F, numel(betas));
% number of folds for nested crossvalidation for hyperparameter search
F2               = 5;
% pre-generate kernel matrices for the sigma values in question
Ks_SVM           = zeros(m, m, numel(sigmas));
for s = 1:numel(sigmas)
    Ks_SVM(:, :, s)        = eig_correct(exp(-0.5 * D.^2 / sigmas(s).^2));
end
clear s;

% data structures to store results
glvq_errs        = cell(F, 1);
goodness_errs    = nan(F, 2);

test_mrglvq_errs = nan(F, numel(method_labels), numel(condition_labels));
test_knn_errs    = nan(F, numel(method_labels), numel(condition_labels));
test_svm_errs    = nan(F, numel(method_labels), numel(condition_labels));
test_good_errs   = nan(F, numel(method_labels), numel(condition_labels));
runtimes         = nan(F, numel(method_labels));

params_bellet    = nan(F, numel(initial_params_matrix));
params           = nan(F, numel(initial_params));

% start to iterate over the crossvalidation folds
for f=1:F
    fprintf('\n----- fold %d of %d -----\n\n', f, F);
    % get the current train and test data
    test_log = false(m, 1);
    test_log(fold_idxs(f, :)) = true;
    train_idxs = find(~test_log);
    X_train  = de.citec.tcs.utils.MatlabListInterface.selectFromList(X_idxs, ~test_log);
%     X_test   = de.citec.tcs.utils.MatlabListInterface.selectFromList(X_idxs, test_log);

    % do a nested crossvalidation/line search to optimize
    % K (for median LVQ) and sigma (for SVM)
    fold_idxs2 = de.citec.tcs.utils.Crossvalidation.createCrossvalidationFolds(Y(~test_log), F2) + 1;
    for f2=1:F2
        test_log2 = false(m, 1);
        test_log2(train_idxs(fold_idxs2(f2, :))) = true;
        train_log2 = ~test_log2 & ~test_log;
        train_idxs2 = find(train_log2);

        for k=1:numel(Ks)
            % train a median rglvq model
            mrglvq_model = de.citec.ml.mrglvq.MedianRelationalGLVQ.train(D(train_idxs2, train_idxs2), Y(train_idxs2), Ks(k));
            W            = train_idxs2(mrglvq_model.getPrototypeIndices() + 1);

            K_errs(f, k) = K_errs(f, k) + mean(Y(test_log2) ~= de.citec.ml.mrglvq.MedianRelationalGLVQ.classify(D(test_log2, W), mrglvq_model));
        end

        for k=1:numel(Ks)
            % check knn accuracy
            K_knn_errs(f, k) = K_errs(f, k) + mean(Y(test_log2) ~= de.citec.ml.icml2018.lmnn.KNNClassifier.predict(D(test_log2, train_log2), Y(train_log2), Ks(k)));
        end

        for s=1:numel(sigmas)
            % train SVM model
            K_SVM              = squeeze(Ks_SVM(:, :, s));
            svm_model          = svmtrain(double(Y(train_log2)), [(1:sum(train_log2))' K_SVM(train_log2, train_log2)], '-t 4');

            sigma_errs(f, s)   = sigma_errs(f, s) + mean(Y(test_log2) ~= svmpredict(double(Y(test_log2)), [(sum(train_log2)+(1:sum(test_log2)))' K_SVM(test_log2, train_log2)], svm_model));
        end

        for l=1:numel(lambdas)
            % train 'good' classifier
            good_model         = train_good_classifier_linprog(D(train_log2, train_log2), Y(train_log2), lambdas(l));
            lambda_errs(f, l)  = lambda_errs(f, l) + mean(Y(test_log2) ~= predict_good_classifier(D(test_log2, train_log2), good_model));
        end
    end
    clear test_log2 train_log2 train_idxs2 k mrglvq_model W s K_SVM svm_model l good_model;
    K_errs(f, :)     = K_errs(f, :) / F2;
    K_knn_errs(f, :) = K_knn_errs(f, :) / F2;
    sigma_errs(f, :) = sigma_errs(f, :) / F2;
    lambda_errs(f, :)= lambda_errs(f, :) / F2;

    % select best hyper-parameters
    [~, best_k]      = min(K_errs(f, :));
    K                = Ks(best_k);
    [~, best_k2]     = min(K_knn_errs(f, :));
    K2               = Ks(best_k2);
    [~, best_s]      = min(sigma_errs(f, :));
    sigma            = sigmas(best_s);
    K_SVM            = squeeze(Ks_SVM(:, :, best_s));
    [~, best_l]      = min(lambda_errs(f, :));
    lambda           = lambdas(best_l);

    % do another nested crossvalidation/line search to optimize
    % beta for both classification schemes
    for f2=1:F2
        test_log2 = false(numel(train_idxs), 1);
        test_log2(fold_idxs2(f2, :)) = true;
        beta_errs_gesl(f, :) = beta_errs_gesl(f, :) + gesl_regul_sweep( ...
            D(~test_log, ~test_log), X_train, Y(~test_log), test_log2, ...
            strict_algo, initial_params_matrix, numel(alphabet), K, lambda, betas * 2 * m * K)';
        soft_algo.setComparator(comp_wrap);
        beta_errs_lvq(f, :)  = beta_errs_lvq(f, :) + mrglvq_regul_sweep( ...
            D(~test_log, ~test_log), X_train, Y(~test_log), test_log2, ...
            soft_algo, score_algo, initial_params, numel(alphabet), K, betas * 2 * m * K)';
    end
    beta_errs_gesl(f, :) = beta_errs_gesl(f, :) / F2;
    clear fold_idxs2 f2 test_log2;

    [~, best_b]      = min(beta_errs_gesl(f, :));
    regul_gesl       = 2 * m * K * betas(best_b);
    [~, best_b]      = min(beta_errs_lvq(f, :));
    regul_lvq        = 2 * m * K * betas(best_b);
    regul_fun        = @(params) (regularize_embedding(params, numel(alphabet), numel(alphabet), regul_lvq, regul_lvq));
    regul_fun_matrix = @(params) (deal(sum(params.^2), 2*params));

    % train median relational GLVQ
    mrglvq_model     = de.citec.ml.mrglvq.MedianRelationalGLVQ.train(D(~test_log, ~test_log), Y(~test_log), K);
    W_idxs           = mrglvq_model.getPrototypeIndices() + 1;
    W_idxs2          = train_idxs(W_idxs);
    W                = de.citec.tcs.utils.MatlabListInterface.selectFromList(X_idxs, W_idxs2);
    % train SVM
    svm_model        = svmtrain(double(Y(~test_log)), [(1:sum(~test_log))' K_SVM(~test_log, ~test_log)], '-t 4');
    % train good classifier
    good_model       = train_good_classifier_linprog(D(~test_log, ~test_log), Y(~test_log), lambda);

    % compute initial test error
    test_mrglvq_errs(f, 1, 2) = mean(Y(test_log) ~= de.citec.ml.mrglvq.MedianRelationalGLVQ.classify(D(test_log, W_idxs2), mrglvq_model));
    test_knn_errs(f, 1, 2)    = mean(Y(test_log) ~= de.citec.ml.icml2018.lmnn.KNNClassifier.predict(D(test_log, ~test_log), Y(~test_log), K2));
    test_svm_errs(f, 1, 2)    = mean(Y(test_log) ~= svmpredict(double(Y(test_log)), [((sum(~test_log)+1):m)' K_SVM(test_log, ~test_log)], svm_model));
    test_good_errs(f, 1, 2)   = mean(Y(test_log) ~= predict_good_classifier(D(test_log, ~test_log), good_model));

    % HERE STARTS THE ACTUAL METRIC LEARNING
    
    % learn with GESL scheme
    c = 2;
    fprintf('\n----- %s -----\n\n', method_labels{c});
    comp_matrix.setParameters(initial_params_matrix);
    tic;
    [params_bellet(f, :), goodness_errs(f, end)] = gesl_linprog(D(~test_log, ~test_log), X_train, Y(~test_log), strict_algo, numel(alphabet), K, regul_gesl );
    runtimes(f, c)       = toc;

    % evaluate test error using both the pseudo-edit edistance and the
    % actual edit distance
    [test_mrglvq_errs(f, c, 1), test_knn_errs(f, c, 1), test_svm_errs(f, c, 1), test_good_errs(f, c, 1), test_mrglvq_errs(f, c, 2), test_knn_errs(f, c, 2), test_svm_errs(f, c, 2), test_good_errs(f, c, 2)] = ...
        evaluate_metric_learning_errors(comp_wrap_matrix, initial_params_matrix, params_bellet(f, :), strict_algo, score_algo, X_idxs, X_train, Y, test_log, mrglvq_model, K2, sigma, lambda, param_fun);

    % learn with GESL scheme with multiple alignments
    c = c + 1;
    fprintf('\n----- %s -----\n\n', method_labels{c});
    comp_matrix.setParameters(initial_params_matrix);
    soft_algo.setComparator(comp_wrap_matrix);
    tic;
    [params_c, ~] = gesl_linprog(D(~test_log, ~test_log), X_train, Y(~test_log), soft_algo, numel(alphabet), K, regul_gesl );
    runtimes(f, c)       = toc;

    % evaluate test error using both the pseudo-edit edistance and the
    % actual edit distance
    [test_mrglvq_errs(f, c, 1), test_knn_errs(f, c, 1), test_svm_errs(f, c, 1), test_good_errs(f, c, 1), test_mrglvq_errs(f, c, 2), test_knn_errs(f, c, 2), test_svm_errs(f, c, 2), test_good_errs(f, c, 2)] = ...
        evaluate_metric_learning_errors(comp_wrap_matrix, initial_params_matrix, params_c, soft_algo, score_algo, X_idxs, X_train, Y, test_log, mrglvq_model, K2, sigma, lambda, param_fun);

    % learn with GESL scheme with multiple alignments and prototypes
    % instead of neighbors
    c = c + 1;
    fprintf('\n----- %s -----\n\n', method_labels{c});
    comp_matrix.setParameters(initial_params_matrix);
    tic;
    [params_c, ~] = gesl_proto_linprog(D(~test_log, W_idxs2), X_train, Y(~test_log), W_idxs, soft_algo, numel(alphabet), regul_gesl );
    runtimes(f, c)       = toc;

    % evaluate test error using both the pseudo-edit edistance and the
    % actual edit distance
    [test_mrglvq_errs(f, c, 1), test_knn_errs(f, c, 1), test_svm_errs(f, c, 1), test_good_errs(f, c, 1), test_mrglvq_errs(f, c, 2), test_knn_errs(f, c, 2), test_svm_errs(f, c, 2), test_good_errs(f, c, 2)] = ...
        evaluate_metric_learning_errors(comp_wrap_matrix, initial_params_matrix, params_c, soft_algo, score_algo, X_idxs, X_train, Y, test_log, mrglvq_model, K2, sigma, lambda, param_fun);

    % learn with LVQ scheme with multiple alignments
    c = c + 1;
    fprintf('\n----- %s -----\n\n', method_labels{c});
    comp_matrix.setParameters(initial_params_matrix);
    tic;
    [params_c, ~, ~] = mrglvq_learn_parameters_em(X_train, Y(~test_log), comp_wrap_matrix, initial_params_matrix, soft_algo, W_idxs, [], regul_fun_matrix, param_fun );
    runtimes(f, c) = toc;

    % evaluate test error using both the pseudo-edit edistance and the
    % actual edit distance
    [test_mrglvq_errs(f, c, 1), test_knn_errs(f, c, 1), test_svm_errs(f, c, 1), test_good_errs(f, c, 1), test_mrglvq_errs(f, c, 2), test_knn_errs(f, c, 2), test_svm_errs(f, c, 2), test_good_errs(f, c, 2)] = ...
        evaluate_metric_learning_errors(comp_wrap_matrix, initial_params_matrix, params_c, soft_algo, score_algo, X_idxs, X_train, Y, test_log, mrglvq_model, K2, sigma, lambda, param_fun);

    % Embedding Learning (proposed method)
    c = c + 1;
    fprintf('\n----- %s -----\n\n', method_labels{c});
    comp.setParameters(initial_params);
    soft_algo.setComparator(comp_wrap);
    tic;
    [params(f, :), ~, glvq_errs{f}] = mrglvq_learn_parameters_em(X_train, Y(~test_log), comp_wrap, initial_params, soft_algo, W_idxs, [], regul_fun, [] );
    runtimes(f, c) = toc;

    % evaluate test error using both the pseudo-edit edistance and the
    % actual edit distance
    [test_mrglvq_errs(f, c, 1), test_knn_errs(f, c, 1), test_svm_errs(f, c, 1), test_good_errs(f, c, 1), test_mrglvq_errs(f, c, 2), test_knn_errs(f, c, 2), test_svm_errs(f, c, 2), test_good_errs(f, c, 2)] = ...
        evaluate_metric_learning_errors(comp_wrap, initial_params, params(f, :), soft_algo, score_algo, X_idxs, X_train, Y, test_log, mrglvq_model, K2, sigma, lambda);
end

clear f c test_log train_idxs X_train X_test best_k K best_k2 K2 best_s sigma K_SVM best_l lambda best_b regul_gesl regul_lvq mrglvq_model W_idxs W_idxs2 W svm_model good_model engine;

%% inspect the results for the respective best runs

[~, best_run] = min(squeeze(test_knn_errs(:, 2, 1)));

comp_matrix.setParameters(params_bellet(best_run, :));
show_cost_matrix(comp_matrix.getCostMatrix(), alphabet);
title('matrix parameters post GESL');

score_engine = de.citec.tcs.alignment.trees.TreeSquareParallelProcessingEngine(score_algo, X_idxs);
score_engine.setFull();
score_algo.setComparator(comp_wrap_matrix);
score_engine.calculate();
D_post = score_engine.getDoubleResultMatrix();
figure; imagesc(D_post); title('distances post GESL'); colorbar;

[~, best_run] = min(squeeze(test_knn_errs(:, end, 2)));

comp.setParameters(params(best_run, :));
show_parameter_embedding(comp.getTheta(), alphabet);
title('embedding parameters post learning');

score_algo.setComparator(comp_wrap);
score_engine.calculate();
D_post = score_engine.getDoubleResultMatrix();
figure; imagesc(D_post); title('distances post embedding learning'); colorbar;

clear best_run score_engine;

%% show quantitative results

eval_labels = {'KNN', 'MRGLVQ', 'SVM', 'good', 'runtime'};

figure;

for c = 1:numel(condition_labels)
    fprintf('\n\nresults for %s distance\n\n', condition_labels{c});
    result_mat_c = [mean(squeeze(test_knn_errs(:, :, c)))' , mean(squeeze(test_mrglvq_errs(:, :, c)))', mean(squeeze(test_svm_errs(:, :, c)))', mean(squeeze(test_good_errs(:, :, c)))', mean(runtimes)'];
    print_table_with_metadata(method_labels', {'method'}, result_mat_c , eval_labels);
    subplot(1, numel(condition_labels), c);
    plot(result_mat_c(:, 1:end-1));
    legend(eval_labels(1:end-1));
    xticks(1:numel(method_labels));
    xticklabels(method_labels);
    title(condition_labels{c});
    ylabel('error')
end
clear c result_mat_c;

%% perform statistical tests

fprintf('embedding better than pre (knn): p = %g\n', signrank(squeeze(test_knn_errs(:, end, 2)), squeeze(test_knn_errs(:, 1, 2)), 'tail', 'left'));
fprintf('embedding better than GESL (knn): p = %g\n', signrank(squeeze(test_knn_errs(:, end, 2)), squeeze(test_knn_errs(:, 2, 1)), 'tail', 'left'));
fprintf('embedding better than pre (mrglvq): p = %g\n', signrank(squeeze(test_mrglvq_errs(:, end, 2)), squeeze(test_mrglvq_errs(:, 1, 2)), 'tail', 'left'));
fprintf('embedding better than GESL (mrglvq): p = %g\n', signrank(squeeze(test_mrglvq_errs(:, end, 2)), squeeze(test_mrglvq_errs(:, 2, 1)), 'tail', 'left'));
fprintf('embedding better than pre (svm): p = %g\n', signrank(squeeze(test_svm_errs(:, end, 2)), squeeze(test_svm_errs(:, 1, 2)), 'tail', 'left'));
fprintf('embedding better than GESL (svm): p = %g\n', signrank(squeeze(test_svm_errs(:, end, 2)), squeeze(test_svm_errs(:, 2, 1)), 'tail', 'left'));
fprintf('embedding better than pre (good): p = %g\n', signrank(squeeze(test_good_errs(:, end, 2)), squeeze(test_good_errs(:, 1, 2)), 'tail', 'left'));
fprintf('embedding better than GESL (good): p = %g\n', signrank(squeeze(test_good_errs(:, end, 2)), squeeze(test_good_errs(:, 2, 1)), 'tail', 'left'));