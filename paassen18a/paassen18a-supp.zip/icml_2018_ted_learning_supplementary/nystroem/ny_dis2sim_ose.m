function Sim_new=ny_dis2sim_ose(ny_Dis, Dis_new)
% Converts new dissimilarity data to similarities in the same way as
% approximated dissimilarities were converted to similarities
%
% Input arguments:
%   ny_Dis    - approximated dissimilarity matrix
%   Dis_new   - matrix of dissimilarities between new points and landmarks
% Output arguments:
%   Sim_new   - matrix of corresponding similarities between new points and
%               landmarks
%
% Note:         see also ny_create for detailed format of approximated
%               matrices

% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.

[N,m]=size(ny_Dis{1});
[N_new,m_new]=size(Dis_new);

if ~m==m_new
    error('Wrong number of landmarks in the new data.');
end

Sim_new=-.5*(Dis_new - 1/N*ones(N_new,1)*sum(ny_Dis{1}) ...
            - 1/N*Dis_new*sum(ny_Dis{2}*ny_Dis{1}',2)*ones(1,m) ...
            + 1/(N*N)*sum(sum(ny_Dis{1}*ny_Dis{2})*ny_Dis{1}'));
