function ny_Sim_new=ny_sim2ker_ose(ny_Sim, Sim_new)
% Extends a Nystroem-approximated similarity matrix with new data,
% correcting the new data in the same way as the kernel.
%
% Input arguments:
%   ny_Sim    - approximated similarity matrix returned by ny_sim2ker;
%               must have ny_Sim{4} describing the correction
%   Sim_new   - similarities between new points and landmarks
% Output arguments:
%   ny_Sim_new- approximated positive semi-definite kernel matrix extended
%               by the new data points
%
% Note:         see also ny_create for detailed format of approximated
%               matrices

% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.

[N,m]=size(ny_Sim{1});
[N_new,m_new]=size(Sim_new);

if ~m==m_new
    error('Wrong number of landmarks in the new data.');
end

if numel(ny_Sim)<4
    error('Transformation matrix for eigenvalue correction is missing.');
end

ny_Sim_new=ny_Sim;
Sim_new=Sim_new*ny_Sim{4};
ny_Sim_new{1}=[ny_Sim{1};Sim_new];
