function [Data, I_pq]=pq_embedding(Sim)
% Computes the pseudo-Euclidean embedding of the similarities using
% eigenvalue decomposition. Also returns the diagonal of the corresponding
% inner product matrix.
%
% Input arguments:
%   Sim       - a symmetric, possibly non-Euclidean similarity matrix
% Output arguments:
%   Data      - an embedding of the similarity data in a possibly
%               pseudo-Euclidean space; each row represent a data point
%   I_pq        an inner product matrix of the corresponding space

% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.

[N,N_]=size(Sim);

if N~=N_
    error('The similarity matrix must be square.');
end
if ~issymmetric(Sim)
    error('The similarity matrix must be symmetric.');
end

% compute the eigenvalue decomposition
[eigVec,eigVal] = eig(Sim);

% sort the eigenvalues
[eigVal_sorted,ind]=sort(diag(eigVal),'descend');

% keep only non zero eigenvalues
ind=ind(abs(eigVal_sorted)>1e-10);

% construct the embedding
Data=eigVec(:,ind)*sqrt(abs(eigVal(ind,ind)));

% construct the inner product matrix
I_pq=sign(eigVal(ind,ind));
