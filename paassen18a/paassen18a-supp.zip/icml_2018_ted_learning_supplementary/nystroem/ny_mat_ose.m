function ny_Mat_new=ny_mat_ose(ny_Mat, Mat_new)
% Extends a Nystroem-approximated matrix with new data.
%
% Input arguments:
%   ny_Mat    - approximated matrix which should be extended
%   Mat_new   - matrix with (dis)similarites between new points and landmarks
% Output arguments:
%   ny_Mat_new- approximated matrix extended by the new data
%
% Note:         see also ny_create for detailed format of approximated
%               matrices

% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.

[N,m]=size(ny_Mat{1});
[N_new,m_new]=size(Mat_new);

if ~m==m_new
    error('Wrong number of landmarks in the new data.');
end

ny_Mat_new{1}=[ny_Mat{1};Mat_new];
