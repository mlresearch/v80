function [C, A] = ny_eig(ny_K)
% Computes the exact eigenvalue decomposition of an approximated matrix.
%
% Input arguments:
%   ny_K      - approximated matrix
% Output arguments:
%   C         - matrix of eigenvectors
%   A         - diagonal matrix of eigenvalues
%
% Note:         see also ny_create for detailed format of approximated
%               matrices

% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.

tmp_K=ny_K{2}*(ny_K{1}'*ny_K{1})*ny_K{2};
tmp_K=.5*(tmp_K+tmp_K');
[ny_U,ny_A] = eig(tmp_K);

B=ny_K{1}*(ny_U*sqrt(abs(ny_A))); % the eigenvalues could be numerically negative
[V,A] = eig(B'*B);
C=B*(V*sqrt(pinv(abs(A))));

[A,idx]=sort(diag((C'*ny_K{1})*ny_K{2}*(ny_K{1}'*C)),'descend');
A=diag(A);
C=C(:,idx);
