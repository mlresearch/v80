function Sim=dis2sim(Dis)
% Computes the transformation of dissimilarities into similarities via
% double centering.
%
% Input arguments:
%   Dis       - a symmetric, possibly non-Euclidean dissimilarity matrix
%               with zero diagonal
% Output arguments:
%   Sim       - a symmetric similarity matrix representing the input data

% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.

[N,N_]=size(Dis);

if N~=N_
    error('The dissimilarity matrix must be square.');
end
if any(diag(Dis))
    error('The dissimilarity matrix must have zero diagonal.');
end
if ~issymmetric(Dis)
    error('The dissimilarity matrix must be symmetric.');
end

J = eye(N) - repmat(1/N,N,N);
Sim = -0.5 * J * Dis * J;
Sim=(Sim+Sim')/2;
