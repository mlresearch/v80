function ny_K=ny_sim2ker(ny_Sim, correction)
% Creates a valid positive semi-definite and approximated kernel matrix from
% approximated and possibly non-metric similarities.
%
% Input arguments:
%   ny_Sim    - approximated simmilarity matrix
%   correction- type of the eigenvalue correction; it can be 'clip' to set
%               the negative eigenvalue to zero or it can be 'flip' to take
%               the absolute values of the eigenvalues
% Output arguments:
%   ny_K      - approximated positive semi-definite kernel matrix; also an
%               additional matrix ny_K{4}, describing the correction,
%               is added to the structure of ny_K
%
% Note:         see also ny_create for detailed format of approximated
%               matrices

% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.

if ~exist('correction','var')
    correction='flip';
end

[C, A] = ny_eig(ny_Sim);

switch correction
    case 'flip'
        A=abs(A);
    case 'clip'
        A(A<0)=0;
    otherwise
        error('Invalid correction type. Use flip or clip.');
end

% The corrected similarities S_ are:
% S_ = S_nm * (C_mm * A_ * C_mm')^-2 * S_nm'
C_mm=C(ny_Sim{3},:);
C_corr=pinv(C_mm')*pinv(A)*pinv(C_mm);

% Compute transformation matrix for consistent representation of ny_K
% i.e. ny_K{2}=pinv(ny_K{1}(ny_K{3},:)).
ny_K{4}=C_corr*ny_Sim{1}(ny_Sim{3},:)';
ny_K{1}=ny_Sim{1}*ny_K{4};

% K_mm is now numerically asymmetric. Save the symmetrised version.
ny_K{2}=ny_K{1}(ny_Sim{3},:);
ny_K{2}=.5*(ny_K{2}+ny_K{2}');
ny_K{1}(ny_Sim{3},:)=ny_K{2};

ny_K{2}=pinv(ny_K{2});
ny_K{3}=ny_Sim{3};
