function ny_Sim=ny_dis2sim(ny_Dis)
% Converts Nystroem-approximated dissimilarity matrix to approximated
% similarities using double centering.
%
% Input arguments:
%   ny_Dis    - approximated dissimilarity matrix
% Output arguments:
%   ny_Sim    - approximated similarity matrix
%
% Note:         see also ny_create for detailed format of approximated
%               matrices

% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.

[N,m]=size(ny_Dis{1});

pinv_D_mm=pinv(ny_Dis{1}(ny_Dis{3},:));
D_nm=ny_Dis{1};

% Compute double centering for a linear part of the matrix.
S_nm=-.5*(D_nm - 1/N*ones(N,1)*sum(D_nm,1) - 1/N*(sum(D_nm*pinv_D_mm)*D_nm')'*ones(1,m) + 1/N^2*sum(sum(D_nm*pinv_D_mm)*D_nm'));

% S_mm is now numerically asymmetric. Save the symmetrised version.
S_mm=S_nm(ny_Dis{3},:);
S_mm=.5*(S_mm+S_mm');
S_nm(ny_Dis{3},:)=S_mm;

ny_Sim{1}=S_nm;
ny_Sim{2}=pinv(S_mm);
ny_Sim{3}=ny_Dis{3};
