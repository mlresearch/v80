% Nystroem Approximation Toolbox.
%
% Scripts demonstrating the toolbox:
%   demo_pq_vis     detailed explanation of the toolbox and its functions
%   demo_short      short demo using most of the relevant functions
%
% Functions for general data transformations:
%   dis2sim         converts a dissimilarity matrix to similarities
%   pq_embedding    computes a pseudo-Euclidean embedding for similarities
%   sim2dis         converts a similarity matrix to dissimilarities
%
% Functions for Nystroem approximation:
%   ny_create       creates a Nystroem-approximated matrix
%   ny_dis2sim      converts approximated dissimilarities to approximated
%                   similarities
%   ny_dis2sim_ose  converts new dissimilarity data to similarities in the
%                   same way as approximated dissimilarities were converted
%                   to approximated similarities
%   ny_eig          computes an exact eigenvalues decomposition of an
%                   approximated matrix
%   ny_mat_ose      extends an approximated matrix with new data
%   ny_pq_embedding computes a pseudo-Euclidean embedding for approximated
%                   similarities
%   ny_reconstruct  reconstructs a full (sub)matrix from an approximated
%                   matrix
%   ny_sim2dis      converts approximated similarities to approximated
%                   dissimilarities
%   ny_sim2ker      corrects the eigenvalues of an approximated similarity
%                   matrix to construct an approximated positive
%                   semi-definite kernel matrix
%   ny_sim2ker_ose  corrects new similarity data in the same way as
%                   approximated similarities were converted to a kernel
%
% Auxiliary functions:
%   README          this file
%   create_data_2d  creates a two-dimensional toy data set with 3 clusters
%   issymmetric     tests whether a matrix is symmetric

% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.
