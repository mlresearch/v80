function Mat=ny_reconstruct(ny_Mat, ind_1, ind_2)
% Reconstructs the full (sub)matrix from an approximated matrix.
%
% Input arguments:
%   ny_Mat    - approximated matrix; if only one argument is given, the
%               full matrix is reconstructed
%   ind_1     - the first index vector; if two arguments are given, the
%               submatrix Mat(ind_1,ind_1) is reconstructed
%   ind_2     - the second index vector; if three arguments are given, the
%               submatrix Mat(ind_1,ind_2) is reconstructed
% Output arguments:
%   Mat       - full (sub)matrix
%
% Note:         see also ny_create for detailed format of approximated
%               matrices

% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.

switch nargin
    case 1
        Mat=ny_Mat{1}*ny_Mat{2}*ny_Mat{1}';
    case 2
        Mat=ny_Mat{1}(ind_1,:)*ny_Mat{2}*ny_Mat{1}(ind_1,:)';
    case 3
        Mat=ny_Mat{1}(ind_1,:)*ny_Mat{2}*ny_Mat{1}(ind_2,:)';
    otherwise
        error('Incorrect number of arguments');
end
