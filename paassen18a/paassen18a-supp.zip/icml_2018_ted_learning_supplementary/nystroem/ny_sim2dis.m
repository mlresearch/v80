function ny_Dis=ny_sim2dis(ny_Sim)
% Converts Nystroem-approximated similarity matrix to dissimilarities.
%
% Input arguments:
%   ny_Sim    - approximated simmilarity matrix
% Output arguments:
%   ny_Dis    - approximated dissimilarity matrix
%
% Note:         see also ny_create for detailed format of approximated
%               matrices

% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.

[N,m]=size(ny_Sim{1});

Sim_diag=sum((ny_Sim{1}*ny_Sim{2}).*ny_Sim{1},2);

D_nm=-2*ny_Sim{1}+repmat(Sim_diag,1,m)+repmat(Sim_diag(ny_Sim{3})',N,1);

% D_mm is now numerically asymmetric. Save the symmetrised version.
D_mm=D_nm(ny_Sim{3},:);
D_mm=.5*(D_mm+D_mm');
D_nm(ny_Sim{3},:)=D_mm;

ny_Dis{1}=D_nm;
ny_Dis{2}=pinv(D_mm);
ny_Dis{3}=ny_Sim{3};
