function ny_Mat=ny_create(Mat,landmarks)
% Creates a Nystroem approximated matrix from the (dis)similarity data
% Input arguments:
%   Mat       - matrix with (dis)similarities; it can be either a full
%               matrix, or the (dis)similarities between all points and the
%               landmarks
%              
%   landmarks - the landmarks used for approximation; it can be either a
%               number, in this case the landmarks will be selected randomly,
%               or index vector specifying the indices of the landmarks
% Output arguments:
%   ny_Mat    - a Nystroem-approximated matrix; it has the following
%               structure:
%               ny_Mat{1} is the matrix Mat_Nm, denoting (dis)similarities
%                         from all points to all landmarks
%               ny_Mat{2} is the pseudo-inverse of Mat_mm, denoting
%                         (dis)similarities between landmarks
%               ny_Mat{3} is the index of landmarks
%               The full matrix can be approximated via
%               Mat=ny_Mat{1}*ny_Mat{2}*ny_Mat{1}'
%               Note: in case of an eigenvalue correction (see ny_sim2ker)
%               an additional matrix ny_Mat{4} is added to the structure to
%               describe the correction

% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.

[N,m]=size(Mat);

if N==m
    if isscalar(landmarks)
        P=randperm(N);
        idx=P(1:landmarks);
        
        ny_Mat{1}=Mat(:,idx);
        if ~issymmetric(Mat(idx,idx))
            warning('The matrix of landmarks is not symmetric. This may result in undesired behaviour such as complex numbers.');
        end
        ny_Mat{2}=pinv(Mat(idx,idx));
        ny_Mat{3}=idx;
    elseif isvector(landmarks)
        ny_Mat{1}=Mat(:,landmarks);
        if ~issymmetric(Mat(landmarks,landmarks))
            warning('The matrix of landmarks is not symmetric. This may result in undesired behaviour such as complex numbers.');
        end
        ny_Mat{2}=pinv(Mat(landmarks,landmarks));
        ny_Mat{3}=landmarks;
    else
        error('Invalid landmarks.');
    end
else
    if isscalar(landmarks)
        error('The indices of the landmarks are required.');
    elseif isvector(landmarks)
        if ~m==numel(landmarks)
            error('The number of the landmarks does not fit the matrix.');
        end
        ny_Mat{1}=Mat;
        if ~issymmetric(Mat(landmarks,:))
            warning('The matrix of landmarks is not symmetric. This may result in undesired behaviour such as complex numbers.');
        end
        ny_Mat{2}=pinv(Mat(landmarks,:));
        ny_Mat{3}=landmarks;
    else
        error('Invalid landmarks.');
    end
end
