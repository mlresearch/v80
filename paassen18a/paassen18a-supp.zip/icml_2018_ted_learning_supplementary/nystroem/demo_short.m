% This demo gives a quick reference of the functions provided by the
% Nystroem Approximation Toolbox. For a detailed example see demo_pq_vis.
%
% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.

%% create 2D pseudo-Euclidean data set
N=100; N_test=20;
Data=create_data_2d(N+N_test);
Data=bsxfun(@minus,Data,mean(Data(1:N,:)));
Data_train=Data(1:N,:);
Data_test=Data(N+1:end,:);
Dis=squareform(pdist(Data_train(:,1)).^2-pdist(Data_train(:,2)).^2);

%% approximate the dissimilarity matrix
ny_Dis = ny_create(Dis,4);

%% convert dissimilarities to similarities
ny_Sim = ny_dis2sim(ny_Dis);

%% compute the kernel matrix by correcting the eigenvalues
ny_K=ny_sim2ker(ny_Sim, 'flip');

%% compute the Euclidean distances from the kernel
ny_Dis=ny_sim2dis(ny_K);

%% out-of-sample extension for dissimilarities
Dis_ose=pdist2(Data_test(:,1),Data_train(ny_Dis{3},1)).^2 ...
    -pdist2(Data_test(:,2),Data_train(ny_Dis{3},2)).^2;
Sim_ose=ny_dis2sim_ose(ny_Dis, Dis_ose);

%% out-of-sample extension with correction
ny_K_ose=ny_sim2ker_ose(ny_K,Sim_ose);

%% out-of-sample extension for Euclidean distances
ny_Dis_ose=ny_sim2dis(ny_K_ose);

%% reconstruct the full matrix of corrected Euclidean distances
D=ny_reconstruct(ny_Dis_ose);
