function flag=issymmetric(Mat)
% Checks whether a matrix is symmetric. Often an essentially symmetric
% matrix is numerically asymmetric, this may lead to errors such as
% complex eigenvalues and eigenvectors.
%
% Input arguments:
%   Mat       - squared matrix
% Output arguments:
%   flag      - is 1 if the matrix is symmetric and 0 otherwise

% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.

flag=~any(any(abs(Mat-Mat')));