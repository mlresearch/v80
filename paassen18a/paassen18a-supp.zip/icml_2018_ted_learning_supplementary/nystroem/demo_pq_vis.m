% Demonstrates the Nystroem Approximation Toolbox on a toy 2D data set.
%
% This script generates a simple artificial data set embedded in a
% two-dimensional pseudo-Euclidean space. It then demonstrates possible
% transformations regarding (dis)similarity representations of these data,
% computes a pseudo-Euclidean embedding from similarities and calculates
% eigenvalue correction to make the data Euclidean.
%
% Since these operations have quadratic or even cubic computational
% complexity the Nystroem approximation is used to compute them in linear
% time. For this purpose the script creates Nystroem approximated matrices
% and applies different functions provided by the toolbox on the
% approximated matrices to achieve the same results as in the exact case.
%
% For the detailed information on pseudo-Euclidean space please refer to:
% E. Pekalska and R. P. Duin. The Dissimilarity Representation for Pattern
% Recognition. Foundations and Applications. World Scientific, 2005.
%
% For the detailed information on Nystroem approximation for
% pseudo-Euclidean (dis)similarity data please refer to:
% A. Gisbrecht and F.-M. Schleif. Metric and non-metric proximity
% transformations at linear cost. Neurocomputing, 2015.

% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.

%% create toy data
% specify the number of points for train and test sets
N=100;
N_test=20;

% create a toy data set with 3 clusters
Data=create_data_2d(N+N_test);

% subtract the mean, since it will be lost in the distance representation.
Data=bsxfun(@minus,Data,mean(Data(1:N,:)));

% separate into train and test sets
Data_train=Data(1:N,:);
Data_test=Data(N+1:end,:);

%% pq-embedding
% Assume the data lives in a pseudo-Euclidean space (also called pq-space
% or Minkowski space), characterised by the indefinite inner product.
% The inner product is positive definite on the first p dimensions and
% negative definite on the remaining q dimensions. In this case p=q=1.

% Plot data
figure
plot(Data_train(:,1),Data_train(:,2),'.');
xlabel('p');
ylabel('q');

% By computing the inner product we get the similarities.
I_pq=[1 0; 0 -1]; % define the inner product matrix
Sim=Data_train*I_pq*Data_train';

% By computing the distances in this space we get dissimilarities.
% These are non-metric and can become negative, i.e. they are not distances.
Dis=squareform(pdist(Data_train(:,1)).^2-pdist(Data_train(:,2)).^2);

% Usually distance-based techniques can not work or fail to converge on
% such data. E.g. the following command would produce an error.
% Data_train_=cmdscale(Dis);

%% transformations
% The dissimilarities and similarities are dual representations of the same
% data and can be converted to each other. The rotation of the data is lost
% and in case of dissimilarities also the mean. This means that if the data
% is not centered, converting similarities to dissimilarities and back will
% result in similarities different from the original ones, but the
% underlying vectorial data is still the same up to rotation and mean.
% Also selecting different subsets of dissimilarities, with different
% means, will result in different similarity representations.

% Convert dissimilarities into similarities using double centering.
Sim_=dis2sim(Dis); % Sim_ is equal to Sim
% Note: here and later "equal" means the matrices are essentially the same,
% although they are numericaly not equal; e.g. the Frobenius norm
% Err = norm(Sim-Sim_,'fro');
% is not zero, but very small (1e-14).

% Convert dissimilarities into similarities.
Dis_=sim2dis(Sim); % Dis_ is equal to Dis

% The underlying vectorial data can also be reconstructed using eigenvalue
% decomposition on the similarity matrix.
[Data_train_, I_pq_]=pq_embedding(Sim); % I_pq_ is equal to I_pq

% Data_train_ is equal to Data_train up to rotation
figure
plot(Data_train_(:,1),Data_train_(:,2),'.');
xlabel('p');
ylabel('q');

%% Nystroem
% Unfortunately, the above transformations are not feasible for big data
% sets. The computation of the full (dis)similarity matrices requires
% time and memory complexity quadratic in the number of data points.
% The transformations between dis- and similarities are quadratic as well.
% The pq-embedding using eigenvalue decomposition is even cubic.
% This problem can be solved, if one first approximates the matrices and
% performs the transformations and embedding afterwards.

% Basically the Nystroem approximation of a matrix Mat is:
% Mat_app=Mat_Nm * Mat_mm.^-1 * Mat_Nm'
% where Mat_Nm is the matrix of relations between all N points and m
% landmarks, Mat_mm.^-1 is the pseudo-inverse of the matrix of landmarks.

% For the Nystroem approximation m landmarks have to be chosen. There are
% many different approaches for the selection. Here we draw landmarks
% randomly, since this is a good and simple heuristic.
m=4; % select the number of landmarks
landmarks=randperm(N,m); % take only m random points as landmarks

% For the approximation only a linear part of the matrix is required:
% the (dis)similarities between all N points and m landmarks.
% approximate the similarities
ny_Sim = ny_create(Sim(:,landmarks),landmarks);
% approximate the dissimilarities
ny_Dis = ny_create(Dis(:,landmarks),landmarks);

% The approximation can also be computed this way:
% % approximate the similarities
% ny_Sim = ny_create(Sim,m);
% % approximate the dissimilarities
% ny_Dis = ny_create(Dis,m);

% The structure of the Nystroem approximated matrix ny_Mat is as follows:
% ny_Mat{1} is the matrix Mat_Nm,
% ny_Mat{2} is the pseudo-inverse of Mat_mm
% ny_Mat{3} is the index of landmarks
% The full matrix can be approximated via
% Mat=ny_Mat{1}*ny_Mat{2}*ny_Mat{1}'

% reconstruct the similarities
Sim_=ny_reconstruct(ny_Sim); % Sim_ is equal to Sim
% reconstruct the dissimilarities
Dis_=ny_reconstruct(ny_Dis); % Dis_ is equal to Dis

% The approximation is exact if the number of landmarks is equal to the
% rank of the approximated matrix. Here 4 landmarks are sufficient.
% In general case the number of landmarks depends on the eigenvalue
% spectrum of the approximated matrix. If there are many eigenvalues with
% large absolute values, many landmarks are required for a good
% approximation quality. Since real-world problems are often intrinsically
% low-dimensional a small number of landmarks is often sufficient.

%% fast transformations
% the same transformations as before can now be carried out on Nystroem
% approximated matrices in linear time
ny_Sim_ = ny_dis2sim(ny_Dis); % ny_Sim_ is equal to ny_Sim
ny_Dis_=ny_sim2dis(ny_Sim); % ny_Dis_ is equal to ny_Dis

%% eigenvalue decomposition
% To compute the pq-embedding eigenvalue decomposition is required.
% With Nystroem approximation it also requires only linear time.
[C, A] = ny_eig(ny_Sim);

% The eigenvalues show that the data is intrinsically two-dimensional with
% one positive and one negative eigenvalues and therefore can be embedded
% into pq-space with p=1 and q=1.
figure
bar(diag(A));

% The pq-embedding can then be computed as
[Data_train_, I_pq_]=ny_pq_embedding(ny_Sim); % I_pq_ is equal to I_pq

% Data_train_ is equal to Data_train up to rotation
figure
plot(Data_train_(:,1),Data_train_(:,2),'.');
xlabel('p');
ylabel('q');

%% eigenvalue correction
% Using the eigenvalue decomposition it is also possible to correct the
% matrix of indefinite similarities and to construct positive definite
% kernel matrix from it. The kernel matrix can then be used in the numerous
% kernel approaches.
ny_K=ny_sim2ker(ny_Sim, 'flip');

% If it is desirable to use dissimilarities, but one requires them to be
% metric distances, this is also possible.
% ny_Sim = ny_dis2sim(ny_Dis); % compute similarities
% ny_K=ny_sim2ker(ny_Sim, 'flip'); % compute correction
ny_D=ny_sim2dis(ny_K); % convert kernel to metric distances

% Now it is possible to compute distance matrix and run classical MDS,
% which was not possible before.
D=ny_reconstruct(ny_D); % compute full distance matrix

% correct numerical errors
D=D-diag(diag(D)); % zero diagonal
D=.5*(D+D'); % symmetry
Data_train_=cmdscale(sqrt(D)); % compute classical MDS

% The recovered coordinates represent the same data, now embedded into the
% Euclidean space.
figure
plot(Data_train_(:,1),Data_train_(:,2),'.');

%% out-of-sample extension
% Assume an algorithm was trained on the corrected data and now new test
% data has to be processed in the same way, consistent with the correction.

% Compute non-metric dissimilarities from new data to the landmarks.
Dis_ose=pdist2(Data_test(:,1),Data_train(landmarks,1)).^2 ...
    -pdist2(Data_test(:,2),Data_train(landmarks,2)).^2;

% Transform the new dissimilarities to similarities in the same way as the
% Nystroem approximated dissimilarities were transformed to similarities.
% Sim_ose is the matrix of similarities between new points and landmarks.
Sim_ose=ny_dis2sim_ose(ny_Dis, Dis_ose);

% The same similarities could also be computed directly using the inner
% product between new points and landmarks.
Sim_ose_=Data_test*I_pq*Data_train(landmarks,:)'; % Sim_ose_ is equal to Sim_ose

%% out-of-sample extension with correction
% The corrected kernel matrix can now be extended by the new similarities.
ny_K_ose=ny_sim2ker_ose(ny_K,Sim_ose);

% The full kernel matrix can then be transformed to metric distances.
ny_D_ose=ny_sim2dis(ny_K_ose);

% The pq-embedding of the full data set can also be computed.
[Data_, I_pq_]=ny_pq_embedding(ny_K_ose); % I_pq_ is equal to I_pq
% Data_ is equal to Data up to rotation

% plot new points in red
figure
plot(Data_(1:N,1),Data_(1:N,2),'.');
hold on
plot(Data_(N+1:end,1),Data_(N+1:end,2),'.r');

% compare to the original data
figure
plot(Data_train(:,1),Data_train(:,2),'.');
hold on
plot(Data_test(:,1),Data_test(:,2),'.r');

% One can see that the training data was consistently extended by the new
% data, which was then corrected and embedded into the Euclidean space in
% the same way as the original data.

%% reconstruct only a part of a matrix
% Based on the Nystroem approximation it is possible to reconstruct
% arbitrary submatrices of a Nystroem approximated matrix.

% Distances between test data points.
D_test_test=ny_reconstruct(ny_D_ose, N+1:N+N_test);

% Distances between test and train data points.
D_test_train=ny_reconstruct(ny_D_ose, N+1:N+N_test, 1:N);

