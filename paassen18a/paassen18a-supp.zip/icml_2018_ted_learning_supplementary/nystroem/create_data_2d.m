function Data=create_data_2d(N)
% Create a two-dimensional data set with three clusters. The points in each
% cluster are normally distributed.
%
% Input arguments:
%   N         - the number of points in the created data set
% Output arguments:
%   Data      - two-dimensional data set; each row represents a data point

% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.

% standard deviation
b=0.1;

% cluster means
means=[1,0,0;0,1,-1]';
means=repmat(means,ceil(N/3),1);

% create data points
Data=b*randn(N,2)+means(1:N,:);
