function [Data, I_pq]=ny_pq_embedding(ny_Sim)
% Computes the pseudo-Euclidean embedding of the Nystroem approximated
% similarities using fast eigenvalue decomposition. Also returns the
% diagonal of the corresponding inner product matrix.
%
% Input arguments:
%   ny_Sim    - approximated similarity matrix
% Output arguments:
%   Data      - an embedding of the similarity data in a possibly
%               pseudo-Euclidean space; each row represent a data point
%   I_pq        an inner product matrix of the corresponding space
%
% Note:         see also ny_create for detailed format of approximated
%               matrices

% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.

% compute the eigenvalue decomposition
[eigVec,eigVal] = ny_eig(ny_Sim);

% sort the eigenvalues
[eigVal_sorted,ind]=sort(diag(eigVal),'descend');

% keep only non zero eigenvalues
ind=ind(abs(eigVal_sorted)>1e-10);

% construct the embedding
Data=eigVec(:,ind)*sqrt(abs(eigVal(ind,ind)));

% construct the inner product matrix
I_pq=sign(eigVal(ind,ind));
