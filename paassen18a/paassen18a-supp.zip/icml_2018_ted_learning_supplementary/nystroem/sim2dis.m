function Dis=sim2dis(Sim)
% Computes the transformation of similarities into dissimilarities.
%
% Input arguments:
%   Sim       - a symmetric, possibly non-Euclidean similarity matrix
% Output arguments:
%   Dis       - a symmetric dissimilarity matrix representing the input data

% Copyright:    This file is part of the Nystroem Approximation Toolbox.
%
%               The Nystroem Approximation Toolbox is distributed under the
%               GNU General Public License (version 3 or later);
%               see <http://www.gnu.org/licenses/> for details.
%
%               Copyright Andrej Gisbrecht, 2015.

[N,N_]=size(Sim);

if N~=N_
    error('The similarity matrix must be square.');
end
if ~issymmetric(Sim)
    error('The similarity matrix must be symmetric.');
end

Dis=bsxfun(@plus,diag(Sim),diag(Sim)')-2*Sim;
Dis=(Dis+Dis')/2;
