function [err,grad] = regularize_embedding(Theta, m, n, weight, l2weight)
% regularizes an embedding by -weight * log(det(Theta' * Theta)) + l2weight
% * sum(sum(Theta.^2))

vectorform = isvector(Theta);

if(vectorform)
    Theta = reshape(Theta, n, m)';
end

det_Theta = det(Theta' * Theta);
if(det_Theta < 1E-30)
    err  = inf;
else
    err  = -weight * log(det_Theta);
end
grad = -weight * 2 * pinv(Theta)';

err  = err  + l2weight * sum(sum(Theta.^2));
grad = grad + l2weight * Theta;

if(vectorform)
    grad = reshape(grad', m * n, 1);
end

end

