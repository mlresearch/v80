%% Tree Edit Distance Learning via Adaptive Symbol Embeddings
% 
% Copyright (C) 2018
% Benjamin Paaßen
% AG Machine Learning
% Centre of Excellence Cognitive Interaction Technology (CITEC)
% University of Bielefeld
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
function [ errs ] = mrglvq_regul_sweep( D, X, Y, test_log, algo, score_algo, initial_params, n, K, reguls )
% Computes MRGLVQ metric learning for a range of regularization parameters
% and returns the MRGLVQ classification error on the edit distance for all
% of them.
%
% Parameters:
% D        - the initial m x m matrix of pairwise edit distances.
% X        - the m tree objects for training and test data.
% Y        - an m x 1 label vector for training and test data.
% test_log - a m x 1 logical specifying the test data
% algo     - an algorithm which returns alignments
% score_algo - an algorithm which returns doubles
% initial_params - the default parameter settings for the comparator used
%            by algo
% n        - the alphabet size
% K        - the number of prototypes to consider
% reguls   - all possible regul parameters

errs             = zeros(numel(reguls), 1);

X_train          = de.citec.tcs.utils.MatlabListInterface.selectFromList(X, ~test_log);
comp             = algo.getComparator();

% train median relational GLVQ
mrglvq_model     = de.citec.ml.mrglvq.MedianRelationalGLVQ.train(D(~test_log, ~test_log), Y(~test_log), K);
W_idxs           = mrglvq_model.getPrototypeIndices() + 1;

algo.setComparator(comp);
for b=1:numel(reguls)
    regul_fun        = @(params) (regularize_embedding(params, n, n, reguls(b), reguls(b)));
    % re-set parameters
    comp.setParameters(initial_params);
    % perform metric learning
    params = mrglvq_learn_parameters_em(X_train, Y(~test_log), comp, initial_params, algo, W_idxs, [], regul_fun, [] );
    comp.setParameters(params);
    % compute the new distances
    try
        engine  = de.citec.tcs.alignment.ParallelProcessingEngine(score_algo, X, X_train);
    catch
        engine  = de.citec.tcs.alignment.trees.TreeParallelProcessingEngine(score_algo, X, X_train);
    end
    engine.setReporter([]);
    engine.setFull();
    engine.calculate();
    D_to_train    = engine.getDoubleResultMatrix();
    % re-train mrglvq using the current prototypes as basis
    new_mrglvq_model = de.citec.ml.mrglvq.MedianRelationalGLVQ.train(D_to_train(~test_log, :), Y(~test_log), mrglvq_model.getPrototypeIndices());
    errs(b)       = mean(Y(test_log) ~= de.citec.ml.mrglvq.MedianRelationalGLVQ.classify(D_to_train(test_log, new_mrglvq_model.getPrototypeIndices() + 1), new_mrglvq_model));

end

