/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.lmnn;

import de.citec.ml.icml2018.comparators.CosineDistanceComparator;
import de.citec.tcs.alignment.Alignment;
import de.citec.tcs.alignment.comparators.IndexingFunction;
import de.citec.tcs.alignment.comparators.SquareReplacementMatrixComparator;
import de.citec.tcs.alignment.trees.CooptimalMatrix;
import de.citec.tcs.alignment.trees.DerivableLabelComparator;
import de.citec.tcs.alignment.trees.Tree;
import de.citec.tcs.alignment.trees.TreeEditCooptimalAlgorithm;
import de.citec.tcs.alignment.trees.TreeEditFullAlgorithm;
import de.citec.tcs.alignment.trees.TreeEditScoreAlgorithm;
import de.citec.tcs.alignment.trees.TreeImpl;
import de.citec.tcs.alignment.trees.TreeParallelProcessingEngine;
import de.citec.tcs.alignment.trees.TreeSquareParallelProcessingEngine;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class LMNNCooptimalGradientCalculatorTest {

	public LMNNCooptimalGradientCalculatorTest() {
	}

	@BeforeClass
	public static void setUpClass() {
	}

	@AfterClass
	public static void tearDownClass() {
	}

	@Before
	public void setUp() {
	}

	@After
	public void tearDown() {
	}

	/**
	 * Test of computeGradient method, of class LMNNCooptimalGradientCalculator.
	 */
	@Test
	public void testComputeGradient() {
		// create simple example data with three trees, namely A, B(C) and C.
		final Tree<Character> X = new TreeImpl<>('A');
		final Tree<Character> Y = TreeImpl.builder('B').node('C').getTree();
		final Tree<Character> Z = new TreeImpl<>('C');
		final List<Tree<Character>> data = Arrays.asList(X, Y, Z, Z);
		final int[] labels = {0, 0, 1, 1};

		// set up a comparator for this data
		final IndexingFunction<Character> idx = new IndexingFunction<Character>() {

			@Override
			public int index(Character c) {
				switch (c) {
					case 'A':
						return 0;
					case 'B':
						return 1;
					case 'C':
						return 2;
					default:
						throw new IllegalArgumentException("illegal argument: " + c);
				}
			}

			@Override
			public int range() {
				return 3;
			}
		};
		final SquareReplacementMatrixComparator<Character> comp = new SquareReplacementMatrixComparator<>(idx);
		final DerivableLabelComparator<Character, Character> wrapComp = new DerivableLabelComparator<>(comp);
		// compute all pairwise distances and all pairwise cooptimals
		final TreeEditScoreAlgorithm<Character, Character> scoreAlgo = new TreeEditScoreAlgorithm<>(wrapComp);
		final TreeEditCooptimalAlgorithm<Character, Character> cooptAlgo = new TreeEditCooptimalAlgorithm<>(wrapComp);
		final CooptimalMatrix[][] coopts = new CooptimalMatrix[data.size()][data.size()];
		final double[][] D = new double[data.size()][data.size()];
		for (int i = 0; i < data.size(); i++) {
			for (int j = 0; j < data.size(); j++) {
				D[i][j] = scoreAlgo.calculateAlignment(data.get(i), data.get(j));
				coopts[i][j] = cooptAlgo.calculateAlignment(data.get(i), data.get(j));
			}
		}

		// compute the expected error and gradient. 
		final double margin = 0.1;
		final int K = 1;

		final double expected_err = D[0][1] * D[0][1] + 2 * (D[0][1] * D[0][1] + margin * margin - D[0][2] * D[0][2])
				+ D[1][0] * D[1][0] + 2 * (D[1][0] * D[1][0] + margin * margin - D[1][2] * D[1][2]);

		final double[][] expected_grad = new double[4][4];

		// we have an A -> B replacement in 50% of the co-optimal alignments between X and Y
		expected_grad[0][1] = 3 * D[0][1] * 0.5;
		// We have an A -> C replacement in 50% of the co-optimal alignments between X and Y and in
		// 100% of co-optimal alignments between X and Z.
		expected_grad[0][2] = 3 * D[0][1] * 0.5 - 2 * D[0][2];
		// we have a B -> A replacement in 50% of the co-optimal alignments between Y and X
		expected_grad[1][0] = 3 * D[1][0] * 0.5;
		// We have a B -> - deletion in 50% of the co-optimal alignments between X and Y and in
		// 100% of co-optimal alignments between Y and Z
		expected_grad[1][3] = 3 * D[1][0] * 0.5 - 2 * D[1][2];
		// We have an C -> A replacement in 50% of the co-optimal alignments between Y and X
		expected_grad[2][0] = 3 * D[1][0] * 0.5;
		// We have a C -> C replacement in 100% of the co-optimal alignments between Y and Z
		expected_grad[2][2] = - 2 * D[1][2];
		// We have a C -> - deletion in 50% of the co-optimal alignments between X and Y
		expected_grad[2][3] = 3 * D[1][0] * 0.5;
		// We have a - -> B insertion in 50% of the co-optimal alignments between Y and X
		expected_grad[3][1] = 3 * D[1][0] * 0.5;
		// We have a - -> C insertion in 50% of the co-optimal alignments between Y and X
		expected_grad[3][2] = 3 * D[1][0] * 0.5;
		expected_grad[3][3] = Double.NaN;

		// set up the LMNNCooptimalGradientCalculator
		final LMNNCooptimalGradientCalculator<Tree<Character>> instance = new LMNNCooptimalGradientCalculator<>(coopts, labels);
		instance.setReporter(null);
		instance.setK(K);
		instance.setMargin(margin);
		double[] errAndGrad = instance.computeErrorAndGradient(wrapComp, D);

		// check the result
		assertEquals(1 + comp.getNumberOfParameters(), errAndGrad.length);
		assertEquals(expected_err, errAndGrad[0], 1E-3);

		final double[] grad = new double[comp.getNumberOfParameters()];
		System.arraycopy(errAndGrad, 1, grad, 0, comp.getNumberOfParameters());

		final double[][] C_gradient = SquareReplacementMatrixComparator.vectorToCostMatrix(grad);
		final String[] syms = {"A", "B", "C", "-"};
		for (int l = 0; l < expected_grad.length; l++) {
			for (int r = 0; r < expected_grad[l].length; r++) {
				assertEquals("Unexpected gradient for replacement of " + syms[l] + " with " + syms[r],
						expected_grad[l][r], C_gradient[l][r], 1E-3);
			}
		}
	}

	/**
	 * Test of computeTargetNeighbors method, of class LMNNCooptimalGradientCalculator.
	 */
	@Test
	public void testComputeTargetNeighbors() {
		// test a trivial case where there is only one potential target neighbor and this should be
		// found
		{
			final double[] d = {0, 0, 0, 1, 0, 0};
			final int[] labels = {0, 1, 1, 0, 1, 1};
			final int i = 0;
			final int K = 1;
			final int[] expected = {3};
			final int[] actual = LMNNCooptimalGradientCalculator.computeTargetNeighbors(d, labels, i, K);
			assertArrayEquals(expected, actual);
		}
		{
			final double[] d = {0, 0, 0, 1, 0, 0};
			final int[] labels = {1, 0, 1, 0, 1, 1};
			final int i = 1;
			final int K = 1;
			final int[] expected = {3};
			final int[] actual = LMNNCooptimalGradientCalculator.computeTargetNeighbors(d, labels, i, K);
			assertArrayEquals(expected, actual);
		}
		{
			final double[] d = {0, 0, 0, 1, 0, 0};
			final int[] labels = {1, 1, 1, 0, 1, 0};
			final int i = 5;
			final int K = 1;
			final int[] expected = {3};
			final int[] actual = LMNNCooptimalGradientCalculator.computeTargetNeighbors(d, labels, i, K);
			assertArrayEquals(expected, actual);
		}
		// test a case where all target neighbors are in the first numbers
		{
			final double[] d = {0, 0, 3, 1, 5, 4};
			final int[] labels = {0, 1, 0, 0, 0, 0};
			final int i = 0;
			final int K = 2;
			final int[] expected = {3, 2};
			final int[] actual = LMNNCooptimalGradientCalculator.computeTargetNeighbors(d, labels, i, K);
			assertArrayEquals(expected, actual);
		}
		// test a case where some target neighbors are in the first numbers and some are not
		{
			final double[] d = {0, 0, 3, 1, 5, 2};
			final int[] labels = {0, 1, 0, 0, 0, 0};
			final int i = 0;
			final int K = 2;
			final int[] expected = {3, 5};
			final int[] actual = LMNNCooptimalGradientCalculator.computeTargetNeighbors(d, labels, i, K);
			assertArrayEquals(expected, actual);
		}
		{
			final double[] d = {0, 3, 1, 5, 0, 2};
			final int[] labels = {1, 0, 0, 0, 0, 0};
			final int i = 4;
			final int K = 2;
			final int[] expected = {2, 5};
			final int[] actual = LMNNCooptimalGradientCalculator.computeTargetNeighbors(d, labels, i, K);
			assertArrayEquals(expected, actual);
		}
		// test a larger case with some random numbers but defined target neighbors
		{
			final int m = 100;
			final double[] d = new double[m];
			final int[] labels = new int[m];
			final int i = 0;
			final Random rnd = new Random();
			for (int j = 1; j < m; j++) {
				labels[j] = rnd.nextDouble() < 0.5 ? 0 : 1;
				if (labels[j] == 1) {
					d[j] = rnd.nextDouble() * 0.5;
				} else {
					d[j] = rnd.nextDouble() + 1;
				}
			}
			final int K = 5;
			final int[] expected = new int[K];
			int j = m - 1;
			for (int k = 0; k < K; k++) {
				while (labels[j] != labels[i]) {
					j--;
				}
				expected[k] = j;
				d[j] = 0.5 + k * 0.5 / K;
				j--;
			}

			final int[] actual = LMNNCooptimalGradientCalculator.computeTargetNeighbors(d, labels, i, K);
			assertArrayEquals(expected, actual);

		}
	}

	/**
	 * Test of computeImpostors method, of class LMNNCooptimalGradientCalculator.
	 */
	@Test
	public void testComputeImpostors() {
		// compute impostors for some example cases
		final double margin = 1;

		final double[] d = {0, 1, 2, 1.2, 2.1, 3.5};
		final int[] labels = {0, 0, 0, 1, 1, 1};

		{
			final int k = 1;
			final List<Integer> expected = Arrays.asList(3);
			final List<Integer> actual = LMNNCooptimalGradientCalculator.computeImpostors(d, margin, labels, k);
			assertEquals(expected, actual);
		}
		{
			final int k = 2;
			final List<Integer> expected = Arrays.asList(3, 4);
			final List<Integer> actual = LMNNCooptimalGradientCalculator.computeImpostors(d, margin, labels, k);
			assertEquals(expected, actual);
		}

	}

	/**
	 * Test of computeErrorAndGradient method, of class MedianGLVQCooptimalGradientCalculator.
	 */
	@Test
	public void testMetricLearning() {

		// generate a very simple and well-controlled 2D data set with only four points:
		// (-1, -10) and (-1, 10) for class -1 and (1,-10), (1, 10) for class 2.
		// The initial configuration ensures that the nearest neighbor that is not the data point
		// itself is wrong.
		final double[][] X_labels = {
			{-1, -10},
			{-1, 10},
			{1, -10},
			{1, 10}
		};
		final int[] Y = {-1, -1, 1, 1};

		final int m = X_labels.length;
		final List<Tree<double[]>> X = new ArrayList<>(m);
		for (int i = 0; i < m; i++) {
			X.add(new TreeImpl<>(X_labels[i]));
		}
		// set up alignment algorithm
		final CosineDistanceComparator comp = new CosineDistanceComparator(2);
		final DerivableLabelComparator compWrap = new DerivableLabelComparator<>(comp);
		final TreeEditFullAlgorithm<double[], double[]> algo = new TreeEditFullAlgorithm<>(compWrap);
		// compute co-optimal matrix
		final TreeSquareParallelProcessingEngine<double[], Alignment> engine = new TreeSquareParallelProcessingEngine<>(algo, X);
		engine.setFull();
		engine.setReporter(null);
		engine.calculate();
		final Alignment[][] C = engine.getResultMatrix();
		// set up cooptimal distance engine
		final CooptimalDistanceEngine<Tree<double[]>, Tree<double[]>> dist_engine = new CooptimalDistanceEngine<>(C, compWrap);
		dist_engine.setFull();
		dist_engine.setReporter(null);

		// set up instance
		final LMNNCooptimalGradientCalculator<Tree<double[]>> instance = new LMNNCooptimalGradientCalculator<>(C, Y);
		instance.setK(1);
		instance.setMargin(0.5);
		instance.setReporter(null);

		// perform gradient descent
		final double eta = 0.05;
		final int T = 20;
		final double[] err = new double[T];
		final double[] params = comp.getParameters();
		for (int t = 0; t < T; t++) {
			// compute current distance matrix
			dist_engine.calculate();
			final double[][] D = dist_engine.getDoubleResultMatrix();
			// compute error and gradient
			final double[] err_and_grad = instance.computeErrorAndGradient(compWrap, D);
			if (t > 0) {
				assertTrue(err_and_grad[0] < err[t - 1] + 1E-3);
			}
			err[t] = err_and_grad[0];
			// do a gradient step
			for (int j = 0; j < params.length; j++) {
				params[j] -= eta * err_and_grad[j + 1];
			}
			comp.setParameters(params);
		}

		assertTrue(params[1] < 1);
		assertTrue(params[2] < 1);
		assertTrue(params[3] < 1);
		assertTrue(params[0] > 1);
		assertTrue(params[0] > 1.5 * params[3]);
	}

}
