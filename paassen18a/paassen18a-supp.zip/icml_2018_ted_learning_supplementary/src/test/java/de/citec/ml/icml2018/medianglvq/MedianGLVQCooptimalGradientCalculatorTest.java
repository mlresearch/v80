/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.medianglvq;

import de.citec.ml.icml2018.comparators.CosineDistanceComparator;
import de.citec.ml.icml2018.comparators.SetIndexingFunction;
import de.citec.ml.icml2018.comparators.SymmetricMatrixComparator;
import de.citec.ml.icml2018.comparators.VectorEmbeddingComparator;
import de.citec.ml.icml2018.input.ArtificialData;
import de.citec.ml.icml2018.input.Dataset;
import de.citec.ml.icml2018.lmnn.CooptimalDistanceEngine;
import de.citec.tcs.alignment.Alignment;
import de.citec.tcs.alignment.comparators.DerivableComparator;
import de.citec.tcs.alignment.trees.CooptimalMatrix;
import de.citec.tcs.alignment.trees.DerivableLabelComparator;
import de.citec.tcs.alignment.trees.Tree;
import de.citec.tcs.alignment.trees.TreeEditCooptimalAlgorithm;
import de.citec.tcs.alignment.trees.TreeEditFullAlgorithm;
import de.citec.tcs.alignment.trees.TreeImpl;
import de.citec.tcs.alignment.trees.TreeParallelProcessingEngine;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class MedianGLVQCooptimalGradientCalculatorTest {

	public MedianGLVQCooptimalGradientCalculatorTest() {
	}

	@BeforeClass
	public static void setUpClass() {
	}

	@AfterClass
	public static void tearDownClass() {
	}

	@Before
	public void setUp() {
	}

	@After
	public void tearDown() {
	}

	/**
	 * Test of computeErrorAndGradient method, of class MedianGLVQCooptimalGradientCalculator.
	 */
	@Test
	public void testComputeErrorAndGradient() {
		final int m = 50;
		final Dataset<Tree<Character>> dataset = ArtificialData.createStringDataset(m, 5);
		final SetIndexingFunction<Character> idxfun = new SetIndexingFunction<>('A', 'B', 'C', 'D');
		final List<Tree<Integer>> idx_data = VectorEmbeddingComparator.indexForest(dataset.data, idxfun);

		// select the first and second data point within both classes as prototypes
		final int[] W_idxs = {0, 1, m / 2, m / 2 + 1};

		final List<Tree<Integer>> W = new ArrayList<>();
		for (int k = 0; k < W_idxs.length; k++) {
			W.add(idx_data.get(W_idxs[k]));
		}

		// compute co-optimals
		final SymmetricMatrixComparator innerComp = new SymmetricMatrixComparator(4);
		final DerivableComparator<Tree<Integer>, Tree<Integer>> comp = new DerivableLabelComparator<>(innerComp);
		final TreeEditCooptimalAlgorithm<Integer, Integer> algo = new TreeEditCooptimalAlgorithm<>(comp);
		final TreeParallelProcessingEngine<Integer, Integer, CooptimalMatrix> coopt_engine = new TreeParallelProcessingEngine<>(algo, idx_data, W);
		coopt_engine.setReporter(null);
		coopt_engine.setFull();
		coopt_engine.calculate();

		final MedianGLVQCooptimalGradientCalculator<Tree<Integer>> instance = new MedianGLVQCooptimalGradientCalculator<>(
				coopt_engine.getResultMatrix(), Dataset.collectionToPrimitiveArr(dataset.labels), W_idxs);
		instance.setReporter(null);

		final CooptimalDistanceEngine<Tree<Integer>, Tree<Integer>> distEngine
				= new CooptimalDistanceEngine<>(coopt_engine.getResultMatrix(), comp);
		distEngine.setReporter(null);
		distEngine.setFull();
		distEngine.calculate();

		final double[] err_and_grad = instance.computeErrorAndGradient(comp, distEngine.getDoubleResultMatrix());
		final double err = err_and_grad[0];
		final double[] grad = new double[err_and_grad.length - 1];
		System.arraycopy(err_and_grad, 0, grad, 0, err_and_grad.length - 1);
		innerComp.setParameters(grad);
		final double[][] grad_mat = innerComp.getCostMatrix();
		assertEquals(grad_mat.length, 5);
		final char[] alph = {'A', 'B', 'C', 'D', '-'};
		System.out.println(matrixToString(grad_mat, alph));
	}

	private static String matrixToString(double[][] mat, char[] alph) {
		final NumberFormat formatter = new DecimalFormat("00.00");
		final StringBuilder build = new StringBuilder();
		build.append("C|");
		for (int j = 0; j < alph.length; j++) {
			build.append(alph[j]);
			build.append("     |");
		}
		build.append("\n");
		for (int i = 0; i < alph.length; i++) {
			build.append(alph[i]);
			build.append('|');
			for (int j = 0; j < alph.length; j++) {
				if (mat[i][j] > 0) {
					build.append('+');
				}
				build.append(formatter.format(mat[i][j]));
				build.append('|');
			}
			build.append('\n');
		}
		return build.toString();
	}

	/**
	 * Test of computeErrorAndGradient method, of class MedianGLVQCooptimalGradientCalculator.
	 */
	@Test
	public void testMetricLearning() {

		// generate a very simple and well-controlled 2D data set with only four points:
		// (-1, -10) and (-1, 10) for class -1 and (1,-10), (1, 10) for class 2.
		// The initial configuration ensures that the nearest neighbor that is not the data point
		// itself is wrong.
		final double[][] X_labels = {
			{-1, -10},
			{-1, 10},
			{1, -10},
			{1, 10}
		};
		final int[] Y = {-1, -1, 1, 1};

		final int m = X_labels.length;
		final List<Tree<double[]>> X = new ArrayList<>(m);
		for (int i = 0; i < m; i++) {
			X.add(new TreeImpl<>(X_labels[i]));
		}
		// use points 0 and 2 as prototypes
		final List<Tree<double[]>> W = Arrays.asList(X.get(0), X.get(2));
		// set up alignment algorithm
		final CosineDistanceComparator comp = new CosineDistanceComparator(2);
		final DerivableLabelComparator compWrap = new DerivableLabelComparator<>(comp);
		final TreeEditFullAlgorithm<double[], double[]> algo = new TreeEditFullAlgorithm<>(compWrap);
		// compute co-optimal matrix
		final TreeParallelProcessingEngine<double[], double[], Alignment> engine = new TreeParallelProcessingEngine<>(algo, X, W);
		engine.setFull();
		engine.setReporter(null);
		engine.calculate();
		final Alignment[][] C = engine.getResultMatrix();
		// set up cooptimal distance engine
		final CooptimalDistanceEngine<Tree<double[]>, Tree<double[]>> dist_engine = new CooptimalDistanceEngine<>(C, compWrap);
		dist_engine.setFull();
		dist_engine.setReporter(null);

		// set up instance
		final MedianGLVQCooptimalGradientCalculator<Tree<double[]>> instance = new MedianGLVQCooptimalGradientCalculator<>(C, Y, new int[]{0, 2});
		instance.setReporter(null);

		// perform gradient descent
		final double eta = 2;
		final int T = 20;
		final double[] err = new double[T];
		final double[] params = comp.getParameters();
		for (int t = 0; t < T; t++) {
			// compute current distance matrix
			dist_engine.calculate();
			final double[][] D = dist_engine.getDoubleResultMatrix();
			// compute error and gradient
			final double[] err_and_grad = instance.computeErrorAndGradient(compWrap, D);
			if (t > 0) {
				assertTrue(err_and_grad[0] < err[t - 1] + 1E-3);
			}
			err[t] = err_and_grad[0];
			// do a gradient step
			for (int j = 0; j < params.length; j++) {
				params[j] -= eta * err_and_grad[j + 1];
			}
			comp.setParameters(params);
		}

		assertTrue(params[1] < 1);
		assertTrue(params[2] < 1);
		assertTrue(params[3] < 1);
		assertTrue(params[0] > 1);
		assertTrue(params[0] > 1.5 * params[3]);
	}
}
