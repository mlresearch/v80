/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.gesl;

import de.citec.ml.icml2018.gesl.GESLLinearProgram.IndexMatrix;
import de.citec.ml.icml2018.gesl.GESLLinearProgram.SparseEntry;
import de.citec.tcs.alignment.comparators.TrivialEditComparator;
import de.citec.tcs.alignment.trees.LabelComparator;
import de.citec.tcs.alignment.trees.Tree;
import de.citec.tcs.alignment.trees.TreeEditFullAlgorithm;
import de.citec.tcs.alignment.trees.TreeEditScoreAlgorithm;
import de.citec.tcs.alignment.trees.TreeImpl;
import de.citec.tcs.alignment.trees.TreeParallelProcessingEngine;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math3.optim.PointValuePair;
import org.apache.commons.math3.optim.linear.LinearConstraint;
import org.apache.commons.math3.optim.linear.LinearConstraintSet;
import org.apache.commons.math3.optim.linear.LinearObjectiveFunction;
import org.apache.commons.math3.optim.linear.Relationship;
import org.apache.commons.math3.optim.linear.SimplexSolver;
import org.apache.commons.math3.optim.nonlinear.scalar.GoalType;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Benjamin Paassen - bpaassen@techfak.uni-bielefeld.de
 */
public class GESLPrototypeLinearProgramTest {

	public GESLPrototypeLinearProgramTest() {
	}

	@BeforeClass
	public static void setUpClass() {
	}

	@AfterClass
	public static void tearDownClass() {
	}

	@Before
	public void setUp() {
	}

	@After
	public void tearDown() {
	}

	/**
	 * Solves a GESLPrototypeLinearProgram using the apache commons implementation of the Simplex
	 * algorithm.
	 *
	 * @param prog
	 * @return
	 */
	private static PointValuePair solve(GESLPrototypeLinearProgram prog) {
		// wrap objective function
		final LinearObjectiveFunction objective = new LinearObjectiveFunction(prog.f, 0);
		// transform inequality constraints
		final double[][] A = new double[prog.b.length][prog.f.length];
		for (int s = 0; s < prog.A.i.length; s++) {
			A[prog.A.i[s]][prog.A.j[s]] = prog.A.v[s];
		}
		final ArrayList<LinearConstraint> constraints = new ArrayList<>();
		for (int i = 0; i < prog.b.length; i++) {
			constraints.add(new LinearConstraint(A[i], Relationship.LEQ, prog.b[i]));
		}
		// transform lower bounds
		for (int i = 0; i < prog.lb.length; i++) {
			final double[] e_i = new double[prog.lb.length];
			e_i[i] = 1;
			constraints.add(new LinearConstraint(e_i, Relationship.GEQ, 0));
		}
		// transform the upper bound for nu.
		final double[] e_R = new double[prog.lb.length];
		e_R[e_R.length - 1] = 1;
		constraints.add(new LinearConstraint(e_R, Relationship.LEQ, Math.log(2)));
		// solve
		return new SimplexSolver().optimize(objective, new LinearConstraintSet(constraints), GoalType.MINIMIZE);
	}

	/**
	 * Test of initialize method, of class GESLPrototypeLinearProgram.
	 */
	@Test
	public void testInitialize() {
		// we use a very simple example with three single-letter trees
		final List<Tree<Integer>> data = new ArrayList<>();
		data.add(new TreeImpl<>(0));
		data.add(new TreeImpl<>(1));
		data.add(new TreeImpl<>(2));
		data.add(new TreeImpl<>(2));
		final int[] Y = {1, 1, 2, 2};
		final int[] W = {0, 2};
		final List<Tree<Integer>> protos = new ArrayList<>(W.length);
		for (int k = 0; k < W.length; k++) {
			protos.add(data.get(W[k]));
		}

		final TrivialEditComparator<Integer> comp = new TrivialEditComparator<>();
		final TreeEditFullAlgorithm<Integer, Integer> full_algo = new TreeEditFullAlgorithm<>(new LabelComparator<>(comp));
		final TreeEditScoreAlgorithm<Integer, Integer> score_algo = new TreeEditScoreAlgorithm<>(new LabelComparator<>(comp));
		final TreeParallelProcessingEngine<Integer, Integer, Double> engine = new TreeParallelProcessingEngine<>(
				score_algo, data, protos);
		engine.setReporter(null);
		engine.setFull();
		engine.calculate();
		final double[][] D = engine.getDoubleResultMatrix();

		final int n = 3;
		final GESLPrototypeLinearProgram instance = GESLPrototypeLinearProgram.fromTreeEditAlgorithm(D, Y, full_algo, data, n, W, 16);

		// check the resulting linear program
		// we have 1 + 2 + 3 = 6 parameters, 2*4 = 8 slack variables and the shift variable nu.
		final double[] expected_f = {0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0};
		assertArrayEquals(expected_f, instance.f, 1E-3);

		final ArrayList<SparseEntry> sparse = new ArrayList<>();
		// 0 vs 0: trivial
		// 1 vs 0: C[1, 0] -slack_1^+ - nu <= 0
		add(sparse, 1, 0, 1);
		add(sparse, 1, 7, -1);
		add(sparse, 1, 14, -1);
		// 2 vs 2: trivial
		// 3 vs 2: trivial
		// 0 vs 2: -C[0, 2] - slack_1^- + nu <= -log(2)
		add(sparse, 4, 1, -1);
		add(sparse, 4, 10, -1);
		add(sparse, 4, 14, 1);
		// 1 vs 2: -C[1, 2] -slack_2^- + nu <= -log(2)
		add(sparse, 5, 2, -1);
		add(sparse, 5, 11, -1);
		add(sparse, 5, 14, 1);
		// 3 vs 0: -C[0, 2] -slack_3^- + nu <= -log(2)
		add(sparse, 6, 1, -1);
		add(sparse, 6, 12, -1);
		add(sparse, 6, 14, 1);
		// 4 vs 0: -C[0, 2] -slack_4^- + nu <= -log(2)
		add(sparse, 7, 1, -1);
		add(sparse, 7, 13, -1);
		add(sparse, 7, 14, 1);

		final IndexMatrix expected_A = new IndexMatrix(sparse);
		assertEquals(expected_A, instance.A);

		final double[] expected_b = {0, 0, 0, 0, -Math.log(2), -Math.log(2), -Math.log(2), -Math.log(2)};
		assertArrayEquals(expected_b, instance.b, 1E-3);

		final double[] expected_lb = new double[expected_f.length];
		assertArrayEquals(expected_lb, instance.lb, 1E-3);
		final double[] expected_ub = new double[expected_f.length];
		Arrays.fill(expected_ub, Double.POSITIVE_INFINITY);
		expected_ub[expected_ub.length - 1] = Math.log(2);
		assertArrayEquals(expected_ub, instance.ub, 1E-3);

		// solve the linear program and check the result
		final PointValuePair solution = solve(instance);
		// we expect that no error remains
		assertEquals(0, solution.getValue(), 1E-3);
		// we expect that the 0->1 replacement cost is zero
		assertEquals(0, solution.getPoint()[0], 1E-3);
		// the 0->2 and 1->2 replacement cost should be at least log(2)
		assertTrue(solution.getPoint()[1] >= Math.log(2));
		assertTrue(solution.getPoint()[2] >= Math.log(2));
		// the gap costs don't matter.
		// the slack variables should be zero
		for (int s = 6; s < 6 + 2 * 4; s++) {
			assertEquals(0, solution.getPoint()[s], 1E-3);
		}
		// nu should be zero as well
		assertEquals(0, solution.getPoint()[solution.getPoint().length - 1], 1E-3);

	}

	/**
	 * Test of initialize method, of class GESLPrototypeLinearProgram.
	 */
	@Test
	public void testInitialize2() {
		// we use a very simple example with six trees in two classes using only two letters
		final List<Tree<Integer>> data = new ArrayList<>();
		data.add(TreeImpl.builder(0).getTree());
		data.add(TreeImpl.builder(0).nodeAndDesc(0).getTree());
		data.add(TreeImpl.builder(0).nodeAndDesc(0).nodeAndDesc(0).getTree());
		data.add(TreeImpl.builder(1).getTree());
		data.add(TreeImpl.builder(1).nodeAndDesc(1).getTree());
		data.add(TreeImpl.builder(1).nodeAndDesc(1).nodeAndDesc(1).getTree());
		final int[] Y = {1, 1, 1, 2, 2, 2};

		final int[] W = {0, 3};
		final List<Tree<Integer>> protos = new ArrayList<>(W.length);
		for (int k = 0; k < W.length; k++) {
			protos.add(data.get(W[k]));
		}

		final TrivialEditComparator<Integer> comp = new TrivialEditComparator<>();
		final TreeEditFullAlgorithm<Integer, Integer> full_algo = new TreeEditFullAlgorithm<>(new LabelComparator<>(comp));
		final TreeEditScoreAlgorithm<Integer, Integer> score_algo = new TreeEditScoreAlgorithm<>(new LabelComparator<>(comp));
		final TreeParallelProcessingEngine<Integer, Integer, Double> engine = new TreeParallelProcessingEngine<>(score_algo, data, protos);
		engine.setReporter(null);
		engine.setFull();
		engine.calculate();
		final double[][] D = engine.getDoubleResultMatrix();

		final int n = 2;
		final int m = data.size();

		final GESLPrototypeLinearProgram instance = GESLPrototypeLinearProgram.fromTreeEditAlgorithm(D, Y, full_algo, data, n, W, 16);

		// Check the resulting linear program
		// we have 1 + 2 = 3 parameters, 2*6 = 12 slack variables and the shift variable nu.
		final int expected_num_params = (n * (n + 1)) / 2;
		final int expected_num_slacks = 2 * m;
		final int expected_num_vars = expected_num_params + expected_num_slacks + 1;
		final double[] expected_f = new double[expected_num_vars];
		// only the slack variables should be considered in the objective function
		for (int s = expected_num_params; s < expected_num_params + expected_num_slacks; s++) {
			expected_f[s] = 1;
		}
		assertArrayEquals(expected_f, instance.f, 1E-3);

		// check the constraint matrix
		// note that C[0, 1] = C[1, 0] = c_0,
		// C[0, 2] = C[2, 0] = c_1, and
		// C[1, 2] = C[2, 1] = c_2.
		final ArrayList<SparseEntry> sparse = new ArrayList<>();

		// POSITIVE CONSTRAINTS
		// 0 vs 0: trivial
		// 00 vs 0: c_1 -slack_1^+ - nu <= 0
		add(sparse, 1, 1, 1);
		add(sparse, 1, expected_num_params + 1, -1);
		add(sparse, 1, expected_num_vars - 1, -1);
		// 000 vs 0: 2*c_1 -slack_2^+ - nu <= 0
		add(sparse, 2, 1, 2);
		add(sparse, 2, expected_num_params + 2, -1);
		add(sparse, 2, expected_num_vars - 1, -1);
		// 1 vs 1: trivial
		// 11 vs 1: c_2 -slack_4^+ - nu <= 0
		add(sparse, 4, 2, 1);
		add(sparse, 4, expected_num_params + 4, -1);
		add(sparse, 4, expected_num_vars - 1, -1);
		// 111 vs 1: 2*c_2 -slack_5^+ - nu <= 0
		add(sparse, 5, 2, 2);
		add(sparse, 5, expected_num_params + 5, -1);
		add(sparse, 5, expected_num_vars - 1, -1);

		// NEGATIVE CONSTRAINTS
		// 0 vs 1: -c_0 -slack_0^- + nu <= -log(2)
		add(sparse, 6, 0, -1);
		add(sparse, 6, expected_num_params + 6, -1);
		add(sparse, 6, expected_num_vars - 1, +1);
		// 00 vs 1: -c_0 -c_1 -slack_2^- + nu <= -log(2)
		add(sparse, 7, 0, -1);
		add(sparse, 7, 1, -1);
		add(sparse, 7, expected_num_params + 7, -1);
		add(sparse, 7, expected_num_vars - 1, +1);
		// 000 vs 1: -c_0 -2*c_1 -slack_3^- + nu <= -log(2)
		add(sparse, 8, 0, -1);
		add(sparse, 8, 1, -2);
		add(sparse, 8, expected_num_params + 8, -1);
		add(sparse, 8, expected_num_vars - 1, +1);
		// 1 vs 0: -c_0 -slack_4^- + nu <= -log(2)
		add(sparse, 9, 0, -1);
		add(sparse, 9, expected_num_params + 9, -1);
		add(sparse, 9, expected_num_vars - 1, +1);
		// 11 vs 0: -c_0 -c_2 -slack_5^- + nu <= -log(2)
		add(sparse, 10, 0, -1);
		add(sparse, 10, 2, -1);
		add(sparse, 10, expected_num_params + 10, -1);
		add(sparse, 10, expected_num_vars - 1, +1);
		// 111 vs 0: -c_0 -2*c_2 -slack_6^- + nu <= -log(2)
		add(sparse, 11, 0, -1);
		add(sparse, 11, 2, -2);
		add(sparse, 11, expected_num_params + 11, -1);
		add(sparse, 11, expected_num_vars - 1, +1);

		final IndexMatrix expected_A = new IndexMatrix(sparse);
		for (int s = 0; s < expected_A.i.length; s++) {
			assertEquals("Error in " + s + "th sparse constraint matrix entry!", expected_A.i[s], instance.A.i[s]);
			assertEquals("Error in " + s + "th sparse constraint matrix entry!", expected_A.j[s], instance.A.j[s]);
			assertEquals("Error in " + s + "th sparse constraint matrix entry!", expected_A.v[s], instance.A.v[s], 1E-3);
		}

		// check constraint bounds
		final double[] expected_b = new double[expected_num_slacks];
		Arrays.fill(expected_b, m, expected_num_slacks, -Math.log(2));
		assertArrayEquals(expected_b, instance.b, 1E-3);

		// check lower and upper bounds
		final double[] expected_lb = new double[expected_f.length];
		assertArrayEquals(expected_lb, instance.lb, 1E-3);
		final double[] expected_ub = new double[expected_f.length];
		Arrays.fill(expected_ub, Double.POSITIVE_INFINITY);
		expected_ub[expected_ub.length - 1] = Math.log(2);
		assertArrayEquals(expected_ub, instance.ub, 1E-3);

		// solve the linear program and check the result
		final PointValuePair solution = solve(instance);
		// we expect that no error remains
		assertEquals(0, solution.getValue(), 1E-3);
		// we expect that the 0->1 replacement cost is larger than log(2)
		assertTrue(solution.getPoint()[0] >= Math.log(2));
		// the gap costs should be zero
		assertEquals(0, solution.getPoint()[1], 1E-3);
		assertEquals(0, solution.getPoint()[2], 1E-3);
		// the slack variables should be zero
		for (int s = expected_num_params; s < expected_num_params + expected_num_slacks; s++) {
			assertEquals(0, solution.getPoint()[s], 1E-3);
		}
		// nu should be zero as well
		assertEquals(0, solution.getPoint()[solution.getPoint().length - 1], 1E-3);

	}

	private static void add(List<SparseEntry> sparse, int i, int j, double v) {
		sparse.add(new SparseEntry(i, j, v));
	}

}
