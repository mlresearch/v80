/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.comparators;

import de.citec.tcs.alignment.comparators.Gradient;
import de.citec.tcs.alignment.comparators.IndexingFunction;
import de.citec.tcs.alignment.comparators.OperationType;
import de.citec.tcs.alignment.trees.Tree;
import de.citec.tcs.alignment.trees.TreeImpl;
import java.util.Arrays;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class VectorEmbeddingComparatorTest {

	public VectorEmbeddingComparatorTest() {
	}

	@BeforeClass
	public static void setUpClass() {
	}

	@AfterClass
	public static void tearDownClass() {
	}

	@Before
	public void setUp() {
	}

	@After
	public void tearDown() {
	}

	/**
	 * Test of defaultEmbedding method, of class VectorEmbeddingComparator.
	 */
	@Test
	public void testDefaultEmbedding() {
		final int m = 10;
		final double[][] Theta = VectorEmbeddingComparator.defaultEmbedding(m);

		for (int i = 0; i < m; i++) {
			assertEquals(1., VectorEmbeddingComparator.norm(Theta[i]), 1E-3);
			for (int j = i + 1; j < m; j++) {
				assertEquals(1, VectorEmbeddingComparator.distance(Theta[i], Theta[j]), 1E-3);
			}
		}

	}

	/**
	 * Test of compare method, of class VectorEmbeddingComparator.
	 */
	@Test
	public void testCompare() {
		final double[][] Theta = {
			{0, 0, 0},
			{1, 0, 0},
			{0, 1, 0},
			{0, 1, 1}
		};

		final VectorEmbeddingComparator instance = new VectorEmbeddingComparator(Theta);

		for (int i = 0; i < Theta.length; i++) {
			assertEquals(0., instance.compare(OperationType.REPLACEMENT, i, i), 0);
			assertEquals(VectorEmbeddingComparator.norm(Theta[i]), instance.compare(OperationType.DELETION, i, null), 1E-3);
			assertEquals(VectorEmbeddingComparator.norm(Theta[i]), instance.compare(OperationType.INSERTION, null, i), 1E-3);
			for (int j = i + 1; j < Theta.length; j++) {
				assertEquals(VectorEmbeddingComparator.distance(Theta[i], Theta[j]), instance.compare(OperationType.REPLACEMENT, i, j), 0);
				assertEquals(VectorEmbeddingComparator.distance(Theta[j], Theta[i]), instance.compare(OperationType.REPLACEMENT, j, i), 0);
			}
		}

	}

	/**
	 * Test of distance method, of class VectorEmbeddingComparator.
	 */
	@Test
	public void testDistance() {
		assertEquals(1, VectorEmbeddingComparator.distance(new double[]{1}, new double[]{0}), 1E-3);
		assertEquals(1, VectorEmbeddingComparator.distance(new double[]{0}, new double[]{1}), 1E-3);
		assertEquals(1, VectorEmbeddingComparator.distance(new double[]{1, 0, 1}, new double[]{1, 0, 0}), 1E-3);
		assertEquals(1, VectorEmbeddingComparator.distance(new double[]{1, 0, 0}, new double[]{1, 0, 1}), 1E-3);
		assertEquals(Math.sqrt(2), VectorEmbeddingComparator.distance(new double[]{0, 0, 1, 0}, new double[]{1, 0, 0, 0}), 1E-3);
		assertEquals(Math.sqrt(2), VectorEmbeddingComparator.distance(new double[]{1, 0, 0, 0}, new double[]{0, 0, 1, 0}), 1E-3);
		assertEquals(1., VectorEmbeddingComparator.distance(new double[]{0, 0.5, 0.5, 0}, new double[]{0.5, 1, 1, 0.5}), 1E-3);
		assertEquals(1., VectorEmbeddingComparator.distance(new double[]{0.5, 1, 1, 0.5}, new double[]{0, 0.5, 0.5, 0}), 1E-3);
		assertEquals(1, VectorEmbeddingComparator.distance(new double[]{0, -0.5, 0}, new double[]{0, 0.5, 0}), 1E-3);
		assertEquals(1, VectorEmbeddingComparator.distance(new double[]{0, 0.5, 0}, new double[]{0, -0.5, 0}), 1E-3);
	}

	/**
	 * Test of norm method, of class VectorEmbeddingComparator.
	 */
	@Test
	public void testNorm() {
		assertEquals(1, VectorEmbeddingComparator.norm(new double[]{1}), 1E-3);
		assertEquals(1, VectorEmbeddingComparator.norm(new double[]{0, 0, 1}), 1E-3);
		assertEquals(1, VectorEmbeddingComparator.norm(new double[]{0, 0, 1, 0}), 1E-3);
		assertEquals(Math.sqrt(2), VectorEmbeddingComparator.distance(new double[]{1, 0, 1, 0}, new double[4]), 1E-3);
		assertEquals(Math.sqrt(2), VectorEmbeddingComparator.distance(new double[]{-1, 0, -1, 0}, new double[4]), 1E-3);
	}

	private static void assertGradientEquals(final double[] expected, final int[] expected_idxs, Gradient grad) {
		int k = 0;
		while (grad.notEmpty()) {
			assertTrue(k < expected.length);
			assertEquals(expected_idxs[k], grad.currentParameterIndex());
			assertEquals(expected[k], grad.currentValue(), 1E-3);
			grad.next();
			k++;
		}
		assertEquals(k, expected.length);
	}

	/**
	 * Test of computeGradient method, of class VectorEmbeddingComparator.
	 */
	@Test
	public void testComputeGradient() {

		final double[][] Theta = {
			{0, 0},
			{1, 0},
			{0, 1}
		};

		final VectorEmbeddingComparator instance = new VectorEmbeddingComparator(Theta);

		// check self-replacement, deletion and insertion gradient
		assertGradientEquals(new double[0], new int[0], instance.computeGradient(OperationType.REPLACEMENT, 0, 0));
		assertGradientEquals(new double[0], new int[0], instance.computeGradient(OperationType.DELETION, 0, null));
		assertGradientEquals(new double[0], new int[0], instance.computeGradient(OperationType.INSERTION, null, 0));
		for (int i = 1; i < Theta.length; i++) {
			assertGradientEquals(new double[0], new int[0], instance.computeGradient(OperationType.REPLACEMENT, i, i));
			assertGradientEquals(Arrays.copyOf(Theta[i], 2), new int[]{i * 2, i * 2 + 1}, instance.computeGradient(OperationType.DELETION, i, null));
			assertGradientEquals(Arrays.copyOf(Theta[i], 2), new int[]{i * 2, i * 2 + 1}, instance.computeGradient(OperationType.INSERTION, null, i));
		}
		// then check some replacement gradients
		assertGradientEquals(new double[]{-1, 0, 1, 0}, new int[]{0, 1, 2, 3}, instance.computeGradient(OperationType.REPLACEMENT, 0, 1));
		assertGradientEquals(new double[]{1, 0, -1, 0}, new int[]{2, 3, 0, 1}, instance.computeGradient(OperationType.REPLACEMENT, 1, 0));
		assertGradientEquals(new double[]{0, -1, 0, 1}, new int[]{0, 1, 4, 5}, instance.computeGradient(OperationType.REPLACEMENT, 0, 2));
		assertGradientEquals(new double[]{0, 1, 0, -1}, new int[]{4, 5, 0, 1}, instance.computeGradient(OperationType.REPLACEMENT, 2, 0));
		final double invsqrt2 = 1. / Math.sqrt(2);
		assertGradientEquals(new double[]{invsqrt2, -invsqrt2, -invsqrt2, invsqrt2}, new int[]{2, 3, 4, 5},
				instance.computeGradient(OperationType.REPLACEMENT, 1, 2));
		assertGradientEquals(new double[]{-invsqrt2, invsqrt2, invsqrt2, -invsqrt2}, new int[]{4, 5, 2, 3},
				instance.computeGradient(OperationType.REPLACEMENT, 2, 1));
	}

	/**
	 * Test of vectorToMatrix method, of class VectorEmbeddingComparator.
	 */
	@Test
	public void testVectorToMatrix() {
		final double[] thetas = {1, 0, 0, 2, 3, 0, 4, 5, 6};

		final double[][] expected = {{1, 0, 0}, {2, 3, 0}, {4, 5, 6}};
		final double[][] actual = VectorEmbeddingComparator.vectorToMatrix(thetas, expected.length);

		for (int i = 0; i < expected.length; i++) {
			assertArrayEquals(expected[i], actual[i], 1E-8);
		}
	}

	/**
	 * Test of matrixToVector method, of class VectorEmbeddingComparator.
	 */
	@Test
	public void testMatrixToVector() {
		final double[][] Theta = {{1, 0, 0}, {2, 3, 0}, {4, 5, 6}};
		final double[] expected = {1, 0, 0, 2, 3, 0, 4, 5, 6};

		assertArrayEquals(expected, VectorEmbeddingComparator.matrixToVector(Theta), 1E-8);
	}

	/**
	 * Test of indexTree method, of class VectorEmbeddingComparator.
	 */
	@Test
	public void testIndexTree() {
		final Tree<String> tree = TreeImpl.builder("A").node("B").nodeAndDesc("C").node("A").getTree();

		final IndexingFunction<String> idxFun = new SetIndexingFunction<>("B", "A", "C");

		final Tree<Integer> expected = TreeImpl.builder(1).node(0).nodeAndDesc(2).node(1).getTree();

		assertEquals(expected, VectorEmbeddingComparator.indexTree(tree, idxFun));
	}

}
