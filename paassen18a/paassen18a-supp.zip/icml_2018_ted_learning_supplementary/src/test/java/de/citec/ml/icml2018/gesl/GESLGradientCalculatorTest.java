/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.gesl;

import de.citec.ml.icml2018.comparators.CosineDistanceComparator;
import de.citec.ml.icml2018.lmnn.KNNClassifier;
import de.citec.tcs.alignment.trees.DerivableLabelComparator;
import de.citec.tcs.alignment.trees.Tree;
import de.citec.tcs.alignment.trees.TreeEditFullAlgorithm;
import de.citec.tcs.alignment.trees.TreeEditScoreAlgorithm;
import de.citec.tcs.alignment.trees.TreeImpl;
import de.citec.tcs.alignment.trees.TreeSquareParallelProcessingEngine;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class GESLGradientCalculatorTest {

	public GESLGradientCalculatorTest() {
	}

	@BeforeClass
	public static void setUpClass() {
	}

	@AfterClass
	public static void tearDownClass() {
	}

	@Before
	public void setUp() {
	}

	@After
	public void tearDown() {
	}

	private static double nn_classification_error(int K, double[][] D, int[] Y_train, int[] Y_test) {
		final int[] prediction = KNNClassifier.predict(D, Y_train, K);
		int num_wrong = 0;
		for (int i = 0; i < Y_test.length; i++) {
			if (Y_test[i] != prediction[i]) {
				num_wrong++;
			}
		}
		return (double) num_wrong / Y_test.length;
	}

	/**
	 * Test of computeErrorAndGradient method, of class GESLGradientCalculator.
	 */
	@Test
	public void testMetricLearning() {

		// generate a very simple and well-controlled 2D data set with only four points:
		// (-1, -10) and (-1, 10) for class -1 and (1,-10), (1, 10) for class 2.
		// The initial configuration ensures that the nearest neighbor that is not the data point
		// itself is wrong.
		final double[][] X_labels = {
			{-1, -10},
			{-1, 10},
			{1, -10},
			{1, 10}
		};
		final int[] Y = {-1, -1, 1, 1};

		final int m = X_labels.length;
		final List<Tree<double[]>> X = new ArrayList<>(m);
		for (int i = 0; i < m; i++) {
			X.add(new TreeImpl<>(X_labels[i]));
		}
		// set up alignment algorithm
		final CosineDistanceComparator comp = new CosineDistanceComparator(2);
		final DerivableLabelComparator compWrap = new DerivableLabelComparator<>(comp);
		final TreeEditScoreAlgorithm<double[], double[]> scoreAlgo = new TreeEditScoreAlgorithm<>(compWrap);
		final TreeEditFullAlgorithm<double[], double[]> algo = new TreeEditFullAlgorithm<>(compWrap);
		// compute initial distance matrix
		final TreeSquareParallelProcessingEngine<double[], Double> engine = new TreeSquareParallelProcessingEngine<>(scoreAlgo, X);
		engine.setFull();
		engine.setReporter(null);
		engine.calculate();
		double[][] D = engine.getDoubleResultMatrix();
		// set up instance
		final GESLGradientCalculator instance = GESLGradientCalculator.fromTreeEditAlgorithm(D, Y, algo, X, 1, 16);

		instance.setRegularization(0);
		instance.setReporter(null);
		// perform gradient descent
		final double eta = 1;
		final int T = 20;
		final double[] err = new double[T];
		final double[] params = comp.getParameters();
		for (int t = 0; t < T; t++) {
			// compute error and gradient
			final double[] err_and_grad = instance.computeErrorAndGradient(compWrap);
			if (t > 0) {
				assertTrue(err_and_grad[0] < err[t - 1] + 1E-3);
			}
			err[t] = err_and_grad[0];
			// do a gradient step
			for (int j = 0; j < params.length; j++) {
				params[j] -= eta * err_and_grad[j + 1];
			}
			comp.setParameters(params);
		}

		assertTrue(params[1] < 1);
		assertTrue(params[2] < 1);
		assertTrue(params[3] < 1);
		assertTrue(params[0] > 1);
		assertTrue(params[0] > 1.5 * params[3]);
	}

}
