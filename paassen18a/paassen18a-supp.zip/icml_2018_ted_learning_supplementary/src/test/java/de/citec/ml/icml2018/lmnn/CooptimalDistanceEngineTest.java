/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.lmnn;

import de.citec.tcs.alignment.comparators.IndexingFunction;
import de.citec.tcs.alignment.comparators.SquareReplacementMatrixComparator;
import de.citec.tcs.alignment.trees.CooptimalMatrix;
import de.citec.tcs.alignment.trees.LabelComparator;
import de.citec.tcs.alignment.trees.Tree;
import de.citec.tcs.alignment.trees.TreeEditCooptimalAlgorithm;
import de.citec.tcs.alignment.trees.TreeEditScoreAlgorithm;
import de.citec.tcs.alignment.trees.TreeImpl;
import java.util.Arrays;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class CooptimalDistanceEngineTest {

	public CooptimalDistanceEngineTest() {
	}

	@BeforeClass
	public static void setUpClass() {
	}

	@AfterClass
	public static void tearDownClass() {
	}

	@Before
	public void setUp() {
	}

	@After
	public void tearDown() {
	}

	/**
	 * Test of createCallable method, of class CooptimalDistanceEngine.
	 */
	@Test
	public void testCreateCallable() {
		// create simple example data with three trees, namely A, B(C) and C.
		final Tree<Character> X = new TreeImpl<>('A');
		final Tree<Character> Y = TreeImpl.builder('B').node('C').getTree();
		final Tree<Character> Z = new TreeImpl<>('C');
		final List<Tree<Character>> data = Arrays.asList(X, Y, Z);

		// set up a comparator for this data
		final IndexingFunction<Character> idx = new IndexingFunction<Character>() {

			@Override
			public int index(Character c) {
				switch (c) {
					case 'A':
						return 0;
					case 'B':
						return 1;
					case 'C':
						return 2;
					default:
						throw new IllegalArgumentException("illegal argument: " + c);
				}
			}

			@Override
			public int range() {
				return 3;
			}
		};
		final SquareReplacementMatrixComparator<Character> comp = new SquareReplacementMatrixComparator<>(idx);
		final LabelComparator<Character, Character> wrapComp = new LabelComparator<>(comp);
		// compute all pairwise distances and all pairwise cooptimals
		final TreeEditScoreAlgorithm<Character, Character> scoreAlgo = new TreeEditScoreAlgorithm<>(wrapComp);
		final TreeEditCooptimalAlgorithm<Character, Character> cooptAlgo = new TreeEditCooptimalAlgorithm<>(wrapComp);
		final CooptimalMatrix[][] coopts = new CooptimalMatrix[data.size()][data.size()];
		final double[][] D_expected = new double[data.size()][data.size()];
		for (int i = 0; i < data.size(); i++) {
			for (int j = 0; j < data.size(); j++) {
				D_expected[i][j] = scoreAlgo.calculateAlignment(data.get(i), data.get(j));
				coopts[i][j] = cooptAlgo.calculateAlignment(data.get(i), data.get(j));
			}
		}
		// check whether the CooptimalDistanceEngine yields the same result as the score algorithm
		final CooptimalDistanceEngine<Tree<Character>, Tree<Character>> instance = new CooptimalDistanceEngine<>(coopts, wrapComp);
		instance.setFull();
		instance.setReporter(null);
		instance.calculate();
		final double[][] D_actual = instance.getDoubleResultMatrix();

		for (int i = 0; i < data.size(); i++) {
			for (int j = 0; j < data.size(); j++) {
				assertEquals(D_expected[i][j], D_actual[i][j], 1E-4);
			}
		}

	}

}
