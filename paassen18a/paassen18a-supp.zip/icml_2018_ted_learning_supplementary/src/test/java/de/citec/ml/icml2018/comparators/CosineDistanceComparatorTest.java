/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.comparators;

import de.citec.ml.icml2018.lmnn.KNNClassifier;
import de.citec.tcs.alignment.comparators.Gradient;
import de.citec.tcs.alignment.comparators.OperationType;
import java.util.Arrays;
import java.util.Random;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class CosineDistanceComparatorTest {

	public CosineDistanceComparatorTest() {
	}

	@BeforeClass
	public static void setUpClass() {
	}

	@AfterClass
	public static void tearDownClass() {
	}

	@Before
	public void setUp() {
	}

	@After
	public void tearDown() {
	}

	/**
	 * Test of compare method, of class CosineDistanceComparator.
	 */
	@Test
	public void testCompare() {

		CosineDistanceComparator instance = new CosineDistanceComparator(1);
		for (double x : new double[]{0.5, 1, 2}) {
			assertEquals(0.5, instance.compare(OperationType.REPLACEMENT, new double[]{x}, new double[]{0}), 1E-3);
			assertEquals(0.5, instance.compare(OperationType.DELETION, new double[]{x}, null), 1E-3);
			assertEquals(0.5, instance.compare(OperationType.REPLACEMENT, new double[]{0}, new double[]{x}), 1E-3);
			assertEquals(0.5, instance.compare(OperationType.INSERTION, null, new double[]{x}), 1E-3);
			for (double y : new double[]{0.5, 1, 2}) {
				assertEquals(0, instance.compare(OperationType.REPLACEMENT, new double[]{x}, new double[]{y}), 1E-3);
				assertEquals(1, instance.compare(OperationType.REPLACEMENT, new double[]{-x}, new double[]{y}), 1E-3);
			}
		}

		instance = new CosineDistanceComparator(new double[][]{{0, 1, 0}, {1, 0, 0}});
		assertEquals(0, instance.compare(OperationType.REPLACEMENT, new double[]{0, 0, 0}, new double[]{0, 0, 0}), 1E-3);
		assertEquals(0, instance.compare(OperationType.REPLACEMENT, new double[]{1, 1, 1}, new double[]{1, 1, 1}), 1E-3);
		assertEquals(0, instance.compare(OperationType.REPLACEMENT, new double[]{1, 1, 1}, new double[]{1, 1, 0}), 1E-3);
		assertEquals(0.5 - 0.5 * Math.cos(0.25 * Math.PI), instance.compare(OperationType.REPLACEMENT, new double[]{1, 0, 1}, new double[]{1, 1, 0}), 1E-3);
		assertEquals(0.5, instance.compare(OperationType.REPLACEMENT, new double[]{1, 0, 1}, new double[]{0, 1, 0}), 1E-3);
		assertEquals(0.5 - 0.5 * Math.cos(0.75 * Math.PI), instance.compare(OperationType.REPLACEMENT, new double[]{1, 0, 1}, new double[]{-1, 1, 0}), 1E-3);
		assertEquals(1, instance.compare(OperationType.REPLACEMENT, new double[]{1, 0, 1}, new double[]{-1, 0, 0}), 1E-3);

		// test two large input vectors
		final int dim_tar = 10;
		final int dim_src = 300;
		instance = new CosineDistanceComparator(dim_tar, dim_src);
		final double[] x = new double[dim_src];
		final double[] y = new double[dim_src];
		for (int i = 0; i < dim_src; i++) {
			x[i] = i;
			y[i] = 0.1 * i;
		}
		assertEquals(0, instance.compare(OperationType.REPLACEMENT, x, y), 1E-3);
	}

	private static void assertGradient(double[] expected, Gradient actual) {
		for (int j = 0; j < expected.length; j++) {
			assertEquals(j, actual.currentParameterIndex());
			assertEquals(expected[j], actual.currentValue(), 1E-3);
			actual.next();
		}
		assertFalse(actual.notEmpty());
	}

	/**
	 * Test of computeGradient method, of class CosineDistanceComparator.
	 */
	@Test
	public void testComputeGradient() {

		final CosineDistanceComparator instance = new CosineDistanceComparator(2);
		// check a few cases for which we expect empty gradients
		for (double x : new double[]{-2, -1, -0.5, 0, 0.5, 1, 2}) {
			for (double y : new double[]{-2, -1, -0.5, 0, 0.5, 1, 2}) {
				assertFalse(instance.computeGradient(OperationType.REPLACEMENT, new double[]{x, y}, new double[]{0, 0}).notEmpty());
				assertFalse(instance.computeGradient(OperationType.DELETION, new double[]{x, y}, null).notEmpty());
				assertFalse(instance.computeGradient(OperationType.REPLACEMENT, new double[]{0, 0}, new double[]{x, y}).notEmpty());
				assertFalse(instance.computeGradient(OperationType.INSERTION, null, new double[]{x, y}).notEmpty());
				assertFalse(instance.computeGradient(OperationType.REPLACEMENT, new double[]{x, y}, new double[]{x * x, x * y}).notEmpty());
			}
		}
		// then check a few cases where we expect a nonzero result
		assertGradient(new double[]{0, -0.5, -0.5, 0}, instance.computeGradient(OperationType.REPLACEMENT, new double[]{1, 0}, new double[]{0, 1}));
		assertGradient(new double[]{0, -0.5, -0.5, 0}, instance.computeGradient(OperationType.REPLACEMENT, new double[]{-1, 0}, new double[]{0, -1}));
		assertGradient(new double[]{0, 0.5, 0.5, 0}, instance.computeGradient(OperationType.REPLACEMENT, new double[]{-1, 0}, new double[]{0, 1}));
		assertGradient(new double[]{0, 0.5, 0.5, 0}, instance.computeGradient(OperationType.REPLACEMENT, new double[]{1, 0}, new double[]{0, -1}));
	}

	/**
	 * Test of vectorToMatrix method, of class CosineDistanceComparator.
	 */
	@Test
	public void testVectorToMatrix() {
		final double[] omega = {1, 2, 3, 4, 5, 6};
		final double[][] Omega = {{1, 2, 3}, {4, 5, 6}};
		final double[][] actual = CosineDistanceComparator.vectorToMatrix(omega, 3);
		assertTrue(Arrays.deepEquals(Omega, actual));
	}

	/**
	 * Test of matrixToVector method, of class CosineDistanceComparator.
	 */
	@Test
	public void testMatrixToVector() {
		final double[] omega = {1, 2, 3, 4, 5, 6};
		final double[][] Omega = {{1, 2, 3}, {4, 5, 6}};
		final double[] actual = CosineDistanceComparator.matrixToVector(Omega);
		assertArrayEquals(omega, actual, 1E-8);
	}

	private static double nn_classification_error(int K, double[][] D, int[] Y_train, int[] Y_test) {
		final int[] prediction = KNNClassifier.predict(D, Y_train, K);
		int num_wrong = 0;
		for (int i = 0; i < Y_test.length; i++) {
			if (Y_test[i] != prediction[i]) {
				num_wrong++;
			}
		}
		return (double) num_wrong / Y_test.length;
	}

	@Test
	public void testMetricLearning() {
		// generate two-dimensional vectors with huge spread in a non-discriminative direction
		// and little spread in a discriminative direction
		final Random rand = new Random();
		final int m = 100;
		final double sigma_0 = 0.2;
		final double sigma_1 = 20;
		final double[][] X = new double[m][2];
		final int[] Y = new int[m];
		for (int i = 0; i < m; i++) {
			Y[i] = i < m / 2 ? -1 : 1;
			X[i][0] = rand.nextGaussian() * sigma_0 + Y[i];
			X[i][1] = rand.nextGaussian() * sigma_1;
		}
		// evaluate initial distance matrix and classification error
		final CosineDistanceComparator instance = new CosineDistanceComparator(2);
		final int K = 3;
		final double[][] D = new double[m][m];
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < m; j++) {
				D[i][j] = instance.compare(OperationType.REPLACEMENT, X[i], X[j]);
			}
		}
		final double pre_error = nn_classification_error(K, D, Y, Y);

		// perform metric learning using the sum of intra-class distances minus the sum of the
		// inter-class distances
		final double eta = 0.5 / (m * m);
		final int T = 20;
		final double[] err = new double[T];
		final double[] params = instance.getParameters();
		for (int t = 0; t < T; t++) {
			// compute error and gradient
			final double[] grad = new double[params.length];
			for (int i = 0; i < m; i++) {
				for (int j = 0; j < m; j++) {
					err[t] += Y[i] * Y[j] * instance.compare(OperationType.REPLACEMENT, X[i], X[j]);
					final Gradient grad_ij = instance.computeGradient(OperationType.REPLACEMENT, X[i], X[j]);
					while (grad_ij.notEmpty()) {
						grad[grad_ij.currentParameterIndex()] += Y[i] * Y[j] * grad_ij.currentValue();
						grad_ij.next();
					}
				}
			}
			if (t > 0) {
				assertTrue(err[t] < err[t - 1] + 1E-3);
			}
			// do a gradient step
			for (int l = 0; l < grad.length; l++) {
				params[l] -= eta * grad[l];
			}
			instance.setParameters(params);
		}
		// check classification error again
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < m; j++) {
				D[i][j] = instance.compare(OperationType.REPLACEMENT, X[i], X[j]);
			}
		}
		final double post_error = nn_classification_error(K, D, Y, Y);
		assertTrue(post_error <= pre_error);
		assertTrue(params[1] < 1);
		assertTrue(params[2] < 1);
		assertTrue(params[3] < 1);
		assertTrue(params[0] > 1);
		assertTrue(params[0] > 1.1 * params[3]);
	}
}
