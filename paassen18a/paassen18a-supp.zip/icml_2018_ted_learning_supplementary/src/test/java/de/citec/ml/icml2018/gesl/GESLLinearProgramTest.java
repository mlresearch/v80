/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.gesl;

import de.citec.tcs.alignment.comparators.TrivialEditComparator;
import de.citec.tcs.alignment.trees.LabelComparator;
import de.citec.tcs.alignment.trees.Tree;
import de.citec.tcs.alignment.trees.TreeEditFullAlgorithm;
import de.citec.tcs.alignment.trees.TreeEditScoreAlgorithm;
import de.citec.tcs.alignment.trees.TreeImpl;
import de.citec.tcs.alignment.trees.TreeSquareParallelProcessingEngine;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math3.optim.PointValuePair;
import org.apache.commons.math3.optim.linear.LinearConstraint;
import org.apache.commons.math3.optim.linear.LinearConstraintSet;
import org.apache.commons.math3.optim.linear.LinearObjectiveFunction;
import org.apache.commons.math3.optim.linear.Relationship;
import org.apache.commons.math3.optim.linear.SimplexSolver;
import org.apache.commons.math3.optim.nonlinear.scalar.GoalType;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Benjamin Paassen - bpaassen@techfak.uni-bielefeld.de
 */
public class GESLLinearProgramTest {

	public GESLLinearProgramTest() {
	}

	@BeforeClass
	public static void setUpClass() {
	}

	@AfterClass
	public static void tearDownClass() {
	}

	@Before
	public void setUp() {
	}

	@After
	public void tearDown() {
	}

	/**
	 * Solves a GESLLinearProgram using the apache commons implementation of the Simplex algorithm.
	 *
	 * @param prog
	 * @return
	 */
	private static PointValuePair solve(GESLLinearProgram prog) {
		// wrap objective function
		final LinearObjectiveFunction objective = new LinearObjectiveFunction(prog.f, 0);
		// transform inequality constraints
		final double[][] A = new double[prog.b.length][prog.f.length];
		for (int s = 0; s < prog.A.i.length; s++) {
			A[prog.A.i[s]][prog.A.j[s]] = prog.A.v[s];
		}
		final ArrayList<LinearConstraint> constraints = new ArrayList<>();
		for (int i = 0; i < prog.b.length; i++) {
			constraints.add(new LinearConstraint(A[i], Relationship.LEQ, prog.b[i]));
		}
		// transform lower bounds
		for (int i = 0; i < prog.lb.length; i++) {
			final double[] e_i = new double[prog.lb.length];
			e_i[i] = 1;
			constraints.add(new LinearConstraint(e_i, Relationship.GEQ, 0));
		}
		// transform the upper bound for nu.
		final double[] e_R = new double[prog.lb.length];
		e_R[e_R.length - 1] = 1;
		constraints.add(new LinearConstraint(e_R, Relationship.LEQ, Math.log(2)));
		// solve
		return new SimplexSolver().optimize(objective, new LinearConstraintSet(constraints), GoalType.MINIMIZE);
	}

	/**
	 * Test of initialize method, of class GESLLinearProgram.
	 */
	@Test
	public void testInitialize() {
		// we use a very simple example with three single-letter trees
		final List<Tree<Integer>> data = new ArrayList<>();
		data.add(new TreeImpl<>(0));
		data.add(new TreeImpl<>(1));
		data.add(new TreeImpl<>(2));
		data.add(new TreeImpl<>(2));
		final int[] Y = {1, 1, 2, 2};
		final TrivialEditComparator<Integer> comp = new TrivialEditComparator<>();
		final TreeEditFullAlgorithm<Integer, Integer> full_algo = new TreeEditFullAlgorithm<>(new LabelComparator<>(comp));
		final TreeEditScoreAlgorithm<Integer, Integer> score_algo = new TreeEditScoreAlgorithm<>(new LabelComparator<>(comp));
		final TreeSquareParallelProcessingEngine<Integer, Double> engine = new TreeSquareParallelProcessingEngine<>(score_algo, data);
		engine.setReporter(null);
		engine.setFull();
		engine.calculate();
		final double[][] D = engine.getDoubleResultMatrix();

		final GESLLinearProgram instance = GESLLinearProgram.fromTreeEditAlgorithm(D, Y, full_algo, data, 3, 1, 16);

		// check the resulting linear program
		// we have 1 + 2 + 3 = 6 parameters, 2*4 = 8 slack variables and the shift variable nu.
		final double[] expected_f = {0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0};
		assertArrayEquals(expected_f, instance.f, 1E-3);

		final ArrayList<GESLLinearProgram.SparseEntry> sparse = new ArrayList<>();
		// slack_1^+ >= C[0, 1] - nu
		add(sparse, 0, 0, 1);
		add(sparse, 0, 6, -1);
		add(sparse, 0, 14, -1);
		// slack_2^+ >= C[1, 0] - nu
		add(sparse, 1, 0, 1);
		add(sparse, 1, 7, -1);
		add(sparse, 1, 14, -1);
		// slack_3^+ >= C[2, 2] - nu
		add(sparse, 2, 8, -1);
		add(sparse, 2, 14, -1);
		// slack_4^+ >= C[2, 2] - nu
		add(sparse, 3, 9, -1);
		add(sparse, 3, 14, -1);
		// slack_1^- >= log(2) - C[0, 2] + nu
		add(sparse, 4, 1, -1);
		add(sparse, 4, 10, -1);
		add(sparse, 4, 14, 1);
		// slack_2^- >= log(2) - C[1, 2] + nu
		add(sparse, 5, 2, -1);
		add(sparse, 5, 11, -1);
		add(sparse, 5, 14, 1);
		// slack_3^- >= log(2) - C[0, 2] + nu
		add(sparse, 6, 1, -1);
		add(sparse, 6, 12, -1);
		add(sparse, 6, 14, 1);
		// slack_4^- >= log(2) - C[0, 2] + nu
		add(sparse, 7, 1, -1);
		add(sparse, 7, 13, -1);
		add(sparse, 7, 14, 1);

		final GESLLinearProgram.IndexMatrix expected_A = new GESLLinearProgram.IndexMatrix(sparse);
		assertEquals(expected_A, instance.A);

		final double[] expected_b = {0, 0, 0, 0, -Math.log(2), -Math.log(2), -Math.log(2), -Math.log(2)};
		assertArrayEquals(expected_b, instance.b, 1E-3);

		final double[] expected_lb = new double[expected_f.length];
		assertArrayEquals(expected_lb, instance.lb, 1E-3);
		final double[] expected_ub = new double[expected_f.length];
		Arrays.fill(expected_ub, Double.POSITIVE_INFINITY);
		expected_ub[expected_ub.length - 1] = Math.log(2);
		assertArrayEquals(expected_ub, instance.ub, 1E-3);

		// solve the linear program and check the result
		final PointValuePair solution = solve(instance);
		// we expect that no error remains
		assertEquals(0, solution.getValue(), 1E-3);
		// we expect that the 0->1 replacement cost is zero
		assertEquals(0, solution.getPoint()[0], 1E-3);
		// the 0->2 and 1->2 replacement cost should be at least log(2)
		assertTrue(solution.getPoint()[1] >= Math.log(2));
		assertTrue(solution.getPoint()[2] >= Math.log(2));
		// the gap costs don't matter.
		// the slack variables should be zero
		for (int s = 6; s < 6 + 2 * 4; s++) {
			assertEquals(0, solution.getPoint()[s], 1E-3);
		}
		// nu should be zero as well
		assertEquals(0, solution.getPoint()[solution.getPoint().length - 1], 1E-3);

	}

	/**
	 * Test of initialize method, of class GESLLinearProgram.
	 */
	@Test
	public void testInitialize2() {
		// we use a very simple example with six trees in two classes using only two letters
		final List<Tree<Integer>> data = new ArrayList<>();
		data.add(TreeImpl.builder(0).getTree());
		data.add(TreeImpl.builder(0).nodeAndDesc(0).getTree());
		data.add(TreeImpl.builder(0).nodeAndDesc(0).nodeAndDesc(0).getTree());
		data.add(TreeImpl.builder(1).getTree());
		data.add(TreeImpl.builder(1).nodeAndDesc(1).getTree());
		data.add(TreeImpl.builder(1).nodeAndDesc(1).nodeAndDesc(1).getTree());
		final int[] Y = {1, 1, 1, 2, 2, 2};
		final TrivialEditComparator<Integer> comp = new TrivialEditComparator<>();
		final TreeEditFullAlgorithm<Integer, Integer> full_algo = new TreeEditFullAlgorithm<>(new LabelComparator<>(comp));
		final TreeEditScoreAlgorithm<Integer, Integer> score_algo = new TreeEditScoreAlgorithm<>(new LabelComparator<>(comp));
		final TreeSquareParallelProcessingEngine<Integer, Double> engine = new TreeSquareParallelProcessingEngine<>(score_algo, data);
		engine.setReporter(null);
		engine.setFull();
		engine.calculate();
		final double[][] D = engine.getDoubleResultMatrix();

		final int n = 2;
		final int K = 2;
		final int m = data.size();

		final GESLLinearProgram instance = GESLLinearProgram.fromTreeEditAlgorithm(D, Y, full_algo, data, n, K, 16);

		// Check the resulting linear program
		// we have 1 + 2 = 3 parameters, 2*2*6 = 24 slack variables and the shift variable nu.
		final int expected_num_params = (n * (n + 1)) / 2;
		final int expected_num_slacks = 2 * K * m;
		final int expected_num_vars = expected_num_params + expected_num_slacks + 1;
		final double[] expected_f = new double[expected_num_vars];
		// only the slack variables should be considered in the objective function
		for (int s = expected_num_params; s < expected_num_params + expected_num_slacks; s++) {
			expected_f[s] = 1;
		}
		assertArrayEquals(expected_f, instance.f, 1E-3);

		// check the constraint matrix
		// note that C[0, 1] = C[1, 0] = c_0,
		// C[0, 2] = C[2, 0] = c_1, and
		// C[1, 2] = C[2, 1] = c_2.
		final ArrayList<GESLLinearProgram.SparseEntry> sparse = new ArrayList<>();

		// POSITIVE CONSTRAINTS
		// 0 vs 00: c_1 -slack_1,1^+ - nu <= 0
		add(sparse, 0, 1, 1);
		add(sparse, 0, expected_num_params + 0, -1);
		add(sparse, 0, expected_num_vars - 1, -1);
		// 0 vs 000: 2*c_1 -slack_1,2^+ - nu <= 0
		add(sparse, 1, 1, 2);
		add(sparse, 1, expected_num_params + 1, -1);
		add(sparse, 1, expected_num_vars - 1, -1);
		// 00 vs 0: c_1 -slack_2,1^+ - nu <= 0
		add(sparse, 2, 1, 1);
		add(sparse, 2, expected_num_params + 2, -1);
		add(sparse, 2, expected_num_vars - 1, -1);
		// 00 vs 000: c_1 -slack_2,1^+ - nu <= 0
		add(sparse, 3, 1, 1);
		add(sparse, 3, expected_num_params + 3, -1);
		add(sparse, 3, expected_num_vars - 1, -1);
		// 000 vs 00: c_1 -slack_3,1^+ - nu <= 0
		add(sparse, 4, 1, 1);
		add(sparse, 4, expected_num_params + 4, -1);
		add(sparse, 4, expected_num_vars - 1, -1);
		// 000 vs 0: 2*c_1 -slack_3,1^+ - nu <= 0
		add(sparse, 5, 1, 2);
		add(sparse, 5, expected_num_params + 5, -1);
		add(sparse, 5, expected_num_vars - 1, -1);
		// 1 vs 11: c_2 -slack_4,1^+ - nu <= 0
		add(sparse, 6, 2, 1);
		add(sparse, 6, expected_num_params + 6, -1);
		add(sparse, 6, expected_num_vars - 1, -1);
		// 1 vs 111: 2*c_2 -slack_4,1^+ - nu <= 0
		add(sparse, 7, 2, 2);
		add(sparse, 7, expected_num_params + 7, -1);
		add(sparse, 7, expected_num_vars - 1, -1);
		// 11 vs 1: c_2 -slack_4,1^+ - nu <= 0
		add(sparse, 8, 2, 1);
		add(sparse, 8, expected_num_params + 8, -1);
		add(sparse, 8, expected_num_vars - 1, -1);
		// 11 vs 111: c_2 -slack_4,1^+ - nu <= 0
		add(sparse, 9, 2, 1);
		add(sparse, 9, expected_num_params + 9, -1);
		add(sparse, 9, expected_num_vars - 1, -1);
		// 111 vs 11: c_2 -slack_4,1^+ - nu <= 0
		add(sparse, 10, 2, 1);
		add(sparse, 10, expected_num_params + 10, -1);
		add(sparse, 10, expected_num_vars - 1, -1);
		// 111 vs 1: 2*c_2 -slack_4,1^+ - nu <= 0
		add(sparse, 11, 2, 2);
		add(sparse, 11, expected_num_params + 11, -1);
		add(sparse, 11, expected_num_vars - 1, -1);

		// NEGATIVE CONSTRAINTS
		// 0 vs 111: -c_0 -2*c_2 -slack_1,1^- + nu <= -log(2)
		add(sparse, 12, 0, -1);
		add(sparse, 12, 2, -2);
		add(sparse, 12, expected_num_params + 12, -1);
		add(sparse, 12, expected_num_vars - 1, +1);
		// 0 vs 11: -c_0 -c_2 -slack_1,2^- + nu <= -log(2)
		add(sparse, 13, 0, -1);
		add(sparse, 13, 2, -1);
		add(sparse, 13, expected_num_params + 13, -1);
		add(sparse, 13, expected_num_vars - 1, +1);
		// 00 vs 111: -2*c_0 -c_2 -slack_2,1^- + nu <= -log(2)
		add(sparse, 14, 0, -2);
		add(sparse, 14, 2, -1);
		add(sparse, 14, expected_num_params + 14, -1);
		add(sparse, 14, expected_num_vars - 1, +1);
		// 00 vs 1: -c_0 -c_1 -slack_2,2^- + nu <= -log(2)
		add(sparse, 15, 0, -1);
		add(sparse, 15, 1, -1);
		add(sparse, 15, expected_num_params + 15, -1);
		add(sparse, 15, expected_num_vars - 1, +1);
		// 000 vs 1: -c_0 -2*c_1 -slack_3,1^- + nu <= -log(2)
		add(sparse, 16, 0, -1);
		add(sparse, 16, 1, -2);
		add(sparse, 16, expected_num_params + 16, -1);
		add(sparse, 16, expected_num_vars - 1, +1);
		// 000 vs 11: -2*c_0 -c_1 -slack_3,2^- + nu <= -log(2)
		add(sparse, 17, 0, -2);
		add(sparse, 17, 1, -1);
		add(sparse, 17, expected_num_params + 17, -1);
		add(sparse, 17, expected_num_vars - 1, +1);
		// 1 vs 000: -c_0 -2*c_1 -slack_4,1^- + nu <= -log(2)
		add(sparse, 18, 0, -1);
		add(sparse, 18, 1, -2);
		add(sparse, 18, expected_num_params + 18, -1);
		add(sparse, 18, expected_num_vars - 1, +1);
		// 1 vs 00: -c_0 -c_1 -slack_4,2^- + nu <= -log(2)
		add(sparse, 19, 0, -1);
		add(sparse, 19, 1, -1);
		add(sparse, 19, expected_num_params + 19, -1);
		add(sparse, 19, expected_num_vars - 1, +1);
		// 11 vs 000: -2*c_0 -c_1 -slack_5,1^- + nu <= -log(2)
		add(sparse, 20, 0, -2);
		add(sparse, 20, 1, -1);
		add(sparse, 20, expected_num_params + 20, -1);
		add(sparse, 20, expected_num_vars - 1, +1);
		// 11 vs 0: -c_0 -c_2 -slack_5,2^- + nu <= -log(2)
		add(sparse, 21, 0, -1);
		add(sparse, 21, 2, -1);
		add(sparse, 21, expected_num_params + 21, -1);
		add(sparse, 21, expected_num_vars - 1, +1);
		// 111 vs 0: -c_0 -2*c_2 -slack_6,1^- + nu <= -log(2)
		add(sparse, 22, 0, -1);
		add(sparse, 22, 2, -2);
		add(sparse, 22, expected_num_params + 22, -1);
		add(sparse, 22, expected_num_vars - 1, +1);
		// 111 vs 00: -2*c_0 -c_2 -slack_6,2^- + nu <= -log(2)
		add(sparse, 23, 0, -2);
		add(sparse, 23, 2, -1);
		add(sparse, 23, expected_num_params + 23, -1);
		add(sparse, 23, expected_num_vars - 1, +1);

		final GESLLinearProgram.IndexMatrix expected_A = new GESLLinearProgram.IndexMatrix(sparse);
		for (int s = 0; s < expected_A.i.length; s++) {
			assertEquals("Error in " + s + "th sparse constraint matrix entry!", expected_A.i[s], instance.A.i[s]);
			assertEquals("Error in " + s + "th sparse constraint matrix entry!", expected_A.j[s], instance.A.j[s]);
			assertEquals("Error in " + s + "th sparse constraint matrix entry!", expected_A.v[s], instance.A.v[s], 1E-3);
		}

		// check constraint bounds
		final double[] expected_b = new double[expected_num_slacks];
		Arrays.fill(expected_b, K * m, expected_num_slacks, -Math.log(2));
		assertArrayEquals(expected_b, instance.b, 1E-3);

		// check lower and upper bounds
		final double[] expected_lb = new double[expected_f.length];
		assertArrayEquals(expected_lb, instance.lb, 1E-3);
		final double[] expected_ub = new double[expected_f.length];
		Arrays.fill(expected_ub, Double.POSITIVE_INFINITY);
		expected_ub[expected_ub.length - 1] = Math.log(2);
		assertArrayEquals(expected_ub, instance.ub, 1E-3);

		// solve the linear program and check the result
		final PointValuePair solution = solve(instance);
		// we expect that no error remains
		assertEquals(0, solution.getValue(), 1E-3);
		// we expect that the 0->1 replacement cost is larger than log(2)
		assertTrue(solution.getPoint()[0] >= Math.log(2));
		// the gap costs should be zero
		assertEquals(0, solution.getPoint()[1], 1E-3);
		assertEquals(0, solution.getPoint()[2], 1E-3);
		// the slack variables should be zero
		for (int s = 3; s < 3 + 2 * 2 * 6; s++) {
			assertEquals(0, solution.getPoint()[s], 1E-3);
		}
		// nu should be zero as well
		assertEquals(0, solution.getPoint()[solution.getPoint().length - 1], 1E-3);

	}

	private static void add(List<GESLLinearProgram.SparseEntry> sparse, int i, int j, double v) {
		sparse.add(new GESLLinearProgram.SparseEntry(i, j, v));
	}

}
