/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.comparators;

import de.citec.tcs.alignment.comparators.Gradient;
import de.citec.tcs.alignment.comparators.OperationType;
import java.util.Arrays;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Benjamin Paassen - bpaassen@techfak.uni-bielefeld.de
 */
public class MatrixComparatorTest {

	public MatrixComparatorTest() {
	}

	@BeforeClass
	public static void setUpClass() {
	}

	@AfterClass
	public static void tearDownClass() {
	}

	@Before
	public void setUp() {
	}

	@After
	public void tearDown() {
	}

	/**
	 * Test of compare method, of class MatrixComparator.
	 */
	@Test
	public void testCompare() {
		final double[][] C = {
			{0, 0.1, 0.2},
			{0.3, 0.4, 0.5},
			{0.6, 0.7, Double.NaN}
		};
		final int m = 2;
		final MatrixComparator instance = new MatrixComparator(C);
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < m; j++) {
				assertEquals(C[i][j], instance.compare(OperationType.REPLACEMENT, i, j), 0.);
			}
			assertEquals(C[i][m], instance.compare(OperationType.DELETION, i, null), 0.);
			assertEquals(C[m][i], instance.compare(OperationType.INSERTION, null, i), 0.);
		}

	}

	/**
	 * Test of computeGradient method, of class MatrixComparator.
	 */
	@Test
	public void testComputeGradient() {
		final double[][] C = {
			{0, 0.1, 0.2},
			{0.3, 0.4, 0.5},
			{0.6, 0.7, Double.NaN}
		};
		final int m = 2;
		final MatrixComparator instance = new MatrixComparator(C);
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < m; j++) {
				final Gradient grad = instance.computeGradient(OperationType.REPLACEMENT, i, j);
				assertEquals(i * m + j, grad.currentParameterIndex());
				assertEquals(1, grad.currentValue(), 0);
				grad.next();
				assertFalse(grad.notEmpty());
			}
			final Gradient delGrad = instance.computeGradient(OperationType.DELETION, i, null);
			assertEquals(m * m + i, delGrad.currentParameterIndex());
			assertEquals(1, delGrad.currentValue(), 0);
			delGrad.next();
			assertFalse(delGrad.notEmpty());
			final Gradient insGrad = instance.computeGradient(OperationType.INSERTION, null, i);
			assertEquals(m * m + m + i, insGrad.currentParameterIndex());
			assertEquals(1, insGrad.currentValue(), 0);
			insGrad.next();
			assertFalse(insGrad.notEmpty());
		}
	}

	/**
	 * Test of getCostMatrix method, of class MatrixComparator.
	 */
	@Test
	public void testGetCostMatrix() {
		final double[][] C = {
			{0, 0.1, 0.2},
			{0.3, 0.4, 0.5},
			{0.6, 0.7, Double.NaN}
		};
		final MatrixComparator instance = new MatrixComparator(C);
		assertTrue(Arrays.deepEquals(C, instance.getCostMatrix()));
	}

	/**
	 * Test of setCostMatrix method, of class MatrixComparator.
	 */
	@Test
	public void testSetCostMatrix() {
		final double[][] C = {
			{0, 0.1, 0.2},
			{0.3, 0.4, 0.5},
			{0.6, 0.7, Double.NaN}
		};
		final MatrixComparator instance = new MatrixComparator(1);
		instance.setCostMatrix(C);
		assertTrue(Arrays.deepEquals(C, instance.getCostMatrix()));
	}

	/**
	 * Test of getParameters method, of class MatrixComparator.
	 */
	@Test
	public void testGetParameters() {
		final double[][] C = {
			{0, 0.1, 0.2},
			{0.3, 0.4, 0.5},
			{0.6, 0.7, Double.NaN}
		};
		final MatrixComparator instance = new MatrixComparator(C);
		final double[] expected = {0, 0.1, 0.3, 0.4, 0.2, 0.5, 0.6, 0.7};
		assertArrayEquals(expected, instance.getParameters(), 0.);
	}

	/**
	 * Test of normalizeParameters method, of class MatrixComparator.
	 */
	@Test
	public void testNormalizeParameters() {

		final double[] params = {-1, -1, 0, -1, 3, 1, 2, -1};
		final double[] expected = {0, 0, 0, 0, 0.5, 0.5, 0.5, 0.5};

		final double[] actual = MatrixComparator.normalizeParameters(params);
		assertArrayEquals(expected, actual, 1E-3);

		final double[] params2 = {
			-0.3749,
			0.3650,
			1.1683,
			1.0000,
			0.8583,
			-1.0000,
			1.0742,
			1.0000,
			1.0000,
			1.0855,
			-0.2046,
			1.0000,
			1.0000,
			1.1715,
			0.7959,
			0,
			1.1623,
			1.0666,
			1.0000,
			1.0116,
			1.1004,
			1.1139,
			1.0263,
			1.0000
		};
		MatrixComparator.normalizeParameters(params2);
	}

	/**
	 * Test of normalizeCostMatrix method, of class MatrixComparator.
	 */
	@Test
	public void testNormalizeCostMatrix() {
		final double[][] C = {
			{-1, -1, 3},
			{0, -1, 1},
			{2, -1, 0}
		};
		final double[][] expected = {
			{0, 0, 0.5},
			{0, 0, 0.5},
			{0.5, 0.5, 0}
		};
		final double[][] actual = MatrixComparator.normalizeCostMatrix(C);
		assertSame(actual, C);
		assertEquals(expected.length, actual.length);
		for (int i = 0; i < expected.length; i++) {
			assertArrayEquals(expected[i], actual[i], 1E-3);
		}
	}

}
