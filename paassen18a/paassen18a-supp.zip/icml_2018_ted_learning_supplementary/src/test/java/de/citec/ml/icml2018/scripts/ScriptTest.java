/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.scripts;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class ScriptTest {

	public ScriptTest() {
	}

	@BeforeClass
	public static void setUpClass() {
	}

	@AfterClass
	public static void tearDownClass() {
	}

	@Before
	public void setUp() {
	}

	@After
	public void tearDown() {
	}

	/**
	 * Test of the numDescendants method described in the arxiv paper regarding the tree edit
	 * distance.
	 */
	@Test
	public void testNumDescendants() throws IOException {
		{
			final String spec = "(1(2,3),4(5(6)))";
			final Forest Y = new Forest(spec);
			assertEquals(spec, Y.toString());

			final TreeSet<Integer> J = new TreeSet<>(Arrays.asList(1, 2, 4));
			final NumDescendantsResult actual = numDescendants(Y, 0, J);

			final NumDescendantsResult expected = new NumDescendantsResult();
			expected.j = 6;
			expected.R.addAll(Arrays.asList(2, 1, 0, 0, 1, 1, 0));

			assertEquals(expected, actual);
		}
		{
			final String spec = "(1(2(3,4),5))";
			final Forest Y = new Forest(spec);
			assertEquals(spec, Y.toString());

			final TreeSet<Integer> J = new TreeSet<>(Arrays.asList(2, 3, 5));
			final NumDescendantsResult actual = numDescendants(Y, 0, J);

			final NumDescendantsResult expected = new NumDescendantsResult();
			expected.j = 5;
			expected.R.addAll(Arrays.asList(1, 1, 1, 0, 0, 0));

			assertEquals(expected, actual);
		}
	}

	public static NumDescendantsResult numDescendants(Forest forest, int j, Set<Integer> J) {
		final NumDescendantsResult res = new NumDescendantsResult();
		int R_j = 0;
		for (int c : forest.adj.get(j)) {
			j++;
			if (j != c) {
				throw new RuntimeException("Child ordering is no pre-ordering!");
			}
			final NumDescendantsResult child_res = numDescendants(forest, c, J);
			res.R.addAll(child_res.R);
			if (J.contains(j)) {
				R_j += child_res.R.get(0);
			} else {
				R_j++;
			}
			j = child_res.j;
		}
		res.R.add(0, R_j);
		res.j = j;
		return res;
	}

	/**
	 * Test of the subforest method described in the arxiv paper regarding the tree edit
	 * distance.
	 */
	@Test
	public void testSubforest() throws IOException {
		final String spec = "(1(2,3),4(5(6)))";
		final Forest X = new Forest(spec);
		assertEquals(spec, X.toString());

		{
			final Forest actual = subforest(X, 2, 4);
			final Forest expected = new Forest("(2,3,4)");
			assertEquals(expected, actual);
		}
		{
			final Forest actual = subforest(X, 2, 5);
			final Forest expected = new Forest("(2,3,4(5))");
			assertEquals(expected, actual);
		}
		{
			final Forest actual = subforest(X, 1, 2);
			final Forest expected = new Forest("(1(2))");
			assertEquals(expected, actual);
		}

	}

	public static Forest subforest(Forest X, int i, int j) throws IOException {
		final Forest subforest = new Forest();
		subforest(X, subforest, i, j, 0);
		return subforest;
	}

	private static int subforest(Forest X, Forest Y, int i, int j, int k) {
		for (final int c : X.adj.get(k)) {
			k++;
			if (k > j) {
				return k;
			}
			if (c != k) {
				throw new RuntimeException("Child ordering is no pre-ordering!");
			}
			if (k >= i) {
				int new_parent = X.p.get(k) - i + 1;
				if (new_parent < 0) {
					new_parent = 0;
				}
				Y.p.add(new_parent);
				Y.adj.get(new_parent).add(k - i + 1);
				Y.adj.add(new ArrayList<Integer>());
			}
			k = subforest(X, Y, i, j, k);
		}
		return k;
	}

	public static class Forest {

		public final ArrayList<Integer> p = new ArrayList<>();
		public final ArrayList<ArrayList<Integer>> adj = new ArrayList<>();

		public Forest() {
			adj.add(new ArrayList<Integer>());
			p.add(-1);
		}

		public Forest(String spec) throws IOException {
			this();
			final StringReader inp = new StringReader(spec);
			char c = (char) inp.read();
			if (c != '(') {
				throw new IllegalArgumentException("Expected specification to start with opening bracket");
			}
			int j = 0;
			while (c != ')') {
				j = parse_recursively(j, 0, inp);
				c = (char) inp.read();
			}
			if (inp.read() >= 0) {
				throw new IllegalArgumentException("Content proceeded after last closing bracket!");
			}
		}

		private int parse_recursively(int j, int parent, StringReader in) throws IOException {
			j++;
			int i = j;
			// start by reading the key
			char c = (char) in.read();
			boolean hasKey = false;
			while (c != '(' && c != ',' && c != ')') {
				hasKey = true;
				in.mark(1);
				c = (char) in.read();
			}
			if (!hasKey) {
				throw new IllegalArgumentException("Node " + i + " does not have a key!");
			}
			// add the new node to the tree
			p.add(parent);
			adj.get(parent).add(i);
			adj.add(new ArrayList<Integer>());
			if (c == '(') {
				// if we have an opening bracket, parse the children of this node, until the
				// bracket is closed
				while (c != ')') {
					j = parse_recursively(j, i, in);
					c = (char) in.read();
				}
			} else {
				// if we don't have an opening bracket, re-set the stream
				in.reset();
			}
			return j;
		}

		@Override
		public String toString() {
			final StringBuilder buf = new StringBuilder();
			final Stack<Integer> stk = new Stack<>();
			stk.push(0);
			boolean[] visited = new boolean[p.size()];
			while (!stk.empty()) {
				final int j = stk.pop();
				if (visited[j]) {
					buf.append(')');
					continue;
				}
				visited[j] = true;
				if (j > 0 && adj.get(p.get(j)).get(0) < j) {
					buf.append(',');
				}
				if (j > 0) {
					buf.append(Integer.toString(j));
				}
				final ArrayList<Integer> children = adj.get(j);
				if (!children.isEmpty()) {
					buf.append('(');
					stk.push(j);
					for (int c = children.size() - 1; c >= 0; c--) {
						stk.push(children.get(c));
					}
				}
			}
			return buf.toString();
		}

		@Override
		public int hashCode() {
			int hash = 3;
			hash = 59 * hash + Objects.hashCode(this.p);
			return hash;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj) {
				return true;
			}
			if (obj == null) {
				return false;
			}
			if (getClass() != obj.getClass()) {
				return false;
			}
			final Forest other = (Forest) obj;
			if (!Objects.equals(this.p, other.p)) {
				return false;
			}
			return true;
		}

	}

	public static class NumDescendantsResult {

		public int j;
		public final ArrayList<Integer> R = new ArrayList<>();

		@Override
		public int hashCode() {
			int hash = 7;
			hash = 53 * hash + this.j;
			hash = 53 * hash + Objects.hashCode(this.R);
			return hash;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj) {
				return true;
			}
			if (obj == null) {
				return false;
			}
			if (getClass() != obj.getClass()) {
				return false;
			}
			final NumDescendantsResult other = (NumDescendantsResult) obj;
			if (this.j != other.j) {
				return false;
			}
			if (!Objects.equals(this.R, other.R)) {
				return false;
			}
			return true;
		}

	}

}
