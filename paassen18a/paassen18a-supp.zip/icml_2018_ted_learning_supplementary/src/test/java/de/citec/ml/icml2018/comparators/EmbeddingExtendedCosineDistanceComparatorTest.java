/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.comparators;

import de.citec.tcs.alignment.comparators.Gradient;
import de.citec.tcs.alignment.comparators.OperationType;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class EmbeddingExtendedCosineDistanceComparatorTest {

	public EmbeddingExtendedCosineDistanceComparatorTest() {
	}

	@BeforeClass
	public static void setUpClass() {
	}

	@AfterClass
	public static void tearDownClass() {
	}

	@Before
	public void setUp() {
	}

	@After
	public void tearDown() {
	}

	/**
	 * Test of compare method, of class EmbeddingExtendedCosineDistanceComparator.
	 */
	@Test
	public void testCompare() {
		final double[][] Theta = {{1, 0}, {1, 1}};
		final double[][] Omega = {{1, 1}};
		final EmbeddingExtendedCosineDistanceComparator instance = new EmbeddingExtendedCosineDistanceComparator(Theta, Omega);
		assertEquals(0, instance.compare(OperationType.REPLACEMENT, new double[]{0}, new double[]{0}), 1E-8);
		assertEquals(0, instance.compare(OperationType.REPLACEMENT, new double[]{1}, new double[]{1}), 1E-8);
		assertEquals(0.5 * (1 - Math.cos(0.25 * Math.PI)), instance.compare(OperationType.REPLACEMENT, new double[]{0}, new double[]{1}), 1E-8);
		assertEquals(0.5 * (1 - Math.cos(0.25 * Math.PI)), instance.compare(OperationType.REPLACEMENT, new double[]{1}, new double[]{0}), 1E-8);
		assertEquals(0, instance.compare(OperationType.REPLACEMENT, new double[]{1, 1}, new double[]{1, 8}), 1E-8);
		assertEquals(0, instance.compare(OperationType.REPLACEMENT, new double[]{1, 1}, new double[]{3, 8}), 1E-8);
		assertEquals(1, instance.compare(OperationType.REPLACEMENT, new double[]{1, 1}, new double[]{3, -8}), 1E-8);
		assertEquals(0.5, instance.compare(OperationType.REPLACEMENT, new double[]{1, -1}, new double[]{3, -8}), 1E-8);
		assertEquals(0, instance.compare(OperationType.REPLACEMENT, new double[]{1, -2}, new double[]{3, -8}), 1E-8);
	}

	private static void assertGradient(int offset, double[] expected, Gradient actual) {
		for (int j = offset; j < offset + expected.length; j++) {
			assertEquals(j, actual.currentParameterIndex());
			assertEquals(expected[j - offset], actual.currentValue(), 1E-3);
			actual.next();
		}
		assertFalse(actual.notEmpty());
	}

	/**
	 * Test of computeGradient method, of class EmbeddingExtendedCosineDistanceComparator.
	 */
	@Test
	public void testComputeGradient() {
		final double[][] Theta = {{1, 0}, {1, 1}};
		final double[][] Omega = {{1, 1}};
		final EmbeddingExtendedCosineDistanceComparator instance = new EmbeddingExtendedCosineDistanceComparator(Theta, Omega);
		assertFalse(instance.computeGradient(OperationType.REPLACEMENT, new double[]{0}, new double[]{0}).notEmpty());
		assertFalse(instance.computeGradient(OperationType.REPLACEMENT, new double[]{1}, new double[]{1}).notEmpty());
		assertFalse(instance.computeGradient(OperationType.REPLACEMENT, new double[]{1, 1}, new double[]{1, 8}).notEmpty());
		assertFalse(instance.computeGradient(OperationType.REPLACEMENT, new double[]{1, 1}, new double[]{3, 8}).notEmpty());
		assertFalse(instance.computeGradient(OperationType.REPLACEMENT, new double[]{1, 1}, new double[]{3, -8}).notEmpty());
		final double s = Math.cos(0.25 * Math.PI);
		final double[] expected_gradient = {
			-0.5 * (Theta[1][0] - s * Theta[0][0] * Math.sqrt(2)) / Math.sqrt(2),
			-0.5 * (Theta[1][1] - s * Theta[0][1] * Math.sqrt(2)) / Math.sqrt(2),
			-0.5 * (Theta[0][0] - s * Theta[1][0] / Math.sqrt(2)) / Math.sqrt(2),
			-0.5 * (Theta[0][1] - s * Theta[1][1] / Math.sqrt(2)) / Math.sqrt(2)
		};
		assertGradient(0, expected_gradient, instance.computeGradient(OperationType.REPLACEMENT, new double[]{0}, new double[]{1}));
		// re-set Omega and produce a non-null gradient
		instance.getDistanceComparator().setOmega(new double[][]{{1, 1}, {0, 1}});
		final Gradient grad = instance.computeGradient(OperationType.REPLACEMENT, new double[]{1, 0}, new double[]{0, 1});
		final double[] expected_gradient2 = {
			expected_gradient[0], expected_gradient[2], expected_gradient[1], expected_gradient[3]
		};
		assertGradient(4, expected_gradient2, grad);

	}

}
