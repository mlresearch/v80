/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.input;

import de.citec.tcs.alignment.trees.Tree;
import de.citec.tcs.alignment.trees.TreeProperties;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class ArtificialDataTest {

	public ArtificialDataTest() {
	}

	@BeforeClass
	public static void setUpClass() {
	}

	@AfterClass
	public static void tearDownClass() {
	}

	@Before
	public void setUp() {
	}

	@After
	public void tearDown() {
	}

	/**
	 * Test of createStringDataset method, of class ArtificialData.
	 */
	@Test
	public void testCreateStringDataset() {
		final int m = 20;
		final int l = 5;
		final Dataset<Tree<Character>> dataset = ArtificialData.createStringDataset(m, l);
		assertEquals(m, dataset.data.size());
		assertEquals(dataset.data.size(), dataset.labels.size());
		assertEquals(dataset.data.size(), dataset.names.size());
		assertEquals(2, dataset.classNames.size());
		assertEquals("negative", dataset.classNames.get(-1));
		assertEquals("positive", dataset.classNames.get(1));

		for (int i = 0; i < m; i++) {
			final Tree<Character> tree = dataset.data.get(i);
			assertEquals(2 * l + 2 + 1, TreeProperties.size(tree));
			assertEquals(2 * l + 2, tree.getChildren().size());
		}
	}

}
