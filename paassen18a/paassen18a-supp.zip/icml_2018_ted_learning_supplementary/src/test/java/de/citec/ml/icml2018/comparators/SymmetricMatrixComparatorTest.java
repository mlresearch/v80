/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.comparators;

import de.citec.tcs.alignment.comparators.Gradient;
import de.citec.tcs.alignment.comparators.OperationType;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class SymmetricMatrixComparatorTest {

	public SymmetricMatrixComparatorTest() {
	}

	@BeforeClass
	public static void setUpClass() {
	}

	@AfterClass
	public static void tearDownClass() {
	}

	@Before
	public void setUp() {
	}

	@After
	public void tearDown() {
	}

	/**
	 * Test of compare method, of class SymmetricMatrixComparator.
	 */
	@Test
	public void testCompare() {
		final int m = 2;
		final double[] params = {1, 2, 3};
		final SymmetricMatrixComparator instance = new SymmetricMatrixComparator(params);
		assertEquals(0, instance.compare(OperationType.REPLACEMENT, null, null), 0);
		for (int i = 0; i < m; i++) {
			assertEquals(0, instance.compare(OperationType.REPLACEMENT, i, i), 0);
		}
		assertEquals(1, instance.compare(OperationType.REPLACEMENT, 0, 1), 0);
		assertEquals(1, instance.compare(OperationType.REPLACEMENT, 1, 0), 0);

		assertEquals(2, instance.compare(OperationType.DELETION, 0, null), 0);
		assertEquals(2, instance.compare(OperationType.INSERTION, null, 0), 0);

		assertEquals(3, instance.compare(OperationType.DELETION, 1, null), 0);
		assertEquals(3, instance.compare(OperationType.INSERTION, null, 1), 0);
	}

	private static void assertGradient(int k, Gradient grad) {
		assertTrue(grad.notEmpty());
		assertEquals(k, grad.currentParameterIndex());
		assertEquals(1, grad.currentValue(), 0);
		grad.next();
		assertFalse(grad.notEmpty());
	}

	/**
	 * Test of computeGradient method, of class SymmetricMatrixComparator.
	 */
	@Test
	public void testComputeGradient() {
		final int m = 2;
		final double[][] C = {
			{0, 0, 0},
			{1, 0, 0},
			{2, 3, 0}
		};
		final SymmetricMatrixComparator instance = new SymmetricMatrixComparator(C);
		assertFalse(instance.computeGradient(OperationType.REPLACEMENT, null, null).notEmpty());
		for (int i = 0; i < m; i++) {
			assertFalse(instance.computeGradient(OperationType.REPLACEMENT, i, i).notEmpty());
		}
		assertGradient(0, instance.computeGradient(OperationType.REPLACEMENT, 0, 1));
		assertGradient(0, instance.computeGradient(OperationType.REPLACEMENT, 1, 0));

		assertGradient(1, instance.computeGradient(OperationType.DELETION, 0, null));
		assertGradient(1, instance.computeGradient(OperationType.INSERTION, null, 0));

		assertGradient(2, instance.computeGradient(OperationType.DELETION, 1, null));
		assertGradient(2, instance.computeGradient(OperationType.INSERTION, null, 1));
	}

	/**
	 * Test of toMatrix method, of class SymmetricMatrixComparator.
	 */
	@Test
	public void testToMatrix() {
		final double[] params = {1, 2, 3};
		final double[][] expected = {
			{0, 1, 2},
			{1, 0, 3},
			{2, 3, 0}
		};
		final double[][] actual = SymmetricMatrixComparator.toMatrix(params);
		assertEquals(expected.length, actual.length);
		for (int i = 0; i < expected.length; i++) {
			assertArrayEquals(expected[i], actual[i], 1E-3);
		}
	}

	/**
	 * Test of fromMatrix method, of class SymmetricMatrixComparator.
	 */
	@Test
	public void testFromMatrix() {
		final double[][] C = {
			{0, 0, 0},
			{1, 0, 0},
			{2, 3, 0}
		};
		final double[] expected = {1, 2, 3};
		final double[] actual = SymmetricMatrixComparator.fromMatrix(C);
		assertArrayEquals(expected, actual, 1E-3);
	}

	/**
	 * Test of getCostMatrix method, of class SymmetricMatrixComparator.
	 */
	@Test
	public void testgetCostMatrix() {
		final double[] params = {1, 2, 3};
		final double[][] expected = {
			{0, 1, 2},
			{1, 0, 3},
			{2, 3, 0}
		};
		final SymmetricMatrixComparator instance = new SymmetricMatrixComparator(params);
		instance.setParameters(params);
		final double[][] actual = instance.getCostMatrix();
		assertEquals(expected.length, actual.length);
		for (int i = 0; i < expected.length; i++) {
			assertArrayEquals(expected[i], actual[i], 1E-3);
		}
	}

	/**
	 * Test of normalizeParameters method, of class SymmetricMatrixComparator.
	 */
	@Test
	public void testNormalizeParameters() {
		final double[] params = {3, -1, 0};
		final double[] expected = {1, 0, 1};
		final double[] actual = SymmetricMatrixComparator.normalizeParameters(params);
		assertArrayEquals(expected, actual, 1E-3);
	}

	@Test
	public void testAlphabetSize() {
		for (int m = 1; m < 20; m++) {
			final int n = (m * (m + 1)) / 2;
			assertEquals(m, SymmetricMatrixComparator.alphabetSize(n));
		}
	}
}
