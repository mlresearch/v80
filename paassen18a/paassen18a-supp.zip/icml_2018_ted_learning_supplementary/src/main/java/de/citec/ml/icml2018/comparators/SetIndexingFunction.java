/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.comparators;

import de.citec.tcs.alignment.comparators.IndexingFunction;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.SortedSet;

/**
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class SetIndexingFunction<X> implements IndexingFunction<X> {

	private final HashMap<X, Integer> map;

	public SetIndexingFunction(X... objects) {
		this.map = new HashMap<>(objects.length);
		for (int i = 0; i < objects.length; i++) {
			this.map.put(objects[i], i);
		}
	}

	public SetIndexingFunction(final Collection<X> objects, Comparator<? super X> comp) {
		final ArrayList<X> list = new ArrayList<>(objects);
		Collections.sort(list, comp);
		this.map = new HashMap<>(list.size());
		for (int i = 0; i < list.size(); i++) {
			this.map.put(list.get(i), i);
		}
	}

	public SetIndexingFunction(final SortedSet<X> objects) {
		final ArrayList<X> list = new ArrayList<>(objects);
		this.map = new HashMap<>(list.size());
		for (int i = 0; i < list.size(); i++) {
			this.map.put(list.get(i), i);
		}
	}

	@Override
	public int index(X object) {
		final Integer i = this.map.get(object);
		if (i == null) {
			throw new IllegalArgumentException("Object " + object + " can not be indexed!");
		}
		return i;
	}

	@Override
	public int range() {
		return this.map.size();
	}

}
