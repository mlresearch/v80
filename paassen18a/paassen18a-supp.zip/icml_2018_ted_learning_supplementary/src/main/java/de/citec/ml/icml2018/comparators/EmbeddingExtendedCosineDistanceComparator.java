/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.comparators;

import de.citec.tcs.alignment.comparators.DerivableComparator;
import de.citec.tcs.alignment.comparators.EmptyGradient;
import de.citec.tcs.alignment.comparators.Gradient;
import de.citec.tcs.alignment.comparators.OperationType;

/**
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class EmbeddingExtendedCosineDistanceComparator implements DerivableComparator<double[], double[]>, Copyable<EmbeddingExtendedCosineDistanceComparator> {

	private CosineVectorEmbeddingComparator embeddingComparator;
	private CosineDistanceComparator distanceComparator;

	public EmbeddingExtendedCosineDistanceComparator(int n, int m, int m2) {
		if (m2 < 1) {
			throw new IllegalArgumentException("Expected at least one input dimension!");
		}
		if (m < 0) {
			throw new IllegalArgumentException("Number of embedding dimensions can not be negative!");
		}
		this.embeddingComparator = new CosineVectorEmbeddingComparator(m, n);
		this.distanceComparator = new CosineDistanceComparator(n, m2);
	}

	public EmbeddingExtendedCosineDistanceComparator(double[][] Theta, double[][] Omega) {
		this.embeddingComparator = new CosineVectorEmbeddingComparator(Theta);
		this.distanceComparator = new CosineDistanceComparator(Omega);
	}

	public EmbeddingExtendedCosineDistanceComparator(CosineVectorEmbeddingComparator embeddingComparator,
			CosineDistanceComparator distanceComparator) {
		this.embeddingComparator = embeddingComparator;
		this.distanceComparator = distanceComparator;
	}

	public CosineVectorEmbeddingComparator getEmbeddingComparator() {
		return embeddingComparator;
	}

	public CosineDistanceComparator getDistanceComparator() {
		return distanceComparator;
	}

	public final void reinitialize(int n, int m, int m2) {
		if (m2 < 1) {
			throw new IllegalArgumentException("Expected at least one input dimension!");
		}
		if (m < 0) {
			throw new IllegalArgumentException("Number of embedding dimensions can not be negative!");
		}
		this.embeddingComparator = new CosineVectorEmbeddingComparator(m, n);
		this.distanceComparator = new CosineDistanceComparator(n, m2);
	}

	@Override
	public double compare(OperationType type, double[] x, double[] y) {
		switch (type) {
			case DELETION:
				y = null;
				break;
			case INSERTION:
				x = null;
				break;
		}
		if (x == null) {
			if (y == null) {
				return 0;
			}
			return 0.5;
		}
		if (y == null) {
			return 0.5;
		}

		// check if the input is in index representation or in vector representation
		if (x.length == 1) {
			if (y.length == 1) {
				// if both vectors have index representation, use the embedding comparator
				final int i = (int) Math.round(x[0]);
				final int j = (int) Math.round(y[0]);
				return embeddingComparator.compare(OperationType.REPLACEMENT, i, j);
			}
			// if one vector is in index representation, but the other is not, return distance 1.
			return 1;
		}
		if (y.length == 1) {
			// if one vector is in index representation, but the other is not, return distance 1.
			return 1;
		}
		// if neither vector is in index representation, use the distance comparator
		return distanceComparator.compare(OperationType.REPLACEMENT, x, y);
	}

	private static final double TOL = 1E-3;

	@Override
	public boolean supports(OperationType type) {
		switch (type) {
			case DELETIONREPLACEMENT:
			case INSERTIONREPLACEMENT:
			case REPLACEMENT:
			case INSERTION:
			case DELETION:
				return true;
			default:
				return false;
		}
	}

	@Override
	public boolean hasCoherentReplacementCost() {
		return true;
	}

	@Override
	public Gradient computeGradient(OperationType type, double[] x, double[] y) {
		switch (type) {
			case DELETION:
				y = null;
				break;
			case INSERTION:
				x = null;
				break;
		}
		if (x == null || y == null) {
			return new EmptyGradient();
		}
		// check if the input is in index representation or in vector representation
		if (x.length == 1) {
			if (y.length == 1) {
				// if both vectors have index representation, use the embedding comparator
				final int i = (int) Math.round(x[0]);
				final int j = (int) Math.round(y[0]);
				if (i == j) {
					return new EmptyGradient();
				}
				return embeddingComparator.computeGradient(OperationType.REPLACEMENT, i, j);
			}
			// if one vector is in index representation, but the other is not, the gradient is empty
			return new EmptyGradient();
		}
		if (y.length == 1) {
			// if one vector is in index representation, but the other is not, the gradient is empty
			return new EmptyGradient();
		}
		// if neither vector is in index representation, use the distance comparator
		final Gradient gradient = distanceComparator.computeGradient(OperationType.REPLACEMENT, x, y);
		if(!gradient.notEmpty()) {
			return gradient;
		}
		// add an index offset to the parameters
		final double[] grad = new double[distanceComparator.getNumberOfParameters()];
		while (gradient.notEmpty()) {
			grad[gradient.currentParameterIndex()] = gradient.currentValue();
			gradient.next();
		}
		return new ArrayOffsetGradient(embeddingComparator.getNumberOfParameters(), grad);
	}

	public static class ArrayOffsetGradient implements Gradient {

		private final int p_0;
		private int p;
		private final double[] grad;

		public ArrayOffsetGradient(int p_0, double[] grad) {
			this.p_0 = p_0;
			this.p = p_0;
			this.grad = grad;
		}

		@Override
		public int currentParameterIndex() {
			return p;
		}

		@Override
		public double currentValue() {
			return grad[p - p_0];
		}

		@Override
		public void next() {
			p++;
		}

		@Override
		public boolean notEmpty() {
			return p - p_0 < grad.length;
		}

	}

	@Override
	public int getNumberOfParameters() {
		return this.embeddingComparator.getNumberOfParameters() + this.distanceComparator.getNumberOfParameters();
	}

	@Override
	public double[] getParameters() {
		final double[] params_embedding = this.embeddingComparator.getParameters();
		final double[] params_vectors = this.distanceComparator.getParameters();
		final double[] params = new double[params_embedding.length + params_vectors.length];
		System.arraycopy(params_embedding, 0, params, 0, params_embedding.length);
		System.arraycopy(params_vectors, 0, params, params_embedding.length, params_vectors.length);
		return params;
	}

	@Override
	public void setParameters(double[] params) {
		final double[] params_embedding = new double[this.embeddingComparator.getNumberOfParameters()];
		System.arraycopy(params, 0, params_embedding, 0, params_embedding.length);
		this.embeddingComparator.setParameters(params_embedding);
		final double[] params_vectors = new double[this.distanceComparator.getNumberOfParameters()];
		System.arraycopy(params, params_embedding.length, params_vectors, 0, params_vectors.length);
		this.distanceComparator.setParameters(params_vectors);
	}

	@Override
	public EmbeddingExtendedCosineDistanceComparator copy() {
		return new EmbeddingExtendedCosineDistanceComparator(this.embeddingComparator.copy(), this.distanceComparator.copy());
	}

}
