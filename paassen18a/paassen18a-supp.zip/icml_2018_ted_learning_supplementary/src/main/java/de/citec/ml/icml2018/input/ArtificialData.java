/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.input;

import de.citec.tcs.alignment.trees.Tree;
import de.citec.tcs.alignment.trees.TreeImpl;
import java.util.Random;

/**
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class ArtificialData {

	private ArtificialData() {

	}

	/**
	 * Generates a simple string data set where a single root as 2*l + 2 children, where the
	 * first l children and the last l children have either 'A' or 'B' as label (drawn at random)
	 * and the l+1th child is either 'A' or 'B' for class 1 and 'C' or 'D' for class 2. Conversely,
	 * the l+2th child is either 'C' or 'D' for class 1 and 'A' or 'B' for class 2.
	 *
	 */
	public static Dataset<Tree<Character>> createStringDataset(int m, int l) {

		if (m < 2 || m % 2 != 0) {
			throw new IllegalArgumentException("Expected data set size as first argument!");
		}

		if (l < 0) {
			throw new IllegalArgumentException("Expected prefix and suffix length as second argument!");
		}

		final Random rnd = new Random();
		final Dataset<Tree<Character>> out = new Dataset<>();
		out.classNames.put(-1, "negative");
		out.classNames.put(1, "positive");

		for (int i = 0; i < m; i++) {
			final int y = i >= m / 2 ? 1 : -1;
			out.labels.add(y);
			out.names.add(Integer.toString(i));

			final TreeImpl.ForestBuilder<Character> builder = TreeImpl.builder('A');

			for (int j = 0; j < l; j++) {
				builder.node(rnd.nextDouble() < 0.5 ? 'A' : 'B');
			}
			if (y < 0) {
				builder.node(rnd.nextDouble() < 0.5 ? 'A' : 'B');
				builder.node(rnd.nextDouble() < 0.5 ? 'C' : 'D');
			} else {
				builder.node(rnd.nextDouble() < 0.5 ? 'C' : 'D');
				builder.node(rnd.nextDouble() < 0.5 ? 'A' : 'B');
			}
			for (int j = 0; j < l; j++) {
				builder.node(rnd.nextDouble() < 0.5 ? 'A' : 'B');
			}
			out.data.add(builder.getTree());
		}
		return out;
	}

}
