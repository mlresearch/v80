/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.comparators;

import de.citec.tcs.alignment.comparators.DerivableComparator;
import de.citec.tcs.alignment.comparators.EmptyGradient;
import de.citec.tcs.alignment.comparators.Gradient;
import de.citec.tcs.alignment.comparators.IndexingFunction;
import de.citec.tcs.alignment.comparators.OperationType;
import de.citec.tcs.alignment.trees.Tree;
import de.citec.tcs.alignment.trees.TreeImpl;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Computes the distance between two indices i and j via the Euclidean distance on two vectors
 * &theta;<sub>i</sub> and &theta;<sub>j</sub>. These vectors &theta; form the parameters of the
 * model.
 *
 * Note that the distance can also be described as a generalized quadratic form distance between
 * the ith and jth unit vector e<sub>i</sub> and e<sub>j</sub> via:
 *
 * |&theta;<sub>i</sub> - &theta;<sub>j</sub>| = |&Theta; &middot; (e<sub>i</sub> - e<sub>j</sub>)|
 * = sqrt[ (&Theta; &middot; (e<sub>i</sub> - e<sub>j</sub>))<sup>T</sup> &middot;
 * &Theta; &middot; (e<sub>i</sub> - e<sub>j</sub>) ]
 * = (e<sub>i</sub> - e<sub>j</sub>)<sup>T</sup> &middot; &Theta; <sup>T</sup> &middot;
 * &Theta; &middot; (e<sub>i</sub> - e<sub>j</sub>)
 *
 * where &Theta;<sup>T</sup> &middot; &Theta; is the p.s.d. precision matrix.
 *
 * The deletion / insertion costs for this comparator are computed by using the norm of the
 * respective &theta; vector, or, equivalently, the distance to the zero vector, which is our
 * embedding of the gap symbol.
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class VectorEmbeddingComparator implements DerivableComparator<Integer, Integer>, Copyable<VectorEmbeddingComparator> {

	/**
	 * The vector embedding for all indices.
	 */
	private double[][] Theta;
	/**
	 * The pre-computed distance matrix.
	 */
	private double[][] D;
	/**
	 * The pre-computed vector of norms.
	 */
	private double[] Z;
	/**
	 * The number of embedding dimensions.
	 */
	private int n;

	/**
	 * Initializes a VectorEmbeddingComparator such that deletion and insertion costs are 1 and all
	 * replacement costs are 1. See 'defaultEmbedding' for more details.
	 *
	 * @param m the index range of this comparator, meaning that inputs from 0 to m-1 will be
	 * accepted.
	 */
	public VectorEmbeddingComparator(int m) {
		this.Theta = defaultEmbedding(m);
		this.n = m;
		this.D = new double[m][m];
		this.Z = new double[m];
		for (int i = 0; i < m; i++) {
			Z[i] = 1;
			for (int j = i + 1; j < m; j++) {
				D[i][j] = 1;
				D[j][i] = 1;
			}
		}
	}

	/**
	 * Creates an embedding such that all points have distance 1 and norm 1 (i.e. deletion and
	 * insertion costs are 1). This is, in effect, the m+1-simplex where one vertex is set to
	 * the m-dimensional zero vector (namely the one for the gap symbol). The embedding is
	 * constructed using the following algorithm:
	 *
	 * Set &theta;<sub>1</sub> = e<sub>1</sub>, meaning the first unit vector in the m-dimensional
	 * coordinate system
	 *
	 * Set the first i coordinates of &theta;<sub>i+1</sub> to the mean of all previous vectors,
	 * including the zero vector, and set the i+1-th coordinate of &theta;<sub>i+1</sub>
	 * to sqrt(1 - &Sigma;<sub>j=1</sub><sup>i</sup> &theta;<sub>i, j</sub>²).
	 *
	 * Note that the mean in this process is self-replicating, meaning that the mean of all
	 * vectors for the kth coordinate (for k &lt; i-1) is the same as the k-th entry of the
	 * i-ith vector.
	 *
	 * Further note that this is a deterministic process that always generates the same vectors for
	 * dimensions up to i and takes one new dimension per vector.
	 *
	 * @param m the number of dimensions of the embedding
	 *
	 * @return a triangular array of size m, where each entry Theta[i] is a i+1 dimensional vector
	 * with norm 1 and distance 1 to all other vectors. This forms a m-dimensional simplex or
	 * hyper-tetrahedron.
	 */
	public static double[][] defaultEmbedding(int m) {
		final double[][] Theta = new double[m][m];
		Theta[0][0] = 1;
		double acum = 0;
		for (int i = 0; i < m - 1; i++) {
			// compute the i+1-th embedding vector by first copying all coordinates up to i-1
			if (i > 0) {
				System.arraycopy(Theta[i], 0, Theta[i + 1], 0, i);
			}
			// then compute the ith coordinate as Theta[i][i] / (i + 2)
			Theta[i + 1][i] = Theta[i][i] / (i + 2);
			// finally, compute the i+1th coordinate such that the norm becomes 1
			acum += Theta[i + 1][i] * Theta[i + 1][i];
			Theta[i + 1][i + 1] = Math.sqrt(1 - acum);
		}
		return Theta;
	}

	/**
	 * Initializes a VectorEmbeddingComparator with the given embedding &Theta;
	 *
	 * @param Theta an embedding matrix.
	 */
	public VectorEmbeddingComparator(double[][] Theta) {
		setTheta(Theta);
	}

	@Override
	public double compare(OperationType type, Integer i, Integer j) {
		switch (type) {
			case DELETION:
				j = null;
				break;
			case INSERTION:
				i = null;
				break;
		}
		if (Objects.equals(i, j)) {
			return 0;
		}
		if (j == null) {
			return Z[i];
		}
		if (i == null) {
			return Z[j];
		}
		return D[i][j];
	}

	@Override
	public boolean supports(OperationType type) {
		switch (type) {
			case DELETIONREPLACEMENT:
			case INSERTIONREPLACEMENT:
			case REPLACEMENT:
			case INSERTION:
			case DELETION:
				return true;
			default:
				return false;
		}
	}

	@Override
	public boolean hasCoherentReplacementCost() {
		return true;
	}

	/**
	 * Computes the gradient of the Euclidean distance between Theta[i] and Theta[j] with respect
	 * to Theta. The gradient with respect to Theta[i] is:
	 *
	 * &nabla;<sub>Theta[i]</sub> |Theta[i] - Theta[j]|
	 * = 1 / (2 &middot; |Theta[i] - Theta[j]|) &middot;
	 * &nabla;<sub>Theta[i]</sub> |Theta[i] - Theta[j]|²
	 * = (Theta[i] - Theta[j]) / (|Theta[i] - Theta[j]|)
	 *
	 * Conversely, the gradient with respect to Theta[j] is:
	 *
	 * &nabla;<sub>Theta[j]</sub> |Theta[i] - Theta[j]|
	 * = 1 / (2 &middot; |Theta[i] - Theta[j]|) &middot;
	 * &nabla;<sub>Theta[j]</sub> |Theta[i] - Theta[j]|²
	 * = (Theta[j] - Theta[i]) / (|Theta[i] - Theta[j]|)
	 *
	 * With respect to all other rows of Theta, the gradient is zero.
	 *
	 * @param type the operation type
	 * @param i the left index
	 * @param j the right index
	 *
	 * @return (Theta[i] - Theta[j]) / (|Theta[i] - Theta[j]|) for Theta[i] and
	 * (Theta[j] - Theta[i]) / (|Theta[i] - Theta[j]|) for Theta[j].
	 */
	@Override
	public Gradient computeGradient(OperationType type, Integer i, Integer j) {
		switch (type) {
			case DELETION:
				j = null;
				break;
			case INSERTION:
				i = null;
				break;
		}
		if (Objects.equals(i, j)) {
			return new EmptyGradient();
		}
		if (j == null) {
			if (Z[i] > 0) {
				final double[] grad = new double[n];
				for (int k = 0; k < Theta[i].length; k++) {
					grad[k] = Theta[i][k] / Z[i];
				}
				return new VectorEmbeddingGradient(grad, i, -1, n);
			} else {
				return new EmptyGradient();
			}
		}
		if (i == null) {
			if (Z[j] > 0) {
				final double[] grad = new double[n];
				for (int k = 0; k < Theta[j].length; k++) {
					grad[k] = -Theta[j][k] / Z[j];
				}
				return new VectorEmbeddingGradient(grad, -1, j, n);
			} else {
				return new EmptyGradient();
			}
		}
		final double[] grad = new double[n];

		final int n_min;
		if (Theta[i].length >= Theta[j].length) {
			for (int k = Theta[j].length; k < Theta[i].length; k++) {
				grad[k] = Theta[i][k] / D[i][j];
			}
			n_min = Theta[j].length;
		} else {
			for (int k = Theta[i].length; k < Theta[j].length; k++) {
				grad[k] = -Theta[j][k] / D[i][j];
			}
			n_min = Theta[i].length;
		}

		for (int k = 0; k < n_min; k++) {
			grad[k] = (Theta[i][k] - Theta[j][k]) / D[i][j];
		}

		return new VectorEmbeddingGradient(grad, i, j, n);
	}

	/**
	 * Computes the gradient of the Euclidean distance between Theta[i] and Theta[j] with respect
	 * to Theta. The gradient with respect to Theta[i] is:
	 *
	 * &nabla;<sub>Theta[i]</sub> |Theta[i] - Theta[j]|
	 * = 1 / (2 &middot; |Theta[i] - Theta[j]|) &middot;
	 * &nabla;<sub>Theta[i]</sub> |Theta[i] - Theta[j]|²
	 * = (Theta[i] - Theta[j]) / (|Theta[i] - Theta[j]|)
	 *
	 * Conversely, the gradient with respect to Theta[j] is:
	 *
	 * &nabla;<sub>Theta[j]</sub> |Theta[i] - Theta[j]|
	 * = 1 / (2 &middot; |Theta[i] - Theta[j]|) &middot;
	 * &nabla;<sub>Theta[j]</sub> |Theta[i] - Theta[j]|²
	 * = (Theta[j] - Theta[i]) / (|Theta[i] - Theta[j]|)
	 *
	 * With respect to all other rows of Theta, the gradient is zero. So this method simply
	 * returns the vector
	 *
	 * (Theta[i] - Theta[j]) / (|Theta[i] - Theta[j]|)
	 *
	 * @param Theta the embedding matrix Theta.
	 * @param i the left index
	 * @param j the right index
	 * @param n the number of dimensions in the gradient. The gradient will be padded if necessary.
	 *
	 * @return (Theta[i] - Theta[j]) / (|Theta[i] - Theta[j]|)
	 */
	public static double[] computeGradient(final double[][] Theta, int i, int j, int n) {
		if (Theta[i].length < Theta[j].length) {
			double[] grad = computeGradient(Theta, j, i, n);
			for (int k = 0; k < grad.length; k++) {
				grad[k] = -grad[k];
			}
			return grad;
		}

		final int n_x = Theta[i].length;
		final int n_y = Theta[j].length;

		final double[] diff = new double[n];
		double Z = 0;
		for (int k = 0; k < n_y; k++) {
			diff[k] = Theta[i][k] - Theta[j][k];
			Z += diff[k] * diff[k];
		}
		for (int k = n_y; k < n_x; k++) {
			diff[k] = Theta[i][k];
			Z += diff[k] * diff[k];
		}
		// normalize by the norm
		Z = Math.sqrt(Z);
		for (int k = 0; k < n_x; k++) {
			diff[k] /= Z;
		}
		return diff;
	}

	@Override
	public VectorEmbeddingComparator copy() {
		return new VectorEmbeddingComparator(Theta);
	}

	public static class VectorEmbeddingGradient implements Gradient {

		private final double[] grad;
		private final int i;
		private final int j;
		private final int n;
		int k = 0;

		public VectorEmbeddingGradient(double[] grad, int i, int j, int n) {
			this.grad = grad;
			this.i = i;
			if (i == -1) {
				k = grad.length;
			}
			this.j = j;
			this.n = n;
		}

		@Override
		public int currentParameterIndex() {
			if (k < grad.length) {
				return i * n + k;
			} else {
				return j * n + k - grad.length;
			}
		}

		@Override
		public double currentValue() {
			if (k < grad.length) {
				return grad[k];
			} else {
				if (j < 0) {
					throw new ArrayIndexOutOfBoundsException("Gradient is empty!");
				}
				return -grad[k - grad.length];
			}
		}

		@Override
		public void next() {
			k++;
		}

		@Override
		public boolean notEmpty() {
			return k < grad.length || (j >= 0 && k < 2 * grad.length);
		}

	}

	@Override
	public int getNumberOfParameters() {
		return Theta.length * n;
	}

	@Override
	public double[] getParameters() {
		return matrixToVector(Theta);
	}

	@Override
	public void setParameters(double[] params) {
		setTheta(vectorToMatrix(params, this.Theta.length));
	}

	/**
	 * Returns the vector embedding for all indices.
	 *
	 * @return the vector embedding for all indices.
	 */
	public double[][] getTheta() {
		return Theta;
	}

	/**
	 * Sets the vector embedding for all indices.
	 *
	 * @param Theta the vector embedding for all indices.
	 */
	public final void setTheta(double[][] Theta) {
		this.Theta = Theta;
		this.n = Theta[0].length;
		for (final double[] row : Theta) {
			if (row.length != n) {
				throw new IllegalArgumentException("Expected a consistent embedding dimension!");
			}
		}
		final int m = Theta.length;
		this.Z = new double[m];
		this.D = new double[m][m];
		for (int i = 0; i < m; i++) {
			this.Z[i] = norm(Theta[i]);
			for (int j = i + 1; j < m; j++) {
				this.D[i][j] = distance(Theta[i], Theta[j]);
				this.D[j][i] = this.D[i][j];
			}
		}
	}

	/**
	 * Returns the matrix of pairwise distances for the current embedding Theta.
	 *
	 * @return the matrix of pairwise distances for the current embedding Theta.
	 */
	public double[][] getDistanceMatrix() {
		return D;
	}

	/**
	 * Returns the vector of norms for the current embedding Theta.
	 *
	 * @return the vector of norms for the current embedding Theta.
	 */
	public double[] getNorms() {
		return Z;
	}

	/**
	 * Computes the Euclidean distance between the given vectors x and y.
	 *
	 * @param x a vector.
	 * @param y another vector.
	 *
	 * @return the Euclidean distance between the given vectors x and y.
	 */
	public static double distance(double[] x, double[] y) {
		if (x.length != y.length) {
			throw new IllegalArgumentException("Expected input vectors of the same length!");
		}
		double sum = 0;
		double diff;
		for (int i = 0; i < x.length; i++) {
			diff = x[i] - y[i];
			sum += diff * diff;
		}
		return Math.sqrt(sum);
	}

	/**
	 * Computes the Euclidean norm of the given vector.
	 *
	 * @param x a vector.
	 *
	 * @return the Euclidean norm of the given vector.
	 */
	public static double norm(double[] x) {
		double sum = 0;
		for (int i = 0; i < x.length; i++) {
			sum += x[i] * x[i];
		}
		return Math.sqrt(sum);
	}

	/**
	 * Converts a given vector to a matrix with m rows by assuming that the given vector contains
	 * the m rows in concatenated form.
	 *
	 * @param thetas a vector with m concatenated rows.
	 * @param m the number of rows for the resulting matrix.
	 *
	 * @return a matrix with m rows.
	 */
	public static double[][] vectorToMatrix(final double[] thetas, final int m) {
		// we assume that the parameters are concatenated rows
		if (thetas.length % m != 0) {
			throw new IllegalArgumentException("The length of the input array is not divisible by m");
		}
		final int n = thetas.length / m;
		final double[][] Theta = new double[m][n];
		for (int i = 0; i < m; i++) {
			System.arraycopy(thetas, i * n, Theta[i], 0, n);
		}
		return Theta;
	}

	/**
	 * Converts the given matrix to a vector by concatenating all rows. If the rows have different
	 * length, they get padded with zeros.
	 *
	 * @param Theta a matrix.
	 *
	 * @return a vector of concatenated rows.
	 */
	public static double[] matrixToVector(final double[][] Theta) {
		final int m = Theta.length;
		// retrieve the maximum number of columns
		int n = 0;
		for (final double[] row : Theta) {
			if (row.length > n) {
				n = row.length;
			}
		}
		// then generate the vector.
		final double[] thetas = new double[m * n];
		for (int i = 0; i < m; i++) {
			System.arraycopy(Theta[i], 0, thetas, i * n, Theta[i].length);
		}
		return thetas;
	}

	/**
	 * Preprocesses a given tree to be a tree of symbol indices instead of symbols.
	 *
	 * @param <X> the symbol class.
	 * @param tree a tree.
	 * @param idxFun an IndexingFunction for the given symbol class.
	 *
	 * @return an index tree.
	 */
	public static <X> Tree<Integer> indexTree(Tree<X> tree, IndexingFunction<X> idxFun) {
		final Tree<Integer> idxTree = new TreeImpl<>(idxFun.index(tree.getLabel()));
		for (final Tree<X> child : tree.getChildren()) {
			idxTree.getChildren().add(indexTree(child, idxFun));
		}
		return idxTree;
	}

	/**
	 * Preprocesses a given forest to be a forest of symbol indices instead of symbols.
	 *
	 * @param <X> the symbol class.
	 * @param forest a forest.
	 * @param idxFun an IndexingFunction for the given symbol class.
	 *
	 * @return an index forest.
	 */
	public static <X> List<Tree<Integer>> indexForest(List<Tree<X>> forest, IndexingFunction<X> idxFun) {
		final ArrayList<Tree<Integer>> idxForest = new ArrayList<>(forest.size());
		for (final Tree<X> tree : forest) {
			idxForest.add(indexTree(tree, idxFun));
		}
		return idxForest;
	}

}
