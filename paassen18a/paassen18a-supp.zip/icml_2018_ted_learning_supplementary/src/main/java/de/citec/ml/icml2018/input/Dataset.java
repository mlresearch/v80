/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.input;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class Dataset<X> {

	public final List<X> data;
	public final List<String> names;
	public final List<Integer> labels;
	public final Map<Integer, String> classNames;

	public Dataset() {
		this.data = new ArrayList<>();
		this.names = new ArrayList<>();
		this.labels = new ArrayList<>();
		this.classNames = new TreeMap<>();
	}

	public Dataset(List<X> data, List<String> names, List<Integer> labels, Map<Integer, String> classNames) {
		if (data.size() != names.size()) {
			throw new IllegalArgumentException(
					"Expected one name for each data point, but got "
					+ data.size() + " sequences and "
					+ names.size() + " labels!");
		}
		if (data.size() != labels.size()) {
			throw new IllegalArgumentException(
					"Expected one label for each data point, but got "
					+ data.size() + " sequences and "
					+ labels.size() + " labels!");
		}
		// ensure that a name for each label exists
		for (final Integer label : labels) {
			if (!classNames.containsKey(label)) {
				throw new IllegalArgumentException("The class name for label " + label + " is missing!");
			}
		}
		this.data = data;
		this.names = names;
		this.labels = labels;
		this.classNames = classNames;
	}

	public int size() {
		return this.data.size();
	}

	public void addPoint(X datum, int label, String name) {
		this.data.add(datum);
		this.labels.add(label);
		this.names.add(name);
	}

	public static interface Labeling {

		public int label(File file);
	}

	public static interface ParsingFunction<X> {

		public X parse(File file) throws IOException;
	}

	public static interface Naming {

		public String name(File file);
	}

	public static Map<String, Integer> nameToLabel(String[] classNames) {
		final TreeMap<String, Integer> nameToLabel = new TreeMap<>();
		for (int l = 0; l < classNames.length; l++) {
			nameToLabel.put(classNames[l], l);
		}
		return nameToLabel;
	}

	public static Map<Integer, String> labelToName(String[] classNames) {
		final TreeMap<Integer, String> labelToName = new TreeMap<>();
		for (int l = 0; l < classNames.length; l++) {
			labelToName.put(l, classNames[l]);
		}
		return labelToName;
	}

	public static <X> void readDataFolder(Dataset<X> dataset, File folder,
			FileFilter fileFilter, Labeling labeling, ParsingFunction<X> parse) {
		readDataFolder(dataset, folder, fileFilter, labeling, new Naming() {

			@Override
			public String name(File file) {
				return file.getName().substring(0, file.getName().lastIndexOf('.'));
			}
		}, parse);
	}

	public static <X> void readDataFolder(Dataset<X> dataset, File folder,
			FileFilter fileFilter, Labeling labeling, Naming naming, ParsingFunction<X> parse) {
		if (!folder.exists() || !folder.isDirectory()) {
			throw new IllegalArgumentException(folder.getAbsolutePath() + " does not exist or is no directory!");
		}
		final File[] files = folder.listFiles(fileFilter);
		// sort alphabetically
		Arrays.sort(files);
		// parse
		for (final File file : files) {
			System.out.println("Processing: " + file.getAbsolutePath());
			dataset.labels.add(labeling.label(file));
			dataset.names.add(naming.name(file));
			final X datum;
			try {
				datum = parse.parse(file);
			} catch (IOException ex) {
				throw new RuntimeException(ex);
			}
			dataset.data.add(datum);
		}
	}

	public static int[] collectionToPrimitiveArr(Collection<? extends Integer> col) {
		final int[] arr = new int[col.size()];
		int i = 0;
		for (final Integer n : col) {
			arr[i++] = n;
		}
		return arr;
	}
}
