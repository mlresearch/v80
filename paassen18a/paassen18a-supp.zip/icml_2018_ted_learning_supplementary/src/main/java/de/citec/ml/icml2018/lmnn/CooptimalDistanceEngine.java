/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.lmnn;

import de.citec.tcs.alignment.Alignment;
import de.citec.tcs.alignment.comparators.Comparator;
import de.citec.tcs.alignment.parallel.MatrixEngine;
import de.citec.tcs.alignment.trees.CooptimalMatrix;
import java.util.concurrent.Callable;

/**
 * Computes the edit distance based on given co-optimals in parallel.
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class CooptimalDistanceEngine<X, Y> extends MatrixEngine<Double> {

	private final CooptimalMatrix[][] cooptimals;
	private final Comparator<X, Y> comp;

	public CooptimalDistanceEngine(CooptimalMatrix[][] cooptimals, Comparator<X, Y> comp) {
		super(cooptimals.length, cooptimals[0].length, Double.class);
		this.cooptimals = cooptimals;
		this.comp = comp;
	}

	public CooptimalDistanceEngine(Alignment[][] alignments, Comparator<X, Y> comp) {
		super(alignments.length, alignments[0].length, Double.class);
		this.cooptimals = new CooptimalMatrix[alignments.length][alignments[0].length];
		for (int i = 0; i < alignments.length; i++) {
			for (int j = 0; j < alignments[i].length; j++) {
				this.cooptimals[i][j] = CooptimalMatrix.fromAlignment(alignments[i][j]);
			}
		}
		this.comp = comp;
	}

	@Override
	public Callable<Double> createCallable(MatrixCoordinate ident) {
		return new CooptimalDistanceCallable<>(cooptimals[ident.i][ident.j], comp);
	}

	public Comparator<X, Y> getComparator() {
		return comp;
	}

	private static class CooptimalDistanceCallable<X, Y> implements Callable<Double> {

		private final CooptimalMatrix<X, Y> coopt;
		private final Comparator<X, Y> comp;

		public CooptimalDistanceCallable(CooptimalMatrix<X, Y> coopt, Comparator<X, Y> comp) {
			this.coopt = coopt;
			this.comp = comp;
		}

		@Override
		public Double call() throws Exception {
			return coopt.editDistance(comp);
		}

	}

}
