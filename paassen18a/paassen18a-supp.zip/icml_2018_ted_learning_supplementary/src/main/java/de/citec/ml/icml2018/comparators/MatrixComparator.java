/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.comparators;

import de.citec.tcs.alignment.comparators.DerivableComparator;
import de.citec.tcs.alignment.comparators.EmptyGradient;
import de.citec.tcs.alignment.comparators.Gradient;
import de.citec.tcs.alignment.comparators.OperationType;
import de.citec.tcs.alignment.comparators.SingletonGradient;
import java.util.Arrays;

/**
 * Compares two indices i and j by retrieving an explicit cost value C[i][j] from a matrix.
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class MatrixComparator implements DerivableComparator<Integer, Integer>, Copyable<MatrixComparator> {

	private int m;
	private double[] delCosts;
	private double[] insCosts;
	private double[][] repCosts;

	public MatrixComparator(int m) {
		this.m = m;
		this.delCosts = new double[m];
		Arrays.fill(this.delCosts, 1);
		this.insCosts = new double[m];
		Arrays.fill(this.insCosts, 1);
		this.repCosts = new double[m][m];
		for (int i = 0; i < m; i++) {
			for (int j = i + 1; j < m; j++) {
				this.repCosts[i][j] = 1;
				this.repCosts[j][i] = 1;
			}
		}
	}

	public MatrixComparator(double[] delCosts, double[] insCosts, double[][] repCosts) {
		this.m = delCosts.length;
		this.delCosts = delCosts;
		if (insCosts.length != m) {
			throw new IllegalArgumentException("Expected as many deletion as insertion costs but got "
					+ m + " deletion costs and " + insCosts.length + " insertion costs!");
		}
		this.insCosts = insCosts;
		if (repCosts.length != m) {
			throw new IllegalArgumentException("Expected as many replacement cost matrix rows as insertion costs but got "
					+ repCosts.length + " rows in the replacement cost matrix and " + insCosts.length + " insertion costs!");
		}
		for (int i = 0; i < m; i++) {
			if (repCosts[i].length != m) {
				throw new IllegalArgumentException("Expected as many replacement cost matrix columns as insertion costs but got "
						+ repCosts[i].length + " columns in row " + i + " of the replacement cost matrix and "
						+ insCosts.length + " insertion costs!");
			}
		}
		this.repCosts = repCosts;
	}

	public MatrixComparator(double[][] C) {
		setCostMatrix(C);
	}

	@Override
	public double compare(OperationType type, Integer i, Integer j) {
		switch (type) {
			case DELETION:
				j = null;
				break;
			case INSERTION:
				i = null;
				break;
		}
		if (i == null) {
			if (j == null) {
				return 0.;
			}
			return insCosts[j];
		}
		if (j == null) {
			return delCosts[i];
		}
		return repCosts[i][j];
	}

	@Override
	public boolean supports(OperationType type) {
		switch (type) {
			case DELETION:
			case INSERTION:
			case DELETIONREPLACEMENT:
			case INSERTIONREPLACEMENT:
			case REPLACEMENT:
				return true;
			default:
				return false;
		}
	}

	@Override
	public boolean hasCoherentReplacementCost() {
		return true;
	}

	@Override
	public Gradient computeGradient(OperationType type, Integer i, Integer j) {

		switch (type) {
			case DELETION:
				j = null;
				break;
			case INSERTION:
				i = null;
				break;
		}
		if (i == null) {
			if (j == null) {
				return new EmptyGradient();
			}
			return new SingletonGradient(m * m + m + j, 1);
		}
		if (j == null) {
			return new SingletonGradient(m * m + i, 1);
		}
		return new SingletonGradient(m * i + j, 1);
	}

	@Override
	public int getNumberOfParameters() {
		return m * m + 2 * m;
	}

	public final double[][] getCostMatrix() {
		final double[][] C = new double[m + 1][m + 1];
		C[m][m] = Double.NaN;
		for (int i = 0; i < m; i++) {
			System.arraycopy(repCosts[i], 0, C[i], 0, m);
			C[i][m] = delCosts[i];
		}
		System.arraycopy(insCosts, 0, C[m], 0, m);
		return C;
	}

	public final void setCostMatrix(double[][] C) {
		// check input
		for (int i = 0; i < C.length; i++) {
			if (C[i].length != C.length) {
				throw new IllegalArgumentException("Expected square matrix!");
			}
			for (int j = 0; j < C.length; j++) {
				if (C[i][j] < 0) {
					throw new IllegalArgumentException("A cost matrix may not contain negative entries!");
				}
			}
		}

		this.m = C.length - 1;
		this.repCosts = new double[m][m];
		this.delCosts = new double[m];
		this.insCosts = new double[m];
		for (int i = 0; i < m; i++) {
			System.arraycopy(C[i], 0, this.repCosts[i], 0, m);
			this.delCosts[i] = C[i][m];
		}
		System.arraycopy(C[m], 0, this.insCosts, 0, m);
	}

	public static double[] normalizeParameters(double[] params) {
		final int m = (int) (Math.floor(Math.sqrt(params.length)));
		// transform to cost matrix
		final MatrixComparator instance = new MatrixComparator(m);
		instance.setParameters(params);
		final double[][] C = instance.getCostMatrix();
		// normalize
		normalizeCostMatrix(C);
		// transform back and return
		instance.setCostMatrix(C);
		return instance.getParameters();
	}

	public static double[][] normalizeCostMatrix(double[][] C) {
		final int m = C.length;
		for (int i = 0; i < m; i++) {
			if (C[i].length != m) {
				throw new IllegalArgumentException("Expected a square cost matrix as input!");
			}
		}
		// symmetrize and find minimum
		double min = 0;
		for (int i = 0; i < m; i++) {
			for (int j = i + 1; j < m; j++) {
				C[i][j] = 0.5 * (C[i][j] + C[j][i]);
				C[j][i] = C[i][j];
				if (C[i][j] < min) {
					min = C[i][j];
				}
			}
		}
		if (min < 0) {
			for (int i = 0; i < m; i++) {
				for (int j = 0; j < m; j++) {
					if (i == j) {
						// set diagonal to zero
						C[i][j] = 0;
					} else {
						// subtract minimum to avoid negative entries
						C[i][j] -= min;
					}
				}
			}
		} else {
			for (int i = 0; i < m; i++) {
				// set diagonal to zero
				C[i][i] = 0;
			}
		}
		// perform Floyd-Warshall algorithm to ensure triangular inequality
		for (int k = 0; k < m; k++) {
			for (int i = 0; i < m; i++) {
				if (i == k) {
					continue;
				}
				for (int j = i + 1; j < m; j++) {
					if (C[i][k] + C[k][j] < C[i][j]) {
						C[i][j] = C[i][k] + C[k][j];
						C[j][i] = C[i][j];
					}
				}
			}
		}
		return C;
	}

	@Override
	public double[] getParameters() {
		final double[] params = new double[m * m + 2 * m];
		for (int i = 0; i < m; i++) {
			System.arraycopy(this.repCosts[i], 0, params, m * i, m);
		}
		System.arraycopy(this.delCosts, 0, params, m * m, m);
		System.arraycopy(this.insCosts, 0, params, m * m + m, m);
		return params;
	}

	@Override
	public void setParameters(double[] params) {
		for (int i = 0; i < m; i++) {
			System.arraycopy(params, m * i, this.repCosts[i], 0, m);
		}
		System.arraycopy(params, m * m, this.delCosts, 0, m);
		System.arraycopy(params, m * m + m, this.insCosts, 0, m);

	}

	@Override
	public MatrixComparator copy() {
		return new MatrixComparator(delCosts, insCosts, repCosts);
	}

}
