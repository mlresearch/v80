/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.comparators;

import de.citec.tcs.alignment.comparators.ArrayGradient;
import de.citec.tcs.alignment.comparators.DerivableComparator;
import de.citec.tcs.alignment.comparators.EmptyGradient;
import de.citec.tcs.alignment.comparators.Gradient;
import de.citec.tcs.alignment.comparators.OperationType;

/**
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class CosineDistanceComparator implements DerivableComparator<double[], double[]>, Copyable<CosineDistanceComparator> {

	private double[][] Omega;
	private int m;

	public CosineDistanceComparator(int m) {
		if (m < 1) {
			throw new IllegalArgumentException("Expected at least one dimension!");
		}
		// use the identity matrix per default
		this.m = m;
		this.Omega = new double[m][m];
		for (int i = 0; i < m; i++) {
			this.Omega[i][i] = 1;
		}
	}

	public CosineDistanceComparator(int n, int m) {
		if (n < 1) {
			throw new IllegalArgumentException("Expected at least one target dimension!");
		}
		if (n > m) {
			throw new IllegalArgumentException("The target dimension may be at most as big as the original dimension!");
		}
		// use an identity matrix for the first n dimensions
		this.m = m;
		this.Omega = new double[n][m];
		for (int i = 0; i < n; i++) {
			this.Omega[i][i] = 1;
		}
	}

	public CosineDistanceComparator(double[][] Omega) {
		setOmega(Omega);
	}

	public double[][] getOmega() {
		return Omega;
	}

	public final void setOmega(double[][] Omega) {
		this.m = Omega[0].length;
		this.Omega = Omega;
		for (int i = 0; i < Omega.length; i++) {
			if (Omega[i].length != this.m) {
				throw new IllegalArgumentException("Inconsistent embedding dimension!");
			}
		}
	}

	public int getM() {
		return m;
	}

	@Override
	public double compare(OperationType type, double[] x, double[] y) {
		switch (type) {
			case DELETION:
				y = null;
				break;
			case INSERTION:
				x = null;
				break;
		}
		if (x == null) {
			if (y == null) {
				return 0;
			}
			return 0.5;
		}
		if (y == null) {
			return 0.5;
		}
		return cosine_distance(x, y, Omega);
	}

	private static final double TOL = 1E-3;

	public static double cosine_distance(double[] x, double[] y, double[][] Omega) {
		final double s = cosine_similarity(x, y, Omega);
		final double d = 0.5 * (1 - s);
		if (d < TOL) {
			return 0;
		}
		if (d >= 1) {
			return 1;
		}
		return d;
	}

	public static double cosine_similarity(double[] x, double[] y, double[][] Omega) {
		// handle the special case of null vectors
		double Zx = 0;
		double Zy = 0;
		for (int i = 0; i < x.length; i++) {
			Zx += x[i] * x[i];
			Zy += y[i] * y[i];
		}
		if (Zx < TOL) {
			if (Zy < TOL) {
				return 1;
			}
			return 0;
		} else if (Zy < TOL) {
			return 0;
		}

		final double[] x2 = matrix_multiply(Omega, x);
		final double[] y2 = matrix_multiply(Omega, y);
		return cosine_similarity(x2, y2);
	}

	public static double cosine_similarity(double[] x, double[] y) {
		if (x.length != y.length) {
			throw new IllegalArgumentException("Input vectors had different length!");
		}

		double prod = 0;
		double Zx = 0;
		double Zy = 0;

		for (int i = 0; i < x.length; i++) {
			prod += x[i] * y[i];
			Zx += x[i] * x[i];
			Zy += y[i] * y[i];
		}
		if (Zx < TOL) {
			if (Zy < TOL) {
				return 1;
			}
			return 0;
		} else if (Zy < TOL) {
			return 0;
		}
		return prod / (Math.sqrt(Zx) * Math.sqrt(Zy));
	}

	public static double[] matrix_multiply(double[][] Omega, double[] x) {
		final double[] x2 = new double[Omega.length];
		for (int i = 0; i < Omega.length; i++) {
			if (Omega[i].length != x.length) {
				throw new IllegalArgumentException("In the " + i + "th output dimension, "
						+ "Omega expected length " + Omega[i].length + " but "
						+ "the input vector has length " + x.length);
			}
			for (int j = 0; j < Omega[i].length; j++) {
				x2[i] += Omega[i][j] * x[j];
			}
		}
		return x2;
	}

	@Override
	public boolean supports(OperationType type) {
		switch (type) {
			case DELETIONREPLACEMENT:
			case INSERTIONREPLACEMENT:
			case REPLACEMENT:
			case INSERTION:
			case DELETION:
				return true;
			default:
				return false;
		}
	}

	@Override
	public boolean hasCoherentReplacementCost() {
		return true;
	}

	@Override
	public Gradient computeGradient(OperationType type, double[] x, double[] y) {
		switch (type) {
			case DELETION:
				y = null;
				break;
			case INSERTION:
				x = null;
				break;
		}
		if (x == null || y == null) {
			return new EmptyGradient();
		}

		// handle the special case of null vectors
		{
			double Zx = 0;
			double Zy = 0;
			for (int i = 0; i < x.length; i++) {
				Zx += x[i] * x[i];
				Zy += y[i] * y[i];
			}
			if (Zx < TOL || Zy < TOL) {
				return new EmptyGradient();
			}
		}

		// transform the input vectors using Omega
		final double[] x2 = matrix_multiply(Omega, x);
		final double[] y2 = matrix_multiply(Omega, y);

		// compute the cosine similarity of x2 and y2.
		double prod = 0;
		double Zx = 0;
		double Zy = 0;

		for (int i = 0; i < x2.length; i++) {
			prod += x2[i] * y2[i];
			Zx += x2[i] * x2[i];
			Zy += y2[i] * y2[i];
		}
		if (Zx < TOL || Zy < TOL) {
			// the gradient is zero if at least one vector is the zero vector.
			return new EmptyGradient();
		}
		Zx = Math.sqrt(Zx);
		Zy = Math.sqrt(Zy);
		final double s = prod / (Zx * Zy);
		if (s > 1 - TOL || s < -1 + TOL) {
			// the gradient is also zero if the cosine similarity is 1 or -1
			return new EmptyGradient();
		}

		// if no trivial case occured, we need to compute the actual gradient formula.
		// compute the constant factor in front
		final double factor = -1. / (2 * Zx * Zy);
		// the entries of the gradient matrix are computed via outer products
		final double[] grad = new double[Omega.length * m];
		for (int i = 0; i < Omega.length; i++) {
			for (int j = 0; j < m; j++) {
				grad[i * m + j] = factor * (x2[i] * y[j] + y2[i] * x[j] - s * (x2[i] * x[j] * Zy / Zx + y2[i] * y[j] * Zx / Zy));
			}
		}
		return new ArrayGradient(grad);
	}

	@Override
	public int getNumberOfParameters() {
		return Omega.length * m;
	}

	@Override
	public double[] getParameters() {
		return matrixToVector(Omega);
	}

	@Override
	public void setParameters(double[] params) {
		setOmega(vectorToMatrix(params, m));
	}

	/**
	 * Converts a given vector to a matrix with m rows by assuming that the given vector contains
	 * the m rows in concatenated form.
	 *
	 * @param omega a vector with m concatenated rows.
	 * @param m the number of columns for the resulting matrix.
	 *
	 * @return a matrix with m rows.
	 */
	public static double[][] vectorToMatrix(final double[] omega, final int m) {
		// we assume that the parameters are concatenated rows
		if (omega.length % m != 0) {
			throw new IllegalArgumentException("The length of the input array (" + omega.length + ") is not divisible by m = " + m);
		}
		final int n = omega.length / m;
		final double[][] Omega = new double[n][m];
		for (int i = 0; i < n; i++) {
			System.arraycopy(omega, i * m, Omega[i], 0, m);
		}
		return Omega;
	}

	/**
	 * Converts the given matrix to a vector by concatenating all rows. If the rows have different
	 * length, they get padded with zeros.
	 *
	 * @param Omega a matrix.
	 *
	 * @return a vector of concatenated rows.
	 */
	public static double[] matrixToVector(final double[][] Omega) {
		final int m = Omega.length;
		// retrieve the maximum number of columns
		int n = 0;
		for (final double[] row : Omega) {
			if (row.length > n) {
				n = row.length;
			}
		}
		// then generate the vector.
		final double[] omega = new double[m * n];
		for (int i = 0; i < m; i++) {
			System.arraycopy(Omega[i], 0, omega, i * n, Omega[i].length);
		}
		return omega;
	}

	@Override
	public CosineDistanceComparator copy() {
		return new CosineDistanceComparator(Omega);
	}

}
