/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.gesl;

import de.citec.ml.icml2018.gesl.GESLGradientCalculator.CooptimalFunction;
import de.citec.ml.icml2018.gesl.GESLLinearProgram.IndexMatrix;
import de.citec.ml.icml2018.gesl.GESLLinearProgram.SparseEntry;
import de.citec.tcs.alignment.Alignment;
import de.citec.tcs.alignment.AlignmentAlgorithm;
import de.citec.tcs.alignment.parallel.MatrixEngine;
import de.citec.tcs.alignment.trees.CooptimalMatrix;
import de.citec.tcs.alignment.trees.Tree;
import de.citec.tcs.alignment.trees.TreeEditAlgorithm;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * A standard form representation of the Good Edit Similarity Learning (GESL, Bellet, 2012) linear
 * program, using prototypes as neighbors.
 *
 * min<sub>C, &nu;</sub> &Sigma;<sub>i=1</sub><sup>m</sup>
 * [C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu;]<sub>+</sub> +
 * [&nu; + log(2) - C * coopts(i, w<sub>i</sub><sup>-</sup>)]<sub>+</sub>
 *
 * subject to
 *
 * C, &nu; &ge; 0 and &nu; &le; log(2)
 *
 * where C is the (symmetric, zero-diagonal) matrix of pairwise symbol edit costs,
 * coopts(i, w) denotes a CooptimalMatrix between trees i and w, w<sub>i</sub><sup>+</sup>
 * denotes the index of the closest prototype to i with the same label,
 * w<sub>i</sub><sup>-</sup> denotes the index of the closest prototype to i with
 * a <em>different</em> label, C * coopts denotes the scalar-product of the vectorized versions
 * of the matrices C and coopts and &nu; is a margin variable.
 *
 * Note that this linear program has effectively more variables than the entries of C and &nu;.
 * In particular, we need one slack variable for each hinge loss, resulting in (n+1) * n / 2 +
 * 2 * m + 1 variables overall for n symbols and m data points.
 *
 * The linear program further has 2*m inequality constraints and lower/upper bound constraints
 * for all variables. In particular, we have m inequality constraints of the form
 *
 * C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu; &le; &xi;<sub>i</sub><sup>+</sup>
 * &hArr; C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu; - &xi;<sub>i</sub><sup>+</sup> &le; 0
 *
 * where &xi;<sub>i</sub><sup>+</sup> is the slack variable for the hinge loss of i to the
 * closest prototype from the same class; and we have m inequality constraints of the form
 *
 * &nu; + log(2) - C * coopts(i, w<sub>i</sub><sup>-</sup>) &le; &xi;<sub>i</sub><sup>-</sup>
 * &hArr; &nu; - C * coopts(i, w<sub>i</sub><sup>-</sup>) - &xi;<sub>i</sub><sup>-</sup> &le;
 * - log(2)
 *
 * where &xi;<sub>i</sub><sup>-</sup> is the slack variable for the hinge loss of i to the
 * closest prototype from a different class.
 *
 * The lower bound for all variables is 0, the upper bound for all variables except &nu; is
 * infinity, and the upper bound for &nu; is log(2).
 *
 * @author Benjamin Paassen - bpaassen@techfak.uni-bielefeld.de
 */
public class GESLPrototypeLinearProgram {

	public final double[] f;
	public final IndexMatrix A;
	public final double[] b;
	public final double[] lb;
	public final double[] ub;

	private GESLPrototypeLinearProgram(double[] f, IndexMatrix A, double[] b, double[] lb, double[] ub) {
		this.f = f;
		this.A = A;
		this.b = b;
		this.lb = lb;
		this.ub = ub;
	}

	/**
	 * Initializes a GESLLinearProgram calculator by selecting the closest correct and closest wrong
	 * prototype, computing the edit scripts to them and transforming those scripts into
	 * coefficients of the linear program.
	 *
	 * For m data points and n symbols, the linear program has 2*m + n*(n-1)/2 + 1 variables,
	 * namely n*(n-1)/2 entries in the pairwise symbol replacement matric C which we expect to be
	 * symmetric with zeros on the diagonal, m slack variables representing the hinge loss to
	 * the closest correct prototype
	 *
	 * [C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu;]<sub>+</sub>
	 *
	 * m slack variables representing the hinge loss to the closest wrong prototype
	 *
	 * [&nu; + log(2) - C * coopts(i, w<sub>i</sub><sup>-</sup>)]<sub>+</sub>
	 *
	 * and 1 slack variable representing the shift in the margin &nu;, that is, whether we want
	 * data points of the same class to be closer or data points from different classes to be
	 * further away.
	 *
	 * The linear program further has 2*m inequality constraints and lower/upper bound constraints
	 * for all variables. In particular, we have m inequality constraints of the form
	 *
	 * C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu; &le; &xi;<sub>i</sub><sup>+</sup>
	 * &hArr; C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu; - &xi;<sub>i</sub><sup>+</sup> &le; 0
	 *
	 * where &xi;<sub>i</sub><sup>+</sup> is the slack variable for the hinge loss of i to the
	 * closest prototype from the same class; and we have m inequality constraints of the form
	 *
	 * &nu; + log(2) - C * coopts(i, w<sub>i</sub><sup>-</sup>) &le; &xi;<sub>i</sub><sup>-</sup>
	 * &hArr; &nu; - C * coopts(i, w<sub>i</sub><sup>-</sup>) - &xi;<sub>i</sub><sup>-</sup> &le;
	 * - log(2)
	 *
	 * where &xi;<sub>i</sub><sup>-</sup> is the slack variable for the hinge loss of i to the
	 * closest prototype from a different class.
	 *
	 * The lower bound for all variables is 0, the upper bound for all variables except &nu; is
	 * infinity, and the upper bound for &nu; is log(2).
	 *
	 * @param <X> the data class
	 * @param D the m x K distance matrix of tree edit distances from all data points to all
	 * prototypes.
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param full_algo an AlignmentAlgorithm which returns Alignments
	 * @param data the m-element list of data points.
	 * @param n the size of the alphabet.
	 * @param W the prototypes that should be considered, that is, a K x 1 vector of data point
	 * indices which are 'prototypical' for their respective class, chosen e.g. via median learning
	 * vector quantization.
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLLinearProgram corresponding to the given inputs.
	 */
	public static <X> GESLPrototypeLinearProgram fromAlignmentAlgorithm(double[][] D, int[] labels,
			final AlignmentAlgorithm<X, X, Alignment> full_algo, List<List<X>> data, final int n,
			final int[] W, int numberOfThreads) {
		return initialize(D, labels, new GESLGradientCalculator.CooptimalFunction<List<X>>() {

			@Override
			public CooptimalMatrix compute(List<X> left, List<X> right) {
				final Alignment ali = full_algo.calculateAlignment(left, right);
				return CooptimalMatrix.fromAlignment(ali);
			}
		}, data, n, W, numberOfThreads);
	}

	/**
	 * Initializes a GESLLinearProgram calculator by selecting the closest correct and closest wrong
	 * prototype, computing the edit scripts to them and transforming those scripts into
	 * coefficients of the linear program.
	 *
	 * For m data points and n symbols, the linear program has 2*m + n*(n-1)/2 + 1 variables,
	 * namely n*(n-1)/2 entries in the pairwise symbol replacement matric C which we expect to be
	 * symmetric with zeros on the diagonal, m slack variables representing the hinge loss to
	 * the closest correct prototype
	 *
	 * [C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu;]<sub>+</sub>
	 *
	 * m slack variables representing the hinge loss to the closest wrong prototype
	 *
	 * [&nu; + log(2) - C * coopts(i, w<sub>i</sub><sup>-</sup>)]<sub>+</sub>
	 *
	 * and 1 slack variable representing the shift in the margin &nu;, that is, whether we want
	 * data points of the same class to be closer or data points from different classes to be
	 * further away.
	 *
	 * The linear program further has 2*m inequality constraints and lower/upper bound constraints
	 * for all variables. In particular, we have m inequality constraints of the form
	 *
	 * C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu; &le; &xi;<sub>i</sub><sup>+</sup>
	 * &hArr; C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu; - &xi;<sub>i</sub><sup>+</sup> &le; 0
	 *
	 * where &xi;<sub>i</sub><sup>+</sup> is the slack variable for the hinge loss of i to the
	 * closest prototype from the same class; and we have m inequality constraints of the form
	 *
	 * &nu; + log(2) - C * coopts(i, w<sub>i</sub><sup>-</sup>) &le; &xi;<sub>i</sub><sup>-</sup>
	 * &hArr; &nu; - C * coopts(i, w<sub>i</sub><sup>-</sup>) - &xi;<sub>i</sub><sup>-</sup> &le;
	 * - log(2)
	 *
	 * where &xi;<sub>i</sub><sup>-</sup> is the slack variable for the hinge loss of i to the
	 * closest prototype from a different class.
	 *
	 * The lower bound for all variables is 0, the upper bound for all variables except &nu; is
	 * infinity, and the upper bound for &nu; is log(2).
	 *
	 * @param <X> the data class
	 * @param D the m x K distance matrix of tree edit distances from all data points to all
	 * prototypes.
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param coopt_algo an AlignmentAlgorithm which returns CooptimalMatrices.
	 * @param data the m-element list of data points.
	 * @param n the size of the alphabet.
	 * @param W the prototypes that should be considered, that is, a K x 1 vector of data point
	 * indices which are 'prototypical' for their respective class, chosen e.g. via median learning
	 * vector quantization.
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLLinearProgram corresponding to the given inputs.
	 */
	public static <X> GESLPrototypeLinearProgram fromCooptimalAlgorithm(double[][] D, int[] labels,
			final AlignmentAlgorithm<X, X, CooptimalMatrix> coopt_algo, List<List<X>> data,
			final int n, final int[] W, int numberOfThreads) {
		return initialize(D, labels, new GESLGradientCalculator.CooptimalFunction<List<X>>() {

			@Override
			public CooptimalMatrix compute(List<X> left, List<X> right) {
				return coopt_algo.calculateAlignment(left, right);
			}
		}, data, n, W, numberOfThreads);
	}

	/**
	 * Initializes a GESLLinearProgram calculator by selecting the closest correct and closest wrong
	 * prototype, computing the edit scripts to them and transforming those scripts into
	 * coefficients of the linear program.
	 *
	 * For m data points and n symbols, the linear program has 2*m + n*(n-1)/2 + 1 variables,
	 * namely n*(n-1)/2 entries in the pairwise symbol replacement matric C which we expect to be
	 * symmetric with zeros on the diagonal, m slack variables representing the hinge loss to
	 * the closest correct prototype
	 *
	 * [C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu;]<sub>+</sub>
	 *
	 * m slack variables representing the hinge loss to the closest wrong prototype
	 *
	 * [&nu; + log(2) - C * coopts(i, w<sub>i</sub><sup>-</sup>)]<sub>+</sub>
	 *
	 * and 1 slack variable representing the shift in the margin &nu;, that is, whether we want
	 * data points of the same class to be closer or data points from different classes to be
	 * further away.
	 *
	 * The linear program further has 2*m inequality constraints and lower/upper bound constraints
	 * for all variables. In particular, we have m inequality constraints of the form
	 *
	 * C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu; &le; &xi;<sub>i</sub><sup>+</sup>
	 * &hArr; C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu; - &xi;<sub>i</sub><sup>+</sup> &le; 0
	 *
	 * where &xi;<sub>i</sub><sup>+</sup> is the slack variable for the hinge loss of i to the
	 * closest prototype from the same class; and we have m inequality constraints of the form
	 *
	 * &nu; + log(2) - C * coopts(i, w<sub>i</sub><sup>-</sup>) &le; &xi;<sub>i</sub><sup>-</sup>
	 * &hArr; &nu; - C * coopts(i, w<sub>i</sub><sup>-</sup>) - &xi;<sub>i</sub><sup>-</sup> &le;
	 * - log(2)
	 *
	 * where &xi;<sub>i</sub><sup>-</sup> is the slack variable for the hinge loss of i to the
	 * closest prototype from a different class.
	 *
	 * The lower bound for all variables is 0, the upper bound for all variables except &nu; is
	 * infinity, and the upper bound for &nu; is log(2).
	 *
	 * @param <X> the data class
	 * @param D the m x K distance matrix of tree edit distances from all data points to all
	 * prototypes.
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param full_algo a TreeEditAlgorithm which returns Alignments
	 * @param data the m-element list of data points.
	 * @param n the size of the alphabet.
	 * @param W the prototypes that should be considered, that is, a K x 1 vector of data point
	 * indices which are 'prototypical' for their respective class, chosen e.g. via median learning
	 * vector quantization.
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLLinearProgram corresponding to the given inputs.
	 */
	public static <X> GESLPrototypeLinearProgram fromTreeEditAlgorithm(double[][] D, int[] labels,
			final TreeEditAlgorithm<X, X, Alignment> full_algo, List<Tree<X>> data,
			final int n, final int[] W, int numberOfThreads) {
		return initialize(D, labels, new GESLGradientCalculator.CooptimalFunction<Tree<X>>() {

			@Override
			public CooptimalMatrix compute(Tree<X> left, Tree<X> right) {
				final Alignment ali = full_algo.calculateAlignment(left, right);
				return CooptimalMatrix.fromAlignment(ali);
			}
		}, data, n, W, numberOfThreads);
	}

	/**
	 * Initializes a GESLLinearProgram calculator by selecting the closest correct and closest wrong
	 * prototype, computing the edit scripts to them and transforming those scripts into
	 * coefficients of the linear program.
	 *
	 * For m data points and n symbols, the linear program has 2*m + n*(n-1)/2 + 1 variables,
	 * namely n*(n-1)/2 entries in the pairwise symbol replacement matric C which we expect to be
	 * symmetric with zeros on the diagonal, m slack variables representing the hinge loss to
	 * the closest correct prototype
	 *
	 * [C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu;]<sub>+</sub>
	 *
	 * m slack variables representing the hinge loss to the closest wrong prototype
	 *
	 * [&nu; + log(2) - C * coopts(i, w<sub>i</sub><sup>-</sup>)]<sub>+</sub>
	 *
	 * and 1 slack variable representing the shift in the margin &nu;, that is, whether we want
	 * data points of the same class to be closer or data points from different classes to be
	 * further away.
	 *
	 * The linear program further has 2*m inequality constraints and lower/upper bound constraints
	 * for all variables. In particular, we have m inequality constraints of the form
	 *
	 * C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu; &le; &xi;<sub>i</sub><sup>+</sup>
	 * &hArr; C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu; - &xi;<sub>i</sub><sup>+</sup> &le; 0
	 *
	 * where &xi;<sub>i</sub><sup>+</sup> is the slack variable for the hinge loss of i to the
	 * closest prototype from the same class; and we have m inequality constraints of the form
	 *
	 * &nu; + log(2) - C * coopts(i, w<sub>i</sub><sup>-</sup>) &le; &xi;<sub>i</sub><sup>-</sup>
	 * &hArr; &nu; - C * coopts(i, w<sub>i</sub><sup>-</sup>) - &xi;<sub>i</sub><sup>-</sup> &le;
	 * - log(2)
	 *
	 * where &xi;<sub>i</sub><sup>-</sup> is the slack variable for the hinge loss of i to the
	 * closest prototype from a different class.
	 *
	 * The lower bound for all variables is 0, the upper bound for all variables except &nu; is
	 * infinity, and the upper bound for &nu; is log(2).
	 *
	 * @param <X> the data class
	 * @param D the m x K distance matrix of tree edit distances from all data points to all
	 * prototypes.
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param coopt_algo an AlignmentAlgorithm which returns CooptimalMatrices.
	 * @param data the m-element list of data points.
	 * @param n the size of the alphabet.
	 * @param W the prototypes that should be considered, that is, a K x 1 vector of data point
	 * indices which are 'prototypical' for their respective class, chosen e.g. via median learning
	 * vector quantization.
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLLinearProgram corresponding to the given inputs.
	 */
	public static <X> GESLPrototypeLinearProgram fromTreeEditCooptimalAlgorithm(double[][] D, int[] labels,
			final TreeEditAlgorithm<X, X, CooptimalMatrix> coopt_algo, List<Tree<X>> data, final int n,
			final int[] W, int numberOfThreads) {
		return initialize(D, labels, new GESLGradientCalculator.CooptimalFunction<Tree<X>>() {

			@Override
			public CooptimalMatrix compute(Tree<X> left, Tree<X> right) {
				return coopt_algo.calculateAlignment(left, right);
			}
		}, data, n, W, numberOfThreads);
	}

	/**
	 * Initializes a GESLLinearProgram calculator by selecting the closest correct and closest wrong
	 * prototype, computing the edit scripts to them and transforming those scripts into
	 * coefficients of the linear program.
	 *
	 * For m data points and n symbols, the linear program has 2*m + n*(n-1)/2 + 1 variables,
	 * namely n*(n-1)/2 entries in the pairwise symbol replacement matric C which we expect to be
	 * symmetric with zeros on the diagonal, m slack variables representing the hinge loss to
	 * the closest correct prototype
	 *
	 * [C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu;]<sub>+</sub>
	 *
	 * m slack variables representing the hinge loss to the closest wrong prototype
	 *
	 * [&nu; + log(2) - C * coopts(i, w<sub>i</sub><sup>-</sup>)]<sub>+</sub>
	 *
	 * and 1 slack variable representing the shift in the margin &nu;, that is, whether we want
	 * data points of the same class to be closer or data points from different classes to be
	 * further away.
	 *
	 * The linear program further has 2*m inequality constraints and lower/upper bound constraints
	 * for all variables. In particular, we have m inequality constraints of the form
	 *
	 * C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu; &le; &xi;<sub>i</sub><sup>+</sup>
	 * &hArr; C * coopts(i, w<sub>i</sub><sup>+</sup>) - &nu; - &xi;<sub>i</sub><sup>+</sup> &le; 0
	 *
	 * where &xi;<sub>i</sub><sup>+</sup> is the slack variable for the hinge loss of i to the
	 * closest prototype from the same class; and we have m inequality constraints of the form
	 *
	 * &nu; + log(2) - C * coopts(i, w<sub>i</sub><sup>-</sup>) &le; &xi;<sub>i</sub><sup>-</sup>
	 * &hArr; &nu; - C * coopts(i, w<sub>i</sub><sup>-</sup>) - &xi;<sub>i</sub><sup>-</sup> &le;
	 * - log(2)
	 *
	 * where &xi;<sub>i</sub><sup>-</sup> is the slack variable for the hinge loss of i to the
	 * closest prototype from a different class.
	 *
	 * The lower bound for all variables is 0, the upper bound for all variables except &nu; is
	 * infinity, and the upper bound for &nu; is log(2).
	 *
	 * @param <X> the data class
	 * @param D the m x K distance matrix of tree edit distances from all data points to all
	 * prototypes.
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param fun a function which returns the CooptimalMatrix for two input data points.
	 * @param data the m-element list of data points.
	 * @param n the size of the alphabet.
	 * @param W the prototypes that should be considered, that is, a K x 1 vector of data point
	 * indices which are 'prototypical' for their respective class, chosen e.g. via median learning
	 * vector quantization.
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLLinearProgram corresponding to the given inputs.
	 */
	public static <X> GESLPrototypeLinearProgram initialize(double[][] D, int[] labels,
			GESLGradientCalculator.CooptimalFunction<X> fun, List<X> data, final int n, final int[] W,
			int numberOfThreads) {
		// check input
		final int m = D.length;
		if (m != labels.length) {
			throw new IllegalArgumentException("Expected one row of the distance matrix per label, but got "
					+ m + " rows and " + labels.length + " labels.");
		}
		if (data.size() != m) {
			throw new IllegalArgumentException("Expected one data point per label, but got "
					+ labels.length + " labels and " + data.size() + " data points.");
		}
		if (m < 1) {
			throw new IllegalArgumentException("The input distance matrix was empty!");
		}

		final int K = D[0].length;

		for (int i = 1; i < m; i++) {
			if (D[i].length != K) {
				throw new IllegalArgumentException("Expected a distance matrix as input, but "
						+ "the input array had an inconsistent number of columns.");
			}
		}
		if (K != W.length) {
			throw new IllegalArgumentException("Expected one prototype per column of the distance matrix, but got "
					+ K + " columns and " + W.length + " prototypes.");
		}

		if (n < 1) {
			throw new IllegalArgumentException("We expect an alpahbet size of at least 1.");
		}
		for (int k = 0; k < K; k++) {
			if (W[k] < 0 || W[k] > m) {
				throw new IllegalArgumentException("the " + k + "th prototype has index " + W[k]
						+ " but we expected indices in the range [0," + (m - 1) + "]");
			}
		}
		if (numberOfThreads < 1) {
			throw new IllegalArgumentException("We need at least one thread for parallel constraint computation.");
		}

		// generate the objective function, which is to minimize all slack variables representing
		// the hinge loss. These are the variables n * (n+1) / 2 ... n * (n+1) / 2 + 2 * K * m - 1
		final int num_params = (n * (n + 1)) / 2;
		final int num_vars = num_params + 2 * m + 1;
		final double[] f = new double[num_vars];
		for (int i = 0; i < m; i++) {
			f[num_params + i] = 1;
			f[num_params + m + i] = 1;
		}

		// compute the constraint matrix representing the hinge loss in parallel
		final ExecutorService threadPool = Executors.newFixedThreadPool(numberOfThreads);
		// submit calculation tasks.
		final ArrayList<Future<List<SparseEntry>>> futureResults = new ArrayList<>();
		for (int i = 0; i < m; i++) {
			futureResults.add(threadPool.submit(new PositiveInitializationTask<>(
					i, D[i], W, labels, fun, data, m, n)));
		}
		for (int i = 0; i < m; i++) {
			futureResults.add(threadPool.submit(new NegativeInitializationTask<>(
					i, D[i], W, labels, fun, data, m, n)));
		}
		// initiate thread pool shutdown (which just means that no new jobs
		// will be accepted. The old ones still apply).
		threadPool.shutdown();
		// gather the results
		final ArrayList<SparseEntry> entries = new ArrayList<>(2 * m);
		for (int i = 0; i < 2 * m; i++) {
			try {
				entries.addAll(futureResults.get(i).get());
			} catch (InterruptedException | ExecutionException ex) {
				throw new RuntimeException("GESLGradientCalculator got interrupted during initialization! ", ex);
			}
		}
		final IndexMatrix A = new IndexMatrix(entries);
		// compute the vector containing the constant term for the inequality constraints
		final double[] b = new double[2 * m];
		final double up = Math.log(2);
		for (int i = 0; i < m; i++) {
			b[m + i] = -up;
		}
		// The lower bound for all variables is zero
		final double[] lb = new double[num_vars];
		// Only &nu; has an upper bound, no other variable
		final double[] ub = new double[num_vars];
		Arrays.fill(ub, Double.POSITIVE_INFINITY);
		ub[num_params + 2 * m] = up;
		return new GESLPrototypeLinearProgram(f, A, b, lb, ub);
	}

	private static class PositiveInitializationTask<X> implements Callable<List<SparseEntry>> {

		private final int i;
		private final double[] d;
		private final int[] W;
		private final int[] labels;
		private final GESLGradientCalculator.CooptimalFunction<X> coopt_fun;
		private final List<X> data;
		private final int m;
		private final int n;

		public PositiveInitializationTask(int i, double[] d, int[] W, int[] labels, CooptimalFunction<X> coopt_fun, List<X> data, int m, int n) {
			this.i = i;
			this.d = d;
			this.W = W;
			this.labels = labels;
			this.coopt_fun = coopt_fun;
			this.data = data;
			this.m = m;
			this.n = n;
		}

		@Override
		public List<SparseEntry> call() throws Exception {
			// find the closest prototype with the same label
			int w_plus = -1;
			final int label = labels[i];
			for (int k = 0; k < W.length; k++) {
				if (label != labels[W[k]]) {
					continue;
				}
				if (w_plus < 0 || d[k] < d[w_plus]) {
					w_plus = k;
				}
			}

			if (w_plus < 0) {
				throw new IllegalArgumentException("Did not find a prototype with the same label as data point "
						+ i + " with label " + label + "!");
			}
			// if the data point is the closest prototype, return an empty list
			if (i == W[w_plus]) {
				return new ArrayList<>();
			}

			final int num_params = (n * (n + 1)) / 2;
			final int nu_index = num_params + 2 * m;

			// compute the cheapest edit script between i and w_plus closest neighbor
			final CooptimalMatrix<Tree<Integer>, Tree<Integer>> coopt_plus = coopt_fun.compute(
					data.get(i), data.get(W[w_plus]));

			final ArrayList<SparseEntry> entries = new ArrayList<>(1);
			// transform this edit script into entries of a constraint matrix.
			// first consider replacements
			final CooptimalMatrix.SparseMatrix reps = new CooptimalMatrix.SparseMatrix();
			for (final Entry<MatrixEngine.MatrixCoordinate, Double> entry : coopt_plus.getP_rep().entrySet()) {
				final int l = coopt_plus.getLeft().get(entry.getKey().i).getLabel();
				final int r = coopt_plus.getRight().get(entry.getKey().j).getLabel();
				if (l == r) {
					continue;
				}
				if (l > r) {
					reps.add(l, r, entry.getValue());
				} else {
					reps.add(r, l, entry.getValue());
				}
			}
			for (final Entry<MatrixEngine.MatrixCoordinate, Double> entry : reps.entrySet()) {
				final int l = entry.getKey().i;
				final int r = entry.getKey().j;
				final int s = (l * (l - 1)) / 2 + r;
				entries.add(new SparseEntry(i, s, entry.getValue()));
			}
			// then deletions and insertions
			final double[] gap_coeffs = new double[n];
			for (int i2 = 0; i2 < coopt_plus.getLeft().size(); i2++) {
				if (coopt_plus.getP_del()[i2] > 0) {
					final int l = coopt_plus.getLeft().get(i2).getLabel();
					gap_coeffs[l] += coopt_plus.getP_del()[i2];
				}
			}
			for (int j2 = 0; j2 < coopt_plus.getRight().size(); j2++) {
				if (coopt_plus.getP_ins()[j2] > 0) {
					final int r = coopt_plus.getRight().get(j2).getLabel();
					gap_coeffs[r] += coopt_plus.getP_ins()[j2];
				}
			}
			for (int l = 0; l < n; l++) {
				if (gap_coeffs[l] > 0) {
					entries.add(new SparseEntry(i, (n * (n - 1)) / 2 + l, gap_coeffs[l]));
				}
			}
			// if no entries have accumulated until now, we can drop the whole row of the constraint
			// matrix because it is trivial
			if (entries.isEmpty()) {
				return entries;
			}

			// then add the terms for the slack variable ...
			entries.add(new SparseEntry(i, num_params + i, -1));
			// ... and for the margin shift
			entries.add(new SparseEntry(i, nu_index, -1));
			return entries;
		}

	}

	private static class NegativeInitializationTask<X> implements Callable<List<SparseEntry>> {

		private final int i;
		private final double[] d;
		private final int[] W;
		private final int[] labels;
		private final GESLGradientCalculator.CooptimalFunction<X> coopt_fun;
		private final List<X> data;
		private final int m;
		private final int n;

		public NegativeInitializationTask(int i, double[] d, int[] W, int[] labels,
				CooptimalFunction<X> coopt_fun, List<X> data, int m, int n) {
			this.i = i;
			this.d = d;
			this.W = W;
			this.labels = labels;
			this.coopt_fun = coopt_fun;
			this.data = data;
			this.m = m;
			this.n = n;
		}

		@Override
		public List<SparseEntry> call() throws Exception {

			// find the closest prototype with a different label
			int w_minus = -1;
			final int label = labels[i];
			for (int k = 0; k < W.length; k++) {
				if (label == labels[W[k]]) {
					continue;
				}
				if (w_minus < 0 || d[k] < d[w_minus]) {
					w_minus = k;
				}
			}
			if (w_minus < 0) {
				throw new IllegalArgumentException("Did not find a prototype with the same label as data point "
						+ i + " with label " + label + "!");
			}

			final int num_params = (n * (n + 1)) / 2;
			final int nu_index = num_params + 2 * m;

			// compute the cheapest edit script between i and w_plus closest neighbor
			final CooptimalMatrix<Tree<Integer>, Tree<Integer>> coopt_plus = coopt_fun.compute(
					data.get(i), data.get(W[w_minus]));

			final ArrayList<SparseEntry> entries = new ArrayList<>(1);
			// transform this edit script into entries of a constraint matrix.
			// first consider replacements
			final CooptimalMatrix.SparseMatrix reps = new CooptimalMatrix.SparseMatrix();
			for (final Entry<MatrixEngine.MatrixCoordinate, Double> entry : coopt_plus.getP_rep().entrySet()) {
				final int l = coopt_plus.getLeft().get(entry.getKey().i).getLabel();
				final int r = coopt_plus.getRight().get(entry.getKey().j).getLabel();
				if (l == r) {
					continue;
				}
				if (l > r) {
					reps.add(l, r, entry.getValue());
				} else {
					reps.add(r, l, entry.getValue());
				}
			}
			for (final Entry<MatrixEngine.MatrixCoordinate, Double> entry : reps.entrySet()) {
				final int l = entry.getKey().i;
				final int r = entry.getKey().j;
				final int s = (l * (l - 1)) / 2 + r;
				entries.add(new SparseEntry(m + i, s, -entry.getValue()));
			}
			// then deletions and insertions
			final double[] gap_coeffs = new double[n];
			for (int i2 = 0; i2 < coopt_plus.getLeft().size(); i2++) {
				if (coopt_plus.getP_del()[i2] > 0) {
					final int l = coopt_plus.getLeft().get(i2).getLabel();
					gap_coeffs[l] += coopt_plus.getP_del()[i2];
				}
			}
			for (int j2 = 0; j2 < coopt_plus.getRight().size(); j2++) {
				if (coopt_plus.getP_ins()[j2] > 0) {
					final int r = coopt_plus.getRight().get(j2).getLabel();
					gap_coeffs[r] += coopt_plus.getP_ins()[j2];
				}
			}
			for (int l = 0; l < n; l++) {
				if (gap_coeffs[l] > 0) {
					entries.add(new SparseEntry(m + i, (n * (n - 1)) / 2 + l, -gap_coeffs[l]));
				}
			}
			// then add the terms for the slack variable ...
			entries.add(new SparseEntry(m + i, num_params + m + i, -1));
			// ... and for the margin shift
			entries.add(new SparseEntry(m + i, nu_index, +1));
			return entries;
		}

	}
}
