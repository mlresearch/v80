/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.gesl;

import de.citec.tcs.alignment.Alignment;
import de.citec.tcs.alignment.AlignmentAlgorithm;
import de.citec.tcs.alignment.comparators.Comparator;
import de.citec.tcs.alignment.parallel.MatrixEngine;
import de.citec.tcs.alignment.trees.CooptimalMatrix;
import de.citec.tcs.alignment.trees.Tree;
import de.citec.tcs.alignment.trees.TreeEditAlgorithm;
import java.util.List;
import java.util.concurrent.Callable;
import lombok.Getter;

/**
 *
 * @author Benjamin Paassen - bpaassen@techfak.uni-bielefeld.de
 */
public class PseudoEditDistanceEngine<X> extends MatrixEngine<Double> {

	private final GESLGradientCalculator.CooptimalFunction<X> cooptimalFunction;
	@Getter
	private final Comparator comparator;
	@Getter
	private final List<X> left;
	@Getter
	private final List<X> right;

	public PseudoEditDistanceEngine(GESLGradientCalculator.CooptimalFunction<X> cooptimalFunction,
			Comparator comparator, List<X> left, List<X> right) {
		super(left.size(), right.size(), Double.class);
		this.cooptimalFunction = cooptimalFunction;
		this.comparator = comparator;
		this.left = left;
		this.right = right;
	}

	public static <X> PseudoEditDistanceEngine<List<X>> fromAlignmentAlgorithm(
			final AlignmentAlgorithm<X, X, Alignment> alignmentAlgorithm,
			final Comparator<X, X> comparator, final List<List<X>> left, final List<List<X>> right) {
		if (!Alignment.class.isAssignableFrom(alignmentAlgorithm.getResultClass())) {
			throw new IllegalArgumentException("Input algorithm does not return an Alignment!");
		}
		return new PseudoEditDistanceEngine<>(new GESLGradientCalculator.CooptimalFunction<List<X>>() {
			@Override
			public CooptimalMatrix compute(List<X> left, List<X> right) {
				return CooptimalMatrix.fromAlignment(alignmentAlgorithm.calculateAlignment(left, right));
			}
		}, comparator, left, right);
	}

	public static <X> PseudoEditDistanceEngine<List<X>> fromCooptimalAlgorithm(
			final AlignmentAlgorithm<X, X, CooptimalMatrix> alignmentAlgorithm,
			final Comparator<X, X> comparator, final List<List<X>> left, final List<List<X>> right) {
		if (!CooptimalMatrix.class.isAssignableFrom(alignmentAlgorithm.getResultClass())) {
			throw new IllegalArgumentException("Input algorithm does not return a CooptimalMatrix!");
		}
		return new PseudoEditDistanceEngine<>(new GESLGradientCalculator.CooptimalFunction<List<X>>() {
			@Override
			public CooptimalMatrix compute(List<X> left, List<X> right) {
				return alignmentAlgorithm.calculateAlignment(left, right);
			}
		}, comparator, left, right);
	}

	public static <X> PseudoEditDistanceEngine<Tree<X>> fromTreeEditAlgorithm(
			final TreeEditAlgorithm<X, X, Alignment> alignmentAlgorithm,
			final Comparator<X, X> comparator, final List<Tree<X>> left, final List<Tree<X>> right) {
		if (!Alignment.class.isAssignableFrom(alignmentAlgorithm.getResultClass())) {
			throw new IllegalArgumentException("Input algorithm does not return an Alignment!");
		}
		return new PseudoEditDistanceEngine<>(new GESLGradientCalculator.CooptimalFunction<Tree<X>>() {
			@Override
			public CooptimalMatrix compute(Tree<X> left, Tree<X> right) {
				return CooptimalMatrix.fromAlignment(alignmentAlgorithm.calculateAlignment(left, right));
			}
		}, comparator, left, right);
	}

	public static <X> PseudoEditDistanceEngine<Tree<X>> fromTreeCooptimalAlgorithm(
			final TreeEditAlgorithm<X, X, CooptimalMatrix> alignmentAlgorithm,
			final Comparator<X, X> comparator, final List<Tree<X>> left, final List<Tree<X>> right) {
		if (!CooptimalMatrix.class.isAssignableFrom(alignmentAlgorithm.getResultClass())) {
			throw new IllegalArgumentException("Input algorithm does not return a CooptimalMatrix!");
		}
		return new PseudoEditDistanceEngine<>(new GESLGradientCalculator.CooptimalFunction<Tree<X>>() {
			@Override
			public CooptimalMatrix compute(Tree<X> left, Tree<X> right) {
				return alignmentAlgorithm.calculateAlignment(left, right);
			}
		}, comparator, left, right);
	}

	@Override
	public Callable<Double> createCallable(MatrixCoordinate ident) {
		return new PseudoEditDistanceCallable<>(cooptimalFunction,
				left.get(ident.i), right.get(ident.j),
				comparator);
	}

	private static class PseudoEditDistanceCallable<X> implements Callable<Double> {

		private final GESLGradientCalculator.CooptimalFunction<X> coopt_fun;
		private final X left;
		private final X right;
		private final Comparator learnedComp;

		public PseudoEditDistanceCallable(GESLGradientCalculator.CooptimalFunction<X> coopt_fun,
				X left, X right, Comparator learnedComp) {
			this.coopt_fun = coopt_fun;
			this.left = left;
			this.right = right;
			this.learnedComp = learnedComp;
		}

		@Override
		public Double call() throws Exception {
			final CooptimalMatrix coopt_matrix = coopt_fun.compute(left, right);
			return coopt_matrix.editDistance(learnedComp);
		}

	}

}
