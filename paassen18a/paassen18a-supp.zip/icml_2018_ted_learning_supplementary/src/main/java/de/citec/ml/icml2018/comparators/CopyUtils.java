/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.comparators;

import de.citec.tcs.alignment.comparators.Comparator;
import de.citec.tcs.alignment.comparators.DerivableComparator;
import de.citec.tcs.alignment.trees.DerivableLabelComparator;
import de.citec.tcs.alignment.trees.LabelComparator;

/**
 * This class contains utility functions to copy objects via the Copyable interface.
 *
 * @author Benjamin Paassen - bpaassen@techfak.uni-bielefeld.de
 */
public class CopyUtils {

	private CopyUtils() {

	}

	public static <X> X copy(Copyable<X> original) {
		return original.copy();
	}

	public static <X, Y> DerivableLabelComparator<X, Y> copy(DerivableLabelComparator<X, Y> original) {
		final DerivableComparator<X, Y> comparator = original.getComparator();
		final DerivableComparator<X, Y> copy = ((Copyable<? extends DerivableComparator<X, Y>>) comparator).copy();
		return new DerivableLabelComparator<>(copy);
	}

	public static <X, Y> LabelComparator<X, Y> copy(LabelComparator<X, Y> original) {
		final Comparator<X, Y> comparator = original.getComparator();
		final Comparator<X, Y> copy = ((Copyable<? extends Comparator<X, Y>>) comparator).copy();
		return new LabelComparator<>(copy);
	}
}
