/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.lmnn;

import java.util.HashMap;
import java.util.Map.Entry;

/**
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class KNNClassifier {

	private KNNClassifier() {

	}

	public static int[] predict(double[][] D, int[] train_labels, int K) {
		final int[] predicted = new int[D.length];
		for (int i = 0; i < D.length; i++) {
			predicted[i] = predict(D[i], train_labels, K);
		}
		return predicted;
	}

	public static int predict(double[] d, int[] train_labels, int K) {
		if (d.length != train_labels.length) {
			throw new IllegalArgumentException("Expected one label per training data point!");
		}
		// compute the nearest neighbors
		final int[] N = nearestNeighbors(d, K);
		// count the votes for each label
		final HashMap<Integer, Integer> votes = new HashMap<>();
		for (int k = 0; k < K; k++) {
			final Integer num_votes = votes.get(train_labels[N[k]]);
			if (num_votes == null) {
				votes.put(train_labels[N[k]], 1);
			} else {
				votes.put(train_labels[N[k]], num_votes + 1);
			}
		}
		// retrieve the label with the most votes
		int majority_label = 0;
		int max_votes = 0;
		for (final Entry<Integer, Integer> voteEntry : votes.entrySet()) {
			if (voteEntry.getValue() > max_votes) {
				majority_label = voteEntry.getKey();
				max_votes = voteEntry.getValue();
			}
		}
		return majority_label;
	}

	public static int[] nearestNeighbors(double[] d, int K) {
		// initialize the neighborhood with the K first data points
		final int[] N = new int[K];
		for (int k = 1; k < K; k++) {
			// sort the neighbors via insertion sort
			int l = k - 1;
			while (l >= 0 && d[k] < d[N[l]]) {
				N[l + 1] = N[l];
				l--;
			}
			N[l + 1] = k;
		}
		// then iterate over the remaining data points and find the closest K
		for (int j = K; j < d.length; j++) {
			if (d[j] < d[N[K - 1]]) {
				// if this data point is closer than the furthest neighbor until now, throw out
				// the current furthest neighbor and sort the current data point into the neighbors
				// list
				int l = K - 2;
				while (l >= 0 && d[j] < d[N[l]]) {
					N[l + 1] = N[l];
					l--;
				}
				N[l + 1] = j;
			}
		}
		return N;
	}
}
