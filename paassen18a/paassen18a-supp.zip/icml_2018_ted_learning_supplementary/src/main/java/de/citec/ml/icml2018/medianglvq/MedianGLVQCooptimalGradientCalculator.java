/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.medianglvq;

import de.citec.tcs.alignment.Alignment;
import de.citec.tcs.alignment.comparators.DerivableComparator;
import de.citec.tcs.alignment.parallel.CommandLineProgressReporter;
import de.citec.tcs.alignment.parallel.Engine;
import de.citec.tcs.alignment.parallel.ProgressReporter;
import de.citec.tcs.alignment.trees.CooptimalMatrix;
import java.util.concurrent.Callable;
import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;

/**
 * Implements metric learning via CooptimalMatrix instances on the GLVQ cost function with
 * logarithmic transfer function, given prototypes which are set to data points (median GLVQ).
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 * @param <X> the object class that is compared via Median GLVQ.
 */
public class MedianGLVQCooptimalGradientCalculator<X> {

	/**
	 * The CooptimalMatrix for every combination of input and prototype (i.e. an m x K matrix).
	 *
	 * @return The CooptimalMatrix for every combination of input and prototype (i.e. an m x K
	 * matrix).
	 */
	@Getter
	@NonNull
	private final CooptimalMatrix[][] cooptimals;
	/**
	 * The labels for every data point (i.e. an m x 1 vector).
	 *
	 * @return The labels for every data point (i.e. an m x 1 vector).
	 */
	@Getter
	@NonNull
	private final int[] labels;
	/**
	 * The prototype indices, i.e. a K x 1 vector, where W[k] is the index of the data point
	 * that is equivalent to the kth prototype.
	 *
	 *
	 * @return The prototype indices, i.e. a K x 1 vector, where w[k] is the index of the data point
	 * that is equivalent to the kth prototype.
	 */
	@Getter
	private final int[] W;

	/**
	 * The number of threads used in the parallel computation of the gradient on the LMNN cost
	 * function.
	 *
	 * @param numberOfThreads The number of threads used in the parallel computation of the gradient
	 * on the GLVQ cost function.
	 *
	 * @return The number of threads used in the parallel computation of the gradient on the GLVQ
	 * cost function.
	 */
	@Getter
	@Setter
	private int numberOfThreads = Engine.DEFAULT_NUMBER_OF_THREADS;
	/**
	 * The ProgressReporter that is used to report progress. This is a
	 * CommandLineProgressReporter per default. If it is set to null, the
	 * progress is not reported.
	 *
	 * @param reporter The ProgressReporter that is used to report progress.
	 *
	 * @return The ProgressReporter that is used to report progress.
	 */
	@Getter
	@Setter
	private ProgressReporter reporter = new CommandLineProgressReporter();

	public MedianGLVQCooptimalGradientCalculator(CooptimalMatrix[][] cooptimals, int[] labels, int[] W) {
		this.cooptimals = cooptimals;
		// check the cooptimals
		if (this.cooptimals.length == 0) {
			throw new IllegalArgumentException("The given input data set is empty!");
		}
		final int m = this.cooptimals.length;
		final int K = cooptimals[0].length;
		for (int i = 1; i < m; i++) {
			if (this.cooptimals[i].length != K) {
				throw new IllegalArgumentException("The given cooptimals matrix is inconsistent! Row "
						+ i + " has " + this.cooptimals[i].length + " columns, but the first row has "
						+ K + " columns!");
			}
		}
		this.labels = labels;
		if (this.labels.length != m) {
			throw new IllegalArgumentException("The number of given labels (" + this.labels.length
					+ ") is inconsistent with the number of rows in the given cooptimals matrix (" + m + ")!");
		}
		this.W = W;
		if (this.W.length != K) {
			throw new IllegalArgumentException("The number of given prototype indices (" + this.W.length
					+ ") is inconsistent with the number of columns in the given cooptimals matrix (" + K + ")!");
		}
		for (int k = 0; k < K; k++) {
			if (this.W[k] < 0 || this.W[k] >= m) {
				throw new IllegalArgumentException("The index for the " + k + "th prototype is invalid ("
						+ W[k] + ")!");
			}
		}
	}

	public MedianGLVQCooptimalGradientCalculator(Alignment[][] cooptimals, int[] labels, int[] W) {
		this(fromAlignment(cooptimals), labels, W);
	}

	private static CooptimalMatrix[][] fromAlignment(Alignment[][] alignments) {
		final CooptimalMatrix[][] out = new CooptimalMatrix[alignments.length][];
		for (int i = 0; i < alignments.length; i++) {
			out[i] = new CooptimalMatrix[alignments[i].length];
			for (int k = 0; k < alignments[i].length; k++) {
				out[i][k] = CooptimalMatrix.fromAlignment(alignments[i][k]);
			}
		}
		return out;
	}

	/**
	 * Calculates the value and the gradient of
	 *
	 * &Sigma;<sub>i=1</sub><sup>m</sup> log(2 +
	 * d<sub>i</sub><sup>+</sup> - d<sub>i</sub><sup>-</sup> /
	 * d<sub>i</sub><sup>+</sup> + d<sub>i</sub><sup>-</sup>
	 * )
	 *
	 * with respect to the parameters of the given comparator.
	 *
	 * Note that this method relies on the training-to-prototype distance matrix
	 * already being present. It can be calculated using a CooptimalDistanceEngine.
	 *
	 * This gradient calculation runs in m x K, where m is the number of data points and K is the
	 * number of prototypes.
	 *
	 * @param comp the comparator itself.
	 * @param D given m training data points this should be a m x K matrix specifying the distances
	 * from each data point to each prototype, according to the given comparator and using the
	 * same distance algorithm that was used as for the CooptimalMatrix instances in the constructor
	 * of this instance.
	 *
	 * @return the value and the gradient of the GLVQ cost function with respect to the
	 * parameters of the given comparator.
	 */
	public double[] computeErrorAndGradient(@NonNull DerivableComparator<X, X> comp, @NonNull double[][] D) {
		// check the input
		final int m = labels.length;
		final int K = W.length;
		if (D.length != m) {
			throw new IllegalArgumentException(
					"Expected distances for each training data point, but had "
					+ m + " data points and " + D.length
					+ " rows in the given distance matrix.");
		}
		for (int i = 0; i < m; i++) {
			if (D[i].length != K) {
				throw new IllegalArgumentException(
						"Expected distances to each prototype, but had "
						+ K + " prototypes and " + D[i].length
						+ " columns in row " + i + " of the given distance matrix."
				);
			}
		}

		// calculate the gradient.
		final double[] gradient = new double[comp.getNumberOfParameters() + 1];
		final ParallelGradientEngine engine = new ParallelGradientEngine(comp, D);
		engine.setNumberOfThreads(numberOfThreads);
		engine.setReporter(reporter);
		// iterate over all datapoints.
		for (int i = 0; i < labels.length; i++) {
			// create a parallel processing job for it.
			engine.addTask(i);
		}
		// calculate
		engine.calculate();
		// sum up the resulting part-gradients.
		for (final Engine.CalculationResult<Integer, double[]> res : engine.getResults()) {
			for (int j = 0; j < gradient.length; j++) {
				gradient[j] += res.result[j];
			}
		}
		return gradient;
	}

	private class ParallelGradientEngine extends Engine<Integer, double[]> {

		private final DerivableComparator<X, X> comp;
		private final double[][] D;

		public ParallelGradientEngine(DerivableComparator<X, X> comp, double[][] D) {
			super(Integer.class, double[].class);
			this.comp = comp;
			this.D = D;
		}

		@Override
		public Callable<double[]> createCallable(Integer i) {
			return new GLVQGradientJob(comp, i, D[i]);
		}

	}

	private static final double TOL = 1E-3;

	private class GLVQGradientJob implements Callable<double[]> {

		private final DerivableComparator<X, X> comp;
		private final int i;
		private final double[] distances;

		public GLVQGradientJob(DerivableComparator<X, X> comp, int i, double[] distances) {
			this.comp = comp;
			this.i = i;
			this.distances = distances;
		}

		@Override
		public double[] call() throws Exception {
			final int n = comp.getNumberOfParameters();
			final double[] err_and_grad = new double[n + 1];
			// find the closest prototype for this data point with the same and with a different
			// label
			double d_plus = Double.POSITIVE_INFINITY;
			int k_plus = -1;
			double d_minus = Double.POSITIVE_INFINITY;
			int k_minus = -1;
			for (int k = 0; k < distances.length; k++) {
				if (labels[i] == labels[W[k]]) {
					if (distances[k] < d_plus) {
						d_plus = distances[k];
						k_plus = k;
					}
				} else {
					if (distances[k] < d_minus) {
						d_minus = distances[k];
						k_minus = k;
					}
				}
			}
			// compute the cost function contribution mu<sub>i</sub> of this data point
			final double Z = d_plus + d_minus;
			final double mu;
			if (Z < TOL) {
				return err_and_grad;
			} else {
				mu = (d_plus - d_minus) / Z;
			}
			// log(4 + mu) is the cost function contribution of this data point
			err_and_grad[0] = Math.log(4 + mu);

			// now compute the gradient. The gradient is given by the formula:
			// 1 / (4 + (d_plus - d_minus) / (d_plus + d_minus) ) *
			// 2 / (d_plus + d_minus)² * [d_plus' * d_minus - d_minus' * d_plus]
			// first compute the gradient of the distance to the closest prototype with the same
			// label
			final CooptimalMatrix<X, X> coopt_plus = cooptimals[i][k_plus];
			final double[] grad_plus = coopt_plus.computeGradient(comp);
			// then compute the gradient of the distance to the closest prototype with another
			// label
			final CooptimalMatrix<X, X> coopt_minus = cooptimals[i][k_minus];
			final double[] grad_minus = coopt_minus.computeGradient(comp);
			// then compute the final gradient
			final double pre = 2 / (Z * Z * (4 + mu));
			for (int j = 0; j < n; j++) {
				err_and_grad[j + 1] = pre * (grad_plus[j] * d_minus - grad_minus[j] * d_plus);
			}
			return err_and_grad;
		}
	}

}
