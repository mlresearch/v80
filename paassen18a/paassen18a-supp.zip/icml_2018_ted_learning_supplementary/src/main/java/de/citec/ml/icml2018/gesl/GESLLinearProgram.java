/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.gesl;

import de.citec.ml.icml2018.gesl.GESLGradientCalculator.CooptimalFunction;
import de.citec.tcs.alignment.Alignment;
import de.citec.tcs.alignment.AlignmentAlgorithm;
import de.citec.tcs.alignment.parallel.MatrixEngine;
import de.citec.tcs.alignment.trees.CooptimalMatrix;
import de.citec.tcs.alignment.trees.Tree;
import de.citec.tcs.alignment.trees.TreeEditAlgorithm;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * A standard form representation of the Good Edit Similarity Learning (GESL, Bellet, 2012) linear
 * program
 *
 * min<sub>C, &nu;</sub> &Sigma;<sub>i=1</sub><sup>m</sup>
 * &Sigma;<sub>k=1</sub><sup>K</sup>
 * [C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu;]<sub>+</sub> +
 * [&nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>)]<sub>+</sub>
 *
 * subject to
 *
 * C, &nu; &ge; 0 and &nu; &le; log(2)
 *
 * where C is the (symmetric, zero-diagonal) matrix of pairwise symbol edit costs,
 * coopts(i, j) denotes a CooptimalMatrix between trees i and j, j<sub>i, k</sub><sup>+</sup>
 * denotes the index of the kth closest neighbor to i with the same label,
 * j<sub>i, k</sub><sup>-</sup> denotes the index of the kth <em>furthest</em> neighbor from i with
 * a <em>different</em> label, C * coopts denotes the scalar-product of the vectorized versions
 * of the matrices C and coopts and &nu; is a margin variable.
 *
 * Note that this linear program has effectively more variables than the entries of C and &nu;.
 * In particular, we need one slack variable for each hinge loss, resulting in (n+1) * n / 2 +
 * 2 * K * m + 1 variables overall for n symbols and m data points.
 *
 * The linear program further has 2*K*m inequality constraints and lower/upper bound constraints
 * for all variables. In particular, we have K*m inequality constraints of the form
 *
 * C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; &le; &xi;<sub>i, k</sub><sup>+</sup>
 * &hArr; C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; - &xi;<sub>i, k</sub><sup>+</sup> &le;
 * 0
 *
 * where &xi;<sub>i, k</sub><sup>+</sup> is the slack variable for the hinge loss of i to its
 * kth closest neighbor from the same class; and we have K*m inequality constraints of the form
 *
 * &nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) &le; &xi;<sub>i, k</sub><sup>-</sup>
 * &hArr; &nu; - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) - &xi;<sub>i, k</sub><sup>-</sup> &le;
 * - log(2)
 *
 * &xi;<sub>i, k</sub><sup>-</sup> is the slack variable for the hinge loss of i to its
 * kth furthest neighbor from a different class.
 *
 * The lower bound for all variables is 0, the upper bound for all variables except &nu; is
 * infinity, and the upper bound for &nu; is log(2).
 *
 * @author Benjamin Paassen - bpaassen@techfak.uni-bielefeld.de
 */
public class GESLLinearProgram {

	/**
	 * A sparse matrix which is basically an index list, compatible with MATLAB's sparse matrix
	 * initialization. It maintains an array for the row indices, an array for the column indices,
	 * and an array for the values.
	 */
	public static class IndexMatrix {

		public final int[] i;
		public final int[] j;
		public final double[] v;

		public IndexMatrix(int[] i, int[] j, double[] v) {
			this.i = i;
			this.j = j;
			this.v = v;
			if (i.length != j.length) {
				throw new IllegalArgumentException("Expected as many row indices as column indices!");
			}
			if (i.length != v.length) {
				throw new IllegalArgumentException("Expected as many values as row indices!");
			}
		}

		public IndexMatrix(List<SparseEntry> indexList) {
			this.i = new int[indexList.size()];
			this.j = new int[indexList.size()];
			this.v = new double[indexList.size()];
			for (int s = 0; s < indexList.size(); s++) {
				this.i[s] = indexList.get(s).i;
				this.j[s] = indexList.get(s).j;
				this.v[s] = indexList.get(s).v;
			}
		}

		@Override
		public int hashCode() {
			int hash = 7;
			hash = 71 * hash + Arrays.hashCode(this.i);
			hash = 71 * hash + Arrays.hashCode(this.j);
			hash = 71 * hash + Arrays.hashCode(this.v);
			return hash;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj) {
				return true;
			}
			if (obj == null) {
				return false;
			}
			if (getClass() != obj.getClass()) {
				return false;
			}
			final IndexMatrix other = (IndexMatrix) obj;
			if (!Arrays.equals(this.i, other.i)) {
				return false;
			}
			if (!Arrays.equals(this.j, other.j)) {
				return false;
			}
			if (!Arrays.equals(this.v, other.v)) {
				return false;
			}
			return true;
		}

		@Override
		public String toString() {
			final StringBuilder buf = new StringBuilder();
			for (int s = 0; s < i.length; s++) {
				buf.append('(');
				buf.append(Integer.toString(i[s]));
				buf.append(',');
				buf.append(Integer.toString(j[s]));
				buf.append(") => ");
				buf.append(Double.toString(v[s]));
				buf.append('\n');
			}
			return buf.toString();
		}

	}

	public static class SparseEntry {

		public final int i;
		public final int j;
		public final double v;

		public SparseEntry(int i, int j, double v) {
			this.i = i;
			this.j = j;
			this.v = v;
		}

		@Override
		public int hashCode() {
			int hash = 7;
			hash = 23 * hash + this.i;
			hash = 23 * hash + this.j;
			hash = 23 * hash + (int) (Double.doubleToLongBits(this.v) ^ (Double.doubleToLongBits(this.v) >>> 32));
			return hash;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj) {
				return true;
			}
			if (obj == null) {
				return false;
			}
			if (getClass() != obj.getClass()) {
				return false;
			}
			final SparseEntry other = (SparseEntry) obj;
			if (this.i != other.i) {
				return false;
			}
			if (this.j != other.j) {
				return false;
			}
			if (Double.doubleToLongBits(this.v) != Double.doubleToLongBits(other.v)) {
				return false;
			}
			return true;
		}

		@Override
		public String toString() {
			return "(" + i + ", " + j + ") => " + v;
		}

	}

	public final double[] f;
	public final IndexMatrix A;
	public final double[] b;
	public final double[] lb;
	public final double[] ub;

	private GESLLinearProgram(double[] f, IndexMatrix A, double[] b, double[] lb, double[] ub) {
		this.f = f;
		this.A = A;
		this.b = b;
		this.lb = lb;
		this.ub = ub;
	}

	/**
	 * Initializes a GESLLinearProgram calculator by selecting the K closest correct and furthest
	 * wrong neighbors, computing the edit scripts to them and transforming those scripts into
	 * coefficients of the linear program.
	 *
	 * For m data points and n symbols, the linear program has 2*K*m + n*(n-1)/2 + 1 variables,
	 * namely n*(n-1)/2 entries in the pairwise symbol replacement matric C which we expect to be
	 * symmetric with zeros on the diagonal, K*m slack variables representing the hinge loss to
	 * the closest correct neighbors
	 *
	 * [C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu;]<sub>+</sub>
	 *
	 * K*m slack variables representing the hinge loss to the furthest wrong neighbors
	 *
	 * [&nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>)]<sub>+</sub>
	 *
	 * and 1 slack variable representing the shift in the margin &nu;, that is, whether we want
	 * data points of the same class to be closer or data points from different classes to be
	 * further away.
	 *
	 * The linear program further has 2*K*m inequality constraints and lower/upper bound constraints
	 * for all variables. In particular, we have K*m inequality constraints of the form
	 *
	 * C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; &le; &xi;<sub>i, k</sub><sup>+</sup>
	 * &hArr; C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; - &xi;<sub>i, k</sub><sup>+</sup>
	 * &le;
	 * 0
	 *
	 * where &xi;<sub>i, k</sub><sup>+</sup> is the slack variable for the hinge loss of i to its
	 * kth closest neighbor from the same class; and we have K*m inequality constraints of the form
	 *
	 * &nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) &le; &xi;<sub>i,
	 * k</sub><sup>-</sup>
	 * &hArr; &nu; - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) - &xi;<sub>i, k</sub><sup>-</sup>
	 * &le;
	 * - log(2)
	 *
	 * &xi;<sub>i, k</sub><sup>-</sup> is the slack variable for the hinge loss of i to its
	 * kth furthest neighbor from a different class.
	 *
	 * The lower bound for all variables is 0, the upper bound for all variables except &nu; is
	 * infinity, and the upper bound for &nu; is log(2).
	 *
	 * @param <X> the data class
	 * @param D the m x m distance matrix of pairwise tree edit distances for the whole data set.
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param full_algo an AlignmentAlgorithm which returns Alignments
	 * @param data the m-element list of data points.
	 * @param n the size of the alphabet.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLLinearProgram corresponding to the given inputs.
	 */
	public static <X> GESLLinearProgram fromAlignmentAlgorithm(double[][] D, int[] labels,
			final AlignmentAlgorithm<X, X, Alignment> full_algo, List<List<X>> data, final int n,
			final int K, int numberOfThreads) {
		final int[] subset_idxs = new int[D.length];
		for (int i = 0; i < D.length; i++) {
			subset_idxs[i] = i;
		}
		return initialize(D, subset_idxs, labels, new GESLGradientCalculator.CooptimalFunction<List<X>>() {

			@Override
			public CooptimalMatrix compute(List<X> left, List<X> right) {
				final Alignment ali = full_algo.calculateAlignment(left, right);
				return CooptimalMatrix.fromAlignment(ali);
			}
		}, data, n, K, numberOfThreads);
	}

	/**
	 * Initializes a GESLLinearProgram calculator by selecting the K closest correct and furthest
	 * wrong neighbors, computing the edit scripts to them and transforming those scripts into
	 * coefficients of the linear program.
	 *
	 * For m data points and n symbols, the linear program has 2*K*m + n*(n-1)/2 + 1 variables,
	 * namely n*(n-1)/2 entries in the pairwise symbol replacement matric C which we expect to be
	 * symmetric with zeros on the diagonal, K*m slack variables representing the hinge loss to
	 * the closest correct neighbors
	 *
	 * [C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu;]<sub>+</sub>
	 *
	 * K*m slack variables representing the hinge loss to the furthest wrong neighbors
	 *
	 * [&nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>)]<sub>+</sub>
	 *
	 * and 1 slack variable representing the shift in the margin &nu;, that is, whether we want
	 * data points of the same class to be closer or data points from different classes to be
	 * further away.
	 *
	 * The linear program further has 2*K*m inequality constraints and lower/upper bound constraints
	 * for all variables. In particular, we have K*m inequality constraints of the form
	 *
	 * C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; &le; &xi;<sub>i, k</sub><sup>+</sup>
	 * &hArr; C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; - &xi;<sub>i, k</sub><sup>+</sup>
	 * &le;
	 * 0
	 *
	 * where &xi;<sub>i, k</sub><sup>+</sup> is the slack variable for the hinge loss of i to its
	 * kth closest neighbor from the same class; and we have K*m inequality constraints of the form
	 *
	 * &nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) &le; &xi;<sub>i,
	 * k</sub><sup>-</sup>
	 * &hArr; &nu; - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) - &xi;<sub>i, k</sub><sup>-</sup>
	 * &le;
	 * - log(2)
	 *
	 * &xi;<sub>i, k</sub><sup>-</sup> is the slack variable for the hinge loss of i to its
	 * kth furthest neighbor from a different class.
	 *
	 * The lower bound for all variables is 0, the upper bound for all variables except &nu; is
	 * infinity, and the upper bound for &nu; is log(2).
	 *
	 * @param <X> the data class
	 * @param D an m x m' distance matrix of pairwise tree edit distances between all data points
	 * and the data points which are selectable as neighbors.
	 * @param subset_idxs an m' x 1 index vector such that D[i][j] = d(data.get(i),
	 * data.get(subset_idxs[j])).
	 * @param labels a m' x 1 vector of labels for the potential neighbors.
	 * @param fullAlgo a AlignmentAlgorithm which returns Alignments
	 * @param data the m-element list of data points.
	 * @param n the size of the alphabet.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLLinearProgram corresponding to the given inputs.
	 */
	public static <X> GESLLinearProgram fromAlignmentAlgorithm(double[][] D, int[] subset_idxs,
			int[] labels, final AlignmentAlgorithm<X, X, Alignment> fullAlgo, List<List<X>> data,
			final int n, final int K, int numberOfThreads) {
		return initialize(D, subset_idxs, labels, new GESLGradientCalculator.CooptimalFunction<List<X>>() {

			@Override
			public CooptimalMatrix compute(List<X> left, List<X> right) {
				final Alignment ali = fullAlgo.calculateAlignment(left, right);
				return CooptimalMatrix.fromAlignment(ali);
			}
		}, data, n, K, numberOfThreads);
	}

	/**
	 * Initializes a GESLLinearProgram calculator by selecting the K closest correct and furthest
	 * wrong neighbors, computing the edit scripts to them and transforming those scripts into
	 * coefficients of the linear program.
	 *
	 * For m data points and n symbols, the linear program has 2*K*m + n*(n-1)/2 + 1 variables,
	 * namely n*(n-1)/2 entries in the pairwise symbol replacement matric C which we expect to be
	 * symmetric with zeros on the diagonal, K*m slack variables representing the hinge loss to
	 * the closest correct neighbors
	 *
	 * [C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu;]<sub>+</sub>
	 *
	 * K*m slack variables representing the hinge loss to the furthest wrong neighbors
	 *
	 * [&nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>)]<sub>+</sub>
	 *
	 * and 1 slack variable representing the shift in the margin &nu;, that is, whether we want
	 * data points of the same class to be closer or data points from different classes to be
	 * further away.
	 *
	 * The linear program further has 2*K*m inequality constraints and lower/upper bound constraints
	 * for all variables. In particular, we have K*m inequality constraints of the form
	 *
	 * C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; &le; &xi;<sub>i, k</sub><sup>+</sup>
	 * &hArr; C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; - &xi;<sub>i, k</sub><sup>+</sup>
	 * &le;
	 * 0
	 *
	 * where &xi;<sub>i, k</sub><sup>+</sup> is the slack variable for the hinge loss of i to its
	 * kth closest neighbor from the same class; and we have K*m inequality constraints of the form
	 *
	 * &nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) &le; &xi;<sub>i,
	 * k</sub><sup>-</sup>
	 * &hArr; &nu; - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) - &xi;<sub>i, k</sub><sup>-</sup>
	 * &le;
	 * - log(2)
	 *
	 * &xi;<sub>i, k</sub><sup>-</sup> is the slack variable for the hinge loss of i to its
	 * kth furthest neighbor from a different class.
	 *
	 * The lower bound for all variables is 0, the upper bound for all variables except &nu; is
	 * infinity, and the upper bound for &nu; is log(2).
	 *
	 * @param <X> the data class
	 * @param D the m x m distance matrix of pairwise tree edit distances for the whole data set.
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param coopt_algo an AlignmentAlgorithm which returns CooptimalMatrices.
	 * @param data the m-element list of data points.
	 * @param n the size of the alphabet.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLLinearProgram corresponding to the given inputs.
	 */
	public static <X> GESLLinearProgram fromCooptimalAlgorithm(double[][] D, int[] labels,
			final AlignmentAlgorithm<X, X, CooptimalMatrix> coopt_algo, List<List<X>> data,
			final int n, final int K, int numberOfThreads) {
		final int[] subset_idxs = new int[D.length];
		for (int i = 0; i < D.length; i++) {
			subset_idxs[i] = i;
		}
		return initialize(D, subset_idxs, labels, new GESLGradientCalculator.CooptimalFunction<List<X>>() {

			@Override
			public CooptimalMatrix compute(List<X> left, List<X> right) {
				return coopt_algo.calculateAlignment(left, right);
			}
		}, data, n, K, numberOfThreads);
	}

	/**
	 * Initializes a GESLLinearProgram calculator by selecting the K closest correct and furthest
	 * wrong neighbors, computing the edit scripts to them and transforming those scripts into
	 * coefficients of the linear program.
	 *
	 * For m data points and n symbols, the linear program has 2*K*m + n*(n-1)/2 + 1 variables,
	 * namely n*(n-1)/2 entries in the pairwise symbol replacement matric C which we expect to be
	 * symmetric with zeros on the diagonal, K*m slack variables representing the hinge loss to
	 * the closest correct neighbors
	 *
	 * [C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu;]<sub>+</sub>
	 *
	 * K*m slack variables representing the hinge loss to the furthest wrong neighbors
	 *
	 * [&nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>)]<sub>+</sub>
	 *
	 * and 1 slack variable representing the shift in the margin &nu;, that is, whether we want
	 * data points of the same class to be closer or data points from different classes to be
	 * further away.
	 *
	 * The linear program further has 2*K*m inequality constraints and lower/upper bound constraints
	 * for all variables. In particular, we have K*m inequality constraints of the form
	 *
	 * C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; &le; &xi;<sub>i, k</sub><sup>+</sup>
	 * &hArr; C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; - &xi;<sub>i, k</sub><sup>+</sup>
	 * &le;
	 * 0
	 *
	 * where &xi;<sub>i, k</sub><sup>+</sup> is the slack variable for the hinge loss of i to its
	 * kth closest neighbor from the same class; and we have K*m inequality constraints of the form
	 *
	 * &nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) &le; &xi;<sub>i,
	 * k</sub><sup>-</sup>
	 * &hArr; &nu; - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) - &xi;<sub>i, k</sub><sup>-</sup>
	 * &le;
	 * - log(2)
	 *
	 * &xi;<sub>i, k</sub><sup>-</sup> is the slack variable for the hinge loss of i to its
	 * kth furthest neighbor from a different class.
	 *
	 * The lower bound for all variables is 0, the upper bound for all variables except &nu; is
	 * infinity, and the upper bound for &nu; is log(2).
	 *
	 * @param <X> the data class
	 * @param D an m x m' distance matrix of pairwise tree edit distances between all data points
	 * and the data points which are selectable as neighbors.
	 * @param subset_idxs an m' x 1 index vector such that D[i][j] = d(data.get(i),
	 * data.get(subset_idxs[j])).
	 * @param labels a m' x 1 vector of labels for the potential neighbors.
	 * @param coopt_algo an AlignmentAlgorithm which returns CooptimalMatrices.
	 * @param data the m-element list of data points.
	 * @param n the size of the alphabet.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLLinearProgram corresponding to the given inputs.
	 */
	public static <X> GESLLinearProgram fromCooptimalAlgorithm(double[][] D, int[] subset_idxs, int[] labels,
			final AlignmentAlgorithm<X, X, CooptimalMatrix> coopt_algo, List<List<X>> data,
			final int n, final int K, int numberOfThreads) {
		return initialize(D, subset_idxs, labels, new GESLGradientCalculator.CooptimalFunction<List<X>>() {

			@Override
			public CooptimalMatrix compute(List<X> left, List<X> right) {
				return coopt_algo.calculateAlignment(left, right);
			}
		}, data, n, K, numberOfThreads);
	}

	/**
	 * Initializes a GESLLinearProgram calculator by selecting the K closest correct and furthest
	 * wrong neighbors, computing the edit scripts to them and transforming those scripts into
	 * coefficients of the linear program.
	 *
	 * For m data points and n symbols, the linear program has 2*K*m + n*(n-1)/2 + 1 variables,
	 * namely n*(n-1)/2 entries in the pairwise symbol replacement matric C which we expect to be
	 * symmetric with zeros on the diagonal, K*m slack variables representing the hinge loss to
	 * the closest correct neighbors
	 *
	 * [C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu;]<sub>+</sub>
	 *
	 * K*m slack variables representing the hinge loss to the furthest wrong neighbors
	 *
	 * [&nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>)]<sub>+</sub>
	 *
	 * and 1 slack variable representing the shift in the margin &nu;, that is, whether we want
	 * data points of the same class to be closer or data points from different classes to be
	 * further away.
	 *
	 * The linear program further has 2*K*m inequality constraints and lower/upper bound constraints
	 * for all variables. In particular, we have K*m inequality constraints of the form
	 *
	 * C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; &le; &xi;<sub>i, k</sub><sup>+</sup>
	 * &hArr; C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; - &xi;<sub>i, k</sub><sup>+</sup>
	 * &le;
	 * 0
	 *
	 * where &xi;<sub>i, k</sub><sup>+</sup> is the slack variable for the hinge loss of i to its
	 * kth closest neighbor from the same class; and we have K*m inequality constraints of the form
	 *
	 * &nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) &le; &xi;<sub>i,
	 * k</sub><sup>-</sup>
	 * &hArr; &nu; - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) - &xi;<sub>i, k</sub><sup>-</sup>
	 * &le;
	 * - log(2)
	 *
	 * &xi;<sub>i, k</sub><sup>-</sup> is the slack variable for the hinge loss of i to its
	 * kth furthest neighbor from a different class.
	 *
	 * The lower bound for all variables is 0, the upper bound for all variables except &nu; is
	 * infinity, and the upper bound for &nu; is log(2).
	 *
	 * @param <X> the data class
	 * @param D the m x m distance matrix of pairwise tree edit distances for the whole data set.
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param fullAlgo a TreeEditAlgorithm which returns Alignments
	 * @param data the m-element list of data points.
	 * @param n the size of the alphabet.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLLinearProgram corresponding to the given inputs.
	 */
	public static <X> GESLLinearProgram fromTreeEditAlgorithm(double[][] D, int[] labels,
			final TreeEditAlgorithm<X, X, Alignment> fullAlgo, List<Tree<X>> data,
			final int n, final int K, int numberOfThreads) {
		final int[] subset_idxs = new int[D.length];
		for (int i = 0; i < D.length; i++) {
			subset_idxs[i] = i;
		}
		return initialize(D, subset_idxs, labels, new GESLGradientCalculator.CooptimalFunction<Tree<X>>() {

			@Override
			public CooptimalMatrix compute(Tree<X> left, Tree<X> right) {
				final Alignment ali = fullAlgo.calculateAlignment(left, right);
				return CooptimalMatrix.fromAlignment(ali);
			}
		}, data, n, K, numberOfThreads);
	}

	/**
	 * Initializes a GESLLinearProgram calculator by selecting the K closest correct and furthest
	 * wrong neighbors, computing the edit scripts to them and transforming those scripts into
	 * coefficients of the linear program.
	 *
	 * For m data points and n symbols, the linear program has 2*K*m + n*(n-1)/2 + 1 variables,
	 * namely n*(n-1)/2 entries in the pairwise symbol replacement matric C which we expect to be
	 * symmetric with zeros on the diagonal, K*m slack variables representing the hinge loss to
	 * the closest correct neighbors
	 *
	 * [C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu;]<sub>+</sub>
	 *
	 * K*m slack variables representing the hinge loss to the furthest wrong neighbors
	 *
	 * [&nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>)]<sub>+</sub>
	 *
	 * and 1 slack variable representing the shift in the margin &nu;, that is, whether we want
	 * data points of the same class to be closer or data points from different classes to be
	 * further away.
	 *
	 * The linear program further has 2*K*m inequality constraints and lower/upper bound constraints
	 * for all variables. In particular, we have K*m inequality constraints of the form
	 *
	 * C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; &le; &xi;<sub>i, k</sub><sup>+</sup>
	 * &hArr; C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; - &xi;<sub>i, k</sub><sup>+</sup>
	 * &le;
	 * 0
	 *
	 * where &xi;<sub>i, k</sub><sup>+</sup> is the slack variable for the hinge loss of i to its
	 * kth closest neighbor from the same class; and we have K*m inequality constraints of the form
	 *
	 * &nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) &le; &xi;<sub>i,
	 * k</sub><sup>-</sup>
	 * &hArr; &nu; - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) - &xi;<sub>i, k</sub><sup>-</sup>
	 * &le;
	 * - log(2)
	 *
	 * &xi;<sub>i, k</sub><sup>-</sup> is the slack variable for the hinge loss of i to its
	 * kth furthest neighbor from a different class.
	 *
	 * The lower bound for all variables is 0, the upper bound for all variables except &nu; is
	 * infinity, and the upper bound for &nu; is log(2).
	 *
	 * @param <X> the data class
	 * @param D an m x m' distance matrix of pairwise tree edit distances between all data points
	 * and the data points which are selectable as neighbors.
	 * @param subset_idxs an m' x 1 index vector such that D[i][j] = d(data.get(i),
	 * data.get(subset_idxs[j])).
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param fullAlgo a TreeEditAlgorithm which returns Alignments
	 * @param data the m-element list of data points.
	 * @param n the size of the alphabet.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLLinearProgram corresponding to the given inputs.
	 */
	public static <X> GESLLinearProgram fromTreeEditAlgorithm(double[][] D, int[] subset_idxs,
			int[] labels, final TreeEditAlgorithm<X, X, Alignment> fullAlgo, List<Tree<X>> data,
			final int n, final int K, int numberOfThreads) {
		return initialize(D, subset_idxs, labels, new GESLGradientCalculator.CooptimalFunction<Tree<X>>() {

			@Override
			public CooptimalMatrix compute(Tree<X> left, Tree<X> right) {
				final Alignment ali = fullAlgo.calculateAlignment(left, right);
				return CooptimalMatrix.fromAlignment(ali);
			}
		}, data, n, K, numberOfThreads);
	}

	/**
	 * Initializes a GESLLinearProgram calculator by selecting the K closest correct and furthest
	 * wrong neighbors, computing the edit scripts to them and transforming those scripts into
	 * coefficients of the linear program.
	 *
	 * For m data points and n symbols, the linear program has 2*K*m + n*(n-1)/2 + 1 variables,
	 * namely n*(n-1)/2 entries in the pairwise symbol replacement matric C which we expect to be
	 * symmetric with zeros on the diagonal, K*m slack variables representing the hinge loss to
	 * the closest correct neighbors
	 *
	 * [C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu;]<sub>+</sub>
	 *
	 * K*m slack variables representing the hinge loss to the furthest wrong neighbors
	 *
	 * [&nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>)]<sub>+</sub>
	 *
	 * and 1 slack variable representing the shift in the margin &nu;, that is, whether we want
	 * data points of the same class to be closer or data points from different classes to be
	 * further away.
	 *
	 * The linear program further has 2*K*m inequality constraints and lower/upper bound constraints
	 * for all variables. In particular, we have K*m inequality constraints of the form
	 *
	 * C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; &le; &xi;<sub>i, k</sub><sup>+</sup>
	 * &hArr; C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; - &xi;<sub>i, k</sub><sup>+</sup>
	 * &le;
	 * 0
	 *
	 * where &xi;<sub>i, k</sub><sup>+</sup> is the slack variable for the hinge loss of i to its
	 * kth closest neighbor from the same class; and we have K*m inequality constraints of the form
	 *
	 * &nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) &le; &xi;<sub>i,
	 * k</sub><sup>-</sup>
	 * &hArr; &nu; - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) - &xi;<sub>i, k</sub><sup>-</sup>
	 * &le;
	 * - log(2)
	 *
	 * &xi;<sub>i, k</sub><sup>-</sup> is the slack variable for the hinge loss of i to its
	 * kth furthest neighbor from a different class.
	 *
	 * The lower bound for all variables is 0, the upper bound for all variables except &nu; is
	 * infinity, and the upper bound for &nu; is log(2).
	 *
	 * @param <X> the data class
	 * @param D the m x m distance matrix of pairwise tree edit distances for the whole data set.
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param cooptAlgo a TreeEditAlgorithm which returns CooptimalMatrices.
	 * @param data the m-element list of data points.
	 * @param n the size of the alphabet.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLLinearProgram corresponding to the given inputs.
	 */
	public static <X> GESLLinearProgram fromTreeEditCooptimalAlgorithm(double[][] D, int[] labels,
			final TreeEditAlgorithm<X, X, CooptimalMatrix> cooptAlgo, List<Tree<X>> data, final int n,
			final int K, int numberOfThreads) {
		final int[] subset_idxs = new int[D.length];
		for (int i = 0; i < D.length; i++) {
			subset_idxs[i] = i;
		}
		return initialize(D, subset_idxs, labels, new GESLGradientCalculator.CooptimalFunction<Tree<X>>() {

			@Override
			public CooptimalMatrix compute(Tree<X> left, Tree<X> right) {
				return cooptAlgo.calculateAlignment(left, right);
			}
		}, data, n, K, numberOfThreads);
	}

	/**
	 * Initializes a GESLLinearProgram calculator by selecting the K closest correct and furthest
	 * wrong neighbors, computing the edit scripts to them and transforming those scripts into
	 * coefficients of the linear program.
	 *
	 * For m data points and n symbols, the linear program has 2*K*m + n*(n-1)/2 + 1 variables,
	 * namely n*(n-1)/2 entries in the pairwise symbol replacement matric C which we expect to be
	 * symmetric with zeros on the diagonal, K*m slack variables representing the hinge loss to
	 * the closest correct neighbors
	 *
	 * [C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu;]<sub>+</sub>
	 *
	 * K*m slack variables representing the hinge loss to the furthest wrong neighbors
	 *
	 * [&nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>)]<sub>+</sub>
	 *
	 * and 1 slack variable representing the shift in the margin &nu;, that is, whether we want
	 * data points of the same class to be closer or data points from different classes to be
	 * further away.
	 *
	 * The linear program further has 2*K*m inequality constraints and lower/upper bound constraints
	 * for all variables. In particular, we have K*m inequality constraints of the form
	 *
	 * C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; &le; &xi;<sub>i, k</sub><sup>+</sup>
	 * &hArr; C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; - &xi;<sub>i, k</sub><sup>+</sup>
	 * &le;
	 * 0
	 *
	 * where &xi;<sub>i, k</sub><sup>+</sup> is the slack variable for the hinge loss of i to its
	 * kth closest neighbor from the same class; and we have K*m inequality constraints of the form
	 *
	 * &nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) &le; &xi;<sub>i,
	 * k</sub><sup>-</sup>
	 * &hArr; &nu; - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) - &xi;<sub>i, k</sub><sup>-</sup>
	 * &le;
	 * - log(2)
	 *
	 * &xi;<sub>i, k</sub><sup>-</sup> is the slack variable for the hinge loss of i to its
	 * kth furthest neighbor from a different class.
	 *
	 * The lower bound for all variables is 0, the upper bound for all variables except &nu; is
	 * infinity, and the upper bound for &nu; is log(2).
	 *
	 * @param <X> the data class
	 * @param D an m x m' distance matrix of pairwise tree edit distances between all data points
	 * and the data points which are selectable as neighbors.
	 * @param subset_idxs an m' x 1 index vector such that D[i][j] = d(data.get(i),
	 * data.get(subset_idxs[j])).
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param cooptAlgo a TreeEditAlgorithm which returns CooptimalMatrices.
	 * @param data the m-element list of data points.
	 * @param n the size of the alphabet.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLLinearProgram corresponding to the given inputs.
	 */
	public static <X> GESLLinearProgram fromTreeEditCooptimalAlgorithm(
			double[][] D, int[] subset_idxs, int[] labels,
			final TreeEditAlgorithm<X, X, CooptimalMatrix> cooptAlgo,
			List<Tree<X>> data, final int n, final int K, int numberOfThreads) {
		return initialize(D, subset_idxs, labels, new GESLGradientCalculator.CooptimalFunction<Tree<X>>() {

			@Override
			public CooptimalMatrix compute(Tree<X> left, Tree<X> right) {
				return cooptAlgo.calculateAlignment(left, right);
			}
		}, data, n, K, numberOfThreads);
	}

	/**
	 * Initializes a GESLLinearProgram calculator by selecting the K closest correct and furthest
	 * wrong neighbors, computing the edit scripts to them and transforming those scripts into
	 * coefficients of the linear program.
	 *
	 * For m data points and n symbols, the linear program has 2*K*m + n*(n-1)/2 + 1 variables,
	 * namely n*(n-1)/2 entries in the pairwise symbol replacement matric C which we expect to be
	 * symmetric with zeros on the diagonal, K*m slack variables representing the hinge loss to
	 * the closest correct neighbors
	 *
	 * [C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu;]<sub>+</sub>
	 *
	 * K*m slack variables representing the hinge loss to the furthest wrong neighbors
	 *
	 * [&nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>)]<sub>+</sub>
	 *
	 * and 1 slack variable representing the shift in the margin &nu;, that is, whether we want
	 * data points of the same class to be closer or data points from different classes to be
	 * further away.
	 *
	 * The linear program further has 2*K*m inequality constraints and lower/upper bound constraints
	 * for all variables. In particular, we have K*m inequality constraints of the form
	 *
	 * C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; &le; &xi;<sub>i, k</sub><sup>+</sup>
	 * &hArr; C * coopts(i, j<sub>i, k</sub><sup>+</sup>) - &nu; - &xi;<sub>i, k</sub><sup>+</sup>
	 * &le;
	 * 0
	 *
	 * where &xi;<sub>i, k</sub><sup>+</sup> is the slack variable for the hinge loss of i to its
	 * kth closest neighbor from the same class; and we have K*m inequality constraints of the form
	 *
	 * &nu; + log(2) - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) &le; &xi;<sub>i,
	 * k</sub><sup>-</sup>
	 * &hArr; &nu; - C * coopts(i, j<sub>i, k</sub><sup>-</sup>) - &xi;<sub>i, k</sub><sup>-</sup>
	 * &le;
	 * - log(2)
	 *
	 * &xi;<sub>i, k</sub><sup>-</sup> is the slack variable for the hinge loss of i to its
	 * kth furthest neighbor from a different class.
	 *
	 * The lower bound for all variables is 0, the upper bound for all variables except &nu; is
	 * infinity, and the upper bound for &nu; is log(2).
	 *
	 * @param <X> the data class
	 * @param D an m x m' distance matrix of pairwise tree edit distances between all data points
	 * and the data points which are selectable as neighbors.
	 * @param subset_idxs an m' x 1 index vector such that D[i][j] = d(data.get(i),
	 * data.get(subset_idxs[j])).
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param fun a function which returns the CooptimalMatrix for two input data points.
	 * @param data the m-element list of data points.
	 * @param n the size of the alphabet.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLLinearProgram corresponding to the given inputs.
	 */
	public static <X> GESLLinearProgram initialize(double[][] D, int[] subset_idxs, int[] labels,
			GESLGradientCalculator.CooptimalFunction<X> fun, List<X> data, final int n, final int K,
			int numberOfThreads) {
		// check input
		final int m = D.length;
		if (m != labels.length) {
			throw new IllegalArgumentException("Expected one row of the distance matrix per label, but got "
					+ m + " rows and " + labels.length + " labels.");
		}
		if (data.size() != m) {
			throw new IllegalArgumentException("Expected one data point per label, but got "
					+ labels.length + " labels and " + data.size() + " data points.");
		}
		if (m < 1) {
			throw new IllegalArgumentException("The input distance matrix was empty!");
		}

		final int m2 = D[0].length;

		for (int i = 1; i < m; i++) {
			if (D[i].length != m2) {
				throw new IllegalArgumentException("Expected a distance matrix as input, but "
						+ "the input array had an inconsistent number of columns.");
			}
		}
		if (m2 != subset_idxs.length) {
			throw new IllegalArgumentException("Expected one index per column of the distance matrix, but got "
					+ m2 + " columns and " + subset_idxs.length + " indices.");
		}

		if (n < 1) {
			throw new IllegalArgumentException("We expect an alpahbet size of at least 1.");
		}
		if (K < 1) {
			throw new IllegalArgumentException("We have to consider at least one neighbor for metric learning.");
		}
		if (numberOfThreads < 1) {
			throw new IllegalArgumentException("We need at least one thread for parallel constraint computation.");
		}

		// generate the objective function, which is to minimize all slack variables representing
		// the hinge loss. These are the variables n * (n+1) / 2 ... n * (n+1) / 2 + 2 * K * m - 1
		final int num_params = (n * (n + 1)) / 2;
		final int num_vars = num_params + 2 * K * m + 1;
		final double[] f = new double[num_vars];
		for (int i = 0; i < m; i++) {
			for (int k = 0; k < K; k++) {
				f[num_params + i * K + k] = 1;
				f[num_params + m * K + i * K + k] = 1;
			}
		}

		// compute the constraint matrix representing the hinge loss in parallel
		final ExecutorService threadPool = Executors.newFixedThreadPool(numberOfThreads);
		// submit calculation tasks.
		final ArrayList<Future<List<SparseEntry>>> futureResults = new ArrayList<>();
		for (int i = 0; i < m; i++) {
			futureResults.add(threadPool.submit(new PositiveInitializationTask<>(
					i, D[i], subset_idxs, labels, fun, data, m, n, K)));
		}
		for (int i = 0; i < m; i++) {
			futureResults.add(threadPool.submit(new NegativeInitializationTask<>(
					i, D[i], subset_idxs, labels, fun, data, m, n, K)));
		}
		// initiate thread pool shutdown (which just means that no new jobs
		// will be accepted. The old ones still apply).
		threadPool.shutdown();
		// gather the results
		final ArrayList<SparseEntry> entries = new ArrayList<>(2 * m * K);
		for (int i = 0; i < 2 * m; i++) {
			try {
				entries.addAll(futureResults.get(i).get());
			} catch (InterruptedException | ExecutionException ex) {
				throw new RuntimeException("GESLGradientCalculator got interrupted during initialization! ", ex);
			}
		}
		final IndexMatrix A = new IndexMatrix(entries);
		// compute the vector containing the constant term for the inequality constraints
		final double[] b = new double[2 * K * m];
		final double up = Math.log(2);
		for (int i = 0; i < m; i++) {
			for (int k = 0; k < K; k++) {
				b[(m + i) * K + k] = -up;
			}
		}
		// The lower bound for all variables is zero
		final double[] lb = new double[num_vars];
		// Only &nu; has an upper bound, no other variable
		final double[] ub = new double[num_vars];
		Arrays.fill(ub, Double.POSITIVE_INFINITY);
		ub[num_params + 2 * K * m] = up;
		return new GESLLinearProgram(f, A, b, lb, ub);
	}

	private static class PositiveInitializationTask<X> implements Callable<List<SparseEntry>> {

		private final int i;
		private final double[] d;
		private final int[] subset_idxs;
		private final int[] labels;
		private final GESLGradientCalculator.CooptimalFunction<X> coopt_fun;
		private final List<X> data;
		private final int m;
		private final int n;
		private final int K;

		public PositiveInitializationTask(int i, double[] d, int[] subset_idxs, int[] labels, CooptimalFunction<X> coopt_fun, List<X> data, int m, int n, int K) {
			this.i = i;
			this.d = d;
			this.subset_idxs = subset_idxs;
			this.labels = labels;
			this.coopt_fun = coopt_fun;
			this.data = data;
			this.m = m;
			this.n = n;
			this.K = K;
		}

		@Override
		public List<SparseEntry> call() throws Exception {
			// find the K closest neighbors with the same label
			final int[] target_neighbors = new int[K];
			int found = 0;
			final int label = labels[i];
			for (int j = 0; j < d.length; j++) {
				if (i == subset_idxs[j] || label != labels[subset_idxs[j]]) {
					continue;
				}
				if (found < K) {
					// insert j into the sorted list of target neighbors
					int l = found;
					while (l > 0 && d[j] < d[target_neighbors[l - 1]]) {
						target_neighbors[l] = target_neighbors[l - 1];
						l--;
					}
					target_neighbors[l] = j;
					// increase the number of found neighbors.
					found++;
				} else if (d[j] < d[target_neighbors[K - 1]]) {
					// insert j into the sorted list of target neighbors
					int l = K - 1;
					while (l > 0 && d[j] < d[target_neighbors[l - 1]]) {
						target_neighbors[l] = target_neighbors[l - 1];
						l--;
					}
					target_neighbors[l] = j;
				}
			}
			if (found < 0) {
				throw new IllegalArgumentException("Found only  " + found + " neighbors with label "
						+ label + " for point " + i + " but " + K + " neighbors were requested!");
			}
			final int num_params = (n * (n + 1)) / 2;
			final int nu_index = num_params + 2 * K * m;
			final ArrayList<SparseEntry> entries = new ArrayList<>(K);
			for (int k = 0; k < K; k++) {
				// compute the cheapest edit script between i and the kth closest neighbor
				final CooptimalMatrix<Tree<Integer>, Tree<Integer>> coopt_plus = coopt_fun.compute(
						data.get(i), data.get(subset_idxs[target_neighbors[k]]));
				// transform this edit script into entries of a constraint matrix.
				// first consider replacements
				final CooptimalMatrix.SparseMatrix reps = new CooptimalMatrix.SparseMatrix();
				for (final Entry<MatrixEngine.MatrixCoordinate, Double> entry : coopt_plus.getP_rep().entrySet()) {
					final int l = coopt_plus.getLeft().get(entry.getKey().i).getLabel();
					final int r = coopt_plus.getRight().get(entry.getKey().j).getLabel();
					if (l == r) {
						continue;
					}
					if (l > r) {
						reps.add(l, r, entry.getValue());
					} else {
						reps.add(r, l, entry.getValue());
					}
				}
				for (final Entry<MatrixEngine.MatrixCoordinate, Double> entry : reps.entrySet()) {
					final int l = entry.getKey().i;
					final int r = entry.getKey().j;
					final int s = (l * (l - 1)) / 2 + r;
					entries.add(new SparseEntry(i * K + k, s, entry.getValue()));
				}
				// then deletions and insertions
				final double[] gap_coeffs = new double[n];
				for (int i2 = 0; i2 < coopt_plus.getLeft().size(); i2++) {
					if (coopt_plus.getP_del()[i2] > 0) {
						final int l = coopt_plus.getLeft().get(i2).getLabel();
						gap_coeffs[l] += coopt_plus.getP_del()[i2];
					}
				}
				for (int j2 = 0; j2 < coopt_plus.getRight().size(); j2++) {
					if (coopt_plus.getP_ins()[j2] > 0) {
						final int r = coopt_plus.getRight().get(j2).getLabel();
						gap_coeffs[r] += coopt_plus.getP_ins()[j2];
					}
				}
				for (int l = 0; l < n; l++) {
					if (gap_coeffs[l] > 0) {
						entries.add(new SparseEntry(i * K + k, (n * (n - 1)) / 2 + l, gap_coeffs[l]));
					}
				}
				// then add the terms for the slack variable ...
				entries.add(new SparseEntry(i * K + k, num_params + i * K + k, -1));
				// ... and for the margin shift
				entries.add(new SparseEntry(i * K + k, nu_index, -1));
			}
			return entries;
		}

	}

	private static class NegativeInitializationTask<X> implements Callable<List<SparseEntry>> {

		private final int i;
		private final double[] d;
		private final int[] subset_idxs;
		private final int[] labels;
		private final GESLGradientCalculator.CooptimalFunction<X> coopt_fun;
		private final List<X> data;
		private final int m;
		private final int n;
		private final int K;

		public NegativeInitializationTask(int i, double[] d, int[] subset_idxs, int[] labels, CooptimalFunction<X> coopt_fun, List<X> data, int m, int n, int K) {
			this.i = i;
			this.d = d;
			this.subset_idxs = subset_idxs;
			this.labels = labels;
			this.coopt_fun = coopt_fun;
			this.data = data;
			this.m = m;
			this.n = n;
			this.K = K;
		}

		@Override
		public List<SparseEntry> call() throws Exception {
			// search for the K furthest neighbors with a different label
			final int[] target_neighbors = new int[K];
			int found = 0;
			final int label = labels[i];
			for (int j = 0; j < d.length; j++) {
				if (label == labels[subset_idxs[j]]) {
					continue;
				}
				if (found < K) {
					// insert j into the sorted list of target neighbors
					int l = found;
					while (l > 0 && d[j] > d[target_neighbors[l - 1]]) {
						target_neighbors[l] = target_neighbors[l - 1];
						l--;
					}
					target_neighbors[l] = j;
					// increase the number of found neighbors.
					found++;
				} else if (d[j] > d[target_neighbors[K - 1]]) {
					// insert j into the sorted list of target neighbors
					int l = K - 1;
					while (l > 0 && d[j] > d[target_neighbors[l - 1]]) {
						target_neighbors[l] = target_neighbors[l - 1];
						l--;
					}
					target_neighbors[l] = j;
				}
			}
			if (found < 0) {
				throw new IllegalArgumentException("Found only  " + found + " neighbors a different label than "
						+ label + " for point " + i + " but " + K + " neighbors were requested!");
			}
			final int num_params = (n * (n + 1)) / 2;
			final int nu_index = num_params + 2 * K * m;
			final ArrayList<SparseEntry> entries = new ArrayList<>(K);
			for (int k = 0; k < K; k++) {
				// compute the cheapest edit script between i and the kth furthest neighbor with a different label
				final CooptimalMatrix<Tree<Integer>, Tree<Integer>> coopt_minus = coopt_fun.compute(
						data.get(i), data.get(subset_idxs[target_neighbors[k]]));
				// transform this edit script into entries of a constraint matrix.
				// first consider replacements
				final CooptimalMatrix.SparseMatrix reps = new CooptimalMatrix.SparseMatrix();
				for (final Entry<MatrixEngine.MatrixCoordinate, Double> entry : coopt_minus.getP_rep().entrySet()) {
					final int l = coopt_minus.getLeft().get(entry.getKey().i).getLabel();
					final int r = coopt_minus.getRight().get(entry.getKey().j).getLabel();
					if (l == r) {
						continue;
					}
					if (l > r) {
						reps.add(l, r, entry.getValue());
					} else {
						reps.add(r, l, entry.getValue());
					}
				}
				for (final Entry<MatrixEngine.MatrixCoordinate, Double> entry : reps.entrySet()) {
					final int l = entry.getKey().i;
					final int r = entry.getKey().j;
					final int s = (l * (l - 1)) / 2 + r;
					entries.add(new SparseEntry((m + i) * K + k, s, -entry.getValue()));
				}
				// then deletions and insertions
				final double[] gap_coeffs = new double[n];
				for (int i2 = 0; i2 < coopt_minus.getLeft().size(); i2++) {
					if (coopt_minus.getP_del()[i2] > 0) {
						final int l = coopt_minus.getLeft().get(i2).getLabel();
						gap_coeffs[l] += coopt_minus.getP_del()[i2];
					}
				}
				for (int j2 = 0; j2 < coopt_minus.getRight().size(); j2++) {
					if (coopt_minus.getP_ins()[j2] > 0) {
						final int r = coopt_minus.getRight().get(j2).getLabel();
						gap_coeffs[r] += coopt_minus.getP_ins()[j2];
					}
				}
				for (int l = 0; l < n; l++) {
					if (gap_coeffs[l] > 0) {
						entries.add(new SparseEntry((m + i) * K + k, (n * (n - 1)) / 2 + l, -gap_coeffs[l]));
					}
				}
				// then add the terms for the slack variable ...
				entries.add(new SparseEntry((m + i) * K + k, num_params + (m + i) * K + k, -1));
				// ... and for the margin shift
				entries.add(new SparseEntry((m + i) * K + k, nu_index, +1));
			}
			return entries;
		}

	}
}
