/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.gesl;

import de.citec.tcs.alignment.Alignment;
import de.citec.tcs.alignment.AlignmentAlgorithm;
import de.citec.tcs.alignment.comparators.DerivableComparator;
import de.citec.tcs.alignment.parallel.CommandLineProgressReporter;
import de.citec.tcs.alignment.parallel.Engine;
import de.citec.tcs.alignment.parallel.ProgressReporter;
import de.citec.tcs.alignment.trees.CooptimalMatrix;
import de.citec.tcs.alignment.trees.Tree;
import de.citec.tcs.alignment.trees.TreeEditAlgorithm;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;

/**
 * Implements metric learning via Good Edit Similarity Learning (GESL) according to Bellet et al.
 * (2012).
 *
 * In particular, this implements the (sub-)gradient of the GESL cost function with respect to
 * some metric parameters &lambda; :
 *
 * &nabla;<sub>&lambda;</sub> 1 / (2 * K * m) * &Sigma;<sub>i=1</sub><sup>m</sup>
 * &Sigma;<sub>k=1</sub><sup>K</sup>
 * [d<sub>&lambda;</sub>(i, j<sub>i, k</sub><sup>+</sup>)]<sub>+</sub> +
 * [log(2) - d<sub>&lambda;</sub>(i, j<sub>i, k</sub><sup>-</sup>))]<sub>+</sub>
 * + &beta; ||&lambda;||^2
 *
 * where j<sub>i, k</sub><sup>+</sup> denotes the index of the kth closest neighbor to i with the
 * same label, j<sub>i, k</sub><sup>-</sup> denotes the index of the kth <em>furthest</em> neighbor
 * from i with a <em>different</em> label, and d<sub>&lambda;</sub>(i, j) denotes the tree edit
 * distance between data point i and data point j based on &lambda;.
 *
 * The gradient &nabla;<sub>&lambda;</sub> d<sub>&lambda;</sub>(i, j) is computed via the
 * decomposition
 *
 * d<sub>&lambda;</sub>(i, j) = coopts(i, j) * C
 *
 * where coopts(i, j) is a CooptimalMatrix between i and j, C is the matrix of pairwise symbol
 * replacement costs between all labels of tree i and tree j according to &lambda; and * denotes
 * the scalar product of the vectorized matrices.
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class GESLGradientCalculator {

	/**
	 * The CooptimalMatrix between every data point and its K closest neighbors in the same class,
	 * i.e. a m x K matrix where scripts_plus[i][k] contains the CooptimalMatrix between i and
	 * j<sub>i, k</sub><sup>+</sup>, such that i and j<sub>i, k</sub><sup>+</sup> have the same
	 * label and are as close as possible according to the default tree edit distance.
	 *
	 * @return The CooptimalMatrix between every data point and its K closest neighbors in the same
	 * class.
	 */
	@Getter
	@NonNull
	private final CooptimalMatrix[][] scripts_plus;
	/**
	 * The CooptimalMatrix between every data point and its furthest neighbor in another class,
	 * i.e. a m x K matrix where scripts_minus[i][k] contains the CooptimalMatrix between i and
	 * j<sub>i, k</sub><sup>-</sup>., such that i and j<sub>i, k</sub><sup>-</sup> have different
	 * labels and are as far as possible according to the default tree edit distance.
	 *
	 * @return The CooptimalMatrix between every data point and its K furthest neighbor in another
	 * class.
	 */
	@Getter
	@NonNull
	private final CooptimalMatrix[][] scripts_minus;

	/**
	 * The regularization strength hyper parameter &beta;. Good Edit Similarity Learning (GESL) is
	 * regularized with the L2 norm on the parameters.
	 *
	 * @param regularization The regularization strength hyper parameter &beta;.
	 *
	 * @return The regularization strength hyper parameter &beta;.
	 */
	@Getter
	@Setter
	private double regularization = 1E-5;

	/**
	 * The number of threads used in the parallel computation of the gradient on the LMNN cost
	 * function.
	 *
	 * @param numberOfThreads The number of threads used in the parallel computation of the gradient
	 * on the GLVQ cost function.
	 *
	 * @return The number of threads used in the parallel computation of the gradient on the GLVQ
	 * cost function.
	 */
	@Getter
	@Setter
	private int numberOfThreads = Engine.DEFAULT_NUMBER_OF_THREADS;
	/**
	 * The ProgressReporter that is used to report progress. This is a
	 * CommandLineProgressReporter per default. If it is set to null, the
	 * progress is not reported.
	 *
	 * @param reporter The ProgressReporter that is used to report progress.
	 *
	 * @return The ProgressReporter that is used to report progress.
	 */
	@Getter
	@Setter
	private ProgressReporter reporter = new CommandLineProgressReporter();

	private GESLGradientCalculator(CooptimalMatrix[][] scripts_plus, CooptimalMatrix[][] scripts_minus, int numberOfThreads) {
		this.scripts_plus = scripts_plus;
		this.scripts_minus = scripts_minus;
		this.numberOfThreads = numberOfThreads;
	}

	/**
	 * An interface for any function which can compute a CooptimalMatrix between two inputs.
	 *
	 * @param <X>
	 */
	public static interface CooptimalFunction<X> {

		public CooptimalMatrix compute(X left, X right);
	}

	/**
	 * Initializes a GESLGradientCalculator calculator by selecting the K closest correct and
	 * furthest wrong neighbors, and computing the edit scripts to them.
	 *
	 * @param <X> the data class
	 * @param D the m x m distance matrix of pairwise tree edit distances for the whole data set.
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param full_algo an AlignmentAlgorithm which returns Alignments
	 * @param data the m-element list of data points.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLGradientCalculator corresponding to the given inputs.
	 */
	public static <X> GESLGradientCalculator fromAlignmentAlgorithm(double[][] D, int[] labels,
			final AlignmentAlgorithm<X, X, Alignment> full_algo, List<List<X>> data,
			final int K, int numberOfThreads) {
		final int[] subset_idxs = new int[D.length];
		for (int i = 0; i < D.length; i++) {
			subset_idxs[i] = i;
		}
		return initialize(D, subset_idxs, labels, new GESLGradientCalculator.CooptimalFunction<List<X>>() {

			@Override
			public CooptimalMatrix compute(List<X> left, List<X> right) {
				final Alignment ali = full_algo.calculateAlignment(left, right);
				return CooptimalMatrix.fromAlignment(ali);
			}
		}, data, K, numberOfThreads);
	}

	/**
	 * Initializes a GESLGradientCalculator calculator by selecting the K closest correct and
	 * furthest wrong neighbors, and computing the edit scripts to them.
	 *
	 * @param <X> the data class
	 * @param D an m x m' distance matrix of pairwise tree edit distances between all data points
	 * and the data points which are selectable as neighbors.
	 * @param subset_idxs an m' x 1 index vector such that D[i][j] = d(data.get(i),
	 * data.get(subset_idxs[j])).
	 * @param labels a m' x 1 vector of labels for the potential neighbors.
	 * @param fullAlgo a AlignmentAlgorithm which returns Alignments
	 * @param data the m-element list of data points.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLGradientCalculator corresponding to the given inputs.
	 */
	public static <X> GESLGradientCalculator fromAlignmentAlgorithm(double[][] D, int[] subset_idxs,
			int[] labels, final AlignmentAlgorithm<X, X, Alignment> fullAlgo, List<List<X>> data,
			final int K, int numberOfThreads) {
		return initialize(D, subset_idxs, labels, new GESLGradientCalculator.CooptimalFunction<List<X>>() {

			@Override
			public CooptimalMatrix compute(List<X> left, List<X> right) {
				final Alignment ali = fullAlgo.calculateAlignment(left, right);
				return CooptimalMatrix.fromAlignment(ali);
			}
		}, data, K, numberOfThreads);
	}

	/**
	 * Initializes a GESLGradientCalculator calculator by selecting the K closest correct and
	 * furthest wrong neighbors, and computing the edit scripts to them.
	 *
	 * @param <X> the data class
	 * @param D the m x m distance matrix of pairwise tree edit distances for the whole data set.
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param coopt_algo an AlignmentAlgorithm which returns CooptimalMatrices.
	 * @param data the m-element list of data points.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLGradientCalculator corresponding to the given inputs.
	 */
	public static <X> GESLGradientCalculator fromCooptimalAlgorithm(double[][] D, int[] labels,
			final AlignmentAlgorithm<X, X, CooptimalMatrix> coopt_algo, List<List<X>> data,
			final int K, int numberOfThreads) {
		final int[] subset_idxs = new int[D.length];
		for (int i = 0; i < D.length; i++) {
			subset_idxs[i] = i;
		}
		return initialize(D, subset_idxs, labels, new GESLGradientCalculator.CooptimalFunction<List<X>>() {

			@Override
			public CooptimalMatrix compute(List<X> left, List<X> right) {
				return coopt_algo.calculateAlignment(left, right);
			}
		}, data, K, numberOfThreads);
	}

	/**
	 * Initializes a GESLGradientCalculator calculator by selecting the K closest correct and
	 * furthest wrong neighbors, and computing the edit scripts to them.
	 *
	 * @param <X> the data class
	 * @param D an m x m' distance matrix of pairwise tree edit distances between all data points
	 * and the data points which are selectable as neighbors.
	 * @param subset_idxs an m' x 1 index vector such that D[i][j] = d(data.get(i),
	 * data.get(subset_idxs[j])).
	 * @param labels a m' x 1 vector of labels for the potential neighbors.
	 * @param coopt_algo an AlignmentAlgorithm which returns CooptimalMatrices.
	 * @param data the m-element list of data points.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLGradientCalculator corresponding to the given inputs.
	 */
	public static <X> GESLGradientCalculator fromCooptimalAlgorithm(double[][] D, int[] subset_idxs, int[] labels,
			final AlignmentAlgorithm<X, X, CooptimalMatrix> coopt_algo, List<List<X>> data,
			final int K, int numberOfThreads) {
		return initialize(D, subset_idxs, labels, new GESLGradientCalculator.CooptimalFunction<List<X>>() {

			@Override
			public CooptimalMatrix compute(List<X> left, List<X> right) {
				return coopt_algo.calculateAlignment(left, right);
			}
		}, data, K, numberOfThreads);
	}

	/**
	 * Initializes a GESLGradientCalculator calculator by selecting the K closest correct and
	 * furthest wrong neighbors, and computing the edit scripts to them.
	 *
	 * @param <X> the data class
	 * @param D the m x m distance matrix of pairwise tree edit distances for the whole data set.
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param fullAlgo a TreeEditAlgorithm which returns Alignments
	 * @param data the m-element list of data points.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLGradientCalculator corresponding to the given inputs.
	 */
	public static <X> GESLGradientCalculator fromTreeEditAlgorithm(double[][] D, int[] labels,
			final TreeEditAlgorithm<X, X, Alignment> fullAlgo, List<Tree<X>> data,
			final int K, int numberOfThreads) {
		final int[] subset_idxs = new int[D.length];
		for (int i = 0; i < D.length; i++) {
			subset_idxs[i] = i;
		}
		return initialize(D, subset_idxs, labels, new GESLGradientCalculator.CooptimalFunction<Tree<X>>() {

			@Override
			public CooptimalMatrix compute(Tree<X> left, Tree<X> right) {
				final Alignment ali = fullAlgo.calculateAlignment(left, right);
				return CooptimalMatrix.fromAlignment(ali);
			}
		}, data, K, numberOfThreads);
	}

	/**
	 * Initializes a GESLGradientCalculator calculator by selecting the K closest correct and
	 * furthest wrong neighbors, and computing the edit scripts to them.
	 *
	 * @param <X> the data class
	 * @param D an m x m' distance matrix of pairwise tree edit distances between all data points
	 * and the data points which are selectable as neighbors.
	 * @param subset_idxs an m' x 1 index vector such that D[i][j] = d(data.get(i),
	 * data.get(subset_idxs[j])).
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param fullAlgo a TreeEditAlgorithm which returns Alignments
	 * @param data the m-element list of data points.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLGradientCalculator corresponding to the given inputs.
	 */
	public static <X> GESLGradientCalculator fromTreeEditAlgorithm(double[][] D, int[] subset_idxs,
			int[] labels, final TreeEditAlgorithm<X, X, Alignment> fullAlgo, List<Tree<X>> data,
			final int K, int numberOfThreads) {
		return initialize(D, subset_idxs, labels, new GESLGradientCalculator.CooptimalFunction<Tree<X>>() {

			@Override
			public CooptimalMatrix compute(Tree<X> left, Tree<X> right) {
				final Alignment ali = fullAlgo.calculateAlignment(left, right);
				return CooptimalMatrix.fromAlignment(ali);
			}
		}, data, K, numberOfThreads);
	}

	/**
	 * Initializes a GESLGradientCalculator calculator by selecting the K closest correct and
	 * furthest wrong neighbors, and computing the edit scripts to them.
	 *
	 * @param <X> the data class
	 * @param D the m x m distance matrix of pairwise tree edit distances for the whole data set.
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param cooptAlgo a TreeEditAlgorithm which returns CooptimalMatrices.
	 * @param data the m-element list of data points.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLGradientCalculator corresponding to the given inputs.
	 */
	public static <X> GESLGradientCalculator fromTreeEditCooptimalAlgorithm(double[][] D, int[] labels,
			final TreeEditAlgorithm<X, X, CooptimalMatrix> cooptAlgo, List<Tree<X>> data,
			final int K, int numberOfThreads) {
		final int[] subset_idxs = new int[D.length];
		for (int i = 0; i < D.length; i++) {
			subset_idxs[i] = i;
		}
		return initialize(D, subset_idxs, labels, new GESLGradientCalculator.CooptimalFunction<Tree<X>>() {

			@Override
			public CooptimalMatrix compute(Tree<X> left, Tree<X> right) {
				return cooptAlgo.calculateAlignment(left, right);
			}
		}, data, K, numberOfThreads);
	}

	/**
	 * Initializes a GESLGradientCalculator calculator by selecting the K closest correct and
	 * furthest wrong neighbors, and computing the edit scripts to them.
	 *
	 * @param <X> the data class
	 * @param D an m x m' distance matrix of pairwise tree edit distances between all data points
	 * and the data points which are selectable as neighbors.
	 * @param subset_idxs an m' x 1 index vector such that D[i][j] = d(data.get(i),
	 * data.get(subset_idxs[j])).
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param cooptAlgo a TreeEditAlgorithm which returns CooptimalMatrices.
	 * @param data the m-element list of data points.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLGradientCalculator corresponding to the given inputs.
	 */
	public static <X> GESLGradientCalculator fromTreeEditCooptimalAlgorithm(
			double[][] D, int[] subset_idxs, int[] labels,
			final TreeEditAlgorithm<X, X, CooptimalMatrix> cooptAlgo,
			List<Tree<X>> data, final int K, int numberOfThreads) {
		return initialize(D, subset_idxs, labels, new GESLGradientCalculator.CooptimalFunction<Tree<X>>() {

			@Override
			public CooptimalMatrix compute(Tree<X> left, Tree<X> right) {
				return cooptAlgo.calculateAlignment(left, right);
			}
		}, data, K, numberOfThreads);
	}

	/**
	 * Initializes a GESLGradientCalculator calculator by selecting the K closest correct and
	 * furthest wrong neighbors, and computing the edit scripts to them.
	 *
	 * @param <X> the data class
	 * @param D an m x m' distance matrix of pairwise tree edit distances between all data points
	 * and the data points which are selectable as neighbors.
	 * @param subset_idxs an m' x 1 index vector such that D[i][j] = d(data.get(i),
	 * data.get(subset_idxs[j])).
	 * @param labels a m x 1 vector of labels for all data points.
	 * @param fun a function which returns the CooptimalMatrix for two input data points.
	 * @param data the m-element list of data points.
	 * @param K the number of neighbors that should be considered (should be 1 per default).
	 * @param numberOfThreads the number of threads used for parallel CooptimalMatric computation
	 * (should be 16 per default).
	 *
	 * @return a GESLGradientCalculator corresponding to the given inputs.
	 */
	public static <X> GESLGradientCalculator initialize(double[][] D, int[] subset_idxs, int[] labels,
			GESLGradientCalculator.CooptimalFunction<X> fun, List<X> data, final int K,
			int numberOfThreads) {
		// check input
		final int m = D.length;
		if (m != labels.length) {
			throw new IllegalArgumentException("Expected one row of the distance matrix per label, but got "
					+ m + " rows and " + labels.length + " labels.");
		}
		if (data.size() != m) {
			throw new IllegalArgumentException("Expected one data point per label, but got "
					+ labels.length + " labels and " + data.size() + " data points.");
		}
		if (m < 1) {
			throw new IllegalArgumentException("The input distance matrix was empty!");
		}

		final int m2 = D[0].length;

		for (int i = 1; i < m; i++) {
			if (D[i].length != m2) {
				throw new IllegalArgumentException("Expected a distance matrix as input, but "
						+ "the input array had an inconsistent number of columns.");
			}
		}
		if (m2 != subset_idxs.length) {
			throw new IllegalArgumentException("Expected one index per column of the distance matrix, but got "
					+ m2 + " columns and " + subset_idxs.length + " indices.");
		}

		if (K < 1) {
			throw new IllegalArgumentException("We have to consider at least one neighbor for metric learning.");
		}
		if (numberOfThreads < 1) {
			throw new IllegalArgumentException("We need at least one thread for parallel constraint computation.");
		}

		// compute the initialization in parallel
		final ExecutorService threadPool = Executors.newFixedThreadPool(numberOfThreads);
		// submit calculation tasks.
		final ArrayList<Future<CooptimalMatrix[]>> futureResults = new ArrayList<>();
		for (int i = 0; i < D.length; i++) {
			futureResults.add(threadPool.submit(new PositiveInitializationTask<>(i, D[i], subset_idxs, labels, fun, data, K)));
			futureResults.add(threadPool.submit(new NegativeInitializationTask<>(i, D[i], subset_idxs, labels, fun, data, K)));
		}
		// initiate thread pool shutdown (which just means that no new jobs
		// will be accepted. The old ones still apply).
		threadPool.shutdown();
		// gather the results
		final CooptimalMatrix[][] scripts_plus = new CooptimalMatrix[D.length][];
		final CooptimalMatrix[][] scripts_minus = new CooptimalMatrix[D.length][];
		for (int i = 0; i < D.length; i++) {
			try {
				scripts_plus[i] = futureResults.get(2 * i).get();
				scripts_minus[i] = futureResults.get(2 * i + 1).get();
			} catch (InterruptedException | ExecutionException ex) {
				throw new RuntimeException("GESLGradientCalculator got interrupted during initialization! ", ex);
			}
		}
		return new GESLGradientCalculator(scripts_plus, scripts_minus, numberOfThreads);
	}

	private static class PositiveInitializationTask<X> implements Callable<CooptimalMatrix[]> {

		private final int i;
		private final double[] d;
		private final int[] subset_idxs;
		private final int[] labels;
		private final GESLGradientCalculator.CooptimalFunction<X> coopt_fun;
		private final List<X> data;
		private final int K;

		public PositiveInitializationTask(int i, double[] d, int[] subset_idxs, int[] labels,
				CooptimalFunction<X> coopt_fun, List<X> data, int K) {
			this.i = i;
			this.d = d;
			this.subset_idxs = subset_idxs;
			this.labels = labels;
			this.coopt_fun = coopt_fun;
			this.data = data;
			this.K = K;
		}

		@Override
		public CooptimalMatrix[] call() throws Exception {
			// find the K closest neighbors with the same label
			final int[] target_neighbors = new int[K];
			int found = 0;
			final int label = labels[i];
			for (int j = 0; j < d.length; j++) {
				if (i == subset_idxs[j] || label != labels[subset_idxs[j]]) {
					continue;
				}
				if (found < K) {
					// insert j into the sorted list of target neighbors
					int l = found;
					while (l > 0 && d[j] < d[target_neighbors[l - 1]]) {
						target_neighbors[l] = target_neighbors[l - 1];
						l--;
					}
					target_neighbors[l] = j;
					// increase the number of found neighbors.
					found++;
				} else if (d[j] < d[target_neighbors[K - 1]]) {
					// insert j into the sorted list of target neighbors
					int l = K - 1;
					while (l > 0 && d[j] < d[target_neighbors[l - 1]]) {
						target_neighbors[l] = target_neighbors[l - 1];
						l--;
					}
					target_neighbors[l] = j;
				}
			}
			if (found < 0) {
				throw new IllegalArgumentException("Found only  " + found + " neighbors with label "
						+ label + " for point " + i + " but " + K + " neighbors were requested!");
			}
			final CooptimalMatrix[] coopts_plus = new CooptimalMatrix[K];
			for (int k = 0; k < K; k++) {
				coopts_plus[k] = coopt_fun.compute(data.get(i), data.get(subset_idxs[target_neighbors[k]]));
			}
			return coopts_plus;
		}

	}

	private static class NegativeInitializationTask<X> implements Callable<CooptimalMatrix[]> {

		private final int i;
		private final double[] d;
		private final int[] subset_idxs;
		private final int[] labels;
		private final GESLGradientCalculator.CooptimalFunction<X> coopt_fun;
		private final List<X> data;
		private final int K;

		public NegativeInitializationTask(int i, double[] d, int[] subset_idxs, int[] labels,
				CooptimalFunction<X> coopt_fun, List<X> data, int K) {
			this.i = i;
			this.d = d;
			this.subset_idxs = subset_idxs;
			this.labels = labels;
			this.coopt_fun = coopt_fun;
			this.data = data;
			this.K = K;
		}

		@Override
		public CooptimalMatrix[] call() throws Exception {
			// search for the K furthest neighbors with a different label
			final int[] target_neighbors = new int[K];
			int found = 0;
			final int label = labels[i];
			for (int j = 0; j < d.length; j++) {
				if (label == labels[subset_idxs[j]]) {
					continue;
				}
				if (found < K) {
					// insert j into the sorted list of target neighbors
					int l = found;
					while (l > 0 && d[j] > d[target_neighbors[l - 1]]) {
						target_neighbors[l] = target_neighbors[l - 1];
						l--;
					}
					target_neighbors[l] = j;
					// increase the number of found neighbors.
					found++;
				} else if (d[j] > d[target_neighbors[K - 1]]) {
					// insert j into the sorted list of target neighbors
					int l = K - 1;
					while (l > 0 && d[j] > d[target_neighbors[l - 1]]) {
						target_neighbors[l] = target_neighbors[l - 1];
						l--;
					}
					target_neighbors[l] = j;
				}
			}
			if (found < 0) {
				throw new IllegalArgumentException("Found only  " + found + " neighbors a different label than "
						+ label + " for point " + i + " but " + K + " neighbors were requested!");
			}
			final CooptimalMatrix[] coopts_minus = new CooptimalMatrix[K];
			for (int k = 0; k < K; k++) {
				coopts_minus[k] = coopt_fun.compute(data.get(i), data.get(subset_idxs[target_neighbors[k]]));
			}
			return coopts_minus;
		}

	}

	/**
	 * Calculates the value and the gradient of the GESL cost function with respect to the
	 * parameters of the given comparator.
	 *
	 * This gradient calculation runs in O(m), because only the distances to the closest
	 * correct neighbor and the furthest wrong neighbor are considered.
	 *
	 * @param comp the comparator with respect to which the gradient shall be computed.
	 *
	 * @return the value and the gradient of the GLVQ cost function with respect to the
	 * parameters of the given comparator.
	 */
	public double[] computeErrorAndGradient(@NonNull DerivableComparator comp) {

		// calculate the gradient.
		final double[] err_and_grad = new double[comp.getNumberOfParameters() + 1];
		final ParallelGradientEngine engine = new ParallelGradientEngine(comp);
		engine.setNumberOfThreads(numberOfThreads);
		engine.setReporter(reporter);
		// iterate over all datapoints.
		for (int i = 0; i < scripts_plus.length; i++) {
			// create a parallel processing job for it.
			engine.addTask(i);
		}
		// calculate
		engine.calculate();
		// sum up the resulting part-gradients.
		for (final Engine.CalculationResult<Integer, double[]> res : engine.getResults()) {
			for (int j = 0; j < err_and_grad.length; j++) {
				err_and_grad[j] += res.result[j];
			}
		}
		return err_and_grad;
	}

	private class ParallelGradientEngine extends Engine<Integer, double[]> {

		private final DerivableComparator comp;

		public ParallelGradientEngine(DerivableComparator comp) {
			super(Integer.class, double[].class);
			this.comp = comp;
		}

		@Override
		public Callable<double[]> createCallable(Integer i) {
			return new GESLGradientTask(comp, scripts_plus[i], scripts_minus[i], scripts_plus.length, regularization);
		}

	}

	private static final double MARGIN = Math.log(2);

	private static class GESLGradientTask implements Callable<double[]> {

		private final DerivableComparator comp;
		private final CooptimalMatrix[] scripts_plus;
		private final CooptimalMatrix[] scripts_minus;
		private final int m;
		private final double regularization;

		public GESLGradientTask(DerivableComparator comp,
				CooptimalMatrix[] script_plus, CooptimalMatrix[] script_minus,
				final int m, double regularization) {
			this.comp = comp;
			this.scripts_plus = script_plus;
			this.scripts_minus = script_minus;
			this.m = m;
			this.regularization = regularization;
		}

		@Override
		public double[] call() throws Exception {

			final int K = scripts_plus.length;
			final int n = comp.getNumberOfParameters();
			final double[] err_and_grad = new double[n + 1];

			// add the distance to the correct positive neighbors to the error and add the gradient
			for (int k = 0; k < K; k++) {
				err_and_grad[0] += scripts_plus[k].editDistance(comp);
				final double[] grad_plus = scripts_plus[k].computeGradient(comp);
				for (int j = 0; j < n; j++) {
					err_and_grad[j + 1] += grad_plus[j];
				}
			}
			// check the distance to the furthest neighbors
			for (int k = 0; k < K; k++) {
				final double d_minus = scripts_minus[k].editDistance(comp);
				// if d_minus is bigger than the Margin, it does not contribute to the error.
				if (d_minus < MARGIN) {
					// but if it is smaller, we compute the gradient
					err_and_grad[0] += MARGIN - d_minus;
					final double[] grad_minus = scripts_minus[k].computeGradient(comp);
					for (int j = 0; j < n; j++) {
						err_and_grad[j + 1] -= grad_minus[j];
					}
				}
			}
			// divide error and gradient until now by 2 * m
			for (int j = 0; j <= n; j++) {
				err_and_grad[j] /= (2 * m);
			}

			// finally, apply L2 regularization
			if (regularization > 0) {
				final double[] params = comp.getParameters();
				for (int j = 0; j < n; j++) {
					err_and_grad[0] += regularization * params[j];
					err_and_grad[j] += regularization * params[j];
				}
			}
			return err_and_grad;
		}
	}

}
