/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.lmnn;

import de.citec.tcs.alignment.Alignment;
import de.citec.tcs.alignment.comparators.DerivableComparator;
import de.citec.tcs.alignment.parallel.CommandLineProgressReporter;
import de.citec.tcs.alignment.parallel.Engine;
import de.citec.tcs.alignment.parallel.ProgressReporter;
import de.citec.tcs.alignment.trees.CooptimalMatrix;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;

/**
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class LMNNCooptimalGradientCalculator<X> {

	/**
	 * The CooptimalMatrix for every input combination.
	 *
	 * @return The CooptimalMatrix for every input combination.
	 */
	@Getter
	@NonNull
	private final CooptimalMatrix[][] cooptimals;
	/**
	 * The labels for the training sequences.
	 *
	 * @return The labels for the training sequences.
	 */
	@Getter
	@NonNull
	private final int[] labels;

	/**
	 * The number of considered nearest neighbors in the LMNN cost function.
	 *
	 * @param K The number of considered nearest neighbors in the LMNN cost function.
	 *
	 * @return The number of considered nearest neighbors in the LMNN cost function.
	 */
	@Getter
	@Setter
	private int K = 5;
	/**
	 * The margin of safety that is required by the LMNN cost function.
	 *
	 * @param margin The margin of safety that is required by the LMNN cost function.
	 *
	 * @return The margin of safety that is required by the LMNN cost function.
	 */
	@Getter
	@Setter
	private double margin = 0.01;
	/**
	 * The number of threads used in the parallel computation of the gradient on the LMNN cost
	 * function.
	 *
	 * @param The number of threads used in the parallel computation of the gradient on the LMNN
	 * cost function.
	 *
	 * @return The number of threads used in the parallel computation of the gradient on the LMNN
	 * cost function.
	 */
	@Getter
	@Setter
	private int numberOfThreads = Engine.DEFAULT_NUMBER_OF_THREADS;
	/**
	 * The ProgressReporter that is used to report progress. This is a
	 * CommandLineProgressReporter per default. If it is set to null, the
	 * progress is not reported.
	 *
	 * @param reporter The ProgressReporter that is used to report progress.
	 *
	 * @return The ProgressReporter that is used to report progress.
	 */
	@Getter
	@Setter
	private ProgressReporter reporter = new CommandLineProgressReporter();

	public LMNNCooptimalGradientCalculator(@NonNull CooptimalMatrix[][] cooptimals, @NonNull int[] labels) {
		this.cooptimals = cooptimals;
		this.labels = labels;
		if (cooptimals.length != labels.length) {
			throw new IllegalArgumentException("Expected one label per input!");
		}
		for (int i = 0; i < cooptimals.length; i++) {
			if (cooptimals[i].length != labels.length) {
				throw new IllegalArgumentException("Expected square input matrix!");
			}
		}
	}

	public LMNNCooptimalGradientCalculator(@NonNull Alignment[][] alignments, @NonNull int[] labels) {
		if (alignments.length != labels.length) {
			throw new IllegalArgumentException("Expected one label per input!");
		}
		for (int i = 0; i < labels.length; i++) {
			if (alignments[i].length != labels.length) {
				throw new IllegalArgumentException("Expected square input matrix!");
			}
		}
		this.labels = labels;
		this.cooptimals = new CooptimalMatrix[labels.length][labels.length];
		for (int i = 0; i < labels.length; i++) {
			for (int j = 0; j < labels.length; j++) {
				this.cooptimals[i][j] = CooptimalMatrix.fromAlignment(alignments[i][j]);
			}
		}
	}

	/**
	 * Calculates the value and the gradient of the LMNN cost function with respect to the
	 * parameters of the given comparator.
	 *
	 * Note that this method relies on the intra-training distance matrix
	 * already being present. It can be calculated using a
	 * CooptimalDistanceEngine.
	 *
	 * This gradient calculation is (fairly) fast and works
	 * in linear time if (!) there are not many impostors. The worst case
	 * complexity for this method is still quadratic, but it tries to do as few
	 * computations as possible.
	 *
	 * @param comp the comparator itself.
	 * @param D given N training data points this should be a N x N matrix
	 * of alignment distances computed with the same distance
	 * scheme as is implemented by the given algorithm for this
	 * LMNNGradientCalculator. This distance matrix serves as basis for the
	 * determination of the LMNN cost function.
	 *
	 * @return the value and the gradient of the LMNN cost function with respect to the
	 * parameters of the given comparator. The first entry is the error, all remaining entries are
	 * the gradient.
	 */
	public double[] computeErrorAndGradient(@NonNull DerivableComparator<X, X> comp, @NonNull double[][] D) {
		// check the input
		if (labels.length != D.length) {
			throw new IllegalArgumentException(
					"Expected distances for each training data point, but had "
					+ labels.length + " data points and " + D.length
					+ " rows in the given distance matrix.");
		}
		for (int i = 0; i < labels.length; i++) {
			if (labels.length != D[i].length) {
				throw new IllegalArgumentException(
						"Expected distances to each training data point, but had "
						+ labels.length + " data points and " + D[i].length
						+ " columns in row " + i + " of the given distance matrix."
				);
			}
		}

		// calculate the gradient.
		final double[] gradient = new double[comp.getNumberOfParameters() + 1];
		final ParallelGradientEngine engine = new ParallelGradientEngine(comp, D);
		engine.setNumberOfThreads(numberOfThreads);
		engine.setReporter(reporter);
		// iterate over all datapoints.
		for (int i = 0; i < labels.length; i++) {
			// create a parallel processing job for it.
			engine.addTask(i);
		}
		// calculate
		engine.calculate();
		// sum up the resulting part-gradients.
		for (final Engine.CalculationResult<Integer, double[]> res : engine.getResults()) {
			for (int p = 0; p < gradient.length; p++) {
				gradient[p] += res.result[p];
			}
		}
		return gradient;
	}

	private class ParallelGradientEngine extends Engine<Integer, double[]> {

		private final DerivableComparator<X, X> comp;
		private final double[][] D;

		public ParallelGradientEngine(DerivableComparator<X, X> comp, double[][] D) {
			super(Integer.class, double[].class);
			this.comp = comp;
			this.D = D;
		}

		@Override
		public Callable<double[]> createCallable(Integer i) {
			return new LMNNGradientJob(comp, i, D[i]);
		}

	}

	private class LMNNGradientJob implements Callable<double[]> {

		private final DerivableComparator<X, X> comp;
		private final int i;
		private final double[] distances;

		public LMNNGradientJob(DerivableComparator<X, X> comp, int i, double[] distances) {
			this.comp = comp;
			this.i = i;
			this.distances = distances;
		}

		@Override
		public double[] call() throws Exception {
			final int n = comp.getNumberOfParameters();
			final double[] err_and_grad = new double[n + 1];
			// maintain a list with imposters and a list with gradients to the impostors
			final ArrayList<Integer> impostors = new ArrayList<>(K);
			double lo = 0;
			final ArrayList<double[]> impGrads = new ArrayList<>(K);

			// get the target neighbors.
			for (final int k : computeTargetNeighbors(distances, labels, i, K)) {
				// add the squared distance to the target neighbor to the error
				err_and_grad[0] += distances[k] * distances[k];
				// add the gradient of the squared distance to the target neighbor to the overall
				// gradient
				final CooptimalMatrix<X, X> tnCoopt = cooptimals[i][k];
				final double[] tnGrad = tnCoopt.computeGradient(comp);
				// add it to the existing gradient.
				for (int s = 0; s < n; s++) {
					err_and_grad[s + 1] += distances[k] * tnGrad[s];
				}
				// compute new impostors and compute the new gradients
				final List<Integer> newImpostors = computeImpostors(distances, lo, margin, labels, k);
				for (final int j : newImpostors) {
					final CooptimalMatrix<X, X> impCoopt = cooptimals[i][j];
					final double[] impGrad = impCoopt.computeGradient(comp);
					impGrads.add(impGrad);
				}
				// add the new impostors to the existing list and then process all impostors
				impostors.addAll(newImpostors);
				final double limit = distances[k] * distances[k] + margin * margin;
				final Iterator<double[]> impGradIt = impGrads.iterator();
				for (final int j : impostors) {
					// add the squared distance inside the margin of safety to the error
					err_and_grad[0] += limit - distances[j] * distances[j];
					// add the gradient of the squared distance to the target neighbors to
					// the overall gradient once more
					for (int s = 0; s < n; s++) {
						err_and_grad[s + 1] += distances[k] * tnGrad[s];
					}
					// add the gradient of the negative squared distance to the imposter to the
					// overall gradient
					final double[] impGrad = impGradIt.next();
					for (int s = 0; s < n; s++) {
						err_and_grad[s + 1] -= distances[j] * impGrad[s];
					}
				}
				lo = distances[k];
			}
			return err_and_grad;
		}
	}

	/**
	 * Computes the K target neighbors for the given data point, that is: the indices of the K
	 * closest points to point i which have the same label.
	 *
	 * @param distances the distances of data point i to all other data points.
	 * @param labels the labels for all data points.
	 * @param i the index of the data point for which target neighbors shall be computed.
	 * @param K the number of target neighbors.
	 *
	 * @return an array containing the indices of the K target neighbors, sorted in order of their
	 * distance.
	 */
	public static int[] computeTargetNeighbors(double[] distances, int[] labels, int i, int K) {

		final int[] target_neighbors = new int[K];
		// initialize the target neighbors with the first possible five neighbors
		int j = 0;
		{
			int k = 0;
			for (; j < i; j++) {
				if (labels[i] == labels[j]) {
					// once we found a target neighbor, insert it into the existing sorted list
					// of target neighbors via insertion sort
					int l = k - 1;
					while (l >= 0 && distances[j] < distances[target_neighbors[l]]) {
						target_neighbors[l + 1] = target_neighbors[l];
						l--;
					}
					target_neighbors[l + 1] = j;
					k++;
					if (k == K) {
						break;
					}
				}
			}
			if (k < K) {
				j++;

				for (; j < distances.length; j++) {
					if (labels[i] == labels[j]) {
						// once we found a target neighbor, insert it into the existing sorted list
						// of target neighbors via insertion sort
						int l = k - 1;
						while (l >= 0 && distances[j] < distances[target_neighbors[l]]) {
							target_neighbors[l + 1] = target_neighbors[l];
							l--;
						}
						target_neighbors[l + 1] = j;
						k++;
						if (k == K) {
							break;
						}
					}
				}
				if (k < K) {
					throw new IllegalArgumentException("Not enough target neighbors available!");
				}
			}
		}
		j++;

		// then iterate over the remaining distances and find target neighbors which are closer than
		// the current furthest neighbor
		if (j <= i) {
			for (; j < i; j++) {
				if (labels[i] == labels[j] && distances[j] < distances[target_neighbors[K - 1]]) {
					// sort the new target neighbor into the list
					int l = K - 2;
					while (l >= 0 && distances[j] < distances[target_neighbors[l]]) {
						target_neighbors[l + 1] = target_neighbors[l];
						l--;
					}
					target_neighbors[l + 1] = j;
				}
			}
			j++;
		}
		for (; j < distances.length; j++) {
			if (labels[i] == labels[j] && distances[j] < distances[target_neighbors[K - 1]]) {
				// sort the new target neighbor into the list
				int l = K - 2;
				while (l >= 0 && distances[j] < distances[target_neighbors[l]]) {
					target_neighbors[l + 1] = target_neighbors[l];
					l--;
				}
				target_neighbors[l + 1] = j;
			}
		}
		return target_neighbors;
	}

	/**
	 * Computes the impostors with respect to data point i and target neighbor k, that is, the
	 * indices j of all data points which have a different label than k but for which
	 * distances[j] &lt; distances[k] + margin.
	 *
	 * @param distances the distances of data point i to all other data points.
	 * @param margin a margin of safety
	 * @param labels the labels for all data points.
	 * @param k the index of a target neighbor.
	 *
	 * @return an array containing the indices of the K target neighbors.
	 */
	public static List<Integer> computeImpostors(double[] distances, double margin, int[] labels, int k) {
		return computeImpostors(distances, 0, margin, labels, k);
	}

	private static List<Integer> computeImpostors(double[] distances, double lo, double margin, int[] labels, int k) {
		final ArrayList<Integer> impostors = new ArrayList<>();
		final double limit = distances[k] * distances[k] + margin * margin;
		for (int j = 0; j < distances.length; j++) {
			if (labels[j] != labels[k] && distances[j] >= lo && distances[j] * distances[j] <= limit) {
				impostors.add(j);
			}
		}
		return impostors;
	}

}
