/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.tcs.utils;

import java.util.ArrayList;
import java.util.List;

/**
 * A utility class for selecting data from lists using MATLAB.
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class MatlabListInterface {

	private MatlabListInterface() {

	}

	/**
	 * Selects a sublist of the given list using the given indices. Note: If indices are duplicated,
	 * the data object will also be duplicated in the output list.
	 *
	 * @param <X> the class of the input data objects.
	 * @param list a list of input data objects.
	 * @param idxs an array of indices in matlab notation, that is: indices start at 1.
	 * @return a list where element i is element idxs[i] from the input list.
	 */
	public static <X> List<X> selectFromList(List<X> list, int[] idxs) {
		final ArrayList<X> out = new ArrayList<>(idxs.length);
		for (int i : idxs) {
			out.add(list.get(i - 1));
		}
		return out;
	}

	/**
	 * Selects a sublist of the given list using the given logical array.
	 *
	 * @param <X> the class of the input data objects.
	 * @param list a list of input data objects.
	 * @param logical a boolen array exactly as long as the input array.
	 * @return a list where element i of the original list is contained if logical[i] is true.
	 */
	public static <X> List<X> selectFromList(List<X> list, boolean[] logical) {
		if (list.size() != logical.length) {
			throw new IllegalArgumentException("The given logical array does not have the same length as the input list!");
		}
		final ArrayList<X> out = new ArrayList<>();
		for (int i = 0; i < list.size(); i++) {
			if (logical[i]) {
				out.add(list.get(i));
			}
		}
		return out;
	}

}
