/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.tcs.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * A utility class for creating crossvalidation folds.
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class Crossvalidation {

	private Crossvalidation() {

	}

	/**
	 * Flattens a multidimensional label array to a single dimensional label array by assigning each
	 * class combination to a unique label.
	 *
	 * @param labels a multidimensional label matrix.
	 *
	 * @return a corresponding single-dimensional label vector.
	 */
	public static int[] flattenLabels(final int[][] labels) {
		// check the input and handle special cases
		if (labels.length == 0) {
			return new int[0];
		}
		final int K = labels[0].length;
		for (int i = 1; i < labels.length; i++) {
			if (labels[i].length != K) {
				throw new IllegalArgumentException("Inconsistent number of label dimensions!"
						+ " Data point " + i + " has " + labels[i].length + " dimensions, but the first"
						+ "data point has " + K + " dimensions.");
			}
		}

		// create a set with the unique label combinations
		final TreeSet<int[]> uniqueLabels = new TreeSet<>(new LexicographicComparator());
		uniqueLabels.addAll(Arrays.asList(labels));
		// create a mapping of multi-dimensional labels to single-dimensional labels
		final TreeMap<int[], Integer> labelMapping = new TreeMap<>(new LexicographicComparator());
		{
			int l = 0;
			for (final int[] label : uniqueLabels) {
				labelMapping.put(label, l++);
			}
		}
		// apply the mapping
		final int[] singleLabels = new int[labels.length];
		for (int i = 0; i < labels.length; i++) {
			singleLabels[i] = labelMapping.get(labels[i]);
		}
		return singleLabels;
	}

	private static class LexicographicComparator implements Comparator<int[]> {

		@Override
		public int compare(int[] o1, int[] o2) {
			for (int k = 0; k < o1.length; k++) {
				final int compare = Integer.compare(o1[k], o2[k]);
				if (compare != 0) {
					return compare;
				}
			}
			return 0;
		}

	}

	/**
	 * Given an N x 1 label vector with L unique entries this returns an int array of array where
	 * each row contains the indices of members of the lth class (in numeric order).
	 *
	 * @param labels the labels for each data point.
	 *
	 * @return an int array of array where each row contains the indices of members of the lth class
	 * (in numeric order).
	 */
	public static int[][] getClassMemberMatrix(final int[] labels) {
		return getClassMemberMatrix(labels, false);
	}

	/**
	 * Given an N x 1 label vector with L unique entries this returns an int array of array where
	 * each row contains the indices of members of the lth class (in numeric order).
	 *
	 * @param labels the labels for each data point.
	 * @param normalizeLength if set to true, the output will be a matrix with consistent number of
	 * columns. Missing entries will be filled up with duplicate indices.
	 *
	 * @return an int array of array where each row contains the indices of members of the lth class
	 * (in numeric order).
	 */
	public static int[][] getClassMemberMatrix(final int[] labels, boolean normalizeLength) {
		final Map<Integer, List<Integer>> labelMap = getClassRepresentation(labels);
		int M = 0;
		if (normalizeLength) {
			for (final List<Integer> members : labelMap.values()) {
				M = Math.max(M, members.size());
			}
		}

		final int[][] memberMat = new int[labelMap.size()][];
		int l = 0;
		for (final List<Integer> members : labelMap.values()) {
			if (!normalizeLength) {
				memberMat[l] = new int[members.size()];
			} else {
				memberMat[l] = new int[M];
			}

			for (int i = 0; i < members.size(); i++) {
				memberMat[l][i] = members.get(i);
			}
			if (normalizeLength) {
				final int duplicateIndex = members.get(members.size() - 1);
				for (int i = members.size(); i < M; i++) {
					memberMat[l][i] = duplicateIndex;
				}
			}
			l++;
		}
		return memberMat;
	}

	/**
	 * Given an N x 1 label vector with L unique entries this returns a L x N boolean matrix where
	 * entry [l][i] is true if and only if data point i belongs to the lth class (in numeric order).
	 *
	 * @param labels the labels for each data point.
	 *
	 * @return a L x N boolean matrix where entry [l][i] is true if and only if data point i belongs
	 * to the lth class (in numeric order).
	 */
	public static boolean[][] getClassMemberLogical(final int[] labels) {
		final Map<Integer, List<Integer>> labelMap = getClassRepresentation(labels);
		final boolean[][] memberMat = new boolean[labelMap.size()][labels.length];
		int l = 0;
		for (final List<Integer> members : labelMap.values()) {
			for (final int i : members) {
				memberMat[l][i] = true;
			}
			l++;
		}
		return memberMat;
	}

	/**
	 * Distributes the data set into F folds, each roughly representing the label distribution of
	 * the data set and - if possible - containing at least one point from each class.
	 *
	 * @param labels the labels for each data point.
	 * @param F the number of crossvalidation folds.
	 *
	 * @return a F x (N / F) matrix containing the data point indices for each fold. If the number
	 * of data points N is not divisible by F, some rows will contain duplicates.
	 */
	public static int[][] createCrossvalidationFolds(final int[] labels, int F) {
		// get the class-based representation
		final Map<Integer, List<Integer>> labelMap = getClassRepresentation(labels);
		// get the number of points for each fold
		int M = labels.length;
		int N_fold = (int) Math.ceil((double) M / F);
		int mod = M % F;
		// initialize the output matrix
		final int[][] foldMat = new int[F][];
		for (int f = 0; f < F; f++) {
			if (f < mod || mod == 0) {
				foldMat[f] = selectRandomly(labelMap, N_fold);
			} else {
				// if we are beyond the modulo, we have to select one data point less
				foldMat[f] = new int[N_fold];
				final int[] selected = selectRandomly(labelMap, N_fold - 1);
				System.arraycopy(selected, 0, foldMat[f], 0, selected.length);
				// add a duplicate at the end
				foldMat[f][N_fold - 1] = foldMat[f][N_fold - 2];
			}
		}
		return foldMat;
	}

	/**
	 * Selects N points, such that the label distribution is roughly maintained and at least 1 point
	 * for each label is contained in the selected set. The selected points are returned as an index
	 * vector.
	 *
	 * @param labels the labels for each data point.
	 * @param N the number of points that should be selected.
	 *
	 * @return an index vector identifying N points from the data set (starting at index 0), such
	 * that the label distribution is roughly maintained and at least 1 point for each label is
	 * contained in the selected set.
	 */
	public static int[] selectRandomly(final int[] labels, int N) {
		// get the class-based representation
		final Map<Integer, List<Integer>> labelMap = getClassRepresentation(labels);
		// call the actual selection method
		return selectRandomly(labelMap, N);
	}

	/**
	 * Selects N points, such that the label distribution is roughly maintained and at least 1 point
	 * for each label is contained in the selected set. Note that the second constrained is only
	 * possible if the number of selected points is at least as big as the number of classes. The
	 * selected points are returned as an index vector.
	 *
	 * @param labelMap a map of labels to data point indices that have the given label. The selected
	 * data points will be removed from this map!
	 * @param N the number of points that should be selected.
	 *
	 * @return an index vector identifying N points from the data set (starting at index 0), such
	 * that the label distribution is roughly maintained and at least 1 point for each label is
	 * contained in the selected set.
	 */
	public static int[] selectRandomly(final Map<Integer, List<Integer>> labelMap, final int N) {
		// compute the overall number of data points
		int M = 0;
		for (final List<Integer> pointsInClass : labelMap.values()) {
			M += pointsInClass.size();
		}
		// check the input and handle special cases
		if (N > M) {
			throw new IllegalArgumentException("The number of selected points can not be bigger than the number of available points!");
		}
		if (N < 0) {
			throw new IllegalArgumentException("The number of selected points can not be negative!");
		}
		if (N == 0) {
			return new int[0];
		}

		// get ranked order of labels according to class size.
		final int[] ranks = getLabelRanking(labelMap);
		// initialize the set of selected points
		final TreeSet<Integer> selected = new TreeSet<>();
		// initialize the random number generator
		final Random rand = new Random();
		if (M == N) {
			for (final List<Integer> pointsInClass : labelMap.values()) {
				selected.addAll(pointsInClass);
				pointsInClass.clear();
			}
		} else if (N <= labelMap.size()) {
			// if we have not enough points to represent each label, represent only the most
			// prominent ones
			for (int l = ranks.length - 1; l >= ranks.length - N; l--) {
				final List<Integer> pointsInClass = labelMap.get(ranks[l]);
				final int r = rand.nextInt(pointsInClass.size());
				final int i = pointsInClass.remove(r);
				selected.add(i);
			}
		} else {
			// if we have enough points, generate a distribution of selected points to classes, such
			// that at least one point of the least prominent classes is available
			final int[] N_class = new int[ranks.length];
			int sum = 0;
			for (int l = 0; l < ranks.length; l++) {
				final int M_class = labelMap.get(ranks[l]).size();
				if (M_class == 0) {
					continue;
				}
				N_class[l] = (int) Math.round((double) N / M * M_class);
				if (N_class[l] == 0) {
					N_class[l] = 1;
				}
				sum += N_class[l];
			}
			// if we have too many points selected now, take some away from the most prominent classes
			for (int l = ranks.length - 1; l >= 0 && sum > N; l--) {
				N_class[l]--;
				sum--;
			}
			// if we have too few points selected now, add some to the most prominent classes
			for (int l = ranks.length - 1; l >= 0 && sum < N; l--) {
				N_class[l]++;
				sum++;
			}

			// then actually select the points
			for (int l = 0; l < ranks.length; l++) {
				final List<Integer> pointsInClass = labelMap.get(ranks[l]);
				// select N_class data points from this class
				for (int n = 0; n < N_class[l]; n++) {
					final int r = rand.nextInt(pointsInClass.size());
					final int i = pointsInClass.remove(r);
					selected.add(i);
				}
			}

		}
		// transform the set of selected indices to an index vector.
		final int[] out = new int[selected.size()];
		int i = 0;
		for (final Integer idx : selected) {
			out[i++] = idx;
		}
		return out;
	}

	/**
	 * Transforms the given data set represented only as labels into a class-based representation,
	 * mapping labels to sets of data point indices that belong to the respective class.
	 *
	 * @param labels a label vector.
	 *
	 * @return a class-based representation of the data set, mapping labels to sets of data point
	 * indices that belong to the respective class.
	 */
	public static Map<Integer, List<Integer>> getClassRepresentation(final int[] labels) {
		final TreeMap<Integer, List<Integer>> map = new TreeMap<>();
		for (int i = 0; i < labels.length; i++) {
			List<Integer> pointsInClass = map.get(labels[i]);
			if (pointsInClass == null) {
				pointsInClass = new ArrayList<>();
				map.put(labels[i], pointsInClass);
			}
			pointsInClass.add(i);
		}
		return map;
	}

	/**
	 * Returns a vector containing the labels in ranked ascending order according to the number of
	 * points that have the given label.
	 *
	 * @param labelMap a map of labels to data point indices that have the given label.
	 *
	 * @return a vector containing the labels in ranked ascending order according to the number of
	 * points that have the given label.
	 */
	public static int[] getLabelRanking(final Map<Integer, List<Integer>> labelMap) {
		final ArrayList<PriorityTuple> tuples = new ArrayList<>(labelMap.size());
		for (final Entry<Integer, List<Integer>> labelEntry : labelMap.entrySet()) {
			tuples.add(new PriorityTuple(labelEntry.getKey(), labelEntry.getValue().size()));
		}
		Collections.sort(tuples);
		final int[] out = new int[tuples.size()];
		for (int l = 0; l < tuples.size(); l++) {
			out[l] = tuples.get(l).index;
		}
		return out;
	}

	private static class PriorityTuple implements Comparable<PriorityTuple> {

		public final int index;
		public final int priority;

		public PriorityTuple(int index, int priority) {
			this.index = index;
			this.priority = priority;
		}

		@Override
		public int compareTo(PriorityTuple o) {
			return Integer.compare(this.priority, o.priority);
		}

	}

}
