/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.comparators;

import de.citec.tcs.alignment.comparators.DerivableComparator;
import de.citec.tcs.alignment.comparators.EmptyGradient;
import de.citec.tcs.alignment.comparators.Gradient;
import de.citec.tcs.alignment.comparators.OperationType;
import de.citec.tcs.alignment.comparators.SingletonGradient;
import java.util.Arrays;

/**
 * Compares two indices i and j by retrieving an explicit cost value C[i][j] from a matrix.
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class SymmetricMatrixComparator implements DerivableComparator<Integer, Integer>, Copyable<SymmetricMatrixComparator> {

	private int m;
	private double[] params;

	public SymmetricMatrixComparator(int m) {
		this.m = m;
		this.params = new double[(m * (m + 1)) / 2];
		Arrays.fill(this.params, 1);
	}

	public SymmetricMatrixComparator(double[] params) {
		setParameters(params);
	}

	public SymmetricMatrixComparator(double[][] C) {
		setCostMatrix(C);
	}

	@Override
	public double compare(OperationType type, Integer i, Integer j) {
		switch (type) {
			case DELETION:
				j = null;
				break;
			case INSERTION:
				i = null;
				break;
		}
		if (i == null) {
			if (j == null) {
				return 0.;
			}
			return params[(m * (m - 1)) / 2 + j];
		}
		if (j == null) {
			return params[(m * (m - 1)) / 2 + i];
		}
		if (i >= m) {
			throw new IllegalArgumentException("Input out of range: " + i);
		}
		if (j >= m) {
			throw new IllegalArgumentException("Input out of range: " + j);
		}
		if (i.equals(j)) {
			return 0;
		} else if (i > j) {
			return params[(i * (i - 1)) / 2 + j];
		} else {
			return params[(j * (j - 1)) / 2 + i];
		}
	}

	@Override
	public boolean supports(OperationType type) {
		switch (type) {
			case DELETION:
			case INSERTION:
			case DELETIONREPLACEMENT:
			case INSERTIONREPLACEMENT:
			case REPLACEMENT:
				return true;
			default:
				return false;
		}
	}

	@Override
	public boolean hasCoherentReplacementCost() {
		return true;
	}

	@Override
	public Gradient computeGradient(OperationType type, Integer i, Integer j) {

		switch (type) {
			case DELETION:
				j = null;
				break;
			case INSERTION:
				i = null;
				break;
		}
		if (i == null) {
			if (j == null) {
				return new EmptyGradient();
			}
			return new SingletonGradient((m * (m - 1)) / 2 + j, 1);
		}
		if (j == null) {
			return new SingletonGradient((m * (m - 1)) / 2 + i, 1);
		}
		if (i >= m) {
			throw new IllegalArgumentException("Input out of range: " + i);
		}
		if (j >= m) {
			throw new IllegalArgumentException("Input out of range: " + j);
		}
		if (i.equals(j)) {
			return new EmptyGradient();
		} else if (i > j) {
			return new SingletonGradient((i * (i - 1)) / 2 + j, 1);
		} else {
			return new SingletonGradient((j * (j - 1)) / 2 + i, 1);
		}
	}

	@Override
	public int getNumberOfParameters() {
		return m * (m + 1) / 2;
	}

	public static double[][] toMatrix(double[] params) {
		final int m = alphabetSize(params.length);
		return toMatrix(params, m);
	}

	public static double[][] toMatrix(double[] params, int m) {
		final double[][] C = new double[m + 1][m + 1];
		for (int i = 1; i < m; i++) {
			for (int j = 0; j < i; j++) {
				C[i][j] = params[(i * (i - 1)) / 2 + j];
				C[j][i] = C[i][j];
			}
		}
		for (int i = 0; i < m; i++) {
			C[m][i] = params[(m * (m - 1)) / 2 + i];
			C[i][m] = C[m][i];
		}
		return C;
	}

	public static double[] fromMatrix(double[][] C) {
		final int m = C.length - 1;
		final double[] params = new double[(m * (m + 1)) / 2];
		for (int i = 1; i < m; i++) {
			System.arraycopy(C[i], 0, params, (i * (i - 1)) / 2, i);
		}
		System.arraycopy(C[m], 0, params, (m * (m - 1)) / 2, m);
		return params;
	}

	public final double[][] getCostMatrix() {
		return toMatrix(params, m);
	}

	public final void setCostMatrix(double[][] C) {
		this.m = C.length - 1;
		this.params = fromMatrix(C);
	}

	public static double[] normalizeParameters(double[] params) {
		// transform to cost matrix
		final double[][] C = toMatrix(params);
		// normalize
		normalizeCostMatrix(C);
		// transform back and return
		return fromMatrix(C);
	}

	public static double[][] normalizeCostMatrix(double[][] C) {
		final int m = C.length;
		for (int i = 0; i < m; i++) {
			if (C[i].length != m) {
				throw new IllegalArgumentException("Expected a square cost matrix as input!");
			}
		}
		// symmetrize and find minimum
		double min = 0;
		for (int i = 0; i < m; i++) {
			for (int j = i + 1; j < m; j++) {
				C[i][j] = 0.5 * (C[i][j] + C[j][i]);
				C[j][i] = C[i][j];
				if (C[i][j] < min) {
					min = C[i][j];
				}
			}
		}
		if (min < 0) {
			for (int i = 0; i < m; i++) {
				for (int j = 0; j < m; j++) {
					if (i == j) {
						// set diagonal to zero
						C[i][j] = 0;
					} else {
						// subtract minimum to avoid negative entries
						C[i][j] -= min;
					}
				}
			}
		} else {
			for (int i = 0; i < m; i++) {
				// set diagonal to zero
				C[i][i] = 0;
			}
		}
		// perform Floyd-Warshall algorithm to ensure triangular inequality
		for (int k = 0; k < m; k++) {
			for (int i = 0; i < m; i++) {
				if (i == k) {
					continue;
				}
				for (int j = i + 1; j < m; j++) {
					if (C[i][k] + C[k][j] < C[i][j]) {
						C[i][j] = C[i][k] + C[k][j];
						C[j][i] = C[i][j];
					}
				}
			}
		}
		return C;
	}

	@Override
	public double[] getParameters() {
		return params;
	}

	@Override
	public final void setParameters(double[] params) {
		this.m = alphabetSize(params.length);
		this.params = params;
	}

	public static int alphabetSize(int n) {
		int m = 1;
		int n_triang = 1;
		while (n_triang < n) {
			m++;
			n_triang += m;
		}
		if (n_triang != n) {
			throw new IllegalArgumentException("The given input " + n + " is not a triangle number!");
		}
		return m;
	}

	@Override
	public SymmetricMatrixComparator copy() {
		return new SymmetricMatrixComparator(params);
	}

}
