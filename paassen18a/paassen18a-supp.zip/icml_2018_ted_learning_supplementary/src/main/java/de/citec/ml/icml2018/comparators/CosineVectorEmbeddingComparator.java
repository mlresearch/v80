/* 
 * Tree Edit Distance Learning via Adaptive Symbol Embeddings
 * 
 * Copyright (C) 2018
 * Benjamin Paaßen
 * AG Machine Learning
 * Centre of Excellence Cognitive Interaction Technology (CITEC)
 * University of Bielefeld
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.citec.ml.icml2018.comparators;

import de.citec.tcs.alignment.comparators.DerivableComparator;
import de.citec.tcs.alignment.comparators.EmptyGradient;
import de.citec.tcs.alignment.comparators.Gradient;
import de.citec.tcs.alignment.comparators.OperationType;
import java.util.Arrays;
import java.util.Objects;
import java.util.Random;

/**
 * Computes the distance between two indices i and j via the Cosine distance on two vectors
 * &theta;<sub>i</sub> and &theta;<sub>j</sub>. These vectors &theta; form the parameters of the
 * model. In particular, the distance is defined as:
 *
 * d(i, j) = 0.5 * [1 - (&theta;<sub>i</sub><sup>T</sup> &middot; &theta;<sub>j</sub>) /
 * (norm(&theta;<sub>i</sub>) &middot; norm(&theta;<sub>j</sub>))]
 *
 * The deletion / insertion costs for this comparator are defined as the cosine distance between
 * the respective &theta; vector and the zero vector, which is always 0.5.
 *
 * @author Benjamin Paassen - bpaassen(at)techfak.uni-bielefeld.de
 */
public class CosineVectorEmbeddingComparator implements DerivableComparator<Integer, Integer>, Copyable<CosineVectorEmbeddingComparator> {

	/**
	 * The vector embedding for all indices.
	 */
	private double[][] Theta;
	/**
	 * The pre-computed similarity matrix.
	 */
	private double[][] S;
	/**
	 * The pre-computed norms.
	 */
	private double[] Z;
	/**
	 * The number of embedding dimensions.
	 */
	private int n;

	/**
	 * Initializes a CosineVectorEmbeddingComparator using a Gaussian random embedding.
	 *
	 * @param m the index range of this comparator, meaning that inputs from 0 to m-1 will be
	 * accepted.
	 * @param n the embedding dimension of this comparator.
	 */
	public CosineVectorEmbeddingComparator(int m, int n) {
		final double[][] Theta = new double[m][n];
		final Random rand = new Random();
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				Theta[i][j] = rand.nextGaussian();
			}
		}
		setTheta(Theta);
	}

	/**
	 * Initializes a VectorEmbeddingComparator with the given embedding &Theta;
	 *
	 * @param Theta an embedding matrix.
	 */
	public CosineVectorEmbeddingComparator(double[][] Theta) {
		setTheta(Theta);
	}

	/**
	 * Returns the vector embedding for all indices.
	 *
	 * @return the vector embedding for all indices.
	 */
	public double[][] getTheta() {
		return Theta;
	}

	/**
	 * Sets the vector embedding for all indices.
	 *
	 * @param Theta the vector embedding for all indices.
	 */
	public final void setTheta(double[][] Theta) {
		this.Theta = Theta;
		this.n = Theta[0].length;
		for (final double[] row : Theta) {
			if (row.length != n) {
				throw new IllegalArgumentException("Expected a consistent embedding dimension!");
			}
		}
		final int m = Theta.length;
		this.Z = new double[m];
		this.S = new double[m][m];
		for (int i = 0; i < m; i++) {
			this.Z[i] = VectorEmbeddingComparator.norm(Theta[i]);
			this.S[i][i] = 1;
			for (int j = i + 1; j < m; j++) {
				this.S[i][j] = CosineDistanceComparator.cosine_similarity(Theta[i], Theta[j]);
				this.S[j][i] = this.S[i][j];
			}
		}
	}

	@Override
	public double compare(OperationType type, Integer i, Integer j) {
		switch (type) {
			case DELETION:
				j = null;
				break;
			case INSERTION:
				i = null;
				break;
		}
		if (Objects.equals(i, j)) {
			return 0;
		}
		if (i == null || j == null) {
			return 0.5;
		}
		return 0.5 * (1 - S[i][j]);
	}

	@Override
	public boolean supports(OperationType type) {
		switch (type) {
			case DELETIONREPLACEMENT:
			case INSERTIONREPLACEMENT:
			case REPLACEMENT:
			case INSERTION:
			case DELETION:
				return true;
			default:
				return false;
		}
	}

	@Override
	public boolean hasCoherentReplacementCost() {
		return true;
	}
	private static final double TOL = 1E-3;

	/**
	 * Computes the gradient of the Cosine distance between Theta[i] and Theta[j] with respect
	 * to Theta. Let
	 *
	 * s(Theta[i], Theta[j]) = (Theta[i]<sup>T</sup> &middot; Theta[j]) / (|Theta[i]| &middot;
	 * |Theta[j]|)
	 * Then, the gradient with respect to Theta[i] is:
	 *
	 * &nabla;<sub>Theta[i]</sub> 0.5 * (1 - s(Theta[i], Theta[j]))
	 * = - (Theta[j] - s(Theta[i], Theta[j]) &middot; Theta[i] &middot; (|Theta[j]| / |Theta[i]|)) /
	 * (2 &middot; |Theta[i]| &middot; |Theta[j]|)
	 *
	 * Conversely, the gradient with respect to Theta[j] is:
	 *
	 * &nabla;<sub>Theta[j]</sub> 0.5 * (1 - s(Theta[i], Theta[j]))
	 * = - (Theta[i] - s(Theta[i], Theta[j]) &middot; Theta[j] &middot; (|Theta[i]| / |Theta[j]|)) /
	 * (2 &middot; |Theta[i]| &middot; |Theta[j]|)
	 *
	 * With respect to all other rows of Theta, the gradient is zero.
	 *
	 * @param type the operation type
	 * @param i the left index
	 * @param j the right index
	 *
	 * @return - (Theta[j] - s(Theta[i], Theta[j]) &middot; Theta[i] &middot; (|Theta[j]| /
	 * |Theta[i]|)) / (2 &middot; |Theta[i]| &middot; |Theta[j]|) for Theta[i] and
	 * - (Theta[i] - s(Theta[i], Theta[j]) &middot; Theta[j] &middot; (|Theta[i]| / |Theta[j]|)) /
	 * (2 &middot; |Theta[i]| &middot; |Theta[j]|) for Theta[j]
	 */
	@Override
	public Gradient computeGradient(OperationType type, Integer i, Integer j) {
		switch (type) {
			case DELETION:
				j = null;
				break;
			case INSERTION:
				i = null;
				break;
		}
		if (Objects.equals(i, j)) {
			return new EmptyGradient();
		}
		if (i == null || j == null || S[i][j] < -1 + TOL || S[i][j] > 1 - TOL) {
			return new EmptyGradient();
		}
		final double pre = -0.5 / (Z[i] * Z[j]);
		final double[] theta_i_grad = new double[n];
		for (int k = 0; k < n; k++) {
			theta_i_grad[k] = pre * (Theta[j][k] - S[i][j] * Z[j] / Z[i] * Theta[i][k]);
		}
		final double[] theta_j_grad = new double[n];
		for (int k = 0; k < n; k++) {
			theta_j_grad[k] = pre * (Theta[i][k] - S[i][j] * Z[i] / Z[j] * Theta[j][k]);
		}

		return new EmbeddingGradient(i, theta_i_grad, j, theta_j_grad);
	}

	@Override
	public CosineVectorEmbeddingComparator copy() {
		return new CosineVectorEmbeddingComparator(Theta);
	}

	public static class EmbeddingGradient implements Gradient {

		private final int i;
		private final double[] theta_i_grad;
		private final int j;
		private final double[] theta_j_grad;
		private final int n;
		int p = 0;

		public EmbeddingGradient(int i, double[] theta_i_grad, int j, double[] theta_j_grad) {
			if (theta_i_grad.length != theta_j_grad.length) {
				throw new IllegalArgumentException("Embedding dimension is inconsistent!");
			}
			this.n = theta_i_grad.length;
			this.i = i;
			this.theta_i_grad = theta_i_grad;
			this.j = j;
			this.theta_j_grad = theta_j_grad;
		}

		@Override
		public int currentParameterIndex() {
			if (p < n) {
				return i * n + p;
			} else {
				return j * n + (p - n);
			}
		}

		@Override
		public double currentValue() {
			if (p < n) {
				return theta_i_grad[p];
			} else {
				return theta_j_grad[p - n];
			}

		}

		@Override
		public void next() {
			p++;
		}

		@Override
		public boolean notEmpty() {
			return p < 2 * n;
		}

		@Override
		public String toString() {
			return "gradient w.r.t. Theta[" + i + "] : " + Arrays.toString(theta_i_grad) + 
					", gradient w.r.t. Theta[" + j + "] : " + Arrays.toString(theta_j_grad);
		}

	}

	@Override
	public int getNumberOfParameters() {
		return Theta.length * n;
	}

	@Override
	public double[] getParameters() {
		return VectorEmbeddingComparator.matrixToVector(Theta);
	}

	@Override
	public void setParameters(double[] params) {
		setTheta(VectorEmbeddingComparator.vectorToMatrix(params, this.Theta.length));
	}

	/**
	 * Returns the matrix of pairwise cosine similarities for the current embedding Theta.
	 *
	 * @return the matrix of pairwise cosine similarities for the current embedding Theta.
	 */
	public double[][] getSimilarityMatrix() {
		return S;
	}

	/**
	 * Returns the vector of norms for the current embedding Theta.
	 *
	 * @return the vector of norms for the current embedding Theta.
	 */
	public double[] getNorms() {
		return Z;
	}

}
