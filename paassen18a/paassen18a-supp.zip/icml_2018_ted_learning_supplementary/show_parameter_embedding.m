%% Tree Edit Distance Learning via Adaptive Symbol Embeddings
% 
% Copyright (C) 2018
% Benjamin Paaßen
% AG Machine Learning
% Centre of Excellence Cognitive Interaction Technology (CITEC)
% University of Bielefeld
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% This script displays the given embedding matrix Theta using a PCA
% if necessary.
function show_parameter_embedding(Theta, symbols)

[m, n] = size(Theta);

if(numel(symbols) ~= m || ~iscell(symbols))
    error('expected a symbol label for each embedded symbol');
end

Theta   = [Theta ; zeros(1, n)];
symbols = [symbols, {'-'}];

D = pdist2(Theta, Theta);

figure;
subplot(1, 2, 1);
if(n < 2)
    Theta = [Theta , zeros(m, 2 - n)];
elseif(n > 2)
    % do PCA
    [U, Lambda] = eig(Theta * Theta');
    lambda      = diag(Lambda);
    Theta       = U(:, end-1:end) * diag(sqrt(lambda(end-1:end)));
end
plot(Theta(:, 1), Theta(:, 2), 'ro', 'MarkerSize', 10);
text(Theta(:, 1) + 0.05 * mean(Theta(:, 1)), Theta(:, 2), symbols);
range  = 1.25 * (max(Theta(:, 2)) - min(Theta(:, 2)));
x_mean = 0.5 * (max(Theta(:, 1)) + min(Theta(:, 1)));
y_mean = 0.5 * (max(Theta(:, 2)) + min(Theta(:, 2)));
axis([x_mean - 0.5 * range, x_mean + 0.5 * range, y_mean - 0.5 * range, y_mean + 0.5 * range]);
subplot(1, 2, 2);
imagesc(D); colorbar;
xticks(1:numel(symbols));
xticklabels(symbols);
xtickangle(45);
yticks(1:numel(symbols));
yticklabels(symbols);

end