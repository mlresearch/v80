function [mrglvq_pseudo, knn_pseudo, svm_pseudo, good_pseudo, mrglvq, knn, svm, good, D_to_train, new_mrglvq_model] = evaluate_metric_learning_errors(comp, initial_params, learned_params, algo, score_algo, X, X_train, Y, test_log, mrglvq_model, K, sigma, lambda, param_fun)

m             = X.size();

% first compute the pseudo-edit distance, that is, the distance that would
% result if we take the edit script according to the default edit distance
% parameters and multiply that with the new parameters
default_comp = de.citec.ml.icml2018.comparators.CopyUtils.copy(comp);
default_comp.setParameters(initial_params);
algo.setComparator(default_comp);
comp.setParameters(learned_params);

try
    engine        = de.citec.ml.icml2018.gesl.PseudoEditDistanceEngine.fromAlignmentAlgorithm(algo, comp, X, X_train);
catch
try
    engine        = de.citec.ml.icml2018.gesl.PseudoEditDistanceEngine.fromCooptimalAlgorithm(algo, comp, X, X_train);
catch
try
    engine        = de.citec.ml.icml2018.gesl.PseudoEditDistanceEngine.fromTreeEditAlgorithm(algo, comp, X, X_train);
catch
    engine        = de.citec.ml.icml2018.gesl.PseudoEditDistanceEngine.fromTreeCooptimalAlgorithm(algo, comp, X, X_train);
end
end
end

engine.setReporter([]);
engine.setFull();
engine.calculate();
D_to_train    = engine.getDoubleResultMatrix();
% re-train mrglvq using the current prototypes as basis
new_mrglvq_model = de.citec.ml.mrglvq.MedianRelationalGLVQ.train(D_to_train(~test_log, :), Y(~test_log), mrglvq_model.getPrototypeIndices());
mrglvq_pseudo = mean(Y(test_log) ~= de.citec.ml.mrglvq.MedianRelationalGLVQ.classify(D_to_train(test_log, new_mrglvq_model.getPrototypeIndices() + 1), new_mrglvq_model));
% classify via knn
knn_pseudo    = mean(Y(test_log) ~= de.citec.ml.icml2018.lmnn.KNNClassifier.predict(D_to_train(test_log, :), Y(~test_log), K));
% re-train SVM
K_to_train_ny = ny_create(exp(-0.5 * D_to_train.^2 / sigma.^2), find(~test_log));
% we need to do eigenvalue correction via nystroem to ensure that the
% test-to-train distances are corrected as well
K_to_train_ny = ny_sim2ker(K_to_train_ny, 'clip');
K_SVM         = ny_reconstruct(K_to_train_ny, 1:m, find(~test_log));
svm_model     = svmtrain(double(Y(~test_log)), [(1:sum(~test_log))' K_SVM(~test_log, :)], '-t 4');
svm_pseudo    = mean(Y(test_log) ~= svmpredict(double(Y(test_log)), [((sum(~test_log)+1):m)' K_SVM(test_log, :)], svm_model));
% retrain a good classifier
good_model    = train_good_classifier_linprog(D_to_train(~test_log, :), Y(~test_log), lambda);
good_pseudo   = mean(Y(test_log) ~= predict_good_classifier(D_to_train(test_log, :), good_model));

% finally, compute the _actual_ edit distance according to the learned
% parameters
if(nargin >= 14 && ~isempty(param_fun))
    % it may be that we need to ensure metric properties for this part of
    % the evaluation.
    learned_params = param_fun(learned_params);
    comp.setParameters(learned_params);
end

score_algo.setComparator(comp);
try
    score_engine  = de.citec.tcs.alignment.ParallelProcessingEngine(score_algo, X, X_train);
catch
    score_engine  = de.citec.tcs.alignment.trees.TreeParallelProcessingEngine(score_algo, X, X_train);
end
score_engine.setReporter([]);
score_engine.setFull();
score_engine.calculate();
D_to_train    = score_engine.getDoubleResultMatrix();
% re-train mrglvq using the current prototypes as basis
new_mrglvq_model = de.citec.ml.mrglvq.MedianRelationalGLVQ.train(D_to_train(~test_log, :), Y(~test_log), mrglvq_model.getPrototypeIndices());
mrglvq        = mean(Y(test_log) ~= de.citec.ml.mrglvq.MedianRelationalGLVQ.classify(D_to_train(test_log, new_mrglvq_model.getPrototypeIndices() + 1), new_mrglvq_model));
% classify via knn
knn           = mean(Y(test_log) ~= de.citec.ml.icml2018.lmnn.KNNClassifier.predict(D_to_train(test_log, :), Y(~test_log), K));
% re-train SVM
K_to_train_ny = ny_create(exp(-0.5 * D_to_train.^2 / sigma.^2), find(~test_log));
% we need to do eigenvalue correction via nystroem to ensure that the
% test-to-train distances are corrected as well
K_to_train_ny = ny_sim2ker(K_to_train_ny, 'clip');
K_SVM         = ny_reconstruct(K_to_train_ny, 1:m, find(~test_log));
svm_model     = svmtrain(double(Y(~test_log)), [(1:sum(~test_log))' K_SVM(~test_log, :)], '-t 4');
svm           = mean(Y(test_log) ~= svmpredict(double(Y(test_log)), [((sum(~test_log)+1):m)' K_SVM(test_log, :)], svm_model));
% retrain a good classifier
good_model    = train_good_classifier_linprog(D_to_train(~test_log, :), Y(~test_log), lambda);
good          = mean(Y(test_log) ~= predict_good_classifier(D_to_train(test_log, :), good_model));

end

