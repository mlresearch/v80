%% Tree Edit Distance Learning via Adaptive Symbol Embeddings
% 
% Copyright (C) 2018
% Benjamin Paaßen
% AG Machine Learning
% Centre of Excellence Cognitive Interaction Technology (CITEC)
% University of Bielefeld
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
function [Y_pred, confidences] = predict_good_classifier(D, model)
% Predicts the label for n input data points based on their distances to m
% training data points and a model trained via train_good_classifier.m
%
% In particular, the prediction is made via
%
% argmax_l K * model.Alpha
%
% where K = 2 * exp(-D) - 1
%
% Parameters:
% D     - the n x m pairwise distance matrix between test and training data.
% model - a model trained via train_good_classifier.m
%
% Outputs:
% Y_pred - a n x 1 vector containing the predicted labels for each test
%          data point.
% confidences - a n x 1 containing confidences in the classification.

% check input
if(nargin < 1 || ~ismatrix(D))
    error('Expected a distance matrix as first argument!');
end

[n, m] = size(D);

if(nargin < 2 || ~isstruct(model) || size(model.Alpha, 1) ~= m)
    error('The given model does not fit the given distance matrix: The distance matrix has %d columns but model.Alpha has %d rows!', n, size(model.Alpha, 1));
end

% compute similarity matrix
K = 2 * exp(-D) - 1;

% make the prediction
raw_preds             = K * model.Alpha;
[confidences, Y_pred] = max(raw_preds, [], 2);
% if confidences are smaller than 0 (i.e. all classes claim that the point
% does not belong to them) we assign the last class label
Y_pred(confidences < 0) = numel(model.labels);
Y_pred                  = model.labels(Y_pred);
confidences             = abs(confidences);

end

