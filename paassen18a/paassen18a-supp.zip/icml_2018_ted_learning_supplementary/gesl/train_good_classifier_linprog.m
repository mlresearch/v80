%% Tree Edit Distance Learning via Adaptive Symbol Embeddings
% 
% Copyright (C) 2018
% Benjamin Paaßen
% AG Machine Learning
% Centre of Excellence Cognitive Interaction Technology (CITEC)
% University of Bielefeld
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
function model = train_good_classifier_linprog(D, Y, regul)
% Trains a 'good' classifier based on the theory of Balcan et al. (2008).
% In particular, this method uses the similarity function
%
% K(i, j) = 2 * exp(-D(i, j)) - 1
%
% as suggested by Bellet et al. (2012), and then solves the linear
% minimization problem
%
% min_alpha sum_i [1 - sum_j alpha(j) * Y(i) * K(i, j)]_+ + lambda * sum(abs(alpha))
%
% where i and j iterate over 1 to m, where m is the number of data points.
% lambda is a non-negative scalar regulating the sparsity of alpha.
% The resulting alpha is a linear separator in the space of similarities K,
% that is: the class label of a new point x can be determined via
%
% sign(sum_i alpha_i * K(x, x_i))
%
% Note that it is assumed here that Y is a binary label vector, i.e. -1 for
% the negative and +1 for the positive class. If this is a multi-class
% problem, this method returns L-1 classifiers in a one-vs-rest
% fashion, that is: for the lth classifier we regard all points with
% label l as +1 and all other points as -1.
%
% Note that this linear program actually requires 3*m variables, because we
% need 2*m variables to represent alpha for the L1 minimization and m slack
% variables too represent the hinge loss. Further, the linear program has m
% constraints with a dense constraint matrix A = [diag(Y) * [-K, K], eye(m)] and
% all variables need to be greater equal zero.
%
% For more details regarding 'good' classifiers in this regard, please
% refer to
%
% Bellet, A., Habrard, A., Sebban, M. (2012). Good edit similarity learning
% by loss minimization. Machine Learning, 89, 5-35.
% doi:10.1007/s10994-012-5293-8
%
% Parameters:
% D     - a m x m pairwise distance matrix between all m training data
%         points.
% Y     - a m x 1 vector containing the labels of all training data points.
% regul - a non-negative scalar determining the regularization strength.
%         For higher regul, a sparser alpha is obtained.
%
% Outputs:
% model - a struct containing two fields: labels, which contains the unique
%         labels that can be predicted, and Alpha, which contains the
%         linear separators.

% check the input

% check input
if(nargin < 1 || ~ismatrix(D) || size(D, 1) ~= size(D, 2))
    error('Expected square distance matrix as first argument!');
end

m = size(D, 1);

if(nargin < 2 || ~isvector(Y) || numel(Y) ~= m)
    error('Expected an %d-element label vector as second argument!', m);
end

if(nargin < 3 || isempty(regul))
    regul = 1E-5;
elseif(~isscalar(regul) || regul < 0)
    error('Expected a non-negative scalar as third argument!');
end

% extract unique labels
model.labels = sort(unique(Y));
L            = numel(model.labels);
if(L < 2)
    error('Expected at least two different labels!');
end

% initialize similarity matrix
K = 2*exp(-D) - 1;

% initialize classifiers.
model.Alpha  = zeros(m, L-1);

% options for lbfgs
options = struct( ...
  'GradObj', 'on', ...
  'GradConstr', false, ...
  'Display', 'off', ...
  'MaxIter', 400, ...
  'MaxFunEvals', 10000 ...
);

for l=1:L-1
    % generate the binary labels (-1, +1) for the current class
    Y_l = binary_labels(Y, model.labels(l));

    % train the classifier for this label via linprog
    % The linear program corresponding to our cost function is the
    % following:
    % min_{alpha^+, alpha^-, xi} sum_i xi_i + lambda * (alpha^+_i +
    % alpha^-_i)
    % subject to 1 - Y_l(i) * K(i, :) * (alpha^+ - alpha^-)' <= xi_i for
    % all i
    % and alpha^+, alpha^-, xi >= 0

    f  = [regul * ones(1, 2*m), ones(1, m)];
    A  = [bsxfun(@times, [-K, K], Y_l), -eye(m)];
    b  = -ones(m, 1);
    lb = zeros(3*m, 1);
    ub = inf(3*m, 1);
    
    vars = linprog(f, A, b, [], [], lb, ub);
    
    % we can reconstruct alpha by subtracting alpha^- from alpha^+
    model.Alpha(:, l) = vars(1:m) - vars(m+(1:m));
end

end

function Y_binary = binary_labels(Y, y)
    negative           = Y ~= y;
    Y_binary           = ones(numel(Y), 1);
    Y_binary(negative) = -1;
end