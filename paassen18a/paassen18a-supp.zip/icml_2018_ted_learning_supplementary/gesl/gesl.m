%% Tree Edit Distance Learning via Adaptive Symbol Embeddings
% 
% Copyright (C) 2018
% Benjamin Paaßen
% AG Machine Learning
% Centre of Excellence Cognitive Interaction Technology (CITEC)
% University of Bielefeld
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
function [params, err] = gesl(D, X, Y, algo, params, K, regul, param_fun)
% Learns a 'good' edit distance according to Bellet et al.s (2012)
% good edit similarity learning (GESL) algorithm. In particular, this
% method implements a simplified version which optimizes the cost function
%
% sum_i=1^m sum_k=1^K
%        [D_C(i, j_{i,k}^+)]_+
%      + [log(2) - D_C(i, j_{i,k}^-)]_+ ) + regul * frob(C)^2
% 
% where m is the number of data points, regul is a hyper-parameter between
% 0 and infinity, j_{i,k}^+ is the
% index of the k-th-closest point with the same label to i,
% j_{i,k}^- is the k-th-furthest point from i with a different label
% than i, and [ ]_+ denotes the hinge loss, i.e. [x]_+ = max(0, x).
% This cost function is minimized via lbfgs.
%
% For more details on GESL, please refer to
%
% Bellet, A., Habrard, A., Sebban, M. (2012). Good edit similarity learning
% by loss minimization. Machine Learning, 89, 5-35.
% doi:10.1007/s10994-012-5293-8
%
% Parameters:
% D           - the m x m matrix of initial pair between all training data
%               points.
% X           - an m-element java list containing the tree objects for
%               which the similarity learning should be performed.
% Y           - the m x 1 vector of labels for each data point.
% algo        - a java object which provides the function 'calculateAlignment'
%               to obtain an edit script between input trees, and
%               'getComparator' to retrieve a java object which provides
%               the function 'setParameters()'
%               to set the current parameters. Using this function should
%               also influence all the calculations made by the following
%               java objects. Further, the comparator must support the
%               'computeGradient' function.
% params      - the initial parameter settings.
% K           - (optional) a positive integer specifying how many neighbors
%               should be considered. 1 per default.
% regul       - (optional) a non-negative scalar value determining the
%               regularization strength.
% param_fun   - (optional) a function handle to post-process parameters
%               after a gradient step
%
% Outputs:
% params      - the metric parameters after applying GESL.
% err         - a 1 x 2 vector containing the error before and after metric
%               learning.

% check input
if(nargin < 1 || ~ismatrix(D) || size(D, 1) ~= size(D, 2))
    error('Expected square distance matrix as first argument!');
end

m = size(D, 1);

if(nargin < 2 || X.size() ~= m)
    error('Expected an %d-element list of trees as second argument!', m);
end

if(nargin < 3 || ~isvector(Y) || numel(Y) ~= m)
    error('Expected an %d-element label vector as third argument!', m);
end

if(nargin < 6 || isempty(K))
    K = 1;
elseif(~isscalar(K) || K < 1 || round(K) ~= K)
    error('Expected a positive integer as sixth argument!');
end

if(nargin < 7 || isempty(regul))
    regul = 1E-5;
elseif(~isscalar(regul) || regul < 0)
    error('Expected a non-negative scalar as seventh argument!');
end

if(nargin < 8)
    param_fun = [];
end

% set up gradient calculator
num_threads = 16;

try
    grad_calc = de.citec.ml.icml2018.gesl.GESLGradientCalculator.fromAlignmentAlgorithm(D, Y, algo, X, K, num_threads);
catch
try
    grad_calc = de.citec.ml.icml2018.gesl.GESLGradientCalculator.fromCooptimalAlgorithm(D, Y, algo, X, K, num_threads);
catch
try
    grad_calc = de.citec.ml.icml2018.gesl.GESLGradientCalculator.fromTreeEditAlgorithm(D, Y, algo, X, K, num_threads);
catch
    grad_calc = de.citec.ml.icml2018.gesl.GESLGradientCalculator.fromTreeEditCooptimalAlgorithm(D, Y, algo, X, K, num_threads);
end
end
end

grad_calc.setReporter([]);

comp = algo.getComparator();


% options for lbfgs
options = struct( ...
  'GradObj', 'on', ...
  'GradConstr', false, ...
  'Display', 'off', ...
  'MaxIter', 400, ...
  'MaxFunEvals', 10000 ...
);

% compute initial error
err    = inf(1, 2);
err(1) = gesl_error_and_gradient(params, comp, grad_calc, param_fun);

% optimize parameters using lbfgs
[new_params, current_err, status] = fminlbfgs(@(params) (gesl_error_and_gradient(params, comp, grad_calc, param_fun)), params, options);

if(isempty(current_err))
    warning('had to stop metric learning because fminlbfgs returned in an error state!');
    return;
end
if(~isempty(param_fun))
    params = param_fun(new_params);
else
    params = new_params;
end
err(2) = current_err;

end

function [err, grad] = gesl_error_and_gradient(params, comp, grad_calc, param_fun)

if(~isempty(param_fun))
    params = param_fun(params);
end

comp.setParameters(params);

err_and_grad = grad_calc.computeErrorAndGradient(comp);

err  = err_and_grad(1);
grad = err_and_grad(2:end);

end
