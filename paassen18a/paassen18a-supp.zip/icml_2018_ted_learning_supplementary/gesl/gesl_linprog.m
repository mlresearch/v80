%% Tree Edit Distance Learning via Adaptive Symbol Embeddings
% 
% Copyright (C) 2018
% Benjamin Paaßen
% AG Machine Learning
% Centre of Excellence Cognitive Interaction Technology (CITEC)
% University of Bielefeld
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
function [params, err] = gesl_linprog(D, X, Y, algo, n, K, regul)
% Learns a 'good' edit distance according to Bellet et al.s (2012)
% good edit similarity learning (GESL) algorithm. In particular, this
% method solves the linear program
%
% min_C ( sum_i=1^m sum_k=1^K
%        [D_C(i, j_{i,k}^+) - nu]_+
%      + [log(2) + nu - D_C(i, j_{i,k}^-)]_+ ) + regul * frob(C)
% subject to C >= 0, log(2) >= nu >= 0 and
% D_C(i, j_{i,k}^+) = sum(sum( C .* coopts(i, j_{i,k}^+) ) )
% D_C(i, j_{i,k}^-) = sum(sum( C .* coopts(i, j_{i,k}^-) ) )
% 
% where m is the number of data points, regul is a hyper-parameter between 0
% and infinity regulating the regularization strength, j_{i,k}^+ is the
% index of the k-th-closest point with the same label to i,
% j_{i,k}^- is the k-th-furthest point from i with a different label
% than i, and [ ]_+ denotes the hinge loss, i.e. [x]_+ = max(0, x).
% C are the metric parameters which are learned, i.e. a (n + 1) x (n + 1)
% matrix of pairwise replacement costs, including gap costs.
%
% Because C is assumed to be symmetric and have a zero diagonal, we only
% have to learn n * (n + 1) / 2 parameters. However, the linear program
% additionally needs the variable nu to represent the margin, and 2 * K * m
% slack variables to represent the hinge loss [ ]_+. Overall, the linear
% program has n * (n + 1) / 2 + 2 * K * m + 1 variables, 2 * K * m
% inequality constraints (one per slack variable), a lower bound of 0 for
% all variables, and an upper bound of log(2) for nu.
%
% For more details on GESL, please refer to
%
% Bellet, A., Habrard, A., Sebban, M. (2012). Good edit similarity learning
% by loss minimization. Machine Learning, 89, 5-35.
% doi:10.1007/s10994-012-5293-8
%
% Parameters:
% D           - the m x m matrix of initial pairwise edit distances between
%               all training data points.
% X           - an m-element java list containing the tree objects for
%               which the similarity learning should be performed.
% Y           - the m x 1 vector of labels for each data point.
% algo        - a java object which provides the function 'calculateAlignment'
%               to obtain an edit script between input trees, and
%               'getComparator' to retrieve a java object which provides
%               the function 'setParameters()'
%               to set the current parameters. Using this function should
%               also influence all the calculations made by the following
%               java objects. Further, the comparator must support the
%               'computeGradient' function.
% n           - a positive integer specifying the size of the alphabet.
% K           - (optional) a positive integer specifying how many neighbors
%               should be considered. 1 per default. Note that any
%               additional considered neighbor adds 2*m additional slack
%               variables and constraints to the linear program.
% regul       - (optional) a non-negative scalar value determining the
%               regularization strength. 1E-5 per default.
%
% Outputs:
% C           - the entries of the lower triangle of a (n + 1) x (n + 1)
%               matrix of replacement costs learned via GESL. The diagonal
%               of the matrix is set to zero and the upper triangle is
%               symmetric to the lower triangle.
% err         - a 1 x 2 vector containing the error before and after metric
%               learning.

% check input
if(nargin < 1 || ~ismatrix(D) || size(D, 1) ~= size(D, 2))
    error('Expected square distance matrix as first argument!');
end

m = size(D, 1);

if(nargin < 2 || X.size() ~= m)
    error('Expected an %d-element list of trees as second argument!', m);
end

if(nargin < 3 || ~isvector(Y) || numel(Y) ~= m)
    error('Expected an %d-element label vector as third argument!', m);
end

if(nargin < 5 || ~isscalar(n) || round(n) ~= n || n < 1)
    error('Expected a positive integer as fifth argument!');
end

if(nargin < 6 || isempty(K))
    K = 1;
elseif(~isscalar(K) || round(K) ~= K || K < 1)
    error('Expected a positive integer as sixth argument!');
end

if(nargin < 7 || isempty(regul))
    regul = 1E-5;
elseif(~isscalar(regul) || regul < 0)
    error('Expected a non-negative scalar as seventh argument!');
end

% set up the linear program for GESL
num_threads = 16;

try
    gesl = de.citec.ml.icml2018.gesl.GESLLinearProgram.fromAlignmentAlgorithm(D, Y, algo, X, n, K, num_threads);
catch
try
    gesl = de.citec.ml.icml2018.gesl.GESLLinearProgram.fromCooptimalAlgorithm(D, Y, algo, X, n, K, num_threads);
catch
try
    gesl = de.citec.ml.icml2018.gesl.GESLLinearProgram.fromTreeEditAlgorithm(D, Y, algo, X, n, K, num_threads);
catch
    gesl = de.citec.ml.icml2018.gesl.GESLLinearProgram.fromTreeEditCooptimalAlgorithm(D, Y, algo, X, n, K, num_threads);
end
end
end
num_vars = numel(gesl.f);
num_params = n * (n + 1) / 2;

A = sparse(double(gesl.A.i + 1), double(gesl.A.j + 1), gesl.A.v);

if(regul == 0)
    % apply linprog to solve the linear program
    [params, err] = linprog(gesl.f, A, gesl.b, [], [], gesl.lb, gesl.ub);
else
    % apply quadprog to solve the linear problem with regularization
    H = sparse(1:num_params, 1:num_params, repmat(regul, 1, num_params), num_vars, num_vars);
    [params, err] = quadprog(H, gesl.f, A, gesl.b, [], [], gesl.lb, gesl.ub);
end

% return only the metric parameters and not the slack variables
params     = params(1:num_params);

end