%% Tree Edit Distance Learning via Adaptive Symbol Embeddings
% 
% Copyright (C) 2018
% Benjamin Paaßen
% AG Machine Learning
% Centre of Excellence Cognitive Interaction Technology (CITEC)
% University of Bielefeld
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
function [ errs ] = gesl_regul_sweep( D, X, Y, test_log, algo, initial_params, n, K, lambda, reguls )
% Computes GESL for a range of regularization parameters and returns the
% goodness classification error on the pseudo edit distance for all of
% them.
%
% Parameters:
% D        - the initial m x m matrix of pairwise edit distances.
% X        - the m tree objects for training and test data.
% Y        - an m x 1 label vector for training and test data.
% test_log - a m x 1 logical specifying the test data
% algo     - an algorithm which returns alignments
% initial_params - the default parameter settings for the comparator used
%            by algo
% n        - the alphabet size
% K        - the number of neighbors to consider
% lambda   - the lambda parameter for the goodness classifier
% reguls   - all possible regul parameters

errs      = zeros(numel(reguls), 1);

comp   = algo.getComparator();

% subselect training data
X_train   = de.citec.tcs.utils.MatlabListInterface.selectFromList(X, ~test_log);

for b=1:numel(reguls)
    % re-set parameters
    comp.setParameters(initial_params);
    % perform GESL
    params = gesl_linprog(D(~test_log, ~test_log), X_train, Y(~test_log), algo, n, K, reguls(b) );
    % compute the pseudo-edit distance, that is, the distance that would
    % result if we take the edit script according to the default edit distance
    % parameters and multiply that with the new parameters
    default_comp = de.citec.ml.icml2018.comparators.CopyUtils.copy(comp);
    default_comp.setParameters(initial_params);
    algo.setComparator(default_comp);
    comp.setParameters(params);

    try
        engine        = de.citec.ml.icml2018.gesl.PseudoEditDistanceEngine.fromAlignmentAlgorithm(algo, comp, X, X_train);
    catch
        engine        = de.citec.ml.icml2018.gesl.PseudoEditDistanceEngine.fromTreeEditAlgorithm(algo, comp, X, X_train);
    end
    engine.setReporter([]);
    engine.setFull();
    engine.calculate();
    D_to_train    = engine.getDoubleResultMatrix();
    
    % train a goodness classifier on the training distances
    good_model       = train_good_classifier_linprog(D_to_train(~test_log, :), Y(~test_log), lambda);
    % evaluate the test error
    errs(b)          = mean(Y(test_log) ~= predict_good_classifier(D_to_train(test_log, :), good_model));

end

