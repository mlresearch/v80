% Linear Supervised Transfer Learning Toolbox 
% Copyright (C) 2017 - Benjamin Paassen, Alexander Schulz
% Machine Learning Research Group
% Center of Excellence Cognitive Interaction Technology (CITEC)
% Bielefeld University
% 
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, see <http://www.gnu.org/licenses/>.

function [FigHandle] = plot_2d_prototype_model(X, Y, W, Y_W, Omega, Fig, Y_pred)
% Plots a 2D prototype model with optional relevance projection.
%
% Let N be the number of data points and K be the number of prototypes.
%
% REQUIRED INPUT: 
%   X       ... An N x 2 matrix of data, where each row is one data vector.
%
% OPTIONAL INPUT:
%   Y       ... A N x 1 vector of labels, where Y(i) is the label for data
%               point X(i, :). Per default, the same class is assigned to
%               all data points.
%   W       ... A K x 2 matrix of prototypes, where each row is one
%               prototype vector. Per default, no prototypes are plotted
%   Y_W     ... A K x 1 vector of labels, where Y_W(k) is the
%               label for prototype W(k, :). Per default, all prototypes
%               are assumed to have the same label.
%   Omega   ... A 2 x 2 relevance matrix. This matrix can also
%               be higher-dimensional, in which case a discriminative
%               dimensionality reduction (a PCA on the relevance matrix) is
%               applied to handle higher-dimensional data.
%   Fig     ... either a string as the title for the new figure window or a
%               figure handle in which case no new figure window will be
%               created.
%   Y_pred  ... The predicted labels by the model. Per default, a nearest
%               neighbor classification is done in the space spanned by
%               Omega.
%
% OUTPUT:
%   FigHandle ... a Matlab handle (i.e. address) of the figure window

% check data
if(nargin < 1 || isempty(X) || ~ismatrix(X))
    error('expected a data matrix as first argument');
end

N = size(X, 1);
n = size(X, 2);

if(n == 1)
    X = [X, zeros(N, 1)];
end

% check labels
if(nargin >= 2 && ~isempty(Y))
    if(~isvector(Y) || numel(Y) ~= N)
        error('Expected one label per data point!');
    end
else
    Y = inf(N, 1);
end

% check prototypes
has_prototypes = nargin >= 3 && ~isempty(W);
if(has_prototypes)
    if(~ismatrix(W))
        error('Expected a prototype matrix as third argument!');
    end
    K = size(W, 1);
    if(size(W, 2) ~= n)
        error('Data and prototypes do not have the same dimensionality!');
    end
    if(n == 1)
        W = [W, zeros(K, 1)];
    end

    % check prototype labels
    if(nargin >= 4 && ~isempty(Y_W))
        if(~isvector(Y_W) || numel(Y_W) ~= K)
            error('Expected one label per prototype!');
        end
    else
        Y_W = inf(K, 1);
    end

    % prepare Omega to do relevance projection if necessary
    if(nargin >= 5 && ~isempty(Omega))
        % check size of omega
        if(~ismatrix(Omega) || size(Omega, 1) ~= n || size(Omega, 2) ~= n)
            error('Omega is not a square matrix acc. to data dimensionality!');
        end
        % check if relevance projection is required
        if(n > 2)
            Omega = extract_relevance_projection(Omega' * Omega, 2)';
        end
        % project data and prototypes according to Omega.
        X = X * Omega';
        W = W * Omega';
    else
        if(n > 2)
            error('Expected 2-dimensional input data (or relevance matrices for relevance projection)!');
        end
    end
elseif(n > 2)
    error('Expected 2-dimensional input data (or relevance matrices for relevance projection)!');
end

n = 2;

if nargin>=6 && ~isempty(Fig)
    if(ischar(Fig))
        FigHandle = figure('Name', Fig);
    else
        FigHandle = Fig;
        figure(Fig);
    end
else
    % if no FigTitle is given, use default title
    FigHandle = figure('Name', '2D data and prototypes');
end

if(nargin >=7 && ~isempty(Y_pred))
    if(~isvector(Y_pred) || numel(Y_pred) ~= N)
        error('Expected a %d x 1 vector of predicted labels as seventh argument!', N);
    end
elseif(has_prototypes)
    % infer the predicted labels automatically
    D         = pdist2(X, W);
    [~, idxs] = min(D, [], 2);
    Y_pred    = Y_W(idxs);
    clear D idxs;
else
    Y_pred = Y;
end

uniqueLabels = unique(Y);
L            = numel(uniqueLabels);

% Start the actual plotting

cm = tango_color_scheme;  % use the tango color map.

% plot data in 2D
% iterate over data classes
for l=1:L
    % get points in this classs
    inClass    = Y == uniqueLabels(l);
    % get the color index for the actual class
    c_actual   = mod(l - 1, size(cm, 1)) + 1;
    % iterate over the predicted classes for the points in this class
    [~, preds] = intersect(uniqueLabels, unique(Y_pred(inClass)));
    for l2=preds'
        lw = 1 + (l ~= l2);
        inPredClass = Y_pred == uniqueLabels(l2);
        % get the color index for the predicted class
        c_pred  = mod(l2 - 1, size(cm, 1)) + 1;
        % plot data in 2D
        plot( X(inClass & inPredClass,1), X(inClass & inPredClass,2), 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', 5, ...
            'MarkerEdgeColor', squeeze(cm(c_pred,3,:)), 'MarkerFaceColor', squeeze(cm(c_actual,1,:)), 'LineWidth', lw );
        hold on;
    end
    % plot prototypes for this class
    if(has_prototypes)
        inClass = Y_W == uniqueLabels(l);
        plot( W(inClass,1), W(inClass,2), 'LineStyle', 'none', 'Marker', 'd', 'MarkerSize', 10, 'MarkerEdgeColor', squeeze(cm(c_actual,3,:)), 'MarkerFaceColor', squeeze(cm(c_actual,1,:)), 'LineWidth', 2);
    end
end

if(has_prototypes)
    % plot remaining prototypes
    uniqueLabels = setdiff(unique(Y_W), uniqueLabels);
    for l=1:numel(uniqueLabels)  % iterate through data classes
        % compute color index
        c       = mod(L + l, size(cm, 1)) + 1;
        % plot prototypes in 2D
        inClass = Y_W == uniqueLabels(l);
        plot( W(inClass,1), W(inClass,2), 'LineStyle', 'none', 'Marker', 'd', 'MarkerSize', 10, 'MarkerEdgeColor', squeeze(cm(c,3,:)), 'MarkerFaceColor', squeeze(cm(c,1,:)), 'LineWidth', 2);
    end
end
hold off;

axis tight;  % set coordinate system to fit the data
axis equal;